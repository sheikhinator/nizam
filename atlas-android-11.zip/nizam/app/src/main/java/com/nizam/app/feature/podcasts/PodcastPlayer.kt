package com.nizam.app.feature.podcasts

import android.content.Context
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Podcast playback that keeps going with the screen off, with lock-screen and notification controls.
 * Media3's MediaSessionService gives us those for free; the UI drives the same player in-process.
 */
class PodcastService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(), true)   // duck other audio, speech tuning
            .setHandleAudioBecomingNoisy(true)                                 // pause when headphones are pulled
            .build()
        Playback.player = player
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        // swiping Atlas away shouldn't cut the episode off mid-sentence
        if (Playback.player?.isPlaying != true) { stopSelf() }
    }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null; Playback.player = null
        super.onDestroy()
    }
}

/** What the UI talks to: the live player, the episode on it, speed and the sleep timer. */
object Playback {
    var player: ExoPlayer? = null
    var current: Episode? = null
        private set
    var speed: Float = 1f
        private set
    var sleepMinutesLeft: Int = 0
        private set
    private var sleepJob: Job? = null

    fun start(c: Context, episode: Episode, store: PodcastStore) {
        ensure(c)
        val local = store.downloaded(episode)
        val item = MediaItem.Builder()
            .setUri(local?.toURI()?.toString() ?: episode.audio)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(episode.title).setArtist(episode.show)
                .setArtworkUri(episode.image?.let { android.net.Uri.parse(it) }).build())
            .build()
        player?.apply {
            setMediaItem(item); prepare()
            store.position(episode.id).takeIf { it > 5_000 }?.let { seekTo(it) }
            setPlaybackSpeed(speed)
            playWhenReady = true
        }
        current = episode
    }

    fun ensure(c: Context) {
        if (player == null) c.startForegroundService(Intent(c, PodcastService::class.java))
    }
    fun toggle() = player?.let { if (it.isPlaying) it.pause() else it.play() }
    fun skip(seconds: Int) = player?.let { it.seekTo((it.currentPosition + seconds * 1000L).coerceAtLeast(0)) }
    fun setSpeed(v: Float) { speed = v; player?.setPlaybackSpeed(v) }

    /** Sleep timer — pauses when it runs out, and cancels itself if you stop first. */
    fun sleep(minutes: Int, scope: CoroutineScope) {
        sleepJob?.cancel(); sleepMinutesLeft = minutes
        if (minutes <= 0) return
        sleepJob = scope.launch(Dispatchers.Main) {
            while (sleepMinutesLeft > 0) { delay(60_000); sleepMinutesLeft-- }
            player?.pause()
        }
    }
}
