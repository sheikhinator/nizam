package com.nizam.app.feature.browser

import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.nizam.app.AppContainer
import kotlinx.coroutines.launch

/**
 * A real browser inside Atlas. Pages can be handed straight to the Curator, so "read this and
 * add it to my notes" works without copy-paste.
 */
@Composable
fun BrowserScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("https://duckduckgo.com") }
    var address by remember { mutableStateOf(url) }
    var progress by remember { mutableStateOf(0) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun go(raw: String) {
        val target = raw.trim()
        url = when {
            target.startsWith("http://") || target.startsWith("https://") -> target
            target.contains(".") && !target.contains(" ") -> "https://$target"
            else -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(target, "UTF-8")
        }
        webView?.loadUrl(url)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Search or type a URL") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go(address) }),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { go(address) }) { Text("Go") }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedButton(onClick = { if (webView?.canGoBack() == true) webView?.goBack() }) { Text("←") }
            OutlinedButton(onClick = { if (webView?.canGoForward() == true) webView?.goForward() }) { Text(">") }
            OutlinedButton(onClick = { webView?.reload() }) { Text("⟳") }
            OutlinedButton(
                enabled = !busy,
                onClick = {
                    busy = true
                    val capturedUrl = webView?.url ?: url
                    val capturedTitle = webView?.title.orEmpty()
                    // evaluateJavascript is async: the text only exists inside this callback.
                    // Saving outside it stored the previous page, or nothing.
                    webView?.evaluateJavascript(
                        "(function(){return document.body.innerText.slice(0,12000)})()"
                    ) { raw ->
                        val text = raw.orEmpty()
                            .removeSurrounding("\"")
                            .replace("\\n", "\n").replace("\\t", " ").replace("\\\"", "\"")
                        pageText = text
                        scope.launch {
                            container.agentMemory.remember(
                                "Page the user shared: $capturedTitle ($capturedUrl)\n" + text.take(4000)
                            )
                            status = "Captured \"${capturedTitle.ifBlank { capturedUrl }}\" — ask the Curator about it."
                            busy = false
                        }
                    }
                }
            ) { Text("↗ Send to Curator") }
        }

        if (progress in 1..99) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth()
            )
        }
        status?.let {
            Text(
                it,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView?, request: WebResourceRequest?
                        ): Boolean = false
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress
                            view?.url?.let { address = it }
                        }
                    }
                    loadUrl(url)
                    webView = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}
