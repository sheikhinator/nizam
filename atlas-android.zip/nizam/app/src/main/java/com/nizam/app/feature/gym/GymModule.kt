package com.nizam.app.feature.gym

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import com.nizam.app.AppContainer
import com.nizam.app.core.AiPanel
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.prettyDate
import com.nizam.app.core.today
import com.nizam.app.core.vmFactory
import com.nizam.app.ui.theme.MonoNumber
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Entity(tableName = "workout_set")
data class WorkoutSet(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val localDate: String,
    val exercise: String,
    val weight: Double,
    val reps: Int,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cardio")
data class Cardio(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val localDate: String,
    val type: String,
    val minutes: Int,
    val distanceKm: Double = 0.0
)

@Dao
interface GymDao {
    @Query("SELECT * FROM workout_set ORDER BY localDate DESC, id DESC LIMIT 400")
    fun observeSets(): Flow<List<WorkoutSet>>

    @Query("SELECT * FROM workout_set WHERE exercise = :exercise ORDER BY id DESC LIMIT 20")
    fun observeForExercise(exercise: String): Flow<List<WorkoutSet>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(set: WorkoutSet)

    @Delete
    suspend fun delete(set: WorkoutSet)

    @Query("SELECT * FROM cardio ORDER BY localDate DESC LIMIT 60")
    fun observeCardio(): Flow<List<Cardio>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCardio(cardio: Cardio)
}

class GymRepository(private val dao: GymDao) {
    fun sets() = dao.observeSets()
    fun cardio() = dao.observeCardio()
    suspend fun addSet(exercise: String, weight: Double, reps: Int) {
        dao.insert(WorkoutSet(localDate = today(), exercise = exercise.trim(), weight = weight, reps = reps))
    }
    suspend fun remove(set: WorkoutSet) = dao.delete(set)
    suspend fun addCardio(type: String, minutes: Int, km: Double) {
        dao.insertCardio(Cardio(localDate = today(), type = type, minutes = minutes, distanceKm = km))
    }
}

val COMMON_EXERCISES = listOf(
    "Bench press", "Squat", "Deadlift", "Overhead press", "Barbell row",
    "Pull-up", "Dip", "Lat pulldown", "Leg press", "Bicep curl"
)

/** Epley estimate. */
fun oneRepMax(weight: Double, reps: Int): Double =
    if (reps <= 1) weight else weight * (1 + reps / 30.0)

class GymViewModel(private val repository: GymRepository) : ViewModel() {
    val sets: StateFlow<List<WorkoutSet>> = repository.sets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun addSet(exercise: String, weight: String, reps: String) {
        val w = weight.toDoubleOrNull() ?: return
        val r = reps.toIntOrNull() ?: return
        if (exercise.isBlank()) return
        viewModelScope.launch { repository.addSet(exercise, w, r) }
    }

    fun delete(set: WorkoutSet) = viewModelScope.launch { repository.remove(set) }
}

@Composable
fun GymScreen(container: AppContainer) {
    val vm: GymViewModel = viewModel(factory = vmFactory { GymViewModel(container.gymRepository) })
    val sets by vm.sets.collectAsState()

    var exercise by remember { mutableStateOf(COMMON_EXERCISES.first()) }
    var weight by remember { mutableStateOf("") }
    var reps by remember { mutableStateOf("") }
    var genPrompt by remember { mutableStateOf("") }
    var generating by remember { mutableStateOf(false) }
    var genStatus by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val todaySets = sets.filter { it.localDate == today() }
    val todayVolume = todaySets.sumOf { it.weight * it.reps }
    val lastForExercise = sets.firstOrNull { it.exercise == exercise && it.localDate != today() }
    val best = sets.filter { it.exercise == exercise }
        .maxByOrNull { oneRepMax(it.weight, it.reps) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ModuleTitle("🏋️  Gym", "Log sets as you go")

        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Text("Today", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text("${todaySets.size} sets · ${todayVolume.roundToInt()} kg volume", style = MonoNumber)
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            COMMON_EXERCISES.take(3).forEach { e ->
                FilterChip(selected = exercise == e, onClick = { exercise = e }, label = { Text(e) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            COMMON_EXERCISES.drop(3).take(3).forEach { e ->
                FilterChip(selected = exercise == e, onClick = { exercise = e }, label = { Text(e) })
            }
        }
        OutlinedTextField(
            value = exercise,
            onValueChange = { exercise = it },
            label = { Text("Exercise") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (lastForExercise != null) {
            Text(
                "Last time: ${lastForExercise.weight} kg × ${lastForExercise.reps}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (best != null) {
            Text(
                "Best e1RM: ${oneRepMax(best.weight, best.reps).roundToInt()} kg",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = weight, onValueChange = { weight = it },
                label = { Text("kg") }, singleLine = true, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = reps, onValueChange = { reps = it },
                label = { Text("Reps") }, singleLine = true, modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                vm.addSet(exercise, weight, reps)
                reps = ""
            }) { Text("Log set") }
            OutlinedButton(
                enabled = !generating,
                onClick = {
                    scope.launch {
                        generating = true; genStatus = null
                        genStatus = try {
                            container.moduleGenerator.generateWorkout(genPrompt)
                        } catch (e: Exception) { e.message }
                        generating = false
                    }
                }
            ) { Text(if (generating) "Writing…" else "✦  Write my session") }
            if (generating) CircularProgressIndicator()
        }
        OutlinedTextField(
            value = genPrompt, onValueChange = { genPrompt = it },
            label = { Text("Session focus (optional) — e.g. push day, 45 min") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        genStatus?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(12.dp))
        AiPanel(
            settings = container.settingsRepository,
            label = "Training help",
            contextPrompt = "Recent sets, newest first: " +
                sets.take(40).joinToString("; ") { "${'$'}{it.localDate} ${'$'}{it.exercise} ${'$'}{it.weight}kg x ${'$'}{it.reps}" },
            starterQuestion = "Look at my progression and tell me what to change.",
            system = "You are an experienced strength coach. Analyse the actual numbers given, name " +
                "specific problems, and give concrete programming changes. Flag anything that looks " +
                "like an injury risk."
        )
        Spacer(Modifier.height(12.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)

        LazyColumn(Modifier.fillMaxSize()) {
            items(sets, key = { it.id }) { set ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(set.exercise, style = MaterialTheme.typography.bodyLarge)
                        Text(prettyDate(set.localDate), style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${set.weight} × ${set.reps}", style = MonoNumber)
                    IconButton(onClick = { vm.delete(set) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete set")
                    }
                }
                Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
            }
        }
    }
}
