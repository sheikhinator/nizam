package com.nizam.app.ui.screens.me

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.feature.profile.Face
import com.nizam.app.feature.profile.FaceAvatar
import com.nizam.app.ui.nav.Routes
import com.nizam.app.ui.theme.DisplayFamily

/** Everything about you rather than your day: identity, progress, your town, your settings. */
@Composable
fun MeScreen(container: AppContainer, onOpen: (String) -> Unit) {
    val face by container.settingsRepository.face.collectAsState(initial = "2-1-0-2-0-0-0")
    val name by container.settingsRepository.displayName.collectAsState(initial = "")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp))
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().clickable(role = Role.Button) { onOpen(Routes.PROFILE) }
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                FaceAvatar(Face.decode(face), 72.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(name.ifBlank { "You" },
                        style = MaterialTheme.typography.headlineMedium.copy(fontFamily = DisplayFamily))
                    Text("Edit profile, avatar and stats", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Group("PROGRESS", listOf(
            Triple("🔬", "Understand yourself", Routes.UNDERSTAND),
            Triple("🧠", "Second brain & decisions", Routes.BRAIN),
            Triple("📅", "Timeline — any past day", Routes.DAY),
            Triple("🌿", "Growth — challenges, stacks, badges", Routes.GROWTH),
            Triple("🗓", "Plan my day", Routes.PLAN),
            Triple("🎯", "Missions", Routes.MISSIONS),
            Triple("🏘️", "Pixel Town", Routes.TOWN),
            Triple("🧭", "Character & reviews", Routes.SELF),
            Triple("📈", "Insights", Routes.INSIGHTS)
        ), onOpen)
        Group("CONTROL", listOf(
            Triple("🎙", "Voice — bubble, driving, journal, coach", Routes.VOICE),
            Triple("🧘", "Attention — digest, replies, wind-down", Routes.ATTENTION),
            Triple("🛡", "Focus shield", Routes.SHIELD),
            Triple("📱", "Phone control", Routes.PHONE),
            Triple("🔒", "Vault", Routes.VAULT),
            Triple("🔎", "Search everything", Routes.SEARCH),
            Triple("⚙️", "Settings", Routes.SETTINGS)
        ), onOpen)
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun Group(title: String, rows: List<Triple<String, String, String>>, onOpen: (String) -> Unit) {
    Spacer(Modifier.height(22.dp))
    Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(8.dp))
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
        Column {
            rows.forEach { (emoji, label, route) ->
                Row(
                    Modifier.fillMaxWidth().clickable(role = Role.Button) { onOpen(route) }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(emoji, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(14.dp))
                    Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Icon(Icons.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
