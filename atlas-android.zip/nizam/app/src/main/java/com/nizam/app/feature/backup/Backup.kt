package com.nizam.app.feature.backup

import android.content.Context
import android.net.Uri
import com.nizam.app.AppContainer
import com.nizam.app.data.db.NizamDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup copies the SQLite file itself rather than serialising 37 tables by hand. That means a
 * restore is byte-identical and can never miss a table someone forgot to add to an exporter.
 * The vault's encrypted blobs ride along, and stay encrypted.
 */
object Backup {

    private const val DB_NAME = "nizam.db"

    suspend fun export(context: Context, target: Uri, includeVault: Boolean): String =
        withContext(Dispatchers.IO) {
            // Force WAL contents into the main database file first, or the copy loses recent writes.
            runCatching {
                NizamDatabase.get(context).openHelper.writableDatabase
                    .query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
            }

            val dbFile = context.getDatabasePath(DB_NAME)
            var files = 0
            var bytes = 0L

            context.contentResolver.openOutputStream(target)?.use { out ->
                ZipOutputStream(out.buffered()).use { zip ->
                    listOf(dbFile, File(dbFile.path + "-wal"), File(dbFile.path + "-shm"))
                        .filter { it.exists() }
                        .forEach { file ->
                            zip.putNextEntry(ZipEntry("db/${file.name}"))
                            file.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                            files++; bytes += file.length()
                        }

                    val prefs = File(context.filesDir.parentFile, "datastore")
                    if (prefs.exists()) {
                        prefs.walkTopDown().filter { it.isFile }.forEach { file ->
                            zip.putNextEntry(ZipEntry("prefs/${file.name}"))
                            file.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                            files++; bytes += file.length()
                        }
                    }

                    if (includeVault) {
                        val vault = File(context.filesDir, "vault")
                        if (vault.exists()) {
                            vault.listFiles()?.forEach { file ->
                                zip.putNextEntry(ZipEntry("vault/${file.name}"))
                                file.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                                files++; bytes += file.length()
                            }
                        }
                    }
                }
            } ?: return@withContext "Could not write to that location."

            "Backed up $files files (${bytes / 1024} KB). Vault files stay encrypted inside the zip."
        }

    /**
     * Restore writes the files back and then the app must be killed — Room holds the old database
     * open, so continuing would write the old data back over the restored file.
     */
    suspend fun restore(context: Context, source: Uri): String = withContext(Dispatchers.IO) {
        val dbFile = context.getDatabasePath(DB_NAME)
        var restored = 0
        context.contentResolver.openInputStream(source)?.use { input ->
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    val target = when {
                        name.startsWith("db/") -> File(dbFile.parentFile, name.removePrefix("db/"))
                        name.startsWith("prefs/") ->
                            File(File(context.filesDir.parentFile, "datastore").apply { mkdirs() },
                                name.removePrefix("prefs/"))
                        name.startsWith("vault/") ->
                            File(File(context.filesDir, "vault").apply { mkdirs() },
                                name.removePrefix("vault/"))
                        else -> null
                    }
                    if (target != null && !entry.isDirectory) {
                        target.outputStream().use { zip.copyTo(it) }
                        restored++
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: return@withContext "Could not read that file."
        "Restored $restored files. Atlas will close now — reopen it to load the restored data."
    }

    /** CSV of one module, for spreadsheets. */
    suspend fun exportModuleCsv(
        context: Context,
        container: AppContainer,
        moduleKey: String,
        target: Uri
    ): String = withContext(Dispatchers.IO) {
        val spec = container.dynamicRepository.spec(moduleKey)
            ?: return@withContext "No module with that key."
        val entries = container.dynamicRepository.entries(moduleKey).first()
        val fields = spec.fields

        fun escape(value: String) = "\"" + value.replace("\"", "\"\"") + "\""

        context.contentResolver.openOutputStream(target)?.use { out ->
            out.bufferedWriter().use { writer ->
                writer.appendLine(
                    (listOf("date", "title") + fields.map { it.label }).joinToString(",") { escape(it) }
                )
                entries.forEach { entry ->
                    writer.appendLine(
                        (listOf(entry.localDate, entry.title) + fields.map { entry.value(it.key) })
                            .joinToString(",") { escape(it) }
                    )
                }
            }
        } ?: return@withContext "Could not write that file."
        "Exported ${entries.size} rows from ${spec.name}."
    }
}
