package com.nizam.app.feature.voice

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Voice both ways, using Android's own engines — no dependency, no network, no cost.
 */
class Speaker(context: Context) {
    private var ready = false
    private val tts = TextToSpeech(context.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
    }

    fun speak(text: String) {
        if (!ready || text.isBlank()) return
        runCatching {
            tts.language = Locale.getDefault()
            // Strip the action receipts — reading "✓ Task added" aloud is noise.
            val spoken = text.lines()
                .filterNot { it.trimStart().startsWith("✓") || it.trimStart().startsWith("✕") }
                .joinToString(" ")
                .take(1200)
            tts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "atlas")
        }
    }

    fun stop() = runCatching { tts.stop() }
    fun release() = runCatching { tts.stop(); tts.shutdown() }
}

fun speechIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Atlas")
}
