package com.nizam.app.ui.nav

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nizam.app.AppContainer
import com.nizam.app.feature.assistant.AssistantScreen
import com.nizam.app.feature.diary.DiaryScreen
import com.nizam.app.feature.diet.DietScreen
import com.nizam.app.feature.finance.FinanceScreen
import com.nizam.app.feature.gym.GymScreen
import com.nizam.app.feature.hadith.HadithScreen
import com.nizam.app.feature.learning.LearningScreen
import com.nizam.app.feature.library.LibraryScreen
import com.nizam.app.feature.learning.CoursesScreen
import com.nizam.app.feature.missions.MissionsScreen
import com.nizam.app.feature.news.NewsScreen
import com.nizam.app.feature.agent.AgentScreen
import com.nizam.app.feature.dynamic.DynamicModuleScreen
import com.nizam.app.feature.self.SelfScreen
import com.nizam.app.feature.toolkit.ToolkitScreen
import com.nizam.app.feature.vault.VaultScreen
import com.nizam.app.feature.progress.InsightsScreen
import com.nizam.app.feature.notes.NotesScreen
import com.nizam.app.feature.prayer.PrayerScreen
import com.nizam.app.feature.quotes.QuotesScreen
import com.nizam.app.feature.quran.QuranScreen
import com.nizam.app.feature.survival.SurvivalScreen
import com.nizam.app.ui.screens.modules.ModulesScreen
import com.nizam.app.ui.screens.search.SearchScreen
import com.nizam.app.ui.screens.settings.SettingsScreen
import com.nizam.app.ui.screens.tasks.TasksScreen
import com.nizam.app.ui.screens.today.TodayScreen

object Routes {
    const val TODAY = "today"
    const val MODULES = "modules"
    const val SEARCH = "search"
    const val SETTINGS = "settings"
    const val TASKS = "tasks"
    const val PRAYER = "prayer"
    const val FINANCE = "finance"
    const val DIET = "diet"
    const val GYM = "gym"
    const val NOTES = "notes"
    const val LIBRARY = "library"
    const val DIARY = "diary"
    const val QURAN = "quran"
    const val HADITH = "hadith"
    const val LEARNING = "learning"
    const val SURVIVAL = "survival"
    const val QUOTES = "quotes"
    const val COURSES = "courses"
    const val ASSISTANT = "assistant"
    const val NEWS = "news"
    const val INSIGHTS = "insights"
    const val MISSIONS = "missions"
    const val SELF = "self"
    const val AGENT = "agent"
    const val VAULT = "vault"
    const val TOOLKIT = "toolkit"
    const val DYNAMIC = "module/{key}"
    fun dynamic(key: String) = "module/$key"
}

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)

private val bottomItems = listOf(
    BottomItem(Routes.TODAY, "Today", Icons.Filled.Today),
    BottomItem(Routes.MISSIONS, "Missions", Icons.Filled.Flag),
    BottomItem(Routes.MODULES, "Modules", Icons.Filled.GridView),
    BottomItem(Routes.SELF, "Self", Icons.Filled.Face),
    BottomItem(Routes.ASSISTANT, "Assistant", Icons.Filled.AutoAwesome),
    BottomItem(Routes.SETTINGS, "Settings", Icons.Filled.Settings)
)

@Composable
fun NizamApp(container: AppContainer) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                bottomItems.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute == item.route,
                        onClick = {
                            if (currentRoute != item.route) {
                                navController.navigate(item.route) {
                                    popUpTo(Routes.TODAY) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.TODAY,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.TODAY) {
                TodayScreen(container = container, onOpen = { navController.navigate(it) })
            }
            composable(Routes.MODULES) {
                ModulesScreen(container = container, onOpen = { navController.navigate(it) })
            }
            composable(Routes.SEARCH) { SearchScreen(container) }
            composable(Routes.SETTINGS) { SettingsScreen(container) }
            composable(Routes.TASKS) { TasksScreen(container) }
            composable(Routes.PRAYER) { PrayerScreen(container) }
            composable(Routes.FINANCE) { FinanceScreen(container) }
            composable(Routes.DIET) { DietScreen(container) }
            composable(Routes.GYM) { GymScreen(container) }
            composable(Routes.NOTES) { NotesScreen(container) }
            composable(Routes.LIBRARY) { LibraryScreen(container) }
            composable(Routes.DIARY) { DiaryScreen(container) }
            composable(Routes.QURAN) { QuranScreen(container) }
            composable(Routes.HADITH) { HadithScreen(container) }
            composable(Routes.LEARNING) { LearningScreen(container) }
            composable(Routes.SURVIVAL) { SurvivalScreen(container) }
            composable(Routes.QUOTES) { QuotesScreen(container) }
            composable(Routes.COURSES) { CoursesScreen(container) }
            composable(Routes.ASSISTANT) { AssistantScreen(container) }
            composable(Routes.NEWS) { NewsScreen(container) }
            composable(Routes.INSIGHTS) { InsightsScreen(container) }
            composable(Routes.MISSIONS) { MissionsScreen(container) }
            composable(Routes.SELF) { SelfScreen(container) }
            composable(Routes.AGENT) { AgentScreen(container) }
            composable(Routes.VAULT) { VaultScreen(container) }
            composable(Routes.TOOLKIT) { ToolkitScreen(container) }
            composable(
                route = Routes.DYNAMIC,
                arguments = listOf(androidx.navigation.navArgument("key") {
                    type = androidx.navigation.NavType.StringType
                })
            ) { entry ->
                DynamicModuleScreen(container, entry.arguments?.getString("key").orEmpty())
            }
        }
    }
}
