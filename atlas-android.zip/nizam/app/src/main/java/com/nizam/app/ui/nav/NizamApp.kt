package com.nizam.app.ui.nav

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nizam.app.AppContainer
import com.nizam.app.feature.agent.CuratorScreen
import com.nizam.app.feature.browser.BrowserScreen
import com.nizam.app.feature.council.CouncilScreen
import com.nizam.app.feature.profile.ProfileScreen
import com.nizam.app.feature.town.TownScreen
import com.nizam.app.ui.screens.me.MeScreen
import com.nizam.app.feature.insight.UnderstandScreen
import com.nizam.app.feature.brain.BrainScreen
import com.nizam.app.feature.brain.DayScreen
import com.nizam.app.feature.shield.ShieldScreen
import com.nizam.app.feature.planner.PlannerScreen
import com.nizam.app.feature.language.LanguageScreen
import com.nizam.app.feature.scan.ScanScreen
import com.nizam.app.feature.growth.GrowthScreen
import com.nizam.app.feature.presence.DrivingScreen
import com.nizam.app.feature.attention.AttentionScreen
import com.nizam.app.feature.cinema.CinemaNav
import com.nizam.app.feature.mind.MindScreen
import com.nizam.app.feature.daily.DailyScreen
import com.nizam.app.feature.platform.PlatformScreen
import com.nizam.app.feature.wellbeing.CalmScreen
import com.nizam.app.feature.body.BedsideScreen
import com.nizam.app.feature.commit.CommitScreen
import com.nizam.app.feature.body.FlipFocusScreen
import com.nizam.app.feature.body.RepCounterScreen
import com.nizam.app.feature.body.SmartWakeScreen
import com.nizam.app.feature.body.SnapPlateScreen
import com.nizam.app.feature.body.VoiceCoachScreen
import com.nizam.app.feature.wellbeing.FutureYouScreen
import com.nizam.app.feature.wellbeing.PauseSettingsScreen
import com.nizam.app.feature.wellbeing.ReframeScreen
import com.nizam.app.feature.memory.MemoryScreen
import com.nizam.app.feature.cinema.CinemaScreen
import com.nizam.app.feature.cinema.FilmScreen
import com.nizam.app.feature.cinema.PlayerScreen
import com.nizam.app.feature.presence.RehearsalScreen
import com.nizam.app.feature.presence.VoiceHubScreen
import com.nizam.app.feature.presence.VoiceJournalScreen
import com.nizam.app.feature.phone.PhoneControlScreen
import com.nizam.app.feature.diary.DiaryScreen
import com.nizam.app.feature.diet.DietScreen
import com.nizam.app.feature.finance.FinanceScreen
import com.nizam.app.feature.gym.GymScreen
import com.nizam.app.feature.hadith.HadithScreen
import com.nizam.app.feature.learning.LearningScreen
import com.nizam.app.feature.library.LibraryScreen
import com.nizam.app.feature.learning.CoursesScreen
import com.nizam.app.feature.missions.MissionsScreen
import com.nizam.app.feature.news.NewsScreen
import com.nizam.app.feature.dynamic.DynamicModuleScreen
import com.nizam.app.feature.dynamic.ModuleSettingsScreen
import com.nizam.app.feature.self.SelfScreen
import com.nizam.app.feature.toolkit.ToolkitScreen
import com.nizam.app.feature.vault.VaultScreen
import com.nizam.app.feature.progress.InsightsScreen
import com.nizam.app.feature.notes.NotesScreen
import com.nizam.app.feature.prayer.PrayerScreen
import com.nizam.app.feature.quotes.QuotesScreen
import com.nizam.app.feature.quran.QuranScreen
import com.nizam.app.feature.survival.SurvivalScreen
import com.nizam.app.ui.screens.modules.ModulesScreen
import com.nizam.app.ui.screens.search.SearchScreen
import com.nizam.app.ui.screens.settings.SettingsScreen
import com.nizam.app.ui.screens.tasks.TasksScreen
import com.nizam.app.ui.screens.today.TodayScreen

object Routes {
    const val TODAY = "today"
    const val MODULES = "modules"
    const val SEARCH = "search"
    const val SETTINGS = "settings"
    const val TASKS = "tasks"
    const val PRAYER = "prayer"
    const val FINANCE = "finance"
    const val DIET = "diet"
    const val GYM = "gym"
    const val NOTES = "notes"
    const val LIBRARY = "library"
    const val DIARY = "diary"
    const val QURAN = "quran"
    const val HADITH = "hadith"
    const val LEARNING = "learning"
    const val SURVIVAL = "survival"
    const val QUOTES = "quotes"
    const val COURSES = "courses"
    const val ASSISTANT = "assistant"
    const val BROWSER = "browser"
    const val PHONE = "phone"
    const val COUNCIL = "council"
    const val PROFILE = "profile"
    const val TOWN = "town"
    const val ME = "me"
    const val UNDERSTAND = "understand"
    const val BRAIN = "brain"
    const val DAY = "day"
    const val SHIELD = "shield"
    const val PLAN = "plan"
    const val LANGUAGE = "language"
    const val SCAN = "scan"
    const val GROWTH = "growth"
    const val VOICE = "voice"
    const val DRIVE = "drive"
    const val VOICE_JOURNAL = "voicejournal"
    const val REHEARSE = "rehearse"
    const val ATTENTION = "attention"
    const val CINEMA = "cinema"
    const val FILM = "film"
    const val PLAYER = "player"
    const val MIND = "mind"
    const val MEMORY = "memory"
    const val DAILY = "daily"
    const val TOOLS = "tools"
    const val PAUSE = "pause"
    const val CALM = "calm"
    const val FUTURE = "future"
    const val REFRAME = "reframe"
    const val REPS = "reps"
    const val PLATE = "plate"
    const val COACH = "coach"
    const val FLIP = "flip"
    const val BEDSIDE = "bedside"
    const val WAKE = "smartwake"
    const val COMMIT = "commit"
    const val NEWS = "news"
    const val INSIGHTS = "insights"
    const val MISSIONS = "missions"
    const val SELF = "self"
    const val AGENT = "agent"
    const val VAULT = "vault"
    const val TOOLKIT = "toolkit"
    const val DYNAMIC = "module/{key}"
    const val MODULE_SETTINGS = "module-settings/{key}"
    fun moduleSettings(key: String) = "module-settings/$key"
    fun dynamic(key: String) = "module/$key"
}

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)

private val bottomItems = listOf(
    BottomItem(Routes.TODAY, "Today", Icons.Filled.Today),
    BottomItem(Routes.MODULES, "Life", Icons.Filled.GridView),
    BottomItem(Routes.COUNCIL, "Council", Icons.Filled.Groups),
    BottomItem(Routes.CINEMA, "Cinema", Icons.Filled.Movie),
    BottomItem(Routes.ASSISTANT, "Curator", Icons.Filled.AutoAwesome),
    BottomItem(Routes.ME, "Me", Icons.Filled.Person)
)

@Composable
fun NizamApp(container: AppContainer, startOnCurator: Boolean = false) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val tabRoutes = bottomItems.map { it.route }.toSet()
    val onSubScreen = currentRoute != null && currentRoute !in tabRoutes

    Scaffold(
        topBar = {
            if (onSubScreen && currentRoute != Routes.PLAYER && currentRoute != Routes.BEDSIDE) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 4.dp, end = 12.dp, top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = {
                        navController.navigate(Routes.TODAY) {
                            popUpTo(Routes.TODAY) { inclusive = false }
                            launchSingleTop = true
                        }
                    }) {
                        Icon(Icons.Filled.Today, contentDescription = "Back to today")
                    }
                }
            }
        },
        bottomBar = {
            if (currentRoute != Routes.PLAYER && currentRoute != Routes.BEDSIDE) {
            NavigationBar {
                bottomItems.forEach { item ->
                    NavigationBarItem(
                        alwaysShowLabel = false,
                        selected = currentRoute == item.route,
                        onClick = {
                            if (currentRoute != item.route) {
                                navController.navigate(item.route) {
                                    popUpTo(Routes.TODAY) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = if (startOnCurator) Routes.ASSISTANT else Routes.TODAY,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.TODAY) {
                TodayScreen(container = container, onOpen = { navController.navigate(it) })
            }
            composable(Routes.MODULES) {
                ModulesScreen(container = container, onOpen = { navController.navigate(it) })
            }
            composable(Routes.SEARCH) { SearchScreen(container) }
            composable(Routes.SETTINGS) { SettingsScreen(container) { navController.navigate(it) } }
            composable(Routes.TASKS) { TasksScreen(container) }
            composable(Routes.PRAYER) { PrayerScreen(container) }
            composable(Routes.FINANCE) { FinanceScreen(container) }
            composable(Routes.DIET) { DietScreen(container) }
            composable(Routes.GYM) { GymScreen(container) }
            composable(Routes.NOTES) { NotesScreen(container) }
            composable(Routes.LIBRARY) { LibraryScreen(container) }
            composable(Routes.DIARY) { DiaryScreen(container) }
            composable(Routes.QURAN) { QuranScreen(container) }
            composable(Routes.HADITH) { HadithScreen(container) }
            composable(Routes.LEARNING) { LearningScreen(container) }
            composable(Routes.SURVIVAL) { SurvivalScreen(container) }
            composable(Routes.QUOTES) { QuotesScreen(container) }
            composable(Routes.COURSES) { CoursesScreen(container) }
            composable(Routes.ASSISTANT) { CuratorScreen(container) }
            composable(Routes.BROWSER) { BrowserScreen(container) }
            composable(Routes.PHONE) { PhoneControlScreen(container) }
            composable(Routes.COUNCIL) { CouncilScreen(container) }
            composable(Routes.PROFILE) { ProfileScreen(container) }
            composable(Routes.TOWN) { TownScreen(container) }
            composable(Routes.UNDERSTAND) { UnderstandScreen(container) }
            composable(Routes.BRAIN) { BrainScreen(container) }
            composable(Routes.DAY) { DayScreen(container) }
            composable(Routes.SHIELD) { ShieldScreen() }
            composable(Routes.PLAN) { PlannerScreen(container) }
            composable(Routes.LANGUAGE) { LanguageScreen(container) }
            composable(Routes.SCAN) { ScanScreen(container) }
            composable(Routes.GROWTH) { GrowthScreen(container) }
            composable(Routes.VOICE) { VoiceHubScreen(container) { navController.navigate(it) } }
            composable(Routes.DRIVE) { DrivingScreen(container) }
            composable(Routes.VOICE_JOURNAL) { VoiceJournalScreen(container) }
            composable(Routes.REHEARSE) { RehearsalScreen(container) }
            composable(Routes.ATTENTION) { AttentionScreen(container) }
            composable(Routes.CINEMA) {
                CinemaScreen(
                    onFilm = { CinemaNav.filmId = it; navController.navigate(Routes.FILM) },
                    onPlay = { navController.navigate(Routes.PLAYER) }
                )
            }
            composable(Routes.FILM) {
                FilmScreen(
                    onFilm = { CinemaNav.filmId = it; navController.navigate(Routes.FILM) },
                    onPlay = { navController.navigate(Routes.PLAYER) }
                )
            }
            composable(Routes.PLAYER) { PlayerScreen() }
            composable(Routes.MIND) { MindScreen(container) }
            composable(Routes.MEMORY) { MemoryScreen(container) }
            composable(Routes.DAILY) { DailyScreen(container) }
            composable(Routes.TOOLS) { PlatformScreen(container) }
            composable(Routes.PAUSE) { PauseSettingsScreen() }
            composable(Routes.CALM) { CalmScreen() }
            composable(Routes.FUTURE) { FutureYouScreen(container) }
            composable(Routes.REFRAME) { ReframeScreen(container) }
            composable(Routes.REPS) { RepCounterScreen(container) }
            composable(Routes.PLATE) { SnapPlateScreen(container) }
            composable(Routes.COACH) { VoiceCoachScreen(container) }
            composable(Routes.FLIP) { FlipFocusScreen() }
            composable(Routes.BEDSIDE) { BedsideScreen(container) { navController.popBackStack() } }
            composable(Routes.WAKE) { SmartWakeScreen() }
            composable(Routes.COMMIT) { CommitScreen(container) }
            composable(Routes.ME) { MeScreen(container) { navController.navigate(it) } }
            composable(Routes.NEWS) { NewsScreen(container) }
            composable(Routes.INSIGHTS) { InsightsScreen(container) }
            composable(Routes.MISSIONS) { MissionsScreen(container) }
            composable(Routes.SELF) { SelfScreen(container) }
            composable(Routes.AGENT) { CuratorScreen(container) }
            composable(Routes.VAULT) { VaultScreen(container) }
            composable(Routes.TOOLKIT) { ToolkitScreen(container) }
            composable(
                route = Routes.DYNAMIC,
                arguments = listOf(androidx.navigation.navArgument("key") {
                    type = androidx.navigation.NavType.StringType
                })
            ) { entry ->
                DynamicModuleScreen(
                    container = container,
                    moduleKey = entry.arguments?.getString("key").orEmpty(),
                    onSettings = { navController.navigate(Routes.moduleSettings(it)) }
                )
            }
            composable(
                route = Routes.MODULE_SETTINGS,
                arguments = listOf(androidx.navigation.navArgument("key") {
                    type = androidx.navigation.NavType.StringType
                })
            ) { entry ->
                ModuleSettingsScreen(
                    container = container,
                    moduleKey = entry.arguments?.getString("key").orEmpty(),
                    onDeleted = {
                        navController.navigate(Routes.MODULES) {
                            popUpTo(Routes.MODULES) { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}
