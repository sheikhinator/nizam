package com.nizam.app.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: androidx.datastore.core.DataStore<Preferences> by preferencesDataStore(name = "nizam_settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

class SettingsRepository(private val context: Context) {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val currencyKey = stringPreferencesKey("currency")
    private val latKey = doublePreferencesKey("latitude")
    private val lngKey = doublePreferencesKey("longitude")
    private val methodKey = stringPreferencesKey("prayer_method")
    private val hanafiKey = booleanPreferencesKey("hanafi_asr")
    private val hadithKeyKey = stringPreferencesKey("hadith_api_key")
    private val geminiKeyKey = stringPreferencesKey("gemini_api_key")
    private val geminiModelKey = stringPreferencesKey("gemini_model")
    private val nameKey = stringPreferencesKey("display_name")
    private val focusKey = stringPreferencesKey("focus_areas")
    private val kcalKey = intPreferencesKey("kcal_target")
    private val waterKey = intPreferencesKey("water_target")
    private val onboardedKey = booleanPreferencesKey("onboarded")
    private val providerKey = stringPreferencesKey("ai_provider")
    private val openRouterKeyKey = stringPreferencesKey("openrouter_key")
    private val openRouterModelKey = stringPreferencesKey("openrouter_model")
    private val pinKey = stringPreferencesKey("app_pin")
    private val biometricKey = booleanPreferencesKey("biometric_lock")
    private val sectionOrderKey = stringPreferencesKey("home_section_order")
    private val accentKey = stringPreferencesKey("accent_hex")
    private val customPaletteKey = stringPreferencesKey("custom_palette")
    private val notifyKey = booleanPreferencesKey("notifications_on")

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        when (prefs[themeKey]) {
            "LIGHT" -> ThemeMode.LIGHT
            "DARK" -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
    }

    val currency: Flow<String> = context.dataStore.data.map { it[currencyKey] ?: "PKR" }
    val latitude: Flow<Double> = context.dataStore.data.map { it[latKey] ?: 31.5204 }
    val longitude: Flow<Double> = context.dataStore.data.map { it[lngKey] ?: 74.3587 }
    val prayerMethod: Flow<String> = context.dataStore.data.map { it[methodKey] ?: "KARACHI" }
    val hanafiAsr: Flow<Boolean> = context.dataStore.data.map { it[hanafiKey] ?: true }
    val hadithApiKey: Flow<String> = context.dataStore.data.map { it[hadithKeyKey] ?: "" }
    val geminiApiKey: Flow<String> = context.dataStore.data.map { it[geminiKeyKey] ?: "" }
    // "gemini-flash-latest" is an alias Google repoints at the current Flash model, so this keeps
    // working when model names change.
    val geminiModel: Flow<String> = context.dataStore.data.map { it[geminiModelKey] ?: "gemini-flash-latest" }
    val displayName: Flow<String> = context.dataStore.data.map { it[nameKey] ?: "" }
    val focusAreas: Flow<String> = context.dataStore.data.map { it[focusKey] ?: "" }
    val kcalTarget: Flow<Int> = context.dataStore.data.map { it[kcalKey] ?: 2200 }
    val waterTarget: Flow<Int> = context.dataStore.data.map { it[waterKey] ?: 3000 }
    val onboarded: Flow<Boolean> = context.dataStore.data.map { it[onboardedKey] ?: false }
    val aiProvider: Flow<String> = context.dataStore.data.map { it[providerKey] ?: "GEMINI" }
    val openRouterKey: Flow<String> = context.dataStore.data.map { it[openRouterKeyKey] ?: "" }
    val openRouterModel: Flow<String> = context.dataStore.data.map { it[openRouterModelKey] ?: "deepseek/deepseek-chat-v3.1:free" }
    val appPin: Flow<String> = context.dataStore.data.map { it[pinKey] ?: "" }
    val biometricLock: Flow<Boolean> = context.dataStore.data.map { it[biometricKey] ?: false }
    val homeSectionOrder: Flow<List<String>> = context.dataStore.data.map { prefs ->
        prefs[sectionOrderKey]?.split(",")?.filter { it.isNotBlank() } ?: DEFAULT_SECTIONS
    }
    val accentHex: Flow<String> = context.dataStore.data.map { it[accentKey] ?: "" }
    val customPalette: Flow<String> = context.dataStore.data.map { it[customPaletteKey] ?: "" }
    val notificationsOn: Flow<Boolean> = context.dataStore.data.map { it[notifyKey] ?: false }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }
    suspend fun setCurrency(code: String) {
        context.dataStore.edit { it[currencyKey] = code }
    }
    suspend fun setLocation(lat: Double, lng: Double) {
        context.dataStore.edit {
            it[latKey] = lat
            it[lngKey] = lng
        }
    }
    suspend fun setPrayerMethod(method: String) {
        context.dataStore.edit { it[methodKey] = method }
    }
    suspend fun setHanafiAsr(value: Boolean) {
        context.dataStore.edit { it[hanafiKey] = value }
    }
    suspend fun setHadithApiKey(key: String) {
        context.dataStore.edit { it[hadithKeyKey] = key.trim() }
    }
    suspend fun setGeminiApiKey(key: String) {
        context.dataStore.edit { it[geminiKeyKey] = key.trim() }
    }
    suspend fun setGeminiModel(model: String) {
        context.dataStore.edit { it[geminiModelKey] = model.trim() }
    }
    suspend fun setTargets(kcal: Int, waterMl: Int) {
        context.dataStore.edit {
            it[kcalKey] = kcal
            it[waterKey] = waterMl
        }
    }
    suspend fun completeOnboarding(name: String, kcal: Int, waterMl: Int, focus: String) {
        context.dataStore.edit {
            it[nameKey] = name.trim()
            it[kcalKey] = kcal
            it[waterKey] = waterMl
            it[focusKey] = focus
            it[onboardedKey] = true
        }
    }
    suspend fun setProvider(provider: String) {
        context.dataStore.edit { it[providerKey] = provider }
    }
    suspend fun setOpenRouterKey(key: String) {
        context.dataStore.edit { it[openRouterKeyKey] = key.trim() }
    }
    suspend fun setOpenRouterModel(model: String) {
        context.dataStore.edit { it[openRouterModelKey] = model.trim() }
    }
    suspend fun setPin(pin: String) {
        context.dataStore.edit { it[pinKey] = pin.trim() }
    }
    suspend fun setBiometricLock(enabled: Boolean) {
        context.dataStore.edit { it[biometricKey] = enabled }
    }
    suspend fun setSectionOrder(order: List<String>) {
        context.dataStore.edit { it[sectionOrderKey] = order.joinToString(",") }
    }
    suspend fun setAccent(hex: String) {
        context.dataStore.edit { it[accentKey] = hex.trim() }
    }
    suspend fun setCustomPalette(json: String) {
        context.dataStore.edit { it[customPaletteKey] = json }
    }
    suspend fun setNotifications(enabled: Boolean) {
        context.dataStore.edit { it[notifyKey] = enabled }
    }
    suspend fun resetOnboarding() {
        context.dataStore.edit { it[onboardedKey] = false }
    }

    companion object {
        val DEFAULT_SECTIONS = listOf(
            "MISSIONS", "PRAYER", "COURSE", "TASKS", "HABITS", "DIET",
            "GYM", "FINANCE", "LEARNING", "SELF", "NEWS"
        )
    }
}
