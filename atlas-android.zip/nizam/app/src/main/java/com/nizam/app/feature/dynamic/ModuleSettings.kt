package com.nizam.app.feature.dynamic

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import kotlinx.coroutines.launch

private val EMOJI_CHOICES = listOf(
    "✨", "🌙", "⏱️", "🤝", "🗂️", "🔁", "🏅", "📿", "📍", "🍲", "💡", "🔤", "📦", "🔧",
    "🎬", "🤲", "🚴", "🎧", "🧪", "🌱", "🧿", "🗺️", "🪙", "🎨", "🧩", "⚡", "🔥", "🫀"
)

private val COLOUR_CHOICES = listOf(
    "#4FA694", "#E0603A", "#5B6BA8", "#B57F4A", "#8A4F6B", "#6E8E4E",
    "#C9A227", "#7A5BA8", "#3E7C8A", "#A85D3C", "#6B7280", "#2F7A66"
)

@Composable
fun ModuleSettingsScreen(container: AppContainer, moduleKey: String, onDeleted: () -> Unit) {
    val scope = rememberCoroutineScope()
    val specs by container.dynamicRepository.allSpecs().collectAsState(initial = emptyList())
    val spec = specs.firstOrNull { it.key == moduleKey }

    if (spec == null) {
        Text("Module not found", modifier = Modifier.padding(20.dp))
        return
    }

    var name by remember(spec.key) { mutableStateOf(spec.name) }
    var tagline by remember(spec.key) { mutableStateOf(spec.tagline) }
    var emoji by remember(spec.key) { mutableStateOf(spec.emoji) }
    var colour by remember(spec.key) { mutableStateOf(spec.colorHex) }
    var enabled by remember(spec.key) { mutableStateOf(spec.enabled) }
    var confirmDelete by remember(spec.key) { mutableStateOf(false) }
    var confirmClear by remember(spec.key) { mutableStateOf(false) }
    var status by remember(spec.key) { mutableStateOf<String?>(null) }

    fun save() {
        scope.launch {
            container.dynamicRepository.updateSpec(
                spec.copy(
                    name = name.trim().ifBlank { spec.name },
                    tagline = tagline.trim(),
                    emoji = emoji,
                    colorHex = colour,
                    enabled = enabled
                )
            )
            status = "Saved"
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        ModuleTitle("$emoji  ${spec.name}", "Module settings")

        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = tagline, onValueChange = { tagline = it },
            label = { Text("Tagline") }, modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(14.dp))
        Text("Icon", style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        EMOJI_CHOICES.chunked(7).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { option ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = if (emoji == option) parseColour(colour, MaterialTheme.colorScheme.primary)
                            .copy(alpha = 0.22f)
                        else MaterialTheme.colorScheme.surface,
                        modifier = Modifier.clickable { emoji = option }
                    ) {
                        Text(option, modifier = Modifier.padding(10.dp),
                            style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("Colour", style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        COLOUR_CHOICES.chunked(6).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { hex ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = parseColour(hex, MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .width(44.dp).height(32.dp)
                            .clickable { colour = hex }
                    ) {
                        if (colour == hex) {
                            Text("✓", modifier = Modifier.padding(6.dp),
                                style = MaterialTheme.typography.titleMedium)
                        } else Text("")
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = enabled, onCheckedChange = { enabled = it })
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Show in Modules", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "Hiding keeps your entries — it just takes the tile off the grid.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { save() }) { Text("Save changes") }
            OutlinedButton(onClick = {
                scope.launch {
                    val ordered = specs.sortedBy { it.sortIndex }.toMutableList()
                    val index = ordered.indexOfFirst { it.key == spec.key }
                    if (index > 0) {
                        val item = ordered.removeAt(index)
                        ordered.add(index - 1, item)
                        container.dynamicRepository.reorder(ordered)
                        status = "Moved up"
                    }
                }
            }) { Text("↑  Move up") }
        }

        status?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary)
        }

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        Text("Fields", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        spec.fields.forEach { field ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(field.label, style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f))
                Text(field.type, style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            "To change fields, ask the Curator to build a new version — it designs the schema.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        if (!confirmClear) {
            OutlinedButton(onClick = { confirmClear = true }) { Text("Clear all entries") }
        } else {
            Text("Delete every entry in ${spec.name}? The module stays.",
                style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    scope.launch {
                        container.dynamicRepository.clearEntries(spec)
                        confirmClear = false; status = "Entries cleared"
                    }
                }) { Text("Clear them") }
                OutlinedButton(onClick = { confirmClear = false }) { Text("Cancel") }
            }
        }

        Spacer(Modifier.height(12.dp))
        if (!confirmDelete) {
            Text(
                "delete this module",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.clickable { confirmDelete = true }
            )
        } else {
            Text(
                "Delete ${spec.name} and everything in it? This cannot be undone.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    scope.launch {
                        container.dynamicRepository.deleteModule(spec)
                        onDeleted()
                    }
                }) { Text("Delete it") }
                OutlinedButton(onClick = { confirmDelete = false }) { Text("Keep it") }
            }
        }
        Spacer(Modifier.height(60.dp))
    }
}
