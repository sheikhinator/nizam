package com.nizam.app.feature.agent

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.Tones
import com.nizam.app.feature.voice.Speaker
import com.nizam.app.feature.voice.speechIntent
import com.nizam.app.ui.theme.DisplayFamily
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun CuratorScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val turns by container.agentMemory.turns().collectAsState(initial = emptyList())
    val suggestions by container.curatorRepository.active().collectAsState(initial = emptyList())

    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var useWeb by remember { mutableStateOf(false) }
    var speakBack by remember { mutableStateOf(false) }
    var autoApprove by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<List<Pair<String, JSONObject>>>(emptyList()) }
    var lastSteps by remember { mutableStateOf<List<AgentLoop.Step>>(emptyList()) }

    val speaker = remember { Speaker(context) }
    DisposableEffect(Unit) { onDispose { speaker.release() } }

    val listener = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) draft = spoken
        }
    }

    fun send(message: String) {
        if (message.isBlank()) return
        scope.launch {
            busy = true
            container.agentMemory.addTurn(true, message)
            draft = ""
            val outcome = runCatching {
                container.agentLoop.run(message, useWeb, autoApprove)
            }.getOrElse { e ->
                AgentLoop.Outcome("That failed: ${e.message}", emptyList())
            }
            lastSteps = outcome.steps
            pending = outcome.pendingApproval
            val body = buildString {
                append(outcome.reply)
                if (outcome.steps.isNotEmpty()) {
                    append("\n\n")
                    append(outcome.steps.joinToString("\n") {
                        (if (it.ok) "✓ " else "✕ ") + it.summary
                    })
                }
            }
            container.agentMemory.addTurn(false, body)
            if (speakBack) speaker.speak(outcome.reply)
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ModuleTitle("✦  Curator", "Your agent — it can act, search the web, and speak")

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = useWeb, onClick = { useWeb = !useWeb }, label = { Text("🌐 Web") })
            FilterChip(selected = speakBack, onClick = {
                speakBack = !speakBack; if (!speakBack) speaker.stop()
            }, label = { Text("🔊 Voice") })
            FilterChip(selected = autoApprove, onClick = { autoApprove = !autoApprove },
                label = { Text("⚡ Auto") })
            if (turns.isNotEmpty()) {
                FilterChip(selected = false, onClick = {
                    scope.launch { container.agentMemory.clearChat() }
                }, label = { Text("Clear") })
            }
        }

        if (pending.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Needs your approval", style = MaterialTheme.typography.titleMedium)
                    pending.forEach { (name, args) ->
                        Text("• $name ${args.toString().take(90)}",
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            scope.launch {
                                val done = pending.map { (name, args) ->
                                    val r = Actions.run(container, name, args)
                                    (if (r.ok) "✓ " else "✕ ") + r.summary
                                }
                                container.agentMemory.addTurn(false, done.joinToString("\n"))
                                pending = emptyList()
                            }
                        }) { Text("Approve") }
                        OutlinedButton(onClick = { pending = emptyList() }) { Text("Cancel") }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        LazyColumn(Modifier.weight(1f)) {
            if (turns.isEmpty()) {
                item {
                    suggestions.take(3).forEach { s ->
                        val tones = Tones.forKey(s.moduleKey)
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = tones.tone.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        ) {
                            Row(Modifier.padding(14.dp)) {
                                Text(s.emoji, style = MaterialTheme.typography.titleLarge)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(s.title, style = MaterialTheme.typography.titleMedium)
                                    Text(s.body, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    listOf(
                        "Build me a module to track my bike's fuel",
                        "What should I do today?",
                        "Make the theme deep blue and gold",
                        "Search the web for a good beginner Arabic course"
                    ).forEach { idea ->
                        Text(
                            "→  $idea",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { send(idea) }.padding(vertical = 8.dp)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            busy = true
                            runCatching { container.curatorRepository.refreshSuggestions() }
                            busy = false
                        }
                    }) { Text("🔄  Refresh suggestions") }
                }
            }

            items(turns, key = { it.id }) { turn ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = if (turn.fromUser) MaterialTheme.colorScheme.surfaceVariant
                    else MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                ) {
                    Text(turn.text, style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(13.dp))
                }
            }
            if (busy) {
                item {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator()
                        Spacer(Modifier.width(12.dp))
                        Text("Working…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = { listener.launch(speechIntent()) }) { Text("🎙") }
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(
                value = draft, onValueChange = { draft = it },
                label = { Text("Tell Atlas what to do") },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(enabled = !busy, onClick = { send(draft) }) { Text("Send") }
        }
    }
}
