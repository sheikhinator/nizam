package com.nizam.app.feature.agent

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.Tones
import com.nizam.app.feature.voice.Speaker
import com.nizam.app.feature.voice.speechIntent
import com.nizam.app.ui.theme.DisplayFamily
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun CuratorScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val turns by container.agentMemory.turns().collectAsState(initial = emptyList())
    val suggestions by container.curatorRepository.active().collectAsState(initial = emptyList())

    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var useWeb by remember { mutableStateOf(false) }
    var speakBack by remember { mutableStateOf(false) }
    var autoApprove by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<List<Pair<String, JSONObject>>>(emptyList()) }
    var lastSteps by remember { mutableStateOf<List<AgentLoop.Step>>(emptyList()) }

    val speaker = remember { Speaker(context) }
    DisposableEffect(Unit) { onDispose { speaker.release() } }

    val listener = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) draft = spoken
        }
    }

    fun send(message: String) {
        if (message.isBlank()) return
        scope.launch {
            busy = true
            container.agentMemory.addTurn(true, message)
            draft = ""
            val outcome = runCatching {
                container.agentLoop.run(message, useWeb, autoApprove)
            }.getOrElse { e ->
                AgentLoop.Outcome("That failed: ${e.message}", emptyList())
            }
            lastSteps = outcome.steps
            pending = outcome.pendingApproval
            // The model sometimes narrates an action it never took ("Settings opened.") — catch it.
            val claimed = Regex(
                "\\b(opened|opening|done|set|sent|called|calling|added|created|logged|deleted|playing)\\b",
                RegexOption.IGNORE_CASE
            ).containsMatchIn(outcome.reply)
            val unbacked = claimed && outcome.steps.isEmpty() && outcome.pendingApproval.isEmpty()
            val body = buildString {
                append(outcome.reply)
                if (unbacked) append("\n\n⚠ No action was actually run — try asking again more directly.")
                if (outcome.steps.isNotEmpty()) {
                    append("\n\n")
                    append(outcome.steps.joinToString("\n") {
                        (if (it.ok) "✓ " else "✕ ") + it.summary
                    })
                }
            }
            container.agentMemory.addTurn(false, body)
            if (speakBack) speaker.speak(outcome.reply)
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 18.dp)) {
        ModuleTitle("✦  Curator", "Your agent — it can act, search the web, and speak")

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = useWeb, onClick = { useWeb = !useWeb }, label = { Text("🌐 Web") })
            FilterChip(selected = speakBack, onClick = {
                speakBack = !speakBack; if (!speakBack) speaker.stop()
            }, label = { Text("🔊 Voice") })
            FilterChip(selected = autoApprove, onClick = { autoApprove = !autoApprove },
                label = { Text("⚡ Auto") })
            if (turns.isNotEmpty()) {
                FilterChip(selected = false, onClick = {
                    scope.launch { container.agentMemory.clearChat() }
                }, label = { Text("Clear") })
            }
        }

        if (pending.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Needs your approval", style = MaterialTheme.typography.titleMedium)
                    pending.forEach { (name, args) ->
                        Text("• $name ${args.toString().take(90)}",
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            scope.launch {
                                val done = pending.map { (name, args) ->
                                    val r = Actions.run(container, name, args)
                                    (if (r.ok) "✓ " else "✕ ") + r.summary
                                }
                                container.agentMemory.addTurn(false, done.joinToString("\n"))
                                pending = emptyList()
                            }
                        }) { Text("Approve") }
                        OutlinedButton(onClick = { pending = emptyList() }) { Text("Cancel") }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        LazyColumn(Modifier.weight(1f)) {
            if (turns.isEmpty()) {
                item {
                    suggestions.take(3).forEach { s ->
                        val tones = Tones.forKey(s.moduleKey)
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = tones.tone.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        ) {
                            Row(Modifier.padding(14.dp)) {
                                Text(s.emoji, style = MaterialTheme.typography.titleLarge)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(s.title, style = MaterialTheme.typography.titleMedium)
                                    Text(s.body, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    listOf(
                        "Build me a module to track my bike's fuel",
                        "What should I do today?",
                        "Make the theme deep blue and gold",
                        "Search the web for a good beginner Arabic course"
                    ).forEach { idea ->
                        Text(
                            "✦  $idea",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { send(idea) }.padding(vertical = 8.dp)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            busy = true
                            runCatching { container.curatorRepository.refreshSuggestions() }
                            busy = false
                        }
                    }) { Text("🔄  Refresh suggestions") }
                }
            }

            items(turns, key = { it.id }) { turn ->
                if (turn.fromUser) {
                    com.nizam.app.feature.council.UserBubble(turn.text)
                } else {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                        androidx.compose.foundation.layout.Box(
                            Modifier.size(34.dp).background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                                androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) { Text("✦", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Atlas", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(4.dp))
                            androidx.compose.foundation.layout.Box(
                                Modifier
                                    .background(
                                        MaterialTheme.colorScheme.surface,
                                        androidx.compose.foundation.shape.RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)
                                    )
                                    .padding(horizontal = 14.dp, vertical = 11.dp)
                            ) { Text(turn.text, style = MaterialTheme.typography.bodyLarge) }
                        }
                    }
                }
            }
            if (busy) {
                item {
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.padding(start = 44.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        com.nizam.app.feature.council.TypingDots(MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text("Atlas is working…", style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp)
                .background(MaterialTheme.colorScheme.surface, androidx.compose.foundation.shape.RoundedCornerShape(28.dp))
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.foundation.layout.Box(
                Modifier.size(40.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, androidx.compose.foundation.shape.CircleShape)
                    .clickable { listener.launch(speechIntent()) },
                contentAlignment = Alignment.Center
            ) { Text("🎙", style = MaterialTheme.typography.titleMedium) }
            androidx.compose.foundation.layout.Box(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                if (draft.isEmpty()) Text("Tell Atlas what to do…", style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                androidx.compose.foundation.text.BasicTextField(
                    value = draft, onValueChange = { draft = it }, maxLines = 5,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            val canSend = draft.isNotBlank() && !busy
            androidx.compose.foundation.layout.Box(
                Modifier.size(40.dp)
                    .background(
                        if (canSend) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        androidx.compose.foundation.shape.CircleShape
                    )
                    .clickable(enabled = canSend) { send(draft) },
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.Icon(
                    androidx.compose.material.icons.Icons.Filled.ArrowUpward, contentDescription = "Send",
                    tint = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
