package com.nizam.app.net

import com.nizam.app.data.prefs.SettingsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

/**
 * One entry point for every AI call in the app.
 *
 * Handles the two things that actually break AI features in practice:
 *  - transient overload (HTTP 429/503/500) → exponential backoff and retry
 *  - a specific model being unavailable → fall through a chain of alternatives
 *
 * Supports Google Gemini and OpenRouter. OpenRouter's `openrouter/free` router picks a working
 * free model per request, which is the most reliable zero-cost option.
 */
object Ai {

    class MissingKeyException(message: String) : Exception(message)

    enum class Provider { GEMINI, OPENROUTER }

    private const val MAX_ATTEMPTS = 4

    /** Fallbacks tried in order when the chosen model is unavailable. */
    private val geminiChain = listOf("gemini-flash-latest", "gemini-3.8-flash", "gemini-3.7-flash")
    // Concrete free model slugs first — the "openrouter/free" router is not enabled on every
    // account, and a missing slug returns 404 rather than falling back.
    private val openRouterChain = listOf(
        "deepseek/deepseek-chat-v3.1:free",
        "meta-llama/llama-3.3-70b-instruct:free",
        "qwen/qwen-2.5-72b-instruct:free",
        "google/gemma-3-27b-it:free",
        "openrouter/free"
    )

    /** Ceilings that free tiers actually accept. Asking for 32k is what made create_goal fail. */
    private const val GEMINI_CEILING = 8192
    private const val OPENROUTER_CEILING = 4096

    suspend fun generate(
        settings: SettingsRepository,
        prompt: String,
        system: String? = null,
        maxOutputTokens: Int = 8192,
        useWeb: Boolean = false
    ): String {
        val provider = runCatching { Provider.valueOf(settings.aiProvider.first()) }
            .getOrElse { Provider.GEMINI }

        return when (provider) {
            Provider.GEMINI -> {
                val key = settings.geminiApiKey.first()
                if (key.isBlank()) {
                    throw MissingKeyException(
                        "No Gemini API key. Add one in Settings, or switch the provider to OpenRouter."
                    )
                }
                val preferred = settings.geminiModel.first()
                val budget = maxOutputTokens.coerceAtMost(GEMINI_CEILING)
                runChain(
                    models = listOf(preferred) + geminiChain.filter { it != preferred },
                    call = { model ->
                        try {
                            Gemini.raw(key, model, prompt, system, budget, useWeb)
                        } catch (e: Exception) {
                            // Reflexion: a rejected budget is worth one smaller attempt before
                            // giving up on the model entirely.
                            if (budget > 2048) Gemini.raw(key, model, prompt, system, 2048, useWeb)
                            else throw e
                        }
                    }
                )
            }

            Provider.OPENROUTER -> {
                val key = settings.openRouterKey.first()
                if (key.isBlank()) {
                    throw MissingKeyException(
                        "No OpenRouter API key. Get a free one at openrouter.ai and add it in Settings."
                    )
                }
                val preferred = settings.openRouterModel.first()
                    .takeUnless { it.isBlank() || it == "openrouter/free" } ?: ""
                val budget = maxOutputTokens.coerceAtMost(OPENROUTER_CEILING)
                runChain(
                    models = listOf(preferred) + openRouterChain.filter { it != preferred },
                    call = { model ->
                        val slug = if (useWeb && !model.endsWith(":online")) "$model:online" else model
                        try {
                            OpenRouter.raw(key, slug, prompt, system, budget)
                        } catch (e: Exception) {
                            if (budget > 1500) OpenRouter.raw(key, slug, prompt, system, 1500)
                            else throw e
                        }
                    }
                )
            }
        }
    }

    /** Tries each model in turn; each model gets retries for transient failures. */
    private suspend fun runChain(models: List<String>, call: suspend (String) -> String): String {
        // The FIRST failure is the useful one. Reporting the last means reporting whatever the
        // final fallback said, which hides what actually went wrong on the model you chose.
        var firstError: Exception? = null
        var firstModel = ""
        for (model in models.filter { it.isNotBlank() }.distinct()) {
            var attempt = 0
            while (attempt < MAX_ATTEMPTS) {
                try {
                    return call(model)
                } catch (e: Exception) {
                    if (firstError == null) { firstError = e; firstModel = model }
                    val message = e.message.orEmpty()
                    val transient = message.contains("503") || message.contains("429") ||
                        message.contains("500") || message.contains("overloaded", true) ||
                        message.contains("UNAVAILABLE", true) || message.contains("timeout", true)
                    // A real error (bad key, bad model, bad request) means retrying is pointless —
                    // break out and let the next model in the chain have a go.
                    if (!transient) break
                    attempt++
                    if (attempt < MAX_ATTEMPTS) delay(800L * (1L shl (attempt - 1)))
                }
            }
        }
        throw friendly(firstError, firstModel)
    }

    private fun friendly(error: Exception?, model: String = ""): Exception {
        val message = error?.message.orEmpty()
        val tag = if (model.isBlank()) "" else " [$model]" 
        return when {
            message.contains("503") || message.contains("UNAVAILABLE", true) ->
                Exception(
                    "Every model is busy right now. This is the free tier under load — wait a minute, " +
                        "or switch the provider to OpenRouter in Settings."
                )
            message.contains("429") ->
                Exception("Rate limit reached for this key. Wait a few minutes, or switch provider in Settings.")
            message.contains("401") || message.contains("403") ->
                Exception(
                    "That API key was rejected. For OpenRouter, check the key is active and that " +
                        "free models are enabled in your account privacy settings."
                )
            message.contains("404") ->
                Exception(
                    "That model doesn't exist for your key. Tap \"Fetch models for my key\" in " +
                        "Settings and pick one from the list."
                )
            message.contains("402") ->
                Exception("OpenRouter says this model needs credits. Pick a model ending in :free.")
            message.contains("token", true) && message.contains("max", true) ->
                Exception("The request asked for more output than this model allows$tag. " +
                    "Atlas retries smaller automatically — if you see this, the retry failed too.")
            message.isBlank() -> Exception("The AI request failed with no error message$tag.")
            // Show the provider's own words. Guessing at causes is what sent us chasing ghosts.
            else -> Exception("$tag ${message.take(400)}")
        }
    }

    /** Strips markdown fences so model output can be parsed as JSON. */
    fun cleanJson(raw: String): String {
        var s = raw.trim()
        if (s.startsWith("```")) {
            s = s.substringAfter('\n', "")
            s = s.substringBeforeLast("```")
        }
        val start = s.indexOfFirst { it == '{' || it == '[' }
        val end = s.indexOfLast { it == '}' || it == ']' }
        return if (start >= 0 && end > start) s.substring(start, end + 1) else s
    }

    /** Model lists for the picker in Settings. */
    suspend fun listModels(settings: SettingsRepository): List<String> {
        val provider = runCatching { Provider.valueOf(settings.aiProvider.first()) }
            .getOrElse { Provider.GEMINI }
        return when (provider) {
            Provider.GEMINI -> Gemini.listModels(settings.geminiApiKey.first())
            Provider.OPENROUTER -> OpenRouter.listFreeModels()
        }
    }
}

/** OpenRouter speaks the OpenAI chat-completions format. */
object OpenRouter {

    suspend fun raw(
        apiKey: String,
        model: String,
        prompt: String,
        system: String?,
        maxOutputTokens: Int
    ): String {
        val messages = JSONArray()
        if (!system.isNullOrBlank()) {
            messages.put(JSONObject().put("role", "system").put("content", system))
        }
        messages.put(JSONObject().put("role", "user").put("content", prompt))

        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("max_tokens", maxOutputTokens)
            .put("temperature", 0.7)
            .toString()

        val response = Http.postJson(
            url = "https://openrouter.ai/api/v1/chat/completions",
            body = body,
            headers = mapOf(
                "Authorization" to "Bearer $apiKey",
                "HTTP-Referer" to "https://github.com/atlas-app",
                "X-Title" to "Atlas"
            )
        )
        val root = JSONObject(response)
        root.optJSONObject("error")?.let {
            throw IllegalStateException(it.optString("message", "OpenRouter error"))
        }
        val choices = root.optJSONArray("choices")
            ?: throw IllegalStateException("OpenRouter returned no choices.")
        if (choices.length() == 0) throw IllegalStateException("OpenRouter returned nothing.")
        val content = choices.getJSONObject(0).optJSONObject("message")?.optString("content").orEmpty()
        if (content.isBlank()) throw IllegalStateException("OpenRouter returned an empty message.")
        return content.trim()
    }

    /** Free models, newest first — no key needed to read the catalogue. */
    suspend fun listFreeModels(): List<String> {
        val response = Http.getJson("https://openrouter.ai/api/v1/models")
        val data = JSONObject(response).optJSONArray("data") ?: return emptyList()
        val out = mutableListOf("openrouter/free")
        for (i in 0 until data.length()) {
            val m = data.getJSONObject(i)
            val id = m.optString("id")
            val pricing = m.optJSONObject("pricing")
            val promptPrice = pricing?.optString("prompt", "1") ?: "1"
            val completionPrice = pricing?.optString("completion", "1") ?: "1"
            val free = promptPrice.toDoubleOrNull() == 0.0 && completionPrice.toDoubleOrNull() == 0.0
            if (free && id.isNotBlank() && id != "openrouter/free") out.add(id)
        }
        return out.distinct()
    }
}
