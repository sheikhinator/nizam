package com.nizam.app.ui.theme

import androidx.compose.ui.graphics.Color

// Atlas runs dark by default: deep navy-black with a warm amber signal colour.
// Light
val SurfaceLight = Color(0xFFF5F4F1)
val CardLight = Color(0xFFFFFFFF)
val InkLight = Color(0xFF14171F)
val InkMutedLight = Color(0xFF5E6472)
val PrimaryLight = Color(0xFF1F6F63)
val AccentLight = Color(0xFFC2652F)
val DangerLight = Color(0xFFB3453A)

// Dark
val SurfaceDark = Color(0xFF0B0F1A)
val CardDark = Color(0xFF141A28)
val InkDark = Color(0xFFEDEFF5)
val InkMutedDark = Color(0xFF8C96AC)
val PrimaryDark = Color(0xFF4FC3A1)
val AccentDark = Color(0xFFE0603A)
val DangerDark = Color(0xFFE0685C)

// Module spine colours
object Spine {
    val Tasks = Color(0xFF2E7D6F)
    val Prayer = Color(0xFF1F6F63)
    val Finance = Color(0xFFC9832B)
    val Diet = Color(0xFF6B8E4E)
    val Gym = Color(0xFF3E5C76)
    val Notes = Color(0xFF4A5468)
    val Library = Color(0xFF8A5A3B)
    val Diary = Color(0xFF6E4A7E)
    val Scripture = Color(0xFF2C4A42)
    val Learning = Color(0xFF3A4A8C)
    val Survival = Color(0xFFA44A28)
}
