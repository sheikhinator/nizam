package com.nizam.app.ui.theme

import androidx.compose.ui.graphics.Color

// Atlas runs dark by default: deep navy-black with a warm amber signal colour.
// Light
val SurfaceLight = Color(0xFFF5F4F1)
val CardLight = Color(0xFFFFFFFF)
val InkLight = Color(0xFF14171F)
val InkMutedLight = Color(0xFF5E6472)
val PrimaryLight = Color(0xFF1F6F63)
val AccentLight = Color(0xFFC2652F)
val DangerLight = Color(0xFFB3453A)

// Dark
val SurfaceDark = Color(0xFF0B0F1A)
val CardDark = Color(0xFF141A28)
val InkDark = Color(0xFFEDEFF5)
val InkMutedDark = Color(0xFF8C96AC)
val PrimaryDark = Color(0xFF4FC3A1)
val AccentDark = Color(0xFFE0603A)
val DangerDark = Color(0xFFE0685C)

// Module spine colours
object Spine {
    val Tasks = Color(0xFF2E7D6F)
    val Prayer = Color(0xFF1F6F63)
    val Finance = Color(0xFFC9832B)
    val Diet = Color(0xFF6B8E4E)
    val Gym = Color(0xFF3E5C76)
    val Notes = Color(0xFF4A5468)
    val Library = Color(0xFF8A5A3B)
    val Diary = Color(0xFF6E4A7E)
    val Scripture = Color(0xFF2C4A42)
    val Learning = Color(0xFF3A4A8C)
    val Survival = Color(0xFFA44A28)
}


/**
 * Selectable themes. Each is a full palette, not just an accent swap, so switching actually
 * changes the feel of the app rather than recolouring one button.
 */
data class AtlasPalette(
    val key: String,
    val label: String,
    val surface: Color,
    val card: Color,
    val ink: Color,
    val inkMuted: Color,
    val primary: Color,
    val accent: Color
)

val ATLAS_THEMES = listOf(
    AtlasPalette(
        "void", "Void",
        Color(0xFF0B0F1A), Color(0xFF141A28), Color(0xFFEDEFF5), Color(0xFF8C96AC),
        Color(0xFF4FC3A1), Color(0xFFE0603A)
    ),
    AtlasPalette(
        "ember", "Ember",
        Color(0xFF14100D), Color(0xFF201A15), Color(0xFFF2E9E1), Color(0xFF9E8F82),
        Color(0xFFD98E4A), Color(0xFFC2452F)
    ),
    AtlasPalette(
        "moss", "Moss",
        Color(0xFF0C130F), Color(0xFF161F19), Color(0xFFE8EFE8), Color(0xFF8AA08F),
        Color(0xFF6FB98A), Color(0xFFC9A227)
    ),
    AtlasPalette(
        "ink", "Ink",
        Color(0xFF0D0D10), Color(0xFF17171C), Color(0xFFEDEDF0), Color(0xFF8E8E99),
        Color(0xFF9B8CD6), Color(0xFFE0B14A)
    ),
    AtlasPalette(
        "paper", "Paper",
        Color(0xFFF5F2EA), Color(0xFFFFFDF8), Color(0xFF1A1814), Color(0xFF6B6459),
        Color(0xFF2F6F5E), Color(0xFFB4562C)
    ),
    AtlasPalette(
        "steel", "Steel",
        Color(0xFF0F1418), Color(0xFF1A2229), Color(0xFFE6EDF3), Color(0xFF8595A3),
        Color(0xFF58A6C9), Color(0xFFE08A3C)
    )
)

fun paletteFor(key: String): AtlasPalette =
    ATLAS_THEMES.firstOrNull { it.key == key } ?: ATLAS_THEMES.first()
