package com.nizam.app.feature.agent

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.Tones
import com.nizam.app.net.Ai
import com.nizam.app.ui.theme.DisplayFamily
import kotlinx.coroutines.launch

@Composable
fun AgentScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val suggestions by container.curatorRepository.active().collectAsState(initial = emptyList())
    val specs by container.dynamicRepository.specs().collectAsState(initial = emptyList())

    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var moduleIdea by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
    ) {
        ModuleTitle("✦  Curator", "Keeps Atlas moving — and builds new modules on request")

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = !busy,
                onClick = {
                    scope.launch {
                        busy = true; status = null
                        try {
                            val n = container.curatorRepository.refreshSuggestions()
                            status = "$n fresh suggestions."
                        } catch (e: Ai.MissingKeyException) {
                            status = e.message
                        } catch (e: Exception) {
                            status = e.message
                        }
                        busy = false
                    }
                }
            ) { Text(if (busy) "Thinking…" else "🔄  Refresh suggestions") }
        }

        if (busy) {
            Spacer(Modifier.height(12.dp))
            CircularProgressIndicator()
        }
        status?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(18.dp))

        suggestions.forEach { suggestion ->
            val tones = Tones.forKey(suggestion.moduleKey)
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = tones.tone.copy(alpha = 0.12f),
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row {
                        Text(suggestion.emoji, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(suggestion.title, style = MaterialTheme.typography.titleMedium)
                            Text(
                                suggestion.moduleKey,
                                style = MaterialTheme.typography.labelMedium,
                                color = tones.accent
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(suggestion.body, style = MaterialTheme.typography.bodyLarge)
                    if (suggestion.actionHint.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "→ ${suggestion.actionHint}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "dismiss",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable {
                            scope.launch { container.curatorRepository.dismiss(suggestion) }
                        }
                    )
                }
            }
        }

        if (suggestions.isEmpty() && !busy) {
            Text(
                "No suggestions yet. Tap refresh and the curator reads your data — what you read, " +
                    "study, train, spend and skip — then tells you what to do next in each module.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(24.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(18.dp))

        Text(
            "Build me a module",
            style = MaterialTheme.typography.headlineMedium.copy(fontFamily = DisplayFamily)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Describe what you want to track. The curator designs the fields and installs it " +
                "immediately — no update, no rebuild.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = moduleIdea,
            onValueChange = { moduleIdea = it },
            label = { Text("e.g. track my bike's fuel and servicing") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        Button(
            enabled = !busy && moduleIdea.isNotBlank(),
            onClick = {
                scope.launch {
                    busy = true; status = null
                    try {
                        val spec = container.curatorRepository.createModule(moduleIdea)
                        status = "${spec.emoji}  ${spec.name} installed — find it in Modules."
                        moduleIdea = ""
                    } catch (e: Exception) {
                        status = e.message
                    }
                    busy = false
                }
            }
        ) { Text("✦  Design and install") }

        Spacer(Modifier.height(20.dp))
        Text(
            "${specs.size} modules installed",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(60.dp))
    }
}
