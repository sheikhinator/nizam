package com.nizam.app.ui.screens.search

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.vmFactory
import com.nizam.app.feature.diary.DiaryViewModel
import com.nizam.app.feature.notes.NotesViewModel
import com.nizam.app.ui.screens.tasks.TasksViewModel

@Composable
fun SearchScreen(container: AppContainer) {
    val tasksVm: TasksViewModel = viewModel(
        key = "searchTasks",
        factory = TasksViewModel.factory(container.taskRepository, container.habitRepository)
    )
    val notesVm: NotesViewModel = viewModel(
        key = "searchNotes", factory = vmFactory { NotesViewModel(container.noteRepository) }
    )
    val diaryVm: DiaryViewModel = viewModel(
        key = "searchDiary", factory = vmFactory { DiaryViewModel(container.diaryRepository) }
    )

    val tasks by tasksVm.tasks.collectAsState()
    val notes by notesVm.notes.collectAsState()
    val entries by diaryVm.entries.collectAsState()

    var query by remember { mutableStateOf("") }
    val q = query.trim()

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ModuleTitle("🔎  Search", "Tasks, notes and diary entries")
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("Search everything") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        if (q.isBlank()) {
            Text("Type to search across your modules.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            return@Column
        }

        val taskHits = tasks.filter { it.title.contains(q, true) }
        val noteHits = notes.filter { it.title.contains(q, true) || it.body.contains(q, true) }
        val diaryHits = entries.filter { it.body.contains(q, true) }

        LazyColumn(Modifier.fillMaxSize()) {
            if (taskHits.isNotEmpty()) {
                item { SearchHeader("Tasks") }
                items(taskHits.size) { i ->
                    Text(taskHits[i].title, style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(vertical = 8.dp))
                    Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
            if (noteHits.isNotEmpty()) {
                item { SearchHeader("Notes") }
                items(noteHits.size) { i ->
                    Text(noteHits[i].title, style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(vertical = 8.dp))
                    Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
            if (diaryHits.isNotEmpty()) {
                item { SearchHeader("Diary") }
                items(diaryHits.size) { i ->
                    Text(
                        diaryHits[i].localDate + " · " + diaryHits[i].body.take(70),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
            if (taskHits.isEmpty() && noteHits.isEmpty() && diaryHits.isEmpty()) {
                item {
                    Text("Nothing found for \"$q\".",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun SearchHeader(title: String) {
    Spacer(Modifier.height(12.dp))
    Text(title, style = MaterialTheme.typography.titleMedium)
}
