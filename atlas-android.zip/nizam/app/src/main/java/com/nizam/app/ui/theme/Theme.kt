package com.nizam.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = PrimaryLight,
    onPrimary = CardLight,
    secondary = AccentLight,
    onSecondary = CardLight,
    background = SurfaceLight,
    onBackground = InkLight,
    surface = CardLight,
    onSurface = InkLight,
    surfaceVariant = SurfaceLight,
    onSurfaceVariant = InkMutedLight,
    error = DangerLight
)

private val DarkColors = darkColorScheme(
    primary = PrimaryDark,
    onPrimary = SurfaceDark,
    secondary = AccentDark,
    onSecondary = SurfaceDark,
    background = SurfaceDark,
    onBackground = InkDark,
    surface = CardDark,
    onSurface = InkDark,
    surfaceVariant = CardDark,
    onSurfaceVariant = InkMutedDark,
    error = DangerDark
)

// Asymmetric corners give cards a hand-placed feel instead of the uniform rounded-rect look
// that every generated app defaults to.
val NizamShapes = Shapes(
    small = RoundedCornerShape(topStart = 10.dp, topEnd = 4.dp, bottomEnd = 10.dp, bottomStart = 4.dp),
    medium = RoundedCornerShape(topStart = 16.dp, topEnd = 6.dp, bottomEnd = 16.dp, bottomStart = 6.dp),
    large = RoundedCornerShape(topStart = 22.dp, topEnd = 8.dp, bottomEnd = 22.dp, bottomStart = 8.dp)
)

@Composable
fun NizamTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    paletteKey: String = "",
    content: @Composable () -> Unit
) {
    val scheme = if (paletteKey.isBlank()) {
        if (darkTheme) DarkColors else LightColors
    } else {
        val p = paletteFor(paletteKey)
        val light = p.surface.luminance() > 0.5f
        if (light) {
            lightColorScheme(
                primary = p.primary, onPrimary = p.card,
                secondary = p.accent, onSecondary = p.card,
                background = p.surface, onBackground = p.ink,
                surface = p.card, onSurface = p.ink,
                surfaceVariant = p.surface, onSurfaceVariant = p.inkMuted,
                error = DangerLight
            )
        } else {
            darkColorScheme(
                primary = p.primary, onPrimary = p.surface,
                secondary = p.accent, onSecondary = p.surface,
                background = p.surface, onBackground = p.ink,
                surface = p.card, onSurface = p.ink,
                surfaceVariant = p.card, onSurfaceVariant = p.inkMuted,
                error = DangerDark
            )
        }
    }

    MaterialTheme(
        colorScheme = scheme,
        typography = NizamTypography,
        shapes = NizamShapes,
        content = content
    )
}
