package com.nizam.app.feature.dynamic

/**
 * Built-in modules, defined as specs. Adding one is a data change, not a code change — which is
 * also how the curator agent adds its own.
 */
object Builtins {

    private fun field(
        key: String, label: String, type: String,
        options: List<String> = emptyList(), suffix: String = ""
    ): String {
        val opts = if (options.isEmpty()) "" else
            ""","options":[""" + options.joinToString(",") { "\"$it\"" } + "]"
        val suf = if (suffix.isBlank()) "" else ""","suffix":"$suffix""""
        return """{"key":"$key","label":"$label","type":"$type"$opts$suf}"""
    }

    private fun fields(vararg f: String) = "[" + f.joinToString(",") + "]"

    val specs: List<ModuleSpec> = listOf(
        ModuleSpec(
            key = "sleep", name = "Sleep", emoji = "🌙",
            tagline = "Hours, quality and what wrecked it",
            colorHex = "#5B6BA8", sortIndex = 1, builtIn = true,
            fieldsJson = fields(
                field("hours", "Hours slept", "NUMBER", suffix = "h"),
                field("quality", "Quality", "RATING"),
                field("bedtime", "Bedtime", "TEXT"),
                field("notes", "What affected it", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "focus", name = "Focus", emoji = "⏱️",
            tagline = "Deep work sessions and what you got done",
            colorHex = "#3E7C8A", sortIndex = 2, builtIn = true,
            fieldsJson = fields(
                field("minutes", "Minutes", "NUMBER", suffix = "min"),
                field("task", "Working on", "TEXT"),
                field("depth", "Depth of focus", "RATING"),
                field("distraction", "Biggest distraction", "TEXT")
            )
        ),
        ModuleSpec(
            key = "people", name = "People", emoji = "🤝",
            tagline = "Who matters, and when you last spoke",
            colorHex = "#A8634F", sortIndex = 3, builtIn = true,
            fieldsJson = fields(
                field("relation", "Relationship", "TEXT"),
                field("lastContact", "Last spoke", "DATE"),
                field("cadence", "Check in every", "CHOICE",
                    listOf("Week", "Fortnight", "Month", "Quarter")),
                field("notes", "Notes", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "projects", name = "Projects", emoji = "🗂️",
            tagline = "Bigger things with stages",
            colorHex = "#4F6FA8", sortIndex = 4, builtIn = true,
            fieldsJson = fields(
                field("stage", "Stage", "CHOICE", listOf("Idea", "Planned", "Doing", "Blocked", "Done")),
                field("nextAction", "Next action", "TEXT"),
                field("deadline", "Deadline", "DATE"),
                field("notes", "Notes", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "subscriptions", name = "Subscriptions", emoji = "🔁",
            tagline = "Recurring money, before it surprises you",
            colorHex = "#B57F4A", sortIndex = 5, builtIn = true,
            fieldsJson = fields(
                field("amount", "Amount", "NUMBER", suffix = "PKR"),
                field("cycle", "Billing cycle", "CHOICE", listOf("Monthly", "Quarterly", "Yearly")),
                field("renews", "Next renewal", "DATE"),
                field("worthIt", "Still worth it", "BOOL")
            )
        ),
        ModuleSpec(
            key = "wins", name = "Wins", emoji = "🏅",
            tagline = "Evidence for the days you feel like nothing works",
            colorHex = "#C08A2E", sortIndex = 6, builtIn = true,
            fieldsJson = fields(
                field("area", "Area", "CHOICE",
                    listOf("Work", "Health", "Learning", "Money", "Faith", "People")),
                field("detail", "What happened", "LONGTEXT"),
                field("size", "How big", "RATING")
            )
        ),
        ModuleSpec(
            key = "azkar", name = "Azkar", emoji = "📿",
            tagline = "Morning, evening and counted dhikr",
            colorHex = "#2F7A66", sortIndex = 7, builtIn = true,
            fieldsJson = fields(
                field("set", "Set", "CHOICE",
                    listOf("Morning", "Evening", "After prayer", "Before sleep", "Custom")),
                field("count", "Count", "NUMBER"),
                field("notes", "Notes", "TEXT")
            )
        ),
        ModuleSpec(
            key = "places", name = "Places", emoji = "📍",
            tagline = "Where you went and whether it was worth it",
            colorHex = "#6E8E4E", sortIndex = 8, builtIn = true,
            fieldsJson = fields(
                field("city", "City or area", "TEXT"),
                field("kind", "Type", "CHOICE",
                    listOf("Restaurant", "Cafe", "Park", "Masjid", "Shop", "Trip", "Other")),
                field("rating", "Rating", "RATING"),
                field("notes", "Notes", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "recipes", name = "Recipes", emoji = "🍲",
            tagline = "Things you can actually cook",
            colorHex = "#A85D3C", sortIndex = 9, builtIn = true,
            fieldsJson = fields(
                field("ingredients", "Ingredients", "LONGTEXT"),
                field("method", "Method", "LONGTEXT"),
                field("time", "Time", "NUMBER", suffix = "min"),
                field("rating", "Rating", "RATING")
            )
        ),
        ModuleSpec(
            key = "ideas", name = "Ideas", emoji = "💡",
            tagline = "Catch it before it evaporates",
            colorHex = "#C9A227", sortIndex = 10, builtIn = true,
            fieldsJson = fields(
                field("detail", "The idea", "LONGTEXT"),
                field("area", "Area", "CHOICE",
                    listOf("Business", "App", "Content", "Personal", "Other")),
                field("energy", "Excitement", "RATING")
            )
        ),
        ModuleSpec(
            key = "vocab", name = "Vocabulary", emoji = "🔤",
            tagline = "Words and phrases worth keeping",
            colorHex = "#7A5BA8", sortIndex = 11, builtIn = true,
            fieldsJson = fields(
                field("language", "Language", "CHOICE",
                    listOf("Arabic", "English", "Urdu", "Chinese", "Other")),
                field("meaning", "Meaning", "TEXT"),
                field("example", "Used in a sentence", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "inventory", name = "Inventory", emoji = "📦",
            tagline = "What you own, what it cost, where it is",
            colorHex = "#6B7280", sortIndex = 12, builtIn = true,
            fieldsJson = fields(
                field("category", "Category", "CHOICE",
                    listOf("Tech", "Clothing", "Home", "Tools", "Documents", "Other")),
                field("value", "Value", "NUMBER", suffix = "PKR"),
                field("location", "Where", "TEXT"),
                field("warranty", "Warranty until", "DATE")
            )
        ),
        ModuleSpec(
            key = "maintenance", name = "Maintenance", emoji = "🔧",
            tagline = "Bike, home, documents — things with a due date",
            colorHex = "#8A6A3B", sortIndex = 13, builtIn = true,
            fieldsJson = fields(
                field("item", "What", "TEXT"),
                field("due", "Due", "DATE"),
                field("interval", "Repeats", "CHOICE",
                    listOf("Monthly", "Quarterly", "Every 6 months", "Yearly", "One-off")),
                field("notes", "Notes", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "watchlist", name = "Watchlist", emoji = "🎬",
            tagline = "Films, series, talks and lectures to watch",
            colorHex = "#8A4F6B", sortIndex = 14, builtIn = true,
            fieldsJson = fields(
                field("kind", "Type", "CHOICE",
                    listOf("Film", "Series", "Documentary", "Lecture", "Talk")),
                field("status", "Status", "CHOICE", listOf("To watch", "Watching", "Finished", "Dropped")),
                field("rating", "Rating", "RATING"),
                field("notes", "Notes", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "music", name = "Music", emoji = "🎵",
            tagline = "Your own tracks, playable in the app",
            colorHex = "#8A4F6B", sortIndex = 16, builtIn = true,
            fieldsJson = fields(
                field("file", "Audio file", "FILE"),
                field("artist", "Artist", "TEXT"),
                field("album", "Album", "TEXT"),
                field("rating", "Rating", "RATING")
            )
        ),
        ModuleSpec(
            key = "gallery", name = "Gallery", emoji = "🖼️",
            tagline = "Photos and clips worth keeping",
            colorHex = "#4F7C8A", sortIndex = 17, builtIn = true,
            fieldsJson = fields(
                field("file", "Photo or video", "FILE"),
                field("where", "Where", "TEXT"),
                field("notes", "Notes", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "documents", name = "Documents", emoji = "📄",
            tagline = "PDFs and files you need to find again",
            colorHex = "#6B7280", sortIndex = 18, builtIn = true,
            fieldsJson = fields(
                field("file", "File", "FILE"),
                field("category", "Category", "CHOICE",
                    listOf("ID", "Medical", "Work", "Finance", "Warranty", "Other")),
                field("expires", "Expires", "DATE")
            )
        ),
        ModuleSpec(
            key = "career", name = "Career", emoji = "💼",
            tagline = "Wins, projects and skills — your running brag document",
            colorHex = "#3E7C8A", sortIndex = 19, builtIn = true,
            fieldsJson = fields(
                field("type", "Type", "CHOICE",
                    listOf("Win", "Project", "Skill learned", "Feedback", "Certification", "Setback", "Idea")),
                field("impact", "Impact", "LONGTEXT"),
                field("hours", "Hours invested", "NUMBER", suffix = "h"),
                field("skills", "Skills", "TEXT"),
                field("rating", "Significance", "RATING"),
                field("file", "Evidence", "FILE")
            )
        ),
        ModuleSpec(
            key = "people", name = "People", emoji = "🫂",
            tagline = "The people who matter — and when you last showed it",
            colorHex = "#8A4F6B", sortIndex = 20, builtIn = true,
            fieldsJson = fields(
                field("relation", "Relation", "CHOICE",
                    listOf("Family", "Friend", "Colleague", "Mentor", "Neighbour", "Other")),
                field("birthday", "Birthday", "DATE"),
                field("lastContact", "Last spoke", "DATE"),
                field("phone", "Phone", "TEXT"),
                field("closeness", "Closeness", "RATING"),
                field("notes", "Things to remember", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "skills", name = "Skill tree", emoji = "🌳",
            tagline = "Real skills, levelled by the hours you put in",
            colorHex = "#6E8E4E", sortIndex = 21, builtIn = true,
            fieldsJson = "[" + listOf(
                field("branch", "Branch", "CHOICE", listOf("Work", "Tech", "Language", "Body", "Faith", "Creative", "Social")),
                field("hours", "Hours practised", "NUMBER", suffix = "h"),
                field("confidence", "Confidence", "RATING"),
                field("next", "Next milestone", "TEXT"),
                "{\"key\":\"level\",\"label\":\"Level\",\"type\":\"COMPUTED\",\"formula\":\"floor(sqrt(hours))\"}"
            ).joinToString(",") + "]"
        ),
        ModuleSpec(
            key = "maintenance", name = "Maintenance", emoji = "🔧",
            tagline = "Bike service, AC filters, renewals — reminded on the day",
            colorHex = "#6B7280", sortIndex = 22, builtIn = true,
            fieldsJson = fields(
                field("area", "What", "CHOICE", listOf("Vehicle", "Home", "Appliance", "Document", "Health check", "Other")),
                field("due", "Next due", "DATE"),
                field("cost", "Cost", "NUMBER", suffix = "PKR"),
                field("notes", "Notes", "LONGTEXT")
            )
        ),
        ModuleSpec(
            key = "gratitude", name = "Gratitude", emoji = "🤲",
            tagline = "Three things, most days",
            colorHex = "#4F8A6B", sortIndex = 15, builtIn = true,
            fieldsJson = fields(
                field("one", "First", "TEXT"),
                field("two", "Second", "TEXT"),
                field("three", "Third", "TEXT")
            )
        )
    )
}
