package com.nizam.app.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.data.prefs.ThemeMode
import com.nizam.app.net.Ai
import com.nizam.app.ui.theme.ATLAS_THEMES
import com.nizam.app.ui.components.SectionHeader
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val settings = container.settingsRepository
    val theme by settings.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
    val currency by settings.currency.collectAsState(initial = "PKR")
    val hadithKey by settings.hadithApiKey.collectAsState(initial = "")
    val geminiKey by settings.geminiApiKey.collectAsState(initial = "")
    val geminiModel by settings.geminiModel.collectAsState(initial = "gemini-2.5-flash")

    var hadithDraft by remember(hadithKey) { mutableStateOf(hadithKey) }
    var geminiDraft by remember(geminiKey) { mutableStateOf(geminiKey) }
    val kcalTarget by settings.kcalTarget.collectAsState(initial = 2200)
    val waterTarget by settings.waterTarget.collectAsState(initial = 3000)
    var kcalDraft by remember(kcalTarget) { mutableStateOf(kcalTarget.toString()) }
    var waterDraft by remember(waterTarget) { mutableStateOf(waterTarget.toString()) }
    val provider by settings.aiProvider.collectAsState(initial = "GEMINI")
    val openRouterKey by settings.openRouterKey.collectAsState(initial = "")
    val openRouterModel by settings.openRouterModel.collectAsState(initial = "openrouter/free")
    val pin by settings.appPin.collectAsState(initial = "")
    var openRouterDraft by remember(openRouterKey) { mutableStateOf(openRouterKey) }
    var pinDraft by remember { mutableStateOf("") }
    var availableModels by remember { mutableStateOf<List<String>>(emptyList()) }
    var loadingModels by remember { mutableStateOf(false) }
    var modelError by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))

        SectionHeader("THEME")
        val currentPalette by settings.accentHex.collectAsState(initial = "")
        ATLAS_THEMES.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { palette ->
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = palette.card,
                        modifier = Modifier
                            .weight(1f)
                            .height(76.dp)
                            .clickable { scope.launch { settings.setAccent(palette.key) } }
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(palette.primary, palette.accent, palette.inkMuted).forEach { c ->
                                    Surface(
                                        shape = MaterialTheme.shapes.small,
                                        color = c,
                                        modifier = Modifier.width(18.dp).height(18.dp)
                                    ) { Text("") }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                (if (currentPalette == palette.key) "✓ " else "") + palette.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.ink
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        if (currentPalette.isNotBlank()) {
            OutlinedButton(onClick = { scope.launch { settings.setAccent("") } }) {
                Text("Follow system light/dark instead")
            }
        }

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("APPEARANCE")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.entries.forEach { mode ->
                FilterChip(
                    selected = theme == mode,
                    onClick = { scope.launch { settings.setThemeMode(mode) } },
                    label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("CURRENCY")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("PKR", "USD", "AED", "SAR").forEach { code ->
                FilterChip(
                    selected = currency == code,
                    onClick = { scope.launch { settings.setCurrency(code) } },
                    label = { Text(code) }
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("AI PROVIDER")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("GEMINI" to "Google Gemini", "OPENROUTER" to "OpenRouter").forEach { (value, label) ->
                FilterChip(
                    selected = provider == value,
                    onClick = { scope.launch { settings.setProvider(value) } },
                    label = { Text(label) }
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (provider == "GEMINI")
                "Gemini's free tier returns 503 under load. A Gemini Pro subscription does not cover " +
                    "API keys — that is billed separately in Google Cloud."
            else
                "OpenRouter's openrouter/free router picks a working free model per request, so it " +
                    "rarely fails. Get a key at openrouter.ai — no card needed for free models.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Either way, every request retries with backoff and falls through to a backup model " +
                "before it gives up.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("API KEYS")
        Text(
            "Keys are stored on this device only and are never sent anywhere except the service they belong to.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = hadithDraft,
                onValueChange = { hadithDraft = it },
                label = { Text("Hadith API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { scope.launch { settings.setHadithApiKey(hadithDraft) } }) { Text("Save") }
        }
        Text(
            "Get a free key at hadithapi.com. Without it, the Hadith module shows nothing rather than unsourced text.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = geminiDraft,
                onValueChange = { geminiDraft = it },
                label = { Text("Gemini API key (optional)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { scope.launch { settings.setGeminiApiKey(geminiDraft) } }) { Text("Save") }
        }
        Text(
            "Powers courses, the assistant, and the Ask panels in Diet, Gym, Finance, Diary, Survival and News. " +
                "Get a key at aistudio.google.com.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = openRouterDraft,
                onValueChange = { openRouterDraft = it },
                label = { Text("OpenRouter API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { scope.launch { settings.setOpenRouterKey(openRouterDraft) } }) { Text("Save") }
        }

        Spacer(Modifier.height(10.dp))
        Text("Model", style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(if (provider == "GEMINI") geminiModel else openRouterModel, style = com.nizam.app.ui.theme.MonoNumber)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(
                enabled = !loadingModels,
                onClick = {
                    scope.launch {
                        loadingModels = true
                        modelError = null
                        try {
                            availableModels = Ai.listModels(settings)
                        } catch (e: Ai.MissingKeyException) {
                            modelError = "Save your API key first."
                        } catch (e: Exception) {
                            modelError = e.message
                        }
                        loadingModels = false
                    }
                }
            ) { Text(if (loadingModels) "Loading…" else "Fetch models for my key") }
        }
        modelError?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
        }
        if (availableModels.isEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(
                "Defaults to gemini-flash-latest, an alias Google keeps pointed at the current Flash " +
                    "model — so this keeps working when model names change.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            availableModels.take(14).forEach { m ->
                Text(
                    (if ((if (provider == "GEMINI") geminiModel else openRouterModel) == m) "✓  " else "     ") + m,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if ((if (provider == "GEMINI") geminiModel else openRouterModel) == m) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            scope.launch {
                                if (provider == "GEMINI") settings.setGeminiModel(m)
                                else settings.setOpenRouterModel(m)
                            }
                        }
                        .padding(vertical = 8.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("DAILY TARGETS")
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = kcalDraft, onValueChange = { kcalDraft = it },
                label = { Text("Calories") }, singleLine = true, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = waterDraft, onValueChange = { waterDraft = it },
                label = { Text("Water (ml)") }, singleLine = true, modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            scope.launch {
                settings.setTargets(kcalDraft.toIntOrNull() ?: 2200, waterDraft.toIntOrNull() ?: 3000)
            }
        }) { Text("Save targets") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { scope.launch { settings.resetOnboarding() } }) {
            Text("Run setup again")
        }

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("APP LOCK")
        Text(
            if (pin.isBlank()) "No PIN set — the app opens straight away."
            else "PIN is on. Atlas asks for it every time it starts.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = pinDraft,
                onValueChange = { pinDraft = it.filter { c -> c.isDigit() }.take(8) },
                label = { Text("New PIN (4-8 digits)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            Button(
                enabled = pinDraft.length >= 4,
                onClick = { scope.launch { settings.setPin(pinDraft); pinDraft = "" } }
            ) { Text("Set") }
        }
        if (pin.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { scope.launch { settings.setPin("") } }) { Text("Remove PIN") }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "This stops someone picking up your phone. It is not encryption — your data sits in the " +
                "app's private storage either way.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("ABOUT")
        Text("Atlas 0.7.0", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            "Your data stays on this device. The only network calls are Quran text (Al Quran Cloud) and Hadith (hadithapi.com), both cached after first use.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(40.dp))
    }
}
