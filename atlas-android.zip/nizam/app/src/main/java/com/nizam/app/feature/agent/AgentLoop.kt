package com.nizam.app.feature.agent

import com.nizam.app.AppContainer
import com.nizam.app.net.Ai
import org.json.JSONObject

/**
 * A ReAct loop: plan, act, observe what happened, then decide whether to keep going. The model
 * sees the result of each action before choosing the next, so a failed step can be worked around
 * instead of silently reported as success.
 *
 * Destructive actions stop and ask first — the human-in-the-loop checkpoint that every serious
 * agent design keeps, because an agent that acts alone scales its mistakes as fast as its wins.
 */
class AgentLoop(private val container: () -> AppContainer) {

    data class Step(val action: String, val summary: String, val ok: Boolean)
    data class Outcome(
        val reply: String,
        val steps: List<Step>,
        val pendingApproval: List<Pair<String, JSONObject>> = emptyList()
    )

    private val destructive = setOf(
        "delete_module", "clear_module_entries", "set_pin", "disable_module", "set_home_order"
    )

    private val MAX_ITERATIONS = 4

    suspend fun run(userMessage: String, useWeb: Boolean, autoApprove: Boolean): Outcome {
        val c = container()
        val memory = c.agentMemory
        val steps = mutableListOf<Step>()
        val pending = mutableListOf<Pair<String, JSONObject>>()
        var reply = ""
        var observations = ""

        repeat(MAX_ITERATIONS) { iteration ->
            val raw = Ai.generate(
                settings = c.settingsRepository,
                prompt = buildString {
                    appendLine(memory.recall())
                    appendLine()
                    appendLine("Conversation so far:")
                    appendLine(memory.history())
                    appendLine()
                    appendLine("Current state of their app:")
                    appendLine(Snapshot.of(c))
                    if (observations.isNotBlank()) {
                        appendLine()
                        appendLine("Results of what you just did:")
                        appendLine(observations)
                        appendLine("Decide whether anything else is needed. If the task is finished, " +
                            "return an empty actions array and a final reply.")
                    }
                    appendLine()
                    appendLine("User's latest message: $userMessage")
                },
                system = SYSTEM + "\n\nAvailable actions:\n" + Actions.CATALOGUE,
                maxOutputTokens = 4096,
                useWeb = useWeb
            )

            val parsed = runCatching { JSONObject(Ai.cleanJson(raw)) }.getOrNull()
            if (parsed == null) {
                reply = raw
                return Outcome(reply, steps)
            }

            reply = parsed.optString("reply", reply)

            // Anything worth carrying between sessions
            parsed.optJSONArray("remember")?.let { array ->
                for (i in 0 until array.length()) {
                    memory.remember(array.optString(i), "inferred")
                }
            }

            val actions = parsed.optJSONArray("actions")
            if (actions == null || actions.length() == 0) return Outcome(reply, steps, pending)

            val results = StringBuilder()
            for (i in 0 until actions.length()) {
                val a = actions.getJSONObject(i)
                val name = a.optString("action")
                val args = a.optJSONObject("args") ?: JSONObject()

                if (name in destructive && !autoApprove) {
                    pending.add(name to args)
                    results.appendLine("$name: waiting for the user to approve")
                    continue
                }

                val result = Actions.run(c, name, args)
                steps.add(Step(name, result.summary, result.ok))
                results.appendLine("$name: ${if (result.ok) "OK" else "FAILED"} — ${result.summary}")
            }
            observations = results.toString()

            // Nothing left to react to
            if (pending.isNotEmpty() && steps.isEmpty()) return Outcome(reply, steps, pending)
            if (iteration == MAX_ITERATIONS - 1) return Outcome(reply, steps, pending)
            if (steps.none { !it.ok }) {
                // Everything worked — one more pass only if the model asked to continue
                if (!parsed.optBoolean("continue", false)) return Outcome(reply, steps, pending)
            }
        }
        return Outcome(reply, steps, pending)
    }

    companion object {
        const val SYSTEM = """You are Atlas — the user's personal agent, living inside their own
life app on their phone. You can see their data and you can change the app by returning actions.

Reply with ONE JSON object and nothing else:
{
  "reply": "what you say to them, in plain conversational language",
  "actions": [{"action": "add_task", "args": {"title": "..."}}],
  "remember": ["durable facts worth keeping between sessions"],
  "continue": false
}

How to behave:
- Take action. If they ask for something in the catalogue, do it — don't tell them where to tap.
- Chain properly: build a module, then populate it, then say it's done.
- Set "continue": true only when you genuinely need another round after seeing results.
- When an action fails, try a different approach rather than repeating it.
- Never claim you did something the results didn't confirm.
- Talk like a sharp chief of staff who knows them: direct, specific, no filler, no flattery.
- Use their real numbers. Never invent data you weren't given — say you don't have it."""
    }
}
