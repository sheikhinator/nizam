package com.nizam.app.feature.finance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import com.nizam.app.AppContainer
import com.nizam.app.core.InlineAddRow
import com.nizam.app.core.AiPanel
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.fmtAmount
import com.nizam.app.core.prettyDate
import com.nizam.app.core.today
import com.nizam.app.core.vmFactory
import com.nizam.app.ui.theme.MonoNumber
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

@Entity(tableName = "txn")
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val kind: String,               // INCOME | EXPENSE
    val category: String,
    val account: String = "Cash",
    val localDate: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "budget")
data class Budget(
    @PrimaryKey val category: String,
    val monthlyAmount: Double
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM txn ORDER BY localDate DESC, id DESC LIMIT 300")
    fun observeRecent(): Flow<List<Txn>>

    @Query("SELECT * FROM txn WHERE localDate >= :from ORDER BY localDate DESC")
    fun observeSince(from: String): Flow<List<Txn>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(txn: Txn)

    @Delete
    suspend fun delete(txn: Txn)

    @Query("SELECT * FROM budget")
    fun observeBudgets(): Flow<List<Budget>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBudget(budget: Budget)
}

class FinanceRepository(private val dao: FinanceDao) {
    fun recent() = dao.observeRecent()
    fun since(date: String) = dao.observeSince(date)
    fun budgets() = dao.observeBudgets()
    suspend fun add(amount: Double, kind: String, category: String, note: String) {
        dao.insert(
            Txn(
                amount = amount,
                kind = kind,
                category = category.ifBlank { "Uncategorised" },
                localDate = today(),
                note = note
            )
        )
    }
    suspend fun remove(txn: Txn) = dao.delete(txn)
    suspend fun setBudget(category: String, amount: Double) = dao.upsertBudget(Budget(category, amount))
}

val DEFAULT_CATEGORIES = listOf("Food", "Transport", "Bills", "Groceries", "Shopping", "Health", "Family", "Other")

class FinanceViewModel(private val repository: FinanceRepository) : ViewModel() {

    private val monthStart = LocalDate.now().withDayOfMonth(1).toString()

    val recent: StateFlow<List<Txn>> = repository.recent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val thisMonth: StateFlow<List<Txn>> = repository.since(monthStart)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(amount: String, kind: String, category: String, note: String) {
        val value = amount.toDoubleOrNull() ?: return
        if (value <= 0) return
        viewModelScope.launch { repository.add(value, kind, category, note) }
    }

    fun delete(txn: Txn) {
        viewModelScope.launch { repository.remove(txn) }
    }
}

@Composable
fun FinanceScreen(container: AppContainer) {
    val vm: FinanceViewModel = viewModel(factory = vmFactory { FinanceViewModel(container.financeRepository) })
    val recent by vm.recent.collectAsState()
    val month by vm.thisMonth.collectAsState()

    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("EXPENSE") }
    var category by remember { mutableStateOf(DEFAULT_CATEGORIES.first()) }

    val income = month.filter { it.kind == "INCOME" }.sumOf { it.amount }
    val spent = month.filter { it.kind == "EXPENSE" }.sumOf { it.amount }
    val todaySpend = month.filter { it.kind == "EXPENSE" && it.localDate == today() }.sumOf { it.amount }
    val byCategory = month.filter { it.kind == "EXPENSE" }
        .groupBy { it.category }
        .map { it.key to it.value.sumOf { t -> t.amount } }
        .sortedByDescending { it.second }
        .take(5)

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ModuleTitle("💰  Finance", "This month")

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(
                "In" to income,
                "Out" to spent,
                "Net" to (income - spent)
            ).forEach { (label, value) ->
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(fmtAmount(value), style = MonoNumber)
                        Text(label, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("Today: ${fmtAmount(todaySpend)}", style = MonoNumber,
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = kind == "EXPENSE", onClick = { kind = "EXPENSE" }, label = { Text("Expense") })
            FilterChip(selected = kind == "INCOME", onClick = { kind = "INCOME" }, label = { Text("Income") })
        }

        Spacer(Modifier.height(8.dp))
        InlineAddRow(
            value = amount,
            label = "Amount",
            numeric = true,
            onValueChange = { amount = it },
            onSubmit = {
                vm.add(amount, kind, category, note)
                amount = ""
                note = ""
            }
        )
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("Note (optional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DEFAULT_CATEGORIES.take(4).forEach { c ->
                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
            }
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DEFAULT_CATEGORIES.drop(4).forEach { c ->
                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
            }
        }

        if (byCategory.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("Top categories", style = MaterialTheme.typography.titleMedium)
            byCategory.forEach { (cat, total) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(cat, style = MaterialTheme.typography.bodyMedium)
                    Text(fmtAmount(total), style = MonoNumber)
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        AiPanel(
            settings = container.settingsRepository,
            label = "Money help",
            contextPrompt = "This month: income ${'$'}{fmtAmount(income)}, spent ${'$'}{fmtAmount(spent)}. " +
                "By category: " + byCategory.joinToString(", ") { "${'$'}{it.first} ${'$'}{fmtAmount(it.second)}" } +
                ". Currency is PKR.",
            starterQuestion = "Where am I overspending, and what would you cut first?",
            system = "You are a blunt, practical personal finance advisor familiar with Pakistani costs " +
                "and PKR. Work from the actual numbers. You are not a licensed advisor — say so if the " +
                "question moves into investment or tax advice."
        )
        Spacer(Modifier.height(14.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)

        LazyColumn(Modifier.fillMaxSize()) {
            items(recent, key = { it.id }) { txn ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(txn.category, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            prettyDate(txn.localDate) + if (txn.note.isBlank()) "" else " · ${txn.note}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        (if (txn.kind == "EXPENSE") "-" else "+") + fmtAmount(txn.amount),
                        style = MonoNumber,
                        color = if (txn.kind == "EXPENSE") MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = { vm.delete(txn) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete transaction")
                    }
                }
                Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
            }
        }
    }
}
