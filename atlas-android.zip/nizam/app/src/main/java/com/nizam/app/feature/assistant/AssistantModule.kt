package com.nizam.app.feature.assistant

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.fmtAmount
import com.nizam.app.core.today
import com.nizam.app.core.vmFactory
import com.nizam.app.feature.agent.Actions
import com.nizam.app.net.Ai
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate

data class ChatTurn(val id: Long, val fromUser: Boolean, val text: String)

class AssistantViewModel(private val container: AppContainer) : ViewModel() {

    private val _turns = MutableStateFlow<List<ChatTurn>>(emptyList())
    val turns: StateFlow<List<ChatTurn>> = _turns.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private var nextId = 1L
    private var useMyData = true

    fun setUseMyData(value: Boolean) { useMyData = value }

    fun clear() { _turns.value = emptyList() }
    fun usingMyData() = useMyData

    /** Builds a compact snapshot of the user's own data for grounding. */
    private suspend fun snapshot(): String {
        val tasks = container.taskRepository.all().first()
        val month = container.financeRepository
            .since(LocalDate.now().withDayOfMonth(1).toString()).first()
        val meals = container.dietRepository.day(today()).first()
        val sets = container.gymRepository.sets().first()
        val sessions = container.learningRepository.sessions().first()
        val prayer = container.prayerRepository.day(today()).first()
        val entries = container.diaryRepository.entries().first()
        val goals = container.missionRepository.goals().first()
        val missionsToday = container.missionRepository.today().first()

        val open = tasks.filter { it.completedAt == null }
        val spent = month.filter { it.kind == "EXPENSE" }.sumOf { it.amount }
        val income = month.filter { it.kind == "INCOME" }.sumOf { it.amount }
        val topCats = month.filter { it.kind == "EXPENSE" }
            .groupBy { it.category }
            .map { it.key to it.value.sumOf { t -> t.amount } }
            .sortedByDescending { it.second }.take(4)
        val weekSets = sets.filter { it.localDate >= LocalDate.now().minusDays(7).toString() }
        val weekStudy = sessions.filter { it.localDate >= LocalDate.now().minusDays(7).toString() }
            .sumOf { it.minutes }
        val recentMood = entries.take(7).map { it.mood }

        return buildString {
            appendLine("Today is ${today()}.")
            appendLine("Open tasks (${open.size}): " + open.take(12).joinToString("; ") { it.title })
            appendLine("This month — income ${fmtAmount(income)}, spent ${fmtAmount(spent)}.")
            if (topCats.isNotEmpty()) {
                appendLine("Top spending: " + topCats.joinToString(", ") { "${it.first} ${fmtAmount(it.second)}" })
            }
            appendLine("Today's food: ${meals.sumOf { it.kcal }.toInt()} kcal across ${meals.size} items.")
            appendLine("Training last 7 days: ${weekSets.size} sets, " +
                "exercises ${weekSets.map { it.exercise }.distinct().take(8).joinToString(", ")}.")
            appendLine("Study last 7 days: ${weekStudy / 60}h ${weekStudy % 60}m.")
            prayer?.let {
                val logged = listOf(it.fajr, it.dhuhr, it.asr, it.maghrib, it.isha).count { s -> s != "NOT_PRAYED" }
                appendLine("Prayers logged today: $logged of 5.")
            }
            if (goals.isNotEmpty()) {
                appendLine("Active goals: " + goals.joinToString("; ") {
                    it.title + (if (it.deadline.isBlank()) "" else " by ${it.deadline}")
                })
            }
            if (missionsToday.isNotEmpty()) {
                appendLine("Today's missions: " + missionsToday.joinToString("; ") {
                    (if (it.completedAt != null) "[done] " else "[open] ") + it.title
                })
            }
            if (recentMood.isNotEmpty()) {
                appendLine("Recent mood ratings (newest first): ${recentMood.joinToString(", ")}")
            }
        }
    }

    fun send(text: String) {
        if (text.isBlank()) return
        val question = text.trim()
        _turns.value = _turns.value + ChatTurn(nextId++, true, question)
        viewModelScope.launch {
            _busy.value = true
            val reply = try {
                val key = container.settingsRepository.geminiApiKey.first()
                val model = container.settingsRepository.geminiModel.first()
                val history = _turns.value.takeLast(11).joinToString("\n") {
                    (if (it.fromUser) "User: " else "Assistant: ") + it.text
                }
                val grounding = if (useMyData) "Here is the user's own current data:\n${snapshot()}\n\n" else ""
                val raw = Ai.generate(
                    settings = container.settingsRepository,
                    prompt = grounding + "Conversation so far:\n$history\n\nAnswer the last user message.",
                    system = "You are Atlas, the user's personal assistant living inside their own " +
                        "life app. You can see their tasks, spending, training, study, prayers, mood, " +
                        "goals and missions when provided, and you can CHANGE things in the app by " +
                        "returning actions.\n\n" +
                        "Available actions:\n" + Actions.CATALOGUE + "\n\n" +
                        "ALWAYS reply with a single JSON object, nothing else:\n" +
                        "{\"reply\": \"what you say to the user\", " +
                        "\"actions\": [{\"action\": \"add_task\", \"args\": {\"title\": \"...\"}}]}\n" +
                        "Use an empty actions array when the user only wants to talk. Take action when " +
                        "they ask for something that maps to the catalogue — don't tell them to go and " +
                        "tap it themselves. Never invent data you weren't given; say you don't have it. " +
                        "Be direct and concrete, reference their real numbers, and skip filler.",
                    maxOutputTokens = 4096
                )

                val parsed = runCatching { JSONObject(Ai.cleanJson(raw)) }.getOrNull()
                if (parsed == null) {
                    raw
                } else {
                    val text = parsed.optString("reply", raw)
                    val actions = parsed.optJSONArray("actions")
                    val done = mutableListOf<String>()
                    if (actions != null) {
                        for (i in 0 until actions.length()) {
                            val a = actions.getJSONObject(i)
                            val result = Actions.run(
                                container,
                                a.optString("action"),
                                a.optJSONObject("args") ?: JSONObject()
                            )
                            done.add((if (result.ok) "✓ " else "✕ ") + result.summary)
                        }
                    }
                    if (done.isEmpty()) text else text + "\n\n" + done.joinToString("\n")
                }
            } catch (e: Ai.MissingKeyException) {
                "Add your Gemini API key in Settings, then I can answer."
            } catch (e: Exception) {
                "That failed: ${e.message}"
            }
            _turns.value = _turns.value + ChatTurn(nextId++, false, reply)
            _busy.value = false
        }
    }
}

@Composable
fun AssistantScreen(container: AppContainer) {
    val vm: AssistantViewModel = viewModel(factory = vmFactory { AssistantViewModel(container) })
    val turns by vm.turns.collectAsState()
    val busy by vm.busy.collectAsState()

    var draft by remember { mutableStateOf("") }
    var useData by remember { mutableStateOf(true) }

    val suggestions = listOf(
        "What should I focus on today?",
        "Build me a module to track my bike's fuel",
        "Log 500ml water and mark Asr prayed on time",
        "Set me a goal to earn 30,000 this week",
        "Where is my money going this month?"
    )

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ModuleTitle("✦  Assistant", "Sees your data — and can change things in the app")

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(
                selected = useData,
                onClick = { useData = !useData; vm.setUseMyData(useData) },
                label = { Text(if (useData) "Using my data" else "Data off") }
            )
            if (turns.isNotEmpty()) {
                FilterChip(selected = false, onClick = { vm.clear() }, label = { Text("Clear chat") })
            }
        }

        Spacer(Modifier.height(10.dp))

        if (turns.isEmpty()) {
            suggestions.forEach { s ->
                Text(
                    "• $s",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.send(s) }
                        .padding(vertical = 8.dp)
                )
            }
        }

        LazyColumn(Modifier.weight(1f)) {
            items(turns, key = { it.id }) { turn ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = if (turn.fromUser) MaterialTheme.colorScheme.surfaceVariant
                    else MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Text(
                        turn.text,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
            if (busy) {
                item {
                    Spacer(Modifier.height(8.dp))
                    CircularProgressIndicator()
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                label = { Text("Message") },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(enabled = !busy, onClick = { vm.send(draft); draft = "" }) { Text("Send") }
        }
    }
}
