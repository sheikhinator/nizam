package com.nizam.app.feature.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.nizam.app.MainActivity
import com.nizam.app.NizamApplication
import com.nizam.app.core.hourToClock
import com.nizam.app.core.today
import com.nizam.app.feature.prayer.PrayerTimes
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.LocalTime
import java.util.concurrent.TimeUnit

object Notifications {

    const val CHANNEL_PRAYER = "atlas_prayer"
    const val CHANNEL_NUDGE = "atlas_nudge"

    fun createChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_PRAYER, "Prayer times", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "Alerts at each prayer time" }
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_NUDGE, "Reminders", NotificationManager.IMPORTANCE_DEFAULT)
                .apply { description = "Missions, habits and the evening review" }
        )
    }

    fun post(context: Context, channel: String, id: Int, title: String, body: String) {
        if (NotificationManagerCompat.from(context).areNotificationsEnabled().not()) return
        val intent = PendingIntent.getActivity(
            context, id,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(intent)
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(id, notification) }
    }

    fun schedule(context: Context) {
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "atlas-checks",
            ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<AtlasWorker>(15, TimeUnit.MINUTES).build()
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork("atlas-checks")
    }
}

private fun attention(c: Context, now: Double) {
    val a = com.nizam.app.feature.attention.Attention
    // digest at 13:00, 18:00, 21:00 (the worker runs every 15 min, so each window is 15 min wide)
    if (listOf(13.0, 18.0, 21.0).any { now >= it && now < it + 0.25 }) {
        val held = a.takeHeld(c)
        if (held.isNotEmpty()) Notifications.post(c, Notifications.CHANNEL_NUDGE, 210,
            "${held.size} held notifications", held.take(12).joinToString("\n"))
    }
    val wind = a.windDownHour(c)
    val today = java.time.LocalDate.now().toString()
    if (wind >= 0 && now.toInt() == wind && a.windDoneOn(c) != today) {
        a.markWind(c, today)
        com.nizam.app.feature.phone.PhoneActions.doNotDisturb(c, true)
        com.nizam.app.feature.shield.Shield.activate(c, 120)
        Notifications.post(c, Notifications.CHANNEL_NUDGE, 211, "Wind-down", "Screens are winding down for the night. Rest well.")
    }
    if (a.eyeBreaks(c) && System.currentTimeMillis() - a.lastEyeBreak(c) > 20 * 60_000L &&
        c.getSystemService(android.os.PowerManager::class.java).isInteractive &&
        com.nizam.app.feature.phone.PhoneActions2.hasUsageAccess(c)) {
        val usm = c.getSystemService(android.app.usage.UsageStatsManager::class.java)
        val used = usm.queryAndAggregateUsageStats(System.currentTimeMillis() - 20 * 60_000L, System.currentTimeMillis())
            .values.sumOf { it.totalTimeInForeground }
        if (used > 15 * 60_000L) {
            a.markEyeBreak(c)
            Notifications.post(c, Notifications.CHANNEL_NUDGE, 212, "Eye break", "Look at something 20 feet away for 20 seconds. Stand up.")
        }
    }
}

/**
 * Runs every 15 minutes. Checks whether a prayer just came in, whether missions are still open
 * late in the day, and whether the evening review is outstanding.
 */
class AtlasWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as? NizamApplication)?.container ?: return Result.success()
        val settings = container.settingsRepository
        if (!settings.notificationsOn.first()) return Result.success()

        val now = LocalTime.now().let { it.hour + it.minute / 60.0 }

        runCatching {
            val times = PrayerTimes.calculate(
                date = LocalDate.now(),
                latitude = settings.latitude.first(),
                longitude = settings.longitude.first(),
                method = runCatching {
                    PrayerTimes.Method.valueOf(settings.prayerMethod.first())
                }.getOrElse { PrayerTimes.Method.KARACHI },
                hanafiAsr = settings.hanafiAsr.first()
            )
            val day = container.prayerRepository.day(today()).first()
            listOf(
                Triple("Fajr", times.fajr, day?.fajr),
                Triple("Dhuhr", times.dhuhr, day?.dhuhr),
                Triple("Asr", times.asr, day?.asr),
                Triple("Maghrib", times.maghrib, day?.maghrib),
                Triple("Isha", times.isha, day?.isha)
            ).forEachIndexed { index, (name, time, status) ->
                // Fired if the prayer came in within the last 16 minutes and isn't logged yet
                if (!time.isNaN() && now >= time && now - time < 0.27 &&
                    (status == null || status == "NOT_PRAYED")
                ) {
                    Notifications.post(
                        applicationContext, Notifications.CHANNEL_PRAYER, 100 + index,
                        "$name — ${hourToClock(time)}",
                        "Time for $name. Tap to log it."
                    )
                }
            }
        }

        runCatching { com.nizam.app.feature.widget.TodayWidget.refresh(applicationContext) }
        runCatching { attention(applicationContext, now) }

        // Missions complete themselves in the background now, not only when the screen opens.
        runCatching { container.missionRepository.verifyToday() }

        // First run after 6am generates the day's missions if none exist yet.
        runCatching {
            if (now >= 6.0 && settings.geminiApiKey.first().isNotBlank() ||
                now >= 6.0 && settings.openRouterKey.first().isNotBlank() ||
                now >= 6.0 && settings.customUrl.first().isNotBlank()
            ) container.missionRepository.generateDaily(force = false)
        }

        // Keep the exact prayer alarms current (they're rescheduled daily).
        runCatching { PrayerAlarms.scheduleToday(applicationContext) }

        runCatching {
            val missions = container.missionRepository.today().first()
            val open = missions.count { it.completedAt == null }
            if (open > 0 && now >= 19.0 && now < 19.3) {
                Notifications.post(
                    applicationContext, Notifications.CHANNEL_NUDGE, 200,
                    "$open missions still open",
                    missions.firstOrNull { it.completedAt == null }?.title.orEmpty()
                )
            }
        }

        runCatching {
            if (now >= 21.5 && now < 21.8) {
                val reviewed = container.selfRepository.reviews().first()
                    .any { it.kind == "DAILY" && it.localDate == today() }
                if (!reviewed) {
                    Notifications.post(
                        applicationContext, Notifications.CHANNEL_NUDGE, 201,
                        "Close the day",
                        "Two minutes: what went well, what didn't, one change tomorrow."
                    )
                }
            }
        }

        return Result.success()
    }
}
