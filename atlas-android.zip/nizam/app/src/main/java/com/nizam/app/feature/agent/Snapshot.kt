package com.nizam.app.feature.agent

import com.nizam.app.AppContainer
import com.nizam.app.core.fmtAmount
import com.nizam.app.core.today
import com.nizam.app.feature.progress.Xp
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/** Everything the agent should know about the app's current state, in one compact block. */
object Snapshot {

    suspend fun of(c: AppContainer): String {
        val summary = Xp.summarise(c)
        val tasks = c.taskRepository.all().first().filter { it.completedAt == null }
        val month = c.financeRepository.since(LocalDate.now().withDayOfMonth(1).toString()).first()
        val meals = c.dietRepository.day(today()).first()
        val sets = c.gymRepository.sets().first().filter { it.localDate == today() }
        val prayer = c.prayerRepository.day(today()).first()
        val goals = c.missionRepository.goals().first()
        val missions = c.missionRepository.today().first()
        val specs = c.dynamicRepository.specs().first()
        val books = c.bookRepository.all().first()
        val courses = c.courseRepository.courses().first()
        val theme = c.settingsRepository.accentHex.first()

        val spent = month.filter { it.kind == "EXPENSE" }.sumOf { it.amount }
        val income = month.filter { it.kind == "INCOME" }.sumOf { it.amount }

        val profile = runCatching { org.json.JSONObject(c.settingsRepository.profileJson.first()) }
            .getOrElse { org.json.JSONObject() }
        return buildString {
            if (profile.length() > 0) {
                appendLine("WHO THEY ARE (their own profile — use it, don't ask for it again):")
                profile.keys().forEach { k ->
                    val v = profile.optString(k)
                    if (v.isNotBlank()) appendLine("  $k: $v")
                }
                appendLine()
            }
            appendLine("Today: ${today()} (${LocalDate.now().dayOfWeek}). Lahore, Pakistan. PKR.")
            appendLine("Level ${summary.level}, streak ${summary.streak} days, best ${summary.bestStreak}.")
            appendLine("Open tasks (${tasks.size}): " + tasks.take(10).joinToString("; ") { it.title })
            appendLine("This month: income ${fmtAmount(income)}, spent ${fmtAmount(spent)}.")
            appendLine("Today: ${meals.sumOf { it.kcal }.toInt()} kcal, ${sets.size} sets logged.")
            prayer?.let {
                val logged = listOf(it.fajr, it.dhuhr, it.asr, it.maghrib, it.isha)
                    .count { s -> s != "NOT_PRAYED" }
                appendLine("Prayers logged today: $logged of 5.")
            }
            if (goals.isNotEmpty()) appendLine("Goals: " + goals.joinToString("; ") { it.title })
            if (missions.isNotEmpty()) {
                appendLine("Missions today: " + missions.joinToString("; ") {
                    (if (it.completedAt != null) "[done] " else "[open] ") + it.title
                })
            }
            appendLine("Modules installed: " + specs.joinToString(", ") { "${it.name}(${it.key})" })
            if (books.isNotEmpty()) {
                appendLine("Books: " + books.take(8).joinToString("; ") { "${it.title} [${it.status}]" })
            }
            if (courses.isNotEmpty()) appendLine("Courses: " + courses.joinToString("; ") { it.title })
            appendLine("Theme: " + theme.ifBlank { "system default" })
        }
    }
}
