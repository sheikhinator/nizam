package com.nizam.app.ui.screens.modules

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.feature.dynamic.parseColour
import com.nizam.app.ui.nav.Routes
import com.nizam.app.ui.theme.DisplayFamily
import com.nizam.app.ui.theme.Spine

private data class Tile(
    val emoji: String,
    val name: String,
    val route: String,
    val colour: Color,
    val group: String
)

@Composable
fun ModulesScreen(container: AppContainer, onOpen: (String) -> Unit) {
    val specs by container.dynamicRepository.specs().collectAsState(initial = emptyList())
    var filter by remember { mutableStateOf("All") }

    val core = listOf(
        Tile("⚖️", "Council", Routes.COUNCIL, Spine.Diary, "Core"),
        Tile("✦", "Curator", Routes.ASSISTANT, Spine.Learning, "Core"),
        Tile("⚙️", "Settings", Routes.SETTINGS, Spine.Notes, "Core"),
        Tile("🎯", "Missions", Routes.MISSIONS, Spine.Survival, "Core"),
        Tile("🧭", "Self", Routes.SELF, Spine.Diary, "Core"),
        Tile("📈", "Insights", Routes.INSIGHTS, Spine.Diet, "Core"),
        Tile("🔎", "Search", Routes.SEARCH, Spine.Notes, "Core"),

        Tile("✅", "Tasks", Routes.TASKS, Spine.Tasks, "Daily"),
        Tile("🕌", "Prayer", Routes.PRAYER, Spine.Prayer, "Faith"),
        Tile("📖", "Quran", Routes.QURAN, Spine.Scripture, "Faith"),
        Tile("📜", "Hadith", Routes.HADITH, Spine.Scripture, "Faith"),

        Tile("💰", "Finance", Routes.FINANCE, Spine.Finance, "Life"),
        Tile("🥗", "Diet", Routes.DIET, Spine.Diet, "Body"),
        Tile("🏋️", "Gym", Routes.GYM, Spine.Gym, "Body"),

        Tile("🎓", "Courses", Routes.COURSES, Spine.Learning, "Mind"),
        Tile("🧠", "Learning", Routes.LEARNING, Spine.Learning, "Mind"),
        Tile("🗒️", "Notes", Routes.NOTES, Spine.Notes, "Mind"),
        Tile("📚", "Library", Routes.LIBRARY, Spine.Library, "Mind"),
        Tile("✍️", "Diary", Routes.DIARY, Spine.Diary, "Mind"),
        Tile("💬", "Quotes", Routes.QUOTES, Spine.Diary, "Mind"),

        Tile("🔒", "Vault", Routes.VAULT, Spine.Survival, "Tools"),
        Tile("🧰", "Toolkit", Routes.TOOLKIT, Spine.Gym, "Tools"),
        Tile("📱", "Phone", Routes.PHONE, Spine.Learning, "Core"),
        Tile("🌐", "Browser", Routes.BROWSER, Spine.Notes, "Tools"),
        Tile("📰", "News", Routes.NEWS, Spine.Finance, "Tools"),
        Tile("⛑️", "Survival", Routes.SURVIVAL, Spine.Survival, "Tools")
    )

    val dynamic = specs.map {
        Tile(it.emoji, it.name, Routes.dynamic(it.key), parseColour(it.colorHex, Spine.Notes), "Tracked")
    }

    val all = core + dynamic
    val groups = listOf("All") + all.map { it.group }.distinct()
    val visible = if (filter == "All") all else all.filter { it.group == filter }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Modules",
                style = MaterialTheme.typography.headlineMedium.copy(fontFamily = DisplayFamily),
                modifier = Modifier.weight(1f)
            )
            Text(
                "${all.size}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(visible) { tile ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .clickable { onOpen(tile.route) }
                ) {
                    Column(
                        Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            Modifier
                                .size(34.dp)
                                .background(tile.colour.copy(alpha = 0.18f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(tile.emoji, style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tile.name,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            maxLines = 1
                        )
                        Box(
                            Modifier
                                .width(18.dp)
                                .height(2.dp)
                                .background(tile.colour, RoundedCornerShape(1.dp))
                        )
                    }
                }
            }
        }
    }
}
