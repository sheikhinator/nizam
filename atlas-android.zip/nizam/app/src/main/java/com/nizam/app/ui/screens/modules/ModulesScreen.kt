package com.nizam.app.ui.screens.modules

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Text
import kotlinx.coroutines.launch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.feature.dynamic.parseColour
import com.nizam.app.ui.nav.Routes
import com.nizam.app.ui.theme.DisplayFamily
import com.nizam.app.ui.theme.Spine

private data class Tile(
    val emoji: String,
    val name: String,
    val route: String,
    val colour: Color,
    val group: String,
    val dynamicKey: String? = null      // set for modules you (or the Curator) created
)

@Composable
fun ModulesScreen(container: AppContainer, onOpen: (String) -> Unit) {
    val specs by container.dynamicRepository.specs().collectAsState(initial = emptyList())
    var filter by remember { mutableStateOf("All") }

    val core = listOf(

        Tile("✅", "Tasks", Routes.TASKS, Spine.Tasks, "Daily"),
        Tile("🕌", "Prayer", Routes.PRAYER, Spine.Prayer, "Faith"),
        Tile("📖", "Quran", Routes.QURAN, Spine.Scripture, "Faith"),
        Tile("📜", "Hadith", Routes.HADITH, Spine.Scripture, "Faith"),

        Tile("💰", "Finance", Routes.FINANCE, Spine.Finance, "Money"),
        Tile("🥗", "Diet", Routes.DIET, Spine.Diet, "Body"),
        Tile("🏋️", "Gym", Routes.GYM, Spine.Gym, "Body"),

        Tile("🎓", "Courses", Routes.COURSES, Spine.Learning, "Mind"),
        Tile("🧠", "Learning", Routes.LEARNING, Spine.Learning, "Mind"),
        Tile("🗒️", "Notes", Routes.NOTES, Spine.Notes, "Mind"),
        Tile("📚", "Library", Routes.LIBRARY, Spine.Library, "Mind"),
        Tile("✍️", "Diary", Routes.DIARY, Spine.Diary, "Mind"),
        Tile("💬", "Quotes", Routes.QUOTES, Spine.Diary, "Mind"),
        Tile("🗣", "Language", Routes.LANGUAGE, Spine.Learning, "Mind"),
        Tile("📷", "Scanner", Routes.SCAN, Spine.Gym, "Tools"),
        Tile("🧰", "Toolkit", Routes.TOOLKIT, Spine.Gym, "Tools"),
        Tile("🌐", "Browser", Routes.BROWSER, Spine.Notes, "Tools"),
        Tile("📰", "News", Routes.NEWS, Spine.Finance, "Tools"),
        Tile("⛑️", "Survival", Routes.SURVIVAL, Spine.Survival, "Tools")
    )

    val dynamic = specs.map {
        Tile(it.emoji, it.name, Routes.dynamic(it.key), parseColour(it.colorHex, Spine.Notes), "Tracked", it.key)
    }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val hidden by container.settingsRepository.hiddenTiles.collectAsState(initial = emptySet())
    val savedOrder by container.settingsRepository.tileOrder.collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<Tile?>(null) }

    // Your order first, then anything new appended — so a freshly created module never vanishes
    val all = (core + dynamic).let { tiles ->
        val byRoute = tiles.associateBy { it.route }
        val areas = listOf("Daily", "Body", "Mind", "Money", "Faith", "Tracked", "Tools")
        val natural = tiles.sortedBy { areas.indexOf(it.group).let { i -> if (i < 0) 99 else i } }
        savedOrder.mapNotNull { byRoute[it] } + natural.filterNot { it.route in savedOrder }
    }
    val visible = if (editing) all else all.filterNot { it.route in hidden }

    fun move(tile: Tile, delta: Int) {
        val order = all.map { it.route }.toMutableList()
        val i = order.indexOf(tile.route)
        val j = (i + delta).coerceIn(0, order.lastIndex)
        if (i == j) return
        order.removeAt(i); order.add(j, tile.route)
        scope.launch { container.settingsRepository.setTileOrder(order) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Life",
                style = MaterialTheme.typography.headlineMedium.copy(fontFamily = DisplayFamily),
                modifier = Modifier.weight(1f)
            )
            Text(
                if (editing) "Done" else "Edit",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable(role = androidx.compose.ui.semantics.Role.Button) { editing = !editing }
                    .padding(8.dp)
            )
        }
        if (editing) {
            Text(
                "Reorder with the arrows. Hide tucks a module away; delete removes modules you created.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        confirmDelete?.let { tile ->
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Delete ${tile.name} and every entry in it?", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(top = 8.dp)) {
                        Text("Delete", color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.clickable {
                                scope.launch {
                                    container.dynamicRepository.spec(tile.dynamicKey ?: "")
                                        ?.let { container.dynamicRepository.deleteModule(it) }
                                    confirmDelete = null
                                }
                            })
                        Text("Keep it", modifier = Modifier.clickable { confirmDelete = null })
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(visible) { tile ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (editing && tile.route in hidden) MaterialTheme.colorScheme.surfaceVariant
                    else MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .clickable { if (!editing) onOpen(tile.route) }
                ) {
                    Column(
                        Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            Modifier
                                .size(34.dp)
                                .background(tile.colour.copy(alpha = 0.18f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(tile.emoji, style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tile.group.uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            color = tile.colour
                        )
                        Text(
                            tile.name,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            maxLines = 1
                        )
                        if (editing) {
                            val isHidden = tile.route in hidden
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                androidx.compose.material3.Icon(
                                    androidx.compose.material.icons.Icons.Filled.KeyboardArrowLeft, contentDescription = "Move earlier",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp).clickable { move(tile, -1) }
                                )
                                androidx.compose.material3.Icon(
                                    androidx.compose.material.icons.Icons.Filled.KeyboardArrowRight, contentDescription = "Move later",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp).clickable { move(tile, 1) }
                                )
                                androidx.compose.material3.Icon(
                                    if (isHidden) androidx.compose.material.icons.Icons.Filled.VisibilityOff
                                    else androidx.compose.material.icons.Icons.Filled.Visibility,
                                    contentDescription = if (isHidden) "Show" else "Hide",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp).clickable {
                                        scope.launch {
                                            container.settingsRepository.setHiddenTiles(
                                                if (isHidden) hidden - tile.route else hidden + tile.route
                                            )
                                        }
                                    }
                                )
                                if (tile.dynamicKey != null) {
                                    androidx.compose.material3.Icon(
                                    androidx.compose.material.icons.Icons.Filled.Delete, contentDescription = "Delete module",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp).clickable { confirmDelete = tile }
                                )
                                }
                            }
                        } else {
                            Box(
                                Modifier
                                    .width(18.dp)
                                    .height(2.dp)
                                    .background(tile.colour, RoundedCornerShape(1.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}
