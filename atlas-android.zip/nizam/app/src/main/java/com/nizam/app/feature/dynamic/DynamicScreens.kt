package com.nizam.app.feature.dynamic

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.AiPanel
import com.nizam.app.core.prettyDate
import com.nizam.app.ui.theme.DisplayFamily
import com.nizam.app.ui.theme.MonoNumber
import kotlinx.coroutines.launch
import org.json.JSONObject

fun parseColour(hex: String, fallback: Color): Color = runCatching {
    Color(android.graphics.Color.parseColor(hex))
}.getOrElse { fallback }

@Composable
fun DynamicModuleScreen(container: AppContainer, moduleKey: String) {
    val repository = container.dynamicRepository
    val scope = rememberCoroutineScope()
    val specs by repository.specs().collectAsState(initial = emptyList())
    val spec = specs.firstOrNull { it.key == moduleKey }

    if (spec == null) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("Module not found", style = MaterialTheme.typography.titleLarge)
            Text(
                "It may have been disabled in Modules.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val entries by repository.entries(moduleKey).collectAsState(initial = emptyList())
    val accent = parseColour(spec.colorHex, MaterialTheme.colorScheme.primary)

    var title by remember(moduleKey) { mutableStateOf("") }
    val values = remember(moduleKey) { mutableStateMapOf<String, String>() }
    var expanded by remember(moduleKey) { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(accent.copy(alpha = 0.16f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { Text(spec.emoji, style = MaterialTheme.typography.titleLarge) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    spec.name,
                    style = MaterialTheme.typography.headlineMedium.copy(fontFamily = DisplayFamily)
                )
                Text(
                    spec.tagline,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(14.dp))

        Surface(
            shape = MaterialTheme.shapes.medium,
            color = accent.copy(alpha = 0.10f),
            modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }
        ) {
            Text(
                if (expanded) "Close" else "＋  Add to ${spec.name}",
                style = MaterialTheme.typography.titleMedium,
                color = accent,
                modifier = Modifier.padding(14.dp)
            )
        }

        if (expanded) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).weight(1f, false)) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                spec.fields.forEach { field ->
                    when (field.type) {
                        "CHOICE" -> {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                field.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                field.options.take(3).forEach { option ->
                                    FilterChip(
                                        selected = values[field.key] == option,
                                        onClick = { values[field.key] = option },
                                        label = { Text(option) }
                                    )
                                }
                            }
                            if (field.options.size > 3) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    field.options.drop(3).take(3).forEach { option ->
                                        FilterChip(
                                            selected = values[field.key] == option,
                                            onClick = { values[field.key] = option },
                                            label = { Text(option) }
                                        )
                                    }
                                }
                            }
                        }

                        "RATING" -> {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                field.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                (1..5).forEach { n ->
                                    val on = (values[field.key]?.toIntOrNull() ?: 0) >= n
                                    Text(
                                        if (on) "★" else "☆",
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = if (on) accent else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.clickable { values[field.key] = n.toString() }
                                    )
                                }
                            }
                        }

                        "BOOL" -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = values[field.key] == "true",
                                    onCheckedChange = {
                                        values[field.key] = if (it) "true" else "false"
                                    }
                                )
                                Text(field.label, style = MaterialTheme.typography.bodyLarge)
                            }
                        }

                        else -> {
                            OutlinedTextField(
                                value = values[field.key].orEmpty(),
                                onValueChange = { values[field.key] = it },
                                label = { Text(field.label + if (field.suffix.isBlank()) "" else " (${field.suffix})") },
                                singleLine = field.type != "LONGTEXT",
                                keyboardOptions = if (field.type == "NUMBER")
                                    KeyboardOptions(keyboardType = KeyboardType.Decimal)
                                else KeyboardOptions.Default,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    enabled = title.isNotBlank(),
                    onClick = {
                        scope.launch {
                            repository.addEntry(moduleKey, title, values.toMap())
                            title = ""; values.clear(); expanded = false
                        }
                    }
                ) { Text("Save") }
                Spacer(Modifier.height(16.dp))
            }
        }

        Spacer(Modifier.height(14.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)

        if (entries.isEmpty()) {
            Spacer(Modifier.height(18.dp))
            Text(
                "Nothing here yet. ${spec.emoji}  Add your first and this fills up.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(entries, key = { it.id }) { entry ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(6.dp).background(accent, CircleShape)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                entry.title,
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                prettyDate(entry.localDate),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        val filled = spec.fields.mapNotNull { field ->
                            val v = entry.value(field.key)
                            if (v.isBlank()) null else field to v
                        }
                        if (filled.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            filled.forEach { (field, v) ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                    Text(
                                        field.label,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        if (field.type == "RATING") "★".repeat(v.toIntOrNull() ?: 0)
                                        else v + if (field.suffix.isBlank()) "" else " ${field.suffix}",
                                        style = if (field.type == "NUMBER") MonoNumber
                                        else MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "delete",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.clickable {
                                scope.launch { repository.deleteEntry(entry.id) }
                            }
                        )
                    }
                }
            }
            item {
                Spacer(Modifier.height(18.dp))
                AiPanel(
                    settings = container.settingsRepository,
                    label = "${spec.emoji}  Ask about ${spec.name.lowercase()}",
                    contextPrompt = "The user's ${spec.name} module (${spec.tagline}). Recent entries:\n" +
                        entries.take(25).joinToString("\n") { e ->
                            e.title + " — " + e.values().entries.joinToString(", ") { "${it.key}: ${it.value}" }
                        },
                    starterQuestion = "What patterns do you see, and what should I do next?"
                )
                Spacer(Modifier.height(48.dp))
            }
        }
    }
}
