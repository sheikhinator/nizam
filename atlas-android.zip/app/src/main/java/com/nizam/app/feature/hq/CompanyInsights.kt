package com.nizam.app.feature.hq

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.feature.agent.ApprovalInbox
import com.nizam.app.feature.agent.Crew
import com.nizam.app.feature.next.JsonStore
import com.nizam.app.feature.wild.AgentMeter
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import kotlin.math.ceil
import kotlin.math.floor

private data class WorkSample(
    val threadId: String,
    val goal: String,
    val category: String,
    val status: String,
    val at: Long,
    val toolEvents: Int,
    val failures: List<String>
)

private fun taskCategory(goal: String): String {
    val text = goal.lowercase()
    return when {
        listOf("budget", "spend", "cost", "invoice", "money", "finance").any { it in text } -> "Finance"
        listOf("write", "draft", "email", "message", "post", "copy").any { it in text } -> "Writing"
        listOf("plan", "schedule", "trip", "week", "event", "calendar").any { it in text } -> "Planning"
        listOf("research", "compare", "find", "source", "investigate").any { it in text } -> "Research"
        listOf("automate", "connector", "app", "device", "code", "setup").any { it in text } -> "Operations"
        else -> "General"
    }
}

private fun samplesFor(agentId: String, threads: List<JSONObject>): List<WorkSample> =
    threads.mapNotNull { thread ->
        val messages = thread.optJSONArray("messages") ?: return@mapNotNull null
        val events = (0 until messages.length()).mapNotNull { messages.optJSONObject(it) }
            .filter { it.optString("from") == agentId }
        if (events.isEmpty()) return@mapNotNull null
        WorkSample(
            threadId = thread.optString("id"),
            goal = thread.optString("goal", "Untitled assignment").substringAfter("Topic: ").lines().first().take(100),
            category = taskCategory(thread.optString("goal")),
            status = thread.optString("status"),
            at = events.maxOfOrNull { it.optLong("t") } ?: thread.optLong("updated", thread.optLong("created")),
            toolEvents = events.count { it.optString("kind") == "tool" },
            failures = events.filter {
                it.optString("kind") == "tool" && (it.optString("text").startsWith("✕") || it.optString("text").contains("FAILED", true))
            }.map { it.optString("text").take(180) }
        )
    }.sortedByDescending { it.at }

private object ExampleReviews {
    private fun store(c: android.content.Context) = JsonStore(c, "company_example_reviews", sealed = true)
    fun all(c: android.content.Context) = store(c).all()
    fun key(threadId: String, agentId: String) = "$threadId:$agentId"
    fun review(c: android.content.Context, sample: WorkSample, agentId: String, rating: String) {
        val s = store(c)
        val record = s.all().firstOrNull {
            it.optString("threadId") == sample.threadId && it.optString("agentId") == agentId
        } ?: JSONObject().put("threadId", sample.threadId).put("agentId", agentId)
        record.put("rating", rating).put("goal", sample.goal).put("at", System.currentTimeMillis())
        s.save(s.all().filterNot { it.optString("threadId") == sample.threadId && it.optString("agentId") == agentId } + record)
    }
}

@Composable
fun CompanyInsights(container: AppContainer) {
    val c = LocalContext.current
    val version = Crew.version
    val team = remember(version) { Crew.agents(c) }
    val profiles = remember(version) { team.associate { it.id to Company.profile(c, it) } }
    val stats = remember(version) { team.associate { it.id to Company.stats(c, it) } }
    val board = remember(version) { Company.board(c) }
    val threads = remember(version) { Crew.threads(c).all().sortedByDescending { it.optLong("updated", it.optLong("created")) } }
    val evidence = remember(version) { team.associate { it.id to samplesFor(it.id, threads) } }
    val reviews = remember(version) { ExampleReviews.all(c).associateBy { ExampleReviews.key(it.optString("threadId"), it.optString("agentId")) } }
    var replayId by remember { mutableStateOf("") }
    var fitQuery by remember { mutableStateOf("") }
    var batchDraft by remember { mutableStateOf("") }
    val names = remember(team) { team.associate { it.id to "${it.emoji} ${it.name}" } }
    val weekAgo = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
    val completedWeek = threads.count { it.optString("status") == "done" && it.optLong("updated", it.optLong("created")) >= weekAgo }
    val waiting = board.backlog.size
    val active = board.doing.size
    val review = board.review.size
    val running = threads.count { it.optString("status") == "running" }
    val parallelLimit = Hq.limit(c)
    val approvals = ApprovalInbox.pending(c).size
    val tokensToday = team.sumOf { AgentMeter.today(c, it.name).first }
    val dailyCap = Company.dailyCap(c)
    val batchTasks = batchDraft.lines().map { it.trim() }.filter { it.isNotBlank() }.distinct()
    val agentWork = waiting + active + batchTasks.size
    val perDay = completedWeek / 7.0
    val estimateDays = if (perDay > 0) ceil(agentWork / perDay).toInt() else null
    val lowDays = estimateDays?.let { floor(it * 0.75).toInt().coerceAtLeast(1) }
    val highDays = estimateDays?.let { ceil(it * 1.5).toInt().coerceAtLeast(lowDays ?: 1) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("HQ insights", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Read-only estimates from your team’s saved profiles, board and threads.", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        InsightSection("Expertise map", "Examples come from saved team threads. Configured permissions are not treated as demonstrated skill.") {
            if (team.isEmpty()) Text("No agents on the team yet.")
            team.forEach { agent ->
                val profile = profiles[agent.id]
                val department = Company.DEPTS.firstOrNull { it.id == profile?.dept }?.name ?: "Unassigned"
                val capabilityNames = agent.tools.mapNotNull { Crew.TOOLS[it] }
                val stat = stats[agent.id]
                val examples = evidence[agent.id].orEmpty()
                val commonTypes = examples.groupingBy { it.category }.eachCount().entries.sortedByDescending { it.value }.take(3)
                val reviewedCount = reviews.values.count { it.optString("agentId") == agent.id }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
                ) {
                    Text("${agent.emoji} ${agent.name} · ${agent.role}", fontWeight = FontWeight.SemiBold)
                    Text("$department · ${profile?.let { Company.LEVELS[it.level.coerceIn(0, Company.LEVELS.lastIndex)] } ?: "Associate"}",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Configured: ${capabilityNames.ifEmpty { listOf("Drafts only") }.joinToString()} · ${examples.sumOf { it.toolEvents }} recorded tool events",
                        modifier = Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall)
                    Text("${examples.size} assignment samples · ${commonTypes.joinToString { "${it.key} ${it.value}" }.ifBlank { "no task-type evidence yet" }}",
                        style = MaterialTheme.typography.bodySmall)
                    Text("${examples.sumOf { it.failures.size }} recorded tool failures · $reviewedCount reviewed examples · " +
                        "${examples.firstOrNull()?.let { DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(it.at)) } ?: "no recent sample"}",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    examples.filter { it.status == "done" }.take(2).forEach { sample ->
                        val currentReview = reviews[ExampleReviews.key(sample.threadId, agent.id)]?.optString("rating").orEmpty()
                        Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                            Text("Example: ${sample.goal}", style = MaterialTheme.typography.labelMedium, maxLines = 2)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = { ExampleReviews.review(c, sample, agent.id, "helpful"); Crew.version++ }) {
                                    Text(if (currentReview == "helpful") "✓ Helpful" else "Helpful")
                                }
                                OutlinedButton(onClick = { ExampleReviews.review(c, sample, agent.id, "needs_work"); Crew.version++ }) {
                                    Text(if (currentReview == "needs_work") "✓ Needs work" else "Needs work")
                                }
                            }
                        }
                    }
                    val failures = examples.flatMap { it.failures }.take(2)
                    if (failures.isNotEmpty()) Text("Failure notes: ${failures.joinToString(" · ")}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    Text("${stat?.done ?: 0} completed messages · ${Crew.busyAgents[agent.id]?.let { "working now" } ?: "available"}",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            OutlinedTextField(fitQuery, { fitQuery = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Suggest a fit for an assignment") }, singleLine = true)
            if (fitQuery.isNotBlank()) {
                val category = taskCategory(fitQuery)
                Text("Task type: $category. Suggestions do not route or promote anyone.")
                team.map { agent -> agent to evidence[agent.id].orEmpty().count { it.category == category } }
                    .sortedByDescending { it.second }.take(3).forEach { (agent, count) ->
                        Text("${agent.emoji} ${agent.name} · $count saved examples" +
                            if (count == 0) " · no evidence yet" else "", style = MaterialTheme.typography.bodySmall)
                    }
            }
        }

        InsightSection("Workload forecast", "Ranges use recent throughput and current team settings; estimates are not deadlines or promises.") {
            Text("$waiting queued · $active in progress · $review waiting for review", style = MaterialTheme.typography.titleSmall)
            Text("Parallelism: $running running of ${if (parallelLimit == 0) "paused" else parallelLimit} allowed · $approvals approvals waiting")
            Text("$completedWeek completed in 7 days (${String.format("%.1f", perDay)} per day)",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (dailyCap > 0) Text("Token budget: $tokensToday of $dailyCap used today · ${(dailyCap - tokensToday).coerceAtLeast(0)} remaining.")
            else Text("No team daily token cap is set, so usage cannot be projected against a budget.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (estimateDays == null) {
                Text("Not enough recent completions for a wait estimate.")
            } else {
                Text("Estimated wait range for $agentWork current and drafted items: $lowDays–$highDays days. " +
                    "Assumes a similar task mix and approval turnaround; approval waits can extend it.", style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(
                    progress = { if (agentWork == 0) 1f else (active.toFloat() / agentWork).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("In progress: $active of $agentWork queued, active and drafted items. Review items are excluded from throughput.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedTextField(batchDraft, { batchDraft = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Draft a batch · one task per line") }, minLines = 2)
            Text("${batchTasks.size} tasks will be queued separately. Set HQ queue limit to Paused to hold dispatch.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(enabled = batchTasks.isNotEmpty(), onClick = {
                batchTasks.forEach { Hq.enqueue(container, it) }
                batchDraft = ""
            }) { Text("Queue ${batchTasks.size} task${if (batchTasks.size == 1) "" else "s"}") }
        }

        InsightSection("Work replay", "Review the recorded event sequence. Nothing is replayed or reconstructed.") {
            if (threads.isEmpty()) Text("No saved work threads yet.")
            threads.take(10).forEach { thread ->
                val id = thread.optString("id")
                val expanded = replayId == id
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant).clickable {
                            replayId = if (expanded) "" else id
                        }.padding(12.dp)
                ) {
                    Text(thread.optString("goal", "Untitled work"), fontWeight = FontWeight.SemiBold, maxLines = 2)
                    Text("${thread.optString("status")} · ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(thread.optLong("updated", thread.optLong("created"))))}",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (expanded) {
                        Spacer(Modifier.height(8.dp))
                        val messages = thread.optJSONArray("messages")
                        val rows = if (messages == null) emptyList() else (0 until messages.length()).mapNotNull { messages.optJSONObject(it) }.takeLast(12)
                        if (rows.isEmpty()) Text("No saved messages in this thread.", style = MaterialTheme.typography.bodySmall)
                        rows.forEach { message ->
                            val sender = names[message.optString("from")] ?: message.optString("from").ifBlank { "System" }
                            val kind = message.optString("kind").replace('_', ' ')
                            val at = message.optLong("t")
                            Text("$sender · $kind · ${if (at > 0) DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(at)) else "time not recorded"}",
                                fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall)
                            Text(message.optString("text").take(500), style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(bottom = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InsightSection(title: String, detail: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}