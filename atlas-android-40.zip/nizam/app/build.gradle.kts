plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.nizam.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nizam.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "1.0-beta"
        // Only the processor type the Infinix GT 50 Pro uses (64-bit ARM) — about half the download size
        ndk { abiFilters += listOf("arm64-v8a") }
        // Your own API keys, built in: taken from the build machine's environment (GitHub Actions secrets
        // named ATLAS_KEY_…), never written in the source. Empty when a secret isn't set.
        listOf("GEMINI", "OPENROUTER", "CUSTOM", "CUSTOM_URL", "CUSTOM_MODEL", "FAST", "FAST_URL", "FAST_MODEL", "HADITH",
            "TMDB", "OMDB", "JAMENDO", "HF", "TOMTOM").forEach { k ->
            buildConfigField("String", "KEY_$k", "\"" + (System.getenv("ATLAS_KEY_$k") ?: "").replace("\"", "") + "\"")
        }
    }

    // One fixed key for every build, so a new APK installs OVER the old one and your data survives.
    // Without this, CI generates a fresh debug key each run, Android rejects the update, and
    // uninstalling to get around it wipes the database and settings.
    signingConfigs {
        create("atlas") {
            storeFile = file("atlas.keystore")
            storePassword = "atlas1234"
            keyAlias = "atlas"
            keyPassword = "atlas1234"
        }
    }

    buildTypes {
        // CI builds the debug APK, so it must carry the same fixed key as release — otherwise each
        // build gets a fresh debug key and Android refuses to update the installed app.
        debug {
            signingConfig = signingConfigs.getByName("atlas")
        }
        release {
            signingConfig = signingConfigs.getByName("atlas")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")

    val composeBom = platform("androidx.compose:compose-bom:2024.08.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.navigation:navigation-compose:2.7.7")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.health.connect:connect-client:1.1.0-alpha07")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
    // World maps (OpenStreetMap), no API key
    implementation("org.osmdroid:osmdroid-android:6.1.20")
    // Torrent engine so torrent sources stream inside Cinema (libtorrent, with its native library per CPU)
    implementation("org.libtorrent4j:libtorrent4j:2.1.0-39")
    implementation("org.libtorrent4j:libtorrent4j-android-arm64:2.1.0-39")
    implementation("com.google.mlkit:pose-detection:18.0.0-beta5")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    // On-device LLM for offline answers (the model file is imported by the user, not bundled)
    implementation("com.google.mediapipe:tasks-genai:0.10.24")

    debugImplementation(composeBom)
    debugImplementation("androidx.compose.ui:ui-tooling")
}
