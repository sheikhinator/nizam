// Atlas HQ: a small 3D tower where every Atlas agent has a desk. Kotlin pushes the state in (HQ.update)
// and gets taps back (AtlasHQ.tap). Everything is built from code shapes: no model files.
(function () {
  'use strict';
  const B = window.AtlasHQ || { tap() {}, ready() {}, haptic() {}, room() {}, log() {} };
  const W = 14, D = 10, H = 3.2;            // one floor: 14 m wide, 10 m deep, 3.2 m tall
  const V3 = THREE.Vector3;
  if (THREE.ColorManagement) THREE.ColorManagement.legacyMode = false;   // hex colours are sRGB

  // ─────────────── state from Atlas ───────────────
  let S = {
    rooms: [
      { id: 'hq', name: 'HQ', emoji: '🏢', color: '#6366f1' }, { id: 'home', name: 'Home', emoji: '🏠', color: '#10b981' },
      { id: 'money', name: 'Money', emoji: '💰', color: '#f59e0b' }, { id: 'deen', name: 'Deen', emoji: '🕌', color: '#14b8a6' },
      { id: 'work', name: 'Work', emoji: '💼', color: '#0ea5e9' }, { id: 'lab', name: 'PC Lab', emoji: '🖥️', color: '#8b5cf6' }],
    agents: [], needs: [], approvals: 0, changes: 0, jar: 1, plugs: [], meeting: null, sky: 'DAY', hour: 12, weather: 'clear',
    event: null, prayer: null, salah: false, qibla: 255, loadshed: false, low: false, celebrate: -1, pcOnline: false,
    summary: '', routine: '', you: '#f97316'
  };
  let lastCelebrate = -1;

  // ─────────────── renderer ───────────────
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  let pixelRatio = Math.min(window.devicePixelRatio || 1, 1.75);
  renderer.setPixelRatio(pixelRatio);
  renderer.setSize(innerWidth, innerHeight);
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  document.body.insertBefore(renderer.domElement, document.body.firstChild);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(30, innerWidth / innerHeight, 0.1, 600);

  // toon shading: three flat bands
  const ramp = new THREE.DataTexture(new Uint8Array([90, 170, 255]), 3, 1, THREE.RedFormat);
  ramp.minFilter = ramp.magFilter = THREE.NearestFilter; ramp.needsUpdate = true;
  const mats = {};
  function M(color, extra) {
    const k = color + (extra ? JSON.stringify(extra) : '');
    if (!mats[k]) mats[k] = new THREE.MeshToonMaterial(Object.assign({ color: new THREE.Color(color), gradientMap: ramp }, extra || {}));
    return mats[k];
  }
  function Glow(color, intensity) { return new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(intensity || 1) }); }
  function box(w, h, d, mat, x, y, z, parent, shadow) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z); if (shadow !== false) { m.castShadow = true; m.receiveShadow = true; }
    if (parent) parent.add(m); return m;
  }
  function cyl(rt, rb, h, mat, x, y, z, parent, seg) {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg || 16), mat);
    m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; if (parent) parent.add(m); return m;
  }
  function sphere(r, mat, x, y, z, parent) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(r, 18, 14), mat);
    m.position.set(x, y, z); m.castShadow = true; if (parent) parent.add(m); return m;
  }
  function canvasTex(w, h, draw) {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 4;
    t.redraw = (fn) => { const g = c.getContext('2d'); g.clearRect(0, 0, w, h); (fn || draw)(g, w, h); t.needsUpdate = true; };
    t.redraw(draw); return t;
  }
  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  // ─────────────── sky, sun, weather ───────────────
  const SKY = {
    DAWN: ['#f6b98a', '#7c8fd6', '#ffd7a8', 0.9], DAY: ['#dbeafe', '#4f8fea', '#ffffff', 1.25], GOLDEN: ['#ffd18a', '#6d8fdc', '#ffc27a', 1.05],
    DUSK: ['#f08a6c', '#3b2b6b', '#ff9d6b', 0.7], NIGHT: ['#1b2447', '#070b1c', '#8aa0ff', 0.35]
  };
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false,
    uniforms: { top: { value: new THREE.Color('#4f8fea') }, bottom: { value: new THREE.Color('#dbeafe') } },
    vertexShader: 'varying vec3 p; void main(){ p = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: 'uniform vec3 top; uniform vec3 bottom; varying vec3 p; void main(){ float h = clamp(p.y*1.6+0.15,0.0,1.0); gl_FragColor = vec4(mix(bottom, top, h),1.0); }'
  });
  const skyDome = new THREE.Mesh(new THREE.SphereGeometry(300, 32, 16), skyMat); scene.add(skyDome);
  const stars = (() => {
    const n = 500, a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { const t = Math.random() * Math.PI * 2, u = Math.random() * 0.9 + 0.1; a[i * 3] = Math.cos(t) * 280 * Math.sqrt(1 - u * u); a[i * 3 + 1] = u * 280; a[i * 3 + 2] = Math.sin(t) * 280 * Math.sqrt(1 - u * u); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(a, 3));
    const p = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 1.4, sizeAttenuation: false, transparent: true, opacity: 0.85 }));
    scene.add(p); return p;
  })();
  const hemi = new THREE.HemisphereLight(0xdbeafe, 0x6b5a45, 0.7); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffffff, 1.1);
  sun.castShadow = true; sun.shadow.mapSize.set(1024, 1024);
  Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 14, bottom: -14, near: 1, far: 90 });
  sun.shadow.bias = -0.0008; scene.add(sun); scene.add(sun.target);
  const sunBall = sphere(4, Glow('#fff4cc'), 0, 0, 0, scene); sunBall.castShadow = false;
  const moon = sphere(3, Glow('#e6ecff'), 0, 0, 0, scene); moon.castShadow = false;
  const roomLight = new THREE.PointLight(0xfff1d6, 0.6, 22, 1.6); scene.add(roomLight);

  const rain = (() => {
    const n = 1400, a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { a[i * 3] = (Math.random() - 0.5) * 70; a[i * 3 + 1] = Math.random() * 40; a[i * 3 + 2] = (Math.random() - 0.5) * 70; }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(a, 3));
    const p = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xaecbff, size: 0.12, transparent: true, opacity: 0.7 }));
    p.visible = false; scene.add(p); return p;
  })();

  // ─────────────── the street ───────────────
  const world = new THREE.Group(); scene.add(world);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), M('#7fb069'));
  ground.rotation.x = -Math.PI / 2; ground.position.y = -0.03; ground.receiveShadow = true; world.add(ground);
  box(200, 0.04, 6, M('#3d4250'), 0, -0.01, 13, world, false);                       // road
  box(200, 0.06, 3.2, M('#c9c3b6'), 0, 0, 8.4, world, false);                       // sidewalk
  box(200, 0.06, 3.2, M('#c9c3b6'), 0, 0, 17.6, world, false);
  for (let x = -96; x < 100; x += 6) box(2.4, 0.05, 0.18, M('#f5f0e1'), x, 0.01, 13, world, false);
  function tree(x, z, s) {
    const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g);
    cyl(0.14 * s, 0.2 * s, 1.4 * s, M('#7a5537'), 0, 0.7 * s, 0, g, 8);
    const c = new THREE.Mesh(new THREE.IcosahedronGeometry(1.1 * s, 0), M('#4f9d4f')); c.position.y = 2.1 * s; c.castShadow = true; g.add(c);
    const c2 = new THREE.Mesh(new THREE.IcosahedronGeometry(0.8 * s, 0), M('#5fb35f')); c2.position.set(0.4 * s, 2.7 * s, 0.2 * s); c2.castShadow = true; g.add(c2);
  }
  [[-10, 7.5], [10, 7.5], [-16, 7.5], [16, 7.5], [-22, 7.4], [22, 7.6], [-9, -9], [11, -10], [-14, -6], [18, -4]].forEach(([x, z], i) => tree(x, z, 0.9 + (i % 3) * 0.15));
  const cityWindows = [];
  function building(x, z, w, h, d, color) {
    const b = box(w, h, d, M(color), x, h / 2, z, world); b.castShadow = false;
    for (let fy = 1.4; fy < h - 0.8; fy += 2.2) for (let fx = -w / 2 + 1; fx < w / 2 - 0.6; fx += 1.6) {
      const m = new THREE.MeshBasicMaterial({ color: 0x2a3350 });
      const p = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 1.1), m); p.position.set(x + fx, fy, z + d / 2 + 0.01); world.add(p);
      cityWindows.push({ m, lit: Math.random() < 0.45 });
    }
  }
  // the neighbours stand behind and beside the tower, so they never block the view
  building(-12, -20, 8, 14, 6, '#c7b7a3'); building(2, -24, 9, 22, 7, '#9fb3c8'); building(15, -19, 6, 11, 5, '#d9c8b4');
  building(28, -22, 10, 17, 7, '#b8a894'); building(-30, -16, 9, 12, 6, '#a9b8a0'); building(30, 2, 7, 9, 7, '#d6c7b0');
  // the neighbourhood masjid, whose lights come on for salah
  const masjidGlow = [];
  (function masjid() {
    const g = new THREE.Group(); g.position.set(-24, 0, -8); g.rotation.y = -Math.PI / 2; world.add(g);
    box(8, 4, 6, M('#f1ece2'), 0, 2, 0, g);
    const dome = new THREE.Mesh(new THREE.SphereGeometry(2.3, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), M('#2f9e8f')); dome.position.set(0, 4, 0); dome.castShadow = true; g.add(dome);
    cyl(0.05, 0.05, 0.9, M('#d4af37'), 0, 6.7, 0, g, 6);
    const mn = cyl(0.45, 0.55, 10, M('#f1ece2'), 4.6, 5, -2, g, 12);
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.6, 1.4, 12), M('#2f9e8f')); cap.position.set(4.6, 10.7, -2); g.add(cap);
    for (let i = -1; i <= 1; i++) {
      const m = new THREE.MeshBasicMaterial({ color: 0x5a4a2a });
      const p = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.8), m); p.position.set(i * 2.4, 1.8, -3.01); p.rotation.y = Math.PI; g.add(p); masjidGlow.push(m);
    }
    const ring = new THREE.MeshBasicMaterial({ color: 0x3a3a2a }); masjidGlow.push(ring);
    const r = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.08, 6, 20), ring); r.rotation.x = Math.PI / 2; r.position.set(4.6, 8.6, -2); g.add(r);
  })();
  // cars drifting past
  const cars = [];
  ['#ef4444', '#f8fafc', '#0ea5e9', '#f59e0b'].forEach((col, i) => {
    const g = new THREE.Group(); world.add(g);
    box(2.2, 0.55, 1.1, M(col), 0, 0.45, 0, g); box(1.2, 0.45, 1.0, M('#dfe8f5'), -0.1, 0.95, 0, g);
    [[-0.7, 0.5], [0.7, 0.5], [-0.7, -0.5], [0.7, -0.5]].forEach(([x, z]) => { const w = cyl(0.22, 0.22, 0.2, M('#111827'), x, 0.22, z, g, 10); w.rotation.x = Math.PI / 2; });
    const lamp = new THREE.MeshBasicMaterial({ color: 0xfff6c0 }); box(0.05, 0.14, 0.7, lamp, 1.11, 0.5, 0, g, false);
    cars.push({ g, lane: i % 2 ? 11.5 : 14.5, dir: i % 2 ? 1 : -1, x: -60 + i * 33, speed: 5 + i });
  });

  // ─────────────── the tower ───────────────
  const floors = [];        // { g, y, solids[], hits[], slots[], mats[], extras }
  const hits = [];          // meshes that can be tapped
  const interact = [];      // things you can walk up to in explore mode
  const lamps = [];
  const blinkers = [];
  let roofGroup, gongGroup, screenTex, plugTex, routineTex, jarFill, inboxStack, changesStack, pcSign;
  const qiblaMats = [];

  function tag(obj, kind, id, label, floor, pos) {
    obj.traverse((m) => { if (m.isMesh) { m.userData.hit = { kind, id }; hits.push(m); } });
    if (label) interact.push({ kind, id, label, floor, pos: pos || obj.getWorldPosition(new V3()) });
  }
  function solid(f, x, z, w, d) { floors[f].solids.push({ x1: x - w / 2, x2: x + w / 2, z1: z - d / 2, z2: z + d / 2 }); }

  function desk(f, g, x, z, big) {
    const w = big ? 2.2 : 1.6;
    box(w, 0.08, 0.8, M(big ? '#6b4a33' : '#c79a6b'), x, 0.76, z, g);
    [[-w / 2 + 0.08, -0.32], [w / 2 - 0.08, -0.32], [-w / 2 + 0.08, 0.32], [w / 2 - 0.08, 0.32]].forEach(([dx, dz]) => box(0.06, 0.74, 0.06, M('#4b5563'), x + dx, 0.37, z + dz, g));
    // chair behind the desk (the agent sits facing the room)
    box(0.55, 0.08, 0.5, M('#374151'), x, 0.48, z - 0.78, g); box(0.55, 0.6, 0.08, M('#374151'), x, 0.8, z - 1.04, g);
    cyl(0.04, 0.04, 0.44, M('#6b7280'), x, 0.23, z - 0.78, g, 6);
    // laptop: its lid faces the agent; the back glows in the agent's colour
    const lap = new THREE.Group(); lap.position.set(x, 0.8, z + 0.05); g.add(lap);
    box(0.5, 0.03, 0.34, M('#9ca3af'), 0, 0.015, 0, lap);
    const lid = new THREE.Group(); lid.position.set(0, 0.03, 0.17); lid.rotation.x = 0.35; lap.add(lid);
    box(0.5, 0.34, 0.02, M('#9ca3af'), 0, 0.17, 0, lid);
    const logo = new THREE.MeshBasicMaterial({ color: 0x334155 });
    const lg = new THREE.Mesh(new THREE.CircleGeometry(0.05, 16), logo); lg.position.set(0, 0.18, 0.012); lid.add(lg);
    const scr = new THREE.MeshBasicMaterial({ color: 0x111827 });
    const sc = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.3), scr); sc.position.set(0, 0.17, -0.012); sc.rotation.y = Math.PI; lid.add(sc);
    solid(f, x, z - 0.2, w + 0.1, 1.6);
    return { logo, scr };
  }
  function beanbag(g, x, z, col) {
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.55, 16, 10), M(col)); b.scale.set(1, 0.55, 1); b.position.set(x, 0.3, z - 0.05); b.castShadow = true; g.add(b);
    box(0.7, 0.05, 0.4, M('#c79a6b'), x, 0.42, z + 0.55, g);
    const lap = box(0.4, 0.02, 0.28, M('#9ca3af'), x, 0.46, z + 0.55, g);
    return { logo: new THREE.MeshBasicMaterial(), scr: lap.material };
  }
  function plant(g, x, z, s) {
    s = s || 1;
    cyl(0.22 * s, 0.17 * s, 0.4 * s, M('#b45309'), x, 0.2 * s, z, g, 10);
    for (let i = 0; i < 5; i++) { const l = new THREE.Mesh(new THREE.IcosahedronGeometry(0.22 * s, 0), M(i % 2 ? '#3f8f4a' : '#5aad5f')); l.position.set(x + Math.cos(i * 1.3) * 0.14 * s, (0.55 + i * 0.12) * s, z + Math.sin(i * 1.3) * 0.14 * s); l.castShadow = true; g.add(l); }
  }
  function lamp(g, x, z) {
    const m = new THREE.MeshBasicMaterial({ color: 0xfff2cc });
    const l = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.06, 20), m); l.position.set(x, H - 0.25, z); g.add(l); lamps.push(m);
    cyl(0.01, 0.01, 0.15, M('#9ca3af'), x, H - 0.15, z, g, 4);
  }
  function wallSign(g, text, emoji, color, x, y, z) {
    const t = canvasTex(512, 128, (c, w, h) => {
      rr(c, 4, 4, w - 8, h - 8, 28); c.fillStyle = color; c.fill();
      c.fillStyle = '#fff'; c.font = 'bold 64px sans-serif'; c.textBaseline = 'middle'; c.fillText(emoji + '  ' + text, 36, h / 2 + 4);
    });
    const p = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.6), new THREE.MeshBasicMaterial({ map: t, transparent: true })); p.position.set(x, y, z); g.add(p); return p;
  }

  function slotsFor(i) {
    if (i === 0) return [
      { x: 4.9, z: -2.6, big: true }, { x: -2.6, z: -2.6 }, { x: 4.9, z: 3.4 }, { x: -2.6, z: 3.4 },
      { x: 1.2, z: 4.1, bean: true }, { x: 6.2, z: 0.6, bean: true }, { x: -1.0, z: 4.1, bean: true }];
    const s = [];
    [-2.8, 0.4, 3.6].forEach((x) => s.push({ x, z: -2.0 }));
    [-0.8, 2.4, 5.4].forEach((x) => s.push({ x, z: 3.6, bean: true }));
    s.push({ x: 5.9, z: 0.6, bean: true });
    return s;
  }

  function buildFloor(i, room) {
    const y = i * H, g = new THREE.Group(); g.position.y = y; scene.add(g);
    const f = { g, y, solids: [], slots: [], seats: [], room, i, deco: [] };
    floors[i] = f;
    const tint = new THREE.Color(room.color);
    const floorCol = new THREE.Color('#efe6d8').lerp(tint, 0.08);
    box(W, 0.2, D, M('#' + floorCol.getHexString()), 0, -0.1, 0, g);
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 3.4), M('#' + new THREE.Color('#ffffff').lerp(tint, 0.35).getHexString()));
    rug.rotation.x = -Math.PI / 2; rug.position.set(1.2, 0.01, i === 0 ? 0.2 : -0.5); rug.receiveShadow = true; g.add(rug);
    // back and left walls (a doll's-house cutaway), with window panes that show the sky
    const wallCol = '#' + new THREE.Color('#f7f3ec').lerp(tint, 0.12).getHexString();
    box(W, H, 0.2, M(wallCol), 0, H / 2, -D / 2, g); box(0.2, H, D, M(wallCol), -W / 2, H / 2, 0, g);
    f.panes = [];
    [-4.5, -1.5, 1.5, 4.5].forEach((x) => {
      const m = new THREE.MeshBasicMaterial({ color: 0x9cc3f5 });
      const p = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 1.5), m); p.position.set(x + 1.2, 1.75, -D / 2 + 0.11); g.add(p); f.panes.push(m);
      box(2.0, 0.08, 0.14, M('#e5e7eb'), x + 1.2, 0.98, -D / 2 + 0.14, g);
    });
    // glass rail on the open sides, with a door gap on the ground floor
    const glass = new THREE.MeshToonMaterial({ color: 0xbfe3ff, transparent: true, opacity: 0.25, gradientMap: ramp });
    if (i === 0) { box(5.6, 1.0, 0.05, glass, -3.9, 0.5, D / 2, g, false); box(5.6, 1.0, 0.05, glass, 3.9, 0.5, D / 2, g, false); }
    else box(W, 1.0, 0.05, glass, 0, 0.5, D / 2, g, false);
    box(0.05, 1.0, D, glass, W / 2, 0.5, 0, g, false);
    [[W / 2, D / 2], [-W / 2, D / 2], [W / 2, -D / 2]].forEach(([x, z]) => box(0.3, H, 0.3, M('#d6d3d1'), x, H / 2, z, g));
    // elevator in the back-left corner
    const el = new THREE.Group(); el.position.set(-5.9, 0, -4.1); g.add(el);
    box(1.6, H - 0.1, 1.4, M('#9aa3b2'), 0, (H - 0.1) / 2, 0, el);
    box(0.62, 2.2, 0.05, M('#cbd5e1'), -0.32, 1.1, 0.72, el); box(0.62, 2.2, 0.05, M('#cbd5e1'), 0.32, 1.1, 0.72, el);
    const ind = canvasTex(128, 64, (c) => { c.fillStyle = '#111827'; c.fillRect(0, 0, 128, 64); c.fillStyle = '#fbbf24'; c.font = 'bold 40px monospace'; c.fillText(i === 0 ? 'G' : String(i), 44, 46); });
    const ip = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.2), new THREE.MeshBasicMaterial({ map: ind })); ip.position.set(0, 2.45, 0.73); el.add(ip);
    tag(el, 'elevator', String(i), '🛗 Elevator', i, new V3(-5.9, y, -3.2));
    solid(i, -5.9, -4.1, 1.7, 1.5);
    f.door = new V3(-5.9, y, -3.0);
    wallSign(g, room.name, room.emoji, room.color, -1.5, 2.75, -D / 2 + 0.12);
    lamp(g, -2, -1); lamp(g, 3, -1); lamp(g, -2, 2.5); lamp(g, 3, 2.5);
    plant(g, 6.4, -4.4); plant(g, -6.3, 4.3, 1.2);
    solid(i, 6.4, -4.4, 0.6, 0.6); solid(i, -6.3, 4.3, 0.6, 0.6);

    slotsFor(i).forEach((s) => {
      const kit = s.bean ? beanbag(g, s.x, s.z, room.color) : desk(i, g, s.x, s.z, s.big);
      f.slots.push({ x: s.x, z: s.bean ? s.z : s.z - 0.72, bean: !!s.bean, kit, deskZ: s.z });
    });
    decorate(i, g, room);
  }

  function decorate(i, g, room) {
    const id = room.id;
    if (i === 0) {
      // meeting table
      box(4.4, 0.1, 1.5, M('#5b3b26'), 1.2, 0.76, 0.2, g); cyl(0.25, 0.35, 0.72, M('#3b2a1c'), 0.1, 0.36, 0.2, g); cyl(0.25, 0.35, 0.72, M('#3b2a1c'), 2.3, 0.36, 0.2, g);
      const t = new THREE.Group(); g.add(t);
      floors[0].seats = [];
      [-0.3, 1.2, 2.7].forEach((x) => [[-0.75, 0], [1.15, Math.PI]].forEach(([z, r]) => {
        const c = box(0.5, 0.08, 0.5, M('#1f2937'), x, 0.46, 0.2 + z + (z < 0 ? -0.1 : 0.1), g);
        floors[0].seats.push({ x, z: 0.2 + z + (z < 0 ? -0.2 : 0.2), face: z < 0 ? 0 : Math.PI });
        void c; void r;
      }));
      tag(box(4.4, 0.1, 1.5, new THREE.MeshBasicMaterial({ visible: false }), 1.2, 0.8, 0.2, g, false), 'table', '', '🤝 Meeting table', 0, new V3(1.2, 0, 1.4));
      solid(0, 1.2, 0.2, 4.6, 1.7);
      // the HQ screen on the back wall
      screenTex = canvasTex(1024, 400, drawScreen);
      const scr = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 1.64), new THREE.MeshBasicMaterial({ map: screenTex }));
      scr.position.set(2.6, 1.95, -D / 2 + 0.13); g.add(scr);
      box(4.35, 1.78, 0.06, M('#111827'), 2.6, 1.95, -D / 2 + 0.1, g);
      tag(scr, 'screen', '', null, 0);
      // inbox tray, changes tray, cash jar on a long cabinet by the left wall
      box(1.0, 0.9, 3.6, M('#d6c7b0'), -6.2, 0.45, 0.6, g); solid(0, -6.2, 0.6, 1.1, 3.7);
      const inbox = new THREE.Group(); inbox.position.set(-6.2, 0.9, -0.6); g.add(inbox);
      box(0.6, 0.06, 0.45, M('#ef4444'), 0, 0.03, 0, inbox);
      inboxStack = box(0.5, 0.02, 0.36, M('#ffffff'), 0, 0.07, 0, inbox);
      tag(inbox, 'inbox', '', '📥 Approvals inbox', 0, new V3(-5.4, 0, -0.6));
      const ch = new THREE.Group(); ch.position.set(-6.2, 0.9, 0.5); g.add(ch);
      box(0.6, 0.06, 0.45, M('#0ea5e9'), 0, 0.03, 0, ch);
      changesStack = box(0.5, 0.02, 0.36, M('#e0f2fe'), 0, 0.07, 0, ch);
      tag(ch, 'changes', '', '🧾 What agents changed', 0, new V3(-5.4, 0, 0.5));
      const jar = new THREE.Group(); jar.position.set(-6.2, 0.9, 1.7); g.add(jar);
      const gl = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.7, 20, 1, true), new THREE.MeshToonMaterial({ color: 0xdff3ff, transparent: true, opacity: 0.35, side: THREE.DoubleSide, gradientMap: ramp }));
      gl.position.y = 0.35; jar.add(gl);
      cyl(0.3, 0.3, 0.06, M('#b45309'), 0, 0.73, 0, jar);
      jarFill = cyl(0.25, 0.25, 1, M('#22c55e'), 0, 0.33, 0, jar); jarFill.scale.y = 0.6;
      tag(jar, 'jar', '', '🫙 Agent budget', 0, new V3(-5.4, 0, 1.7));
      // plug wall on the left wall
      plugTex = canvasTex(512, 512, drawPlugs);
      const pw = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 1.8), new THREE.MeshBasicMaterial({ map: plugTex }));
      pw.position.set(-W / 2 + 0.12, 1.9, 3.3); pw.rotation.y = Math.PI / 2; g.add(pw);
      tag(pw, 'plugs', '', '🔌 Connectors', 0, new V3(-6.0, 0, 3.3));
      // routines clock
      routineTex = canvasTex(512, 256, drawRoutine);
      const rb = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.9), new THREE.MeshBasicMaterial({ map: routineTex }));
      rb.position.set(-3.6, 1.9, -D / 2 + 0.12); g.add(rb);
      tag(rb, 'routines', '', '⏰ Routines', 0, new V3(-3.6, 0, -3.8));
      // the gong
      gongGroup = new THREE.Group(); gongGroup.position.set(6.2, 0, 2.0); g.add(gongGroup);
      box(0.08, 1.8, 0.08, M('#3b2a1c'), -0.6, 0.9, 0, gongGroup); box(0.08, 1.8, 0.08, M('#3b2a1c'), 0.6, 0.9, 0, gongGroup);
      box(1.3, 0.08, 0.08, M('#3b2a1c'), 0, 1.8, 0, gongGroup);
      const disc = new THREE.Group(); disc.position.set(0, 1.75, 0); gongGroup.add(disc); gongGroup.userData.disc = disc;
      const gd = cyl(0.45, 0.45, 0.05, M('#d4a017'), 0, -0.55, 0, disc, 28); gd.rotation.x = Math.PI / 2;
      tag(gongGroup, 'gong', '', '🔔 Ring the gong', 0, new V3(6.2, 0, 2.9));
      solid(0, 6.2, 2.0, 1.4, 0.4);
      // the pet's bed
      const bed = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.14, 8, 20), M('#f97316')); bed.rotation.x = -Math.PI / 2; bed.position.set(6.3, 0.1, 4.3); g.add(bed);
    } else if (id === 'home') {
      box(2.8, 0.9, 0.6, M('#e7e5e4'), 3.6, 0.45, -4.5, g); box(2.8, 0.06, 0.64, M('#78716c'), 3.6, 0.92, -4.5, g);
      box(0.8, 1.9, 0.7, M('#f1f5f9'), 5.6, 0.95, -4.45, g);
      solid(i, 4.1, -4.5, 3.8, 0.8);
      sofa(g, -5.6, 1.4); solid(i, -5.6, 1.4, 1.0, 2.2);
      family(g);
    } else if (id === 'money') {
      const safe = new THREE.Group(); safe.position.set(5.8, 0, -4.2); g.add(safe);
      box(1.1, 1.2, 0.9, M('#374151'), 0, 0.6, 0, safe); const dial = cyl(0.14, 0.14, 0.05, M('#d4af37'), 0.2, 0.7, 0.46, safe, 16); dial.rotation.x = Math.PI / 2;
      solid(i, 5.8, -4.2, 1.2, 1.0);
      for (let k = 0; k < 5; k++) for (let h = 0; h < 2 + k; h++) cyl(0.12, 0.12, 0.05, M('#eab308'), -5.8 + k * 0.3, 0.03 + h * 0.055, 2.2, g, 14);
      const chart = canvasTex(512, 256, (c, w, h) => {
        c.fillStyle = '#0f172a'; c.fillRect(0, 0, w, h); c.strokeStyle = '#22c55e'; c.lineWidth = 8; c.beginPath();
        [0.8, 0.7, 0.75, 0.55, 0.6, 0.4, 0.45, 0.25].forEach((v, k) => { const px = 30 + k * 64, py = v * h; k ? c.lineTo(px, py) : c.moveTo(px, py); }); c.stroke();
      });
      const cm = new THREE.Mesh(new THREE.PlaneGeometry(2, 1), new THREE.MeshBasicMaterial({ map: chart })); cm.position.set(-W / 2 + 0.12, 1.9, 1.5); cm.rotation.y = Math.PI / 2; g.add(cm);
    } else if (id === 'deen') {
      for (let k = 0; k < 3; k++) {
        box(1.8, 0.05, 0.4, M('#8b5a2b'), -5.6 + 0, 0.6 + k * 0.55, -1 + 0, g);
        for (let b = 0; b < 8; b++) box(0.14, 0.4, 0.3, M(['#166534', '#7c2d12', '#1e3a8a', '#854d0e'][b % 4]), -6.3 + b * 0.19, 0.83 + k * 0.55, -1, g);
      }
      solid(i, -5.6, -1, 1.9, 0.5);
      // prayer mats, laid out towards the qibla
      for (let k = 0; k < 4; k++) {
        const m = new THREE.Mesh(new THREE.PlaneGeometry(0.75, 1.3), M(['#166534', '#7f1d1d', '#1e3a8a', '#065f46'][k]));
        m.rotation.x = -Math.PI / 2; m.position.set(-5.6 + (k % 2) * 1.0, 0.015, 2.4 + Math.floor(k / 2) * 1.5); g.add(m); qiblaMats.push(m);
      }
      const lantern = new THREE.MeshBasicMaterial({ color: 0xffc36b });
      const ln = new THREE.Mesh(new THREE.OctahedronGeometry(0.25, 0), lantern); ln.position.set(-4.2, 2.6, 1.6); g.add(ln); lamps.push(lantern);
    } else if (id === 'work') {
      const wb = canvasTex(512, 256, (c, w, h) => {
        c.fillStyle = '#ffffff'; c.fillRect(0, 0, w, h); c.strokeStyle = '#2563eb'; c.lineWidth = 6;
        c.strokeRect(40, 40, 120, 70); c.strokeRect(300, 40, 150, 70); c.beginPath(); c.moveTo(160, 75); c.lineTo(300, 75); c.stroke();
        c.fillStyle = '#ef4444'; c.font = 'bold 34px sans-serif'; c.fillText('Q4 plan ✓', 120, 200);
      });
      const wm = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 1.1), new THREE.MeshBasicMaterial({ map: wb })); wm.position.set(-W / 2 + 0.12, 1.8, 1.5); wm.rotation.y = Math.PI / 2; g.add(wm);
      for (let k = 0; k < 3; k++) box(0.6, 1.3, 0.6, M('#94a3b8'), 4.6 + k * 0.65, 0.65, -4.4, g);
      solid(i, 5.25, -4.4, 2.0, 0.7);
    } else if (id === 'lab') {
      for (let k = 0; k < 3; k++) {
        const rack = new THREE.Group(); rack.position.set(4.2 + k * 0.9, 0, -4.3); g.add(rack);
        box(0.8, 2.2, 0.8, M('#1f2937'), 0, 1.1, 0, rack);
        for (let r = 0; r < 8; r++) { const m = new THREE.MeshBasicMaterial({ color: 0x22c55e }); const l = new THREE.Mesh(new THREE.PlaneGeometry(0.06, 0.06), m); l.position.set(-0.25 + (r % 2) * 0.12, 0.4 + r * 0.22, 0.41); rack.add(l); blinkers.push({ m, p: Math.random() * 6 }); }
      }
      solid(i, 5.1, -4.3, 2.8, 0.9);
      pcSign = new THREE.MeshBasicMaterial({ color: 0x7f1d1d });
      const s = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.4), pcSign); s.position.set(-W / 2 + 0.12, 2.3, 1.5); s.rotation.y = Math.PI / 2; g.add(s);
      tag(s, 'pc', '', null, i);
    }
  }
  function sofa(g, x, z) {
    box(0.9, 0.45, 2.1, M('#6366f1'), x, 0.3, z, g); box(0.25, 0.7, 2.1, M('#4f46e5'), x - 0.35, 0.6, z, g);
    box(0.9, 0.55, 0.22, M('#4f46e5'), x, 0.45, z - 1.05, g); box(0.9, 0.55, 0.22, M('#4f46e5'), x, 0.45, z + 1.05, g);
  }
  function family(g) {
    const t = canvasTex(256, 200, (c, w, h) => { c.fillStyle = '#fef3c7'; c.fillRect(0, 0, w, h); c.font = '90px sans-serif'; c.fillText('👨‍👩‍👧', 30, 140); });
    const p = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.7), new THREE.MeshBasicMaterial({ map: t })); p.position.set(-W / 2 + 0.12, 1.9, -1.8); p.rotation.y = Math.PI / 2; g.add(p);
    box(0.06, 0.8, 1.0, M('#92400e'), -W / 2 + 0.1, 1.9, -1.8, g);
  }

  function buildRoof(n) {
    roofGroup = new THREE.Group(); roofGroup.position.y = n * H; scene.add(roofGroup);
    box(W, 0.2, D, M('#d6d3d1'), 0, -0.1, 0, roofGroup);
    box(W, 0.6, 0.2, M('#e7e5e4'), 0, 0.3, D / 2, roofGroup); box(W, 0.6, 0.2, M('#e7e5e4'), 0, 0.3, -D / 2, roofGroup);
    box(0.2, 0.6, D, M('#e7e5e4'), W / 2, 0.3, 0, roofGroup); box(0.2, 0.6, D, M('#e7e5e4'), -W / 2, 0.3, 0, roofGroup);
    const sign = canvasTex(1024, 256, (c, w, h) => { c.fillStyle = 'rgba(0,0,0,0)'; c.fillRect(0, 0, w, h); c.fillStyle = '#ffffff'; c.font = 'bold 170px sans-serif'; c.textAlign = 'center'; c.fillText('ATLAS', w / 2, 190); });
    const s = new THREE.Mesh(new THREE.PlaneGeometry(6, 1.5), new THREE.MeshBasicMaterial({ map: sign, transparent: true, color: 0xa5b4fc }));
    s.position.set(0, 1.4, D / 2 - 0.3); roofGroup.add(s); roofGroup.userData.sign = s;
    box(0.1, 1.2, 0.1, M('#6b7280'), -2.5, 0.8, D / 2 - 0.35, roofGroup); box(0.1, 1.2, 0.1, M('#6b7280'), 2.5, 0.8, D / 2 - 0.35, roofGroup);
    cyl(0.04, 0.06, 3, M('#9ca3af'), 5, 1.5, -3, roofGroup, 6);
    const tip = new THREE.MeshBasicMaterial({ color: 0xef4444 }); const tp = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), tip); tp.position.set(5, 3.05, -3); roofGroup.add(tp);
    blinkers.push({ m: tip, p: 0, slow: true });
    const cres = canvasTex(256, 256, (c) => { c.fillStyle = '#fde68a'; c.beginPath(); c.arc(128, 128, 90, 0, Math.PI * 2); c.fill(); c.globalCompositeOperation = 'destination-out'; c.beginPath(); c.arc(165, 110, 80, 0, Math.PI * 2); c.fill(); });
    const cm = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.2), new THREE.MeshBasicMaterial({ map: cres, transparent: true })); cm.position.set(-5, 2.2, D / 2 - 0.3); cm.visible = false; roofGroup.add(cm); roofGroup.userData.crescent = cm;
  }

  // ─────────────── characters ───────────────
  const cardLayer = document.createElement('div');
  Object.assign(cardLayer.style, { position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', pointerEvents: 'none', overflow: 'hidden' });
  document.body.appendChild(cardLayer);
  const STATUS = { working: '#3b82f6', needs: '#ef4444', done: '#22c55e', idle: '#9ca3af', asleep: '#6b7280', pray: '#14b8a6' };

  function character(color) {
    const g = new THREE.Group();
    const body = new THREE.Group(); g.add(body);
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.27, 0.42, 6, 14), M(color)); torso.position.y = 0.62; torso.castShadow = true; body.add(torso);
    const head = new THREE.Group(); head.position.y = 1.22; body.add(head);
    const skin = new THREE.Color(color).lerp(new THREE.Color('#ffffff'), 0.55);
    sphere(0.27, M('#' + skin.getHexString()), 0, 0, 0, head);
    const eyeM = M('#111827');
    sphere(0.045, eyeM, -0.09, 0.03, 0.24, head).castShadow = false; sphere(0.045, eyeM, 0.09, 0.03, 0.24, head).castShadow = false;
    const blush = new THREE.MeshBasicMaterial({ color: 0xfda4af, transparent: true, opacity: 0.7 });
    const b1 = new THREE.Mesh(new THREE.CircleGeometry(0.04, 10), blush); b1.position.set(-0.16, -0.06, 0.225); head.add(b1);
    const b2 = b1.clone(); b2.position.x = 0.16; head.add(b2);
    cyl(0.012, 0.012, 0.22, M('#6b7280'), 0, 0.36, 0, head, 5);
    const bulbM = new THREE.MeshBasicMaterial({ color: 0x9ca3af });
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 8), bulbM); bulb.position.y = 0.5; head.add(bulb);
    function arm(side) {
      const pivot = new THREE.Group(); pivot.position.set(side * 0.3, 0.86, 0); body.add(pivot);
      const a = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.3, 4, 8), M(color)); a.position.y = -0.2; a.castShadow = true; pivot.add(a);
      return pivot;
    }
    const armL = arm(-1), armR = arm(1);
    // props
    const paper = new THREE.Mesh(new THREE.PlaneGeometry(0.28, 0.36), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide }));
    paper.position.set(0, 0.85, 0.35); paper.rotation.x = -0.5; body.add(paper);
    const globe = new THREE.Mesh(new THREE.IcosahedronGeometry(0.16, 1), new THREE.MeshBasicMaterial({ color: 0x38bdf8, wireframe: true }));
    globe.position.set(0.4, 1.55, 0.2); g.add(globe);
    const phone = box(0.06, 0.16, 0.02, M('#111827'), 0.0, -0.42, 0.06, armR, false);
    const coins = new THREE.Group(); coins.position.set(-0.35, 0.85, 0.45); g.add(coins);
    for (let k = 0; k < 4; k++) cyl(0.07, 0.07, 0.03, M('#eab308'), 0, k * 0.035, 0, coins, 12);
    const zz = null;
    return { g, body, head, torso, armL, armR, bulbM, paper, globe, phone, coins, zz };
  }

  const agents = new Map();
  let you = null;

  function cardEl(a) {
    const el = document.createElement('div');
    Object.assign(el.style, {
      position: 'absolute', transform: 'translate(-50%,-100%)', padding: '4px 9px', borderRadius: '12px', background: 'rgba(255,255,255,.93)',
      color: '#0f172a', font: '600 11px system-ui,sans-serif', boxShadow: '0 2px 8px rgba(0,0,0,.25)', whiteSpace: 'nowrap', maxWidth: '170px',
      pointerEvents: 'auto', display: 'none', lineHeight: '1.25'
    });
    el.addEventListener('click', (e) => { e.stopPropagation(); B.tap('agent', a.id); ping(); });
    cardLayer.appendChild(el); return el;
  }
  function bubbleEl() {
    const el = document.createElement('div');
    Object.assign(el.style, { position: 'absolute', transform: 'translate(-50%,-100%)', font: '700 13px system-ui', color: '#fff', textShadow: '0 1px 3px rgba(0,0,0,.6)', display: 'none', pointerEvents: 'none' });
    cardLayer.appendChild(el); return el;
  }

  function ensureAgent(d) {
    let a = agents.get(d.id);
    if (a && a.color !== d.color) { scene.remove(a.c.g); a.card.remove(); a.bubble.remove(); agents.delete(d.id); a = null; }
    if (!a) {
      const c = character(d.color);
      scene.add(c.g);
      a = { id: d.id, color: d.color, c, card: null, bubble: bubbleEl(), pos: null, path: [], placeKey: '', place: null, walking: false, cardKey: '', phase: Math.random() * 6 };
      a.card = cardEl(a);
      c.g.traverse((m) => { if (m.isMesh) { m.userData.hit = { kind: 'agent', id: d.id }; hits.push(m); } });
      agents.set(d.id, a);
    }
    a.d = d;
    return a;
  }

  function placeFor(a) {
    const d = a.d, f = Math.max(0, Math.min(floors.length - 1, d.room || 0));
    const fl = floors[f];
    const slot = fl.slots[d.slot % fl.slots.length];
    if (S.salah && d.status !== 'asleep') {
      return { key: 'mat' + f, floor: f, x: slot.x, z: slot.z - (slot.bean ? -0.9 : 0.95), face: qiblaYaw(), mode: 'pray' };
    }
    if (S.meeting && S.meeting.members && S.meeting.members.indexOf(d.id) >= 0) {
      const k = S.meeting.members.indexOf(d.id) % floors[0].seats.length, s = floors[0].seats[k];
      return { key: 'table' + k, floor: 0, x: s.x, z: s.z, face: s.face, mode: 'table' };
    }
    return { key: 'desk' + f + '-' + d.slot, floor: f, x: slot.x, z: slot.z, face: slot.bean ? 0 : 0, mode: slot.bean ? 'bean' : 'desk', slot };
  }
  function qiblaYaw() { const b = (S.qibla || 0) * Math.PI / 180; return Math.atan2(Math.sin(b), -Math.cos(b)); }

  function planRoute(a, p) {
    const from = a.floor;
    a.path = [];
    if (from !== undefined && from !== p.floor) {
      const d1 = floors[from].door, d2 = floors[p.floor].door;
      a.path.push({ x: d1.x, z: d1.z, floor: from });
      a.path.push({ x: d2.x, z: d2.z, floor: p.floor, jump: true });
    }
    a.path.push({ x: p.x, z: p.z, floor: p.floor, end: true });
  }

  function updateAgentData() {
    const seen = new Set();
    S.agents.forEach((d) => { seen.add(d.id); ensureAgent(d); });
    for (const [id, a] of agents) if (!seen.has(id)) { scene.remove(a.c.g); a.card.remove(); a.bubble.remove(); agents.delete(id); }
    for (const a of agents.values()) {
      const p = placeFor(a);
      if (!a.pos) { a.pos = new V3(p.x, floors[p.floor].y, p.z); a.floor = p.floor; a.place = p; a.placeKey = p.key; a.path = []; a.face = p.face; }
      else if (p.key !== a.placeKey) { a.placeKey = p.key; a.place = p; planRoute(a, p); }
      else a.place = p;
      const d = a.d;
      const key = [d.name, d.emoji, d.status, d.card, d.line].join('|');
      if (key !== a.cardKey) {
        a.cardKey = key;
        const dot = `<span style="display:inline-block;width:7px;height:7px;border-radius:4px;background:${STATUS[d.status] || '#9ca3af'};margin-right:5px;vertical-align:1px"></span>`;
        const esc = (s) => String(s || '').replace(/[&<>]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch]));
        a.card.innerHTML = dot + esc(d.emoji) + ' <b>' + esc(d.name) + '</b>' +
          (d.card ? `<div style="font-weight:700;color:#334155;overflow:hidden;text-overflow:ellipsis">${esc(d.card)}</div>` : '') +
          (d.line ? `<div style="font-weight:500;color:#64748b;overflow:hidden;text-overflow:ellipsis">${esc(d.line)}</div>` : '');
        a.card.style.border = d.status === 'needs' ? '2px solid #ef4444' : '0';
      }
      a.c.bulbM.color.set(STATUS[d.status] || '#9ca3af');
      const lap = floors[a.place.floor] && a.place.slot ? a.place.slot.kit : null;
      if (lap) { lap.logo.color.set(d.status === 'asleep' ? '#334155' : d.color); lap.scr.color && lap.scr.color.set(d.status === 'working' ? '#1e3a8a' : '#111827'); }
    }
  }

  function animateAgent(a, t, dt) {
    const c = a.c, d = a.d;
    // walking along the route
    if (a.path.length) {
      const w = a.path[0];
      if (w.jump) { a.pos.set(w.x, floors[w.floor].y, w.z); a.floor = w.floor; a.path.shift(); }
      else {
        const dx = w.x - a.pos.x, dz = w.z - a.pos.z, dist = Math.hypot(dx, dz), step = 2.4 * dt;
        a.face = Math.atan2(dx, dz);
        if (dist <= step) { a.pos.x = w.x; a.pos.z = w.z; a.floor = w.floor; a.path.shift(); }
        else { a.pos.x += dx / dist * step; a.pos.z += dz / dist * step; }
      }
    }
    const walking = a.path.length > 0;
    const pose = walking ? 'walk' : a.place.mode === 'pray' ? 'pray' : d.status === 'needs' ? 'needs' : d.status === 'asleep' ? 'asleep' : d.status === 'done' ? 'done' : d.status === 'working' ? (d.pose || 'type') : a.place.mode === 'table' ? 'talk' : 'idle';
    if (!walking) a.face = lerpAngle(a.face, a.place.face, Math.min(1, dt * 6));
    c.g.position.copy(a.pos);
    c.g.rotation.y = a.face;
    const k = t + a.phase;
    let y = 0, bodyRx = 0, headRx = 0, headRz = 0, aL = 0, aR = 0, aLz = 0, aRz = 0;
    c.paper.visible = pose === 'read'; c.globe.visible = pose === 'web'; c.phone.visible = pose === 'call'; c.coins.visible = pose === 'money';
    switch (pose) {
      case 'walk': y = Math.abs(Math.sin(k * 9)) * 0.08; aL = Math.sin(k * 9) * 0.7; aR = -aL; break;
      case 'type': case 'web': case 'money': y = Math.sin(k * 18) * 0.01; aL = -1.1 + Math.sin(k * 22) * 0.18; aR = -1.1 + Math.cos(k * 20) * 0.18; headRx = 0.18; break;
      case 'read': aL = aR = -1.2; headRx = 0.3 + Math.sin(k * 0.8) * 0.05; c.paper.rotation.z = Math.sin(k * 2) * 0.05; break;
      case 'call': aR = -2.6; aRz = 0.35; aL = -0.2; headRz = 0.12; break;
      case 'talk': aL = -0.6 + Math.sin(k * 3) * 0.4; aR = -0.3 + Math.cos(k * 2.3) * 0.3; y = Math.sin(k * 2) * 0.02; headRz = Math.sin(k * 1.5) * 0.08; break;
      case 'needs': y = Math.abs(Math.sin(k * 6)) * 0.35; aR = -2.9 + Math.sin(k * 10) * 0.25; aRz = 0.2; c.bulbM.color.set((Math.floor(k * 4) % 2) ? '#ef4444' : '#fecaca'); break;
      case 'done': { const h = (k % 3.5); y = h < 0.5 ? Math.sin(h / 0.5 * Math.PI) * 0.25 : 0; if (h < 0.6) { aL = aR = -2.8; } break; }
      case 'asleep': headRx = 0.5; y = Math.sin(k * 1.2) * 0.015; break;
      case 'pray': {
        const cy = k % 9;
        if (cy < 3.5) { aL = aR = -0.9; aLz = -0.5; aRz = 0.5; }
        else if (cy < 5.5) { bodyRx = 1.0; aL = aR = -0.6; }
        else if (cy < 8) { bodyRx = 1.45; y = -0.45; aL = aR = -2.6; }
        else { y = -0.35; }
        break;
      }
      default: y = Math.sin(k * 1.6) * 0.012; headRz = Math.sin(k * 0.5) * 0.05;
    }
    c.body.position.y = y; c.body.rotation.x = bodyRx;
    c.head.rotation.x = headRx; c.head.rotation.z = headRz;
    c.armL.rotation.x = aL; c.armR.rotation.x = aR; c.armL.rotation.z = aLz; c.armR.rotation.z = aRz;
    if (c.globe.visible) c.globe.rotation.y += dt * 1.5;
    if (c.coins.visible) c.coins.scale.y = 0.6 + (Math.sin(k * 3) + 1) * 0.35;
  }
  function lerpAngle(a, b, t) { let d = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI; if (d < -Math.PI) d += Math.PI * 2; return a + d * t; }

  // ─────────────── the office dog ───────────────
  const dog = (() => {
    const g = new THREE.Group(); scene.add(g);
    const tan = M('#d9a066'), dark = M('#7c4a1e');
    box(0.55, 0.28, 0.28, tan, 0, 0.32, 0, g);
    const head = new THREE.Group(); head.position.set(0.33, 0.48, 0); g.add(head);
    box(0.24, 0.22, 0.22, tan, 0, 0, 0, head); box(0.12, 0.1, 0.14, M('#f5deb3'), 0.14, -0.05, 0, head);
    box(0.05, 0.14, 0.08, dark, -0.04, 0.12, 0.1, head); box(0.05, 0.14, 0.08, dark, -0.04, 0.12, -0.1, head);
    sphere(0.025, M('#111827'), 0.21, -0.02, 0, head);
    sphere(0.02, M('#111827'), 0.1, 0.04, 0.08, head); sphere(0.02, M('#111827'), 0.1, 0.04, -0.08, head);
    const legs = [];
    [[0.18, 0.09], [0.18, -0.09], [-0.18, 0.09], [-0.18, -0.09]].forEach(([x, z]) => legs.push(box(0.07, 0.2, 0.07, tan, x, 0.1, z, g)));
    const tail = box(0.18, 0.05, 0.05, dark, -0.34, 0.45, 0, g); tail.rotation.z = 0.7;
    g.traverse((m) => { if (m.isMesh) { m.userData.hit = { kind: 'pet', id: '' }; hits.push(m); } });
    return { g, head, legs, tail, pos: new V3(6.3, 0, 4.3), floor: 0, path: [], target: null, next: 0, bark: bubbleEl(), face: 0 };
  })();

  function dogThink(t) {
    if (t < dog.next || dog.path.length) return;
    dog.next = t + 2.5;
    const needy = S.needs && S.needs.length ? agents.get(S.needs[0]) : null;
    let f, x, z;
    if (needy && needy.pos) { f = needy.floor; x = needy.pos.x + 0.6; z = needy.pos.z + 0.8; dog.mode = 'bark'; }
    else {
      f = view.floor; dog.mode = 'wander';
      const busy = [...agents.values()].filter((a) => a.floor === f && a.d.status === 'working');
      if (busy.length && Math.random() < 0.5) { const a = busy[Math.floor(Math.random() * busy.length)]; x = a.pos.x + 0.3; z = (a.place.slot ? a.place.slot.deskZ : a.pos.z) + 0.1; dog.mode = 'nap'; }
      else { x = -3 + Math.random() * 9; z = -1.5 + Math.random() * 1.2; if (Math.random() < 0.3) { x = 6.3; z = 4.3; dog.mode = 'nap'; } }
    }
    dog.path = [];
    if (dog.floor !== f) { dog.path.push({ x: floors[dog.floor].door.x, z: floors[dog.floor].door.z, floor: dog.floor }); dog.path.push({ x: floors[f].door.x, z: floors[f].door.z, floor: f, jump: true }); }
    dog.path.push({ x, z, floor: f });
  }
  function animateDog(t, dt) {
    dogThink(t);
    let moving = false;
    if (dog.path.length) {
      const w = dog.path[0];
      if (w.jump) { dog.pos.set(w.x, 0, w.z); dog.floor = w.floor; dog.path.shift(); }
      else {
        const dx = w.x - dog.pos.x, dz = w.z - dog.pos.z, dist = Math.hypot(dx, dz), step = (dog.mode === 'bark' ? 4 : 2) * dt;
        dog.face = Math.atan2(-dz, dx);
        if (dist <= step) { dog.pos.x = w.x; dog.pos.z = w.z; dog.floor = w.floor; dog.path.shift(); } else { dog.pos.x += dx / dist * step; dog.pos.z += dz / dist * step; moving = true; }
      }
    }
    dog.g.position.set(dog.pos.x, floors[dog.floor] ? floors[dog.floor].y : 0, dog.pos.z);
    dog.g.rotation.y = dog.face;
    dog.legs.forEach((l, i) => { l.rotation.z = moving ? Math.sin(t * 16 + i * Math.PI) * 0.5 : 0; });
    dog.tail.rotation.x = Math.sin(t * (dog.mode === 'bark' ? 20 : 8)) * 0.6;
    const napping = !moving && dog.mode === 'nap';
    dog.g.scale.y = napping ? 0.7 : 1;
    dog.head.rotation.z = napping ? -0.4 : dog.mode === 'bark' && !moving ? Math.sin(t * 10) * 0.15 + 0.2 : 0;
    dog.barking = !moving && dog.mode === 'bark' && (t % 2.2) < 0.7;
    dog.sleeping = napping;
  }

  // ─────────────── confetti ───────────────
  const confetti = (() => {
    const n = 260, geo = new THREE.PlaneGeometry(0.08, 0.14), mat = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide, vertexColors: false });
    const mesh = new THREE.InstancedMesh(geo, mat, n); mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    const cols = ['#ef4444', '#f59e0b', '#22c55e', '#3b82f6', '#a855f7', '#ec4899'].map((c) => new THREE.Color(c));
    for (let i = 0; i < n; i++) mesh.setColorAt(i, cols[i % cols.length]);
    mesh.visible = false; mesh.frustumCulled = false; scene.add(mesh);
    const P = []; for (let i = 0; i < n; i++) P.push({ p: new V3(), v: new V3(), r: new THREE.Euler(), s: Math.random() * 5 });
    return { mesh, P, t: 0 };
  })();
  const dummy = new THREE.Object3D();
  function burst(f) {
    const y = floors[f].y;
    confetti.P.forEach((q) => { q.p.set((Math.random() - 0.5) * 10, y + H - 0.3, (Math.random() - 0.5) * 7); q.v.set((Math.random() - 0.5) * 2, -Math.random() * 1.5, (Math.random() - 0.5) * 2); });
    confetti.t = 4.5; confetti.mesh.visible = true;
  }
  function animateConfetti(dt) {
    if (confetti.t <= 0) return;
    confetti.t -= dt;
    confetti.P.forEach((q, i) => {
      q.v.y -= 1.2 * dt; q.v.x += Math.sin(q.s + confetti.t * 3) * 0.02; q.p.addScaledVector(q.v, dt);
      q.r.x += dt * 4; q.r.y += dt * 3;
      dummy.position.copy(q.p); dummy.rotation.copy(q.r); dummy.updateMatrix(); confetti.mesh.setMatrixAt(i, dummy.matrix);
    });
    confetti.mesh.instanceMatrix.needsUpdate = true;
    if (confetti.t <= 0) confetti.mesh.visible = false;
  }
  let gongSwing = 0;
  function celebrate(msg) {
    burst(view.floor); gongSwing = 1; toast(msg || '🎉 Done!'); B.haptic(40);
    for (const a of agents.values()) if (a.d.status !== 'asleep' && !a.path.length) a.hop = 1.2;
  }

  // ─────────────── the screen, plugs and routine board ───────────────
  function drawScreen(c, w, h) {
    const grd = c.createLinearGradient(0, 0, w, h); grd.addColorStop(0, '#1e1b4b'); grd.addColorStop(1, '#0f172a'); c.fillStyle = grd; c.fillRect(0, 0, w, h);
    c.fillStyle = '#a5b4fc'; c.font = 'bold 44px sans-serif'; c.fillText('ATLAS HQ', 40, 70);
    c.fillStyle = '#fff'; c.font = 'bold 54px sans-serif'; c.fillText(S.summary || 'All quiet', 40, 160);
    c.fillStyle = '#cbd5e1'; c.font = '36px sans-serif';
    if (S.meeting && S.meeting.topic) c.fillText('🤝 ' + S.meeting.topic.slice(0, 44), 40, 240);
    if (S.prayer) c.fillText('🕌 ' + S.prayer, 40, 310);
    if (S.loadshed) { c.fillStyle = '#fbbf24'; c.fillText('⚡ Load-shedding: on backup', 40, 370); }
  }
  function drawPlugs(c, w, h) {
    c.fillStyle = '#1f2937'; rr(c, 0, 0, w, h, 30); c.fill();
    c.fillStyle = '#e5e7eb'; c.font = 'bold 40px sans-serif'; c.fillText('🔌 Connectors', 28, 60);
    const list = (S.plugs || []).slice(0, 12);
    if (!list.length) { c.fillStyle = '#9ca3af'; c.font = '30px sans-serif'; c.fillText('None connected yet', 28, 130); return; }
    list.forEach((p, i) => {
      const x = 28 + (i % 2) * 240, y = 110 + Math.floor(i / 2) * 64;
      c.fillStyle = p.ok === true ? '#22c55e' : p.ok === false ? '#ef4444' : '#9ca3af'; c.beginPath(); c.arc(x + 14, y + 10, 12, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#f9fafb'; c.font = '28px sans-serif'; c.fillText((p.name || '').slice(0, 11), x + 36, y + 20);
    });
  }
  function drawRoutine(c, w, h) {
    c.fillStyle = '#fef3c7'; rr(c, 0, 0, w, h, 24); c.fill();
    c.fillStyle = '#92400e'; c.font = 'bold 40px sans-serif'; c.fillText('⏰ Next routine', 24, 60);
    c.fillStyle = '#451a03'; c.font = '32px sans-serif';
    const lines = (S.routine || 'None scheduled').match(/.{1,26}(\s|$)/g) || [''];
    lines.slice(0, 4).forEach((l, i) => c.fillText(l.trim(), 24, 120 + i * 42));
  }

  // ─────────────── camera: diorama or explore ───────────────
  const view = { mode: 'diorama', floor: 0, yaw: 0.65, pitch: 0.5, zoom: 1, target: new V3(0.8, 1, 0), camTarget: new V3(), focus: null };
  const player = { pos: new V3(0, 0, 3.5), vy: 0, floor: 0, yaw: Math.PI, look: 0.35, onGround: true };
  function fitDist() {
    const a = Math.min(camera.aspect, 1.2);
    return 17.5 / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * a);
  }
  function setFloor(i, fromUser) {
    i = Math.max(0, Math.min(floors.length - 1, i | 0));
    view.floor = i; view.focus = null;
    if (view.mode === 'explore') { player.floor = i; player.pos.set(floors[i].door.x + 0.4, floors[i].y, floors[i].door.z + 0.9); player.vy = 0; }
    if (!fromUser) B.room(i);
    touchActive();
  }
  function applyVisibility() {
    const overview = view.mode === 'diorama' && view.zoom > 1.7;
    floors.forEach((f, i) => { f.g.visible = view.mode === 'explore' || overview || i <= view.floor; });
    if (roofGroup) roofGroup.visible = view.mode === 'explore' || overview || view.floor === floors.length - 1 && false;
    for (const a of agents.values()) {
      const vis = view.mode === 'explore' || overview || a.floor <= view.floor;
      a.c.g.visible = vis;
    }
    dog.g.visible = view.mode === 'explore' || overview || dog.floor <= view.floor;
  }
  function updateCamera(dt) {
    if (view.mode === 'diorama') {
      const f = floors[view.floor];
      const goal = view.focus ? view.focus.clone().add(new V3(0, 0.9, 0)) : new V3(0.6, f.y + 0.9, 0.2);
      view.target.lerp(goal, Math.min(1, dt * 4));
      const dist = fitDist() * view.zoom * (view.focus ? 0.42 : 1);
      const cp = Math.cos(view.pitch);
      const want = new V3(view.target.x + Math.sin(view.yaw) * cp * dist, view.target.y + Math.sin(view.pitch) * dist, view.target.z + Math.cos(view.yaw) * cp * dist);
      camera.position.lerp(want, Math.min(1, dt * 5));
      camera.lookAt(view.target);
      roomLight.position.set(1, f.y + 2.6, 0.5);
    } else {
      const back = 3.6, up = 1.9;
      const want = new V3(player.pos.x - Math.sin(player.yaw) * back * Math.cos(player.look), player.pos.y + up + Math.sin(player.look) * back * 0.6, player.pos.z - Math.cos(player.yaw) * back * Math.cos(player.look));
      if (player.floor >= 0 && player.pos.z < D / 2 + 0.2) {
        // keep the camera inside the room so walls don't block it
        want.x = Math.max(-W / 2 + 0.3, Math.min(W / 2 + 4, want.x)); want.z = Math.max(-D / 2 + 0.3, want.z);
        want.y = Math.min(want.y, player.pos.y + H - 0.35);
      }
      camera.position.lerp(want, Math.min(1, dt * 8));
      camera.lookAt(player.pos.x, player.pos.y + 1.1, player.pos.z);
      roomLight.position.set(player.pos.x, player.pos.y + 2.6, player.pos.z);
    }
    applyVisibility();
  }

  // explore movement with collisions
  const joy = { x: 0, y: 0, id: null, el: document.getElementById('joy'), knob: document.getElementById('knob') };
  function movePlayer(dt) {
    const sp = 3.2;
    const fx = Math.sin(player.yaw), fz = Math.cos(player.yaw);
    const rx = -fz, rz = fx;
    let mx = (fx * -joy.y + rx * -joy.x) * sp * dt, mz = (fz * -joy.y + rz * -joy.x) * sp * dt;
    const moving = Math.abs(joy.x) + Math.abs(joy.y) > 0.08;
    if (moving) player.face = Math.atan2(mx, mz);
    const f = floors[player.floor];
    const outside = player.floor === 0 && player.pos.z > D / 2 - 0.1;
    let nx = player.pos.x + mx, nz = player.pos.z + mz;
    if (!outside) {
      const doorGap = player.floor === 0 && Math.abs(nx) < 1.0;
      nx = Math.max(-W / 2 + 0.35, Math.min(W / 2 - 0.35, nx));
      nz = Math.max(-D / 2 + 0.35, doorGap ? nz : Math.min(D / 2 - 0.35, nz));
      for (const s of f.solids) {
        if (nx > s.x1 - 0.3 && nx < s.x2 + 0.3 && nz > s.z1 - 0.3 && nz < s.z2 + 0.3) {
          const px = player.pos.x, pz = player.pos.z;
          if (px > s.x1 - 0.3 && px < s.x2 + 0.3) nz = pz; else if (pz > s.z1 - 0.3 && pz < s.z2 + 0.3) nx = px; else { nx = px; nz = pz; }
        }
      }
    } else {
      nx = Math.max(-40, Math.min(40, nx)); nz = Math.max(-30, Math.min(30, nz));
      if (nz < D / 2 && (Math.abs(nx) > 1.0 || nx < -W / 2 || nx > W / 2)) { if (nx > -W / 2 - 0.3 && nx < W / 2 + 0.3) nz = D / 2 + 0.05; }
    }
    player.pos.x = nx; player.pos.z = nz;
    player.vy -= 18 * dt; player.pos.y += player.vy * dt;
    const base = f.y;
    if (player.pos.y <= base) { player.pos.y = base; player.vy = 0; player.onGround = true; }
    // you
    you.c.g.position.copy(player.pos);
    you.c.g.rotation.y = lerpAngle(you.c.g.rotation.y, player.face === undefined ? player.yaw : player.face, Math.min(1, dt * 10));
    const t = performance.now() / 1000;
    you.c.body.position.y = moving && player.onGround ? Math.abs(Math.sin(t * 10)) * 0.08 : 0;
    you.c.armL.rotation.x = moving ? Math.sin(t * 10) * 0.7 : 0; you.c.armR.rotation.x = -you.c.armL.rotation.x;
    you.c.paper.visible = you.c.globe.visible = you.c.phone.visible = you.c.coins.visible = false;
    // what's nearby
    let best = null, bd = 1.9;
    interact.forEach((it) => { if (it.floor !== player.floor) return; const d = Math.hypot(it.pos.x - player.pos.x, it.pos.z - player.pos.z); if (d < bd) { bd = d; best = it; } });
    for (const a of agents.values()) if (a.floor === player.floor) { const d = Math.hypot(a.pos.x - player.pos.x, a.pos.z - player.pos.z); if (d < bd) { bd = d; best = { kind: 'agent', id: a.id, label: '💬 ' + a.d.emoji + ' ' + a.d.name }; } }
    if (Math.hypot(dog.pos.x - player.pos.x, dog.pos.z - player.pos.z) < 1.2 && dog.floor === player.floor) best = { kind: 'pet', id: '', label: '🐶 Pat the dog' };
    near = best;
    const act = document.getElementById('act');
    if (best) { act.textContent = best.label; act.style.display = 'block'; } else act.style.display = 'none';
  }
  let near = null;

  // ─────────────── touch ───────────────
  const ptrs = new Map();
  let pinch0 = 0, zoom0 = 1, downAt = 0, moved = 0, lastActive = performance.now();
  function touchActive() { lastActive = performance.now(); }
  const cv = renderer.domElement;
  cv.addEventListener('pointerdown', (e) => {
    cv.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); touchActive();
    if (ptrs.size === 1) { downAt = performance.now(); moved = 0; }
    if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch0 = Math.hypot(a.x - b.x, a.y - b.y); zoom0 = view.zoom; }
  });
  cv.addEventListener('pointermove', (e) => {
    const p = ptrs.get(e.pointerId); if (!p) return; touchActive();
    const dx = e.clientX - p.x, dy = e.clientY - p.y; moved += Math.abs(dx) + Math.abs(dy);
    p.x = e.clientX; p.y = e.clientY;
    if (ptrs.size === 2) {
      const [a, b] = [...ptrs.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y);
      if (pinch0 > 0 && view.mode === 'diorama') { view.zoom = Math.max(0.35, Math.min(2.6, zoom0 * pinch0 / d)); if (view.zoom > 0.8) view.focus = null; }
      return;
    }
    if (view.mode === 'diorama') {
      view.yaw = Math.max(0.08, Math.min(1.45, view.yaw - dx * 0.006));
      view.pitch = Math.max(0.18, Math.min(1.2, view.pitch + dy * 0.004));
    } else {
      player.yaw -= dx * 0.006; player.look = Math.max(-0.2, Math.min(1.1, player.look + dy * 0.004));
    }
  });
  function up(e) {
    const was = ptrs.has(e.pointerId); ptrs.delete(e.pointerId);
    if (ptrs.size < 2) pinch0 = 0;
    if (was && ptrs.size === 0 && moved < 10 && performance.now() - downAt < 400) tapAt(e.clientX, e.clientY);
  }
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', (e) => { ptrs.delete(e.pointerId); pinch0 = 0; });

  const ray = new THREE.Raycaster();
  function tapAt(x, y) {
    ray.setFromCamera(new THREE.Vector2(x / innerWidth * 2 - 1, -(y / innerHeight) * 2 + 1), camera);
    const vis = hits.filter((m) => { let o = m; while (o) { if (!o.visible) return false; o = o.parent; } return true; });
    const h = ray.intersectObjects(vis, false)[0];
    if (!h) return;
    const k = h.object.userData.hit;
    if (k.kind === 'agent' && view.mode === 'diorama') { const a = agents.get(k.id); if (a) view.focus = a.pos.clone(); }
    if (k.kind === 'pet') { petDog(); return; }
    if (k.kind === 'gong') { celebrate('🔔 Gong!'); return; }
    B.tap(k.kind, k.id); ping();
  }
  function petDog() { dog.mode = 'wander'; dog.next = performance.now() / 1000 + 3; toast('🐶 Good dog!'); B.haptic(20); B.tap('pet', ''); }
  function ping() { B.haptic(12); }

  // joystick
  joy.el.addEventListener('pointerdown', (e) => { e.stopPropagation(); joy.id = e.pointerId; joy.el.setPointerCapture(e.pointerId); joyMove(e); touchActive(); });
  joy.el.addEventListener('pointermove', (e) => { if (e.pointerId === joy.id) joyMove(e); });
  const joyEnd = (e) => { if (e.pointerId !== joy.id) return; joy.id = null; joy.x = joy.y = 0; joy.knob.style.left = '39px'; joy.knob.style.top = '39px'; };
  joy.el.addEventListener('pointerup', joyEnd); joy.el.addEventListener('pointercancel', joyEnd);
  function joyMove(e) {
    const r = joy.el.getBoundingClientRect(); let x = (e.clientX - r.left - r.width / 2) / (r.width / 2), y = (e.clientY - r.top - r.height / 2) / (r.height / 2);
    const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
    joy.x = x; joy.y = y; joy.knob.style.left = (39 + x * 40) + 'px'; joy.knob.style.top = (39 + y * 40) + 'px'; touchActive();
  }
  document.getElementById('jump').addEventListener('pointerdown', (e) => { e.stopPropagation(); if (player.onGround) { player.vy = 6.5; player.onGround = false; } touchActive(); });
  document.getElementById('act').addEventListener('pointerdown', (e) => {
    e.stopPropagation(); if (!near) return;
    if (near.kind === 'pet') petDog(); else if (near.kind === 'gong') celebrate('🔔 Gong!'); else { B.tap(near.kind, near.id); ping(); }
  });

  let toastT = 0;
  function toast(s) { const t = document.getElementById('toast'); t.textContent = s; t.style.opacity = 1; toastT = 2.4; }

  // ─────────────── light, weather and time ───────────────
  function applyAmbience() {
    const s = SKY[S.sky] || SKY.DAY;
    const storm = S.weather === 'storm', wet = S.weather === 'rain' || storm, grey = wet || S.weather === 'cloudy' || S.weather === 'fog';
    const bottom = new THREE.Color(s[0]), top = new THREE.Color(s[1]);
    if (grey) { bottom.lerp(new THREE.Color('#9aa3b2'), 0.5); top.lerp(new THREE.Color('#6b7280'), 0.5); }
    skyMat.uniforms.bottom.value.copy(bottom); skyMat.uniforms.top.value.copy(top);
    const night = S.sky === 'NIGHT' || S.sky === 'DUSK';
    stars.visible = S.sky === 'NIGHT' && !grey;
    hemi.color.copy(top).lerp(new THREE.Color('#ffffff'), 0.5); hemi.intensity = (night ? 0.45 : 0.85) * (grey ? 0.85 : 1);
    sun.color.set(s[2]); sun.intensity = s[3] * (grey ? 0.5 : 1);
    const hr = S.hour || 12, ang = (hr - 6) / 12.5 * Math.PI;
    const sx = Math.cos(ang) * 60, sy = Math.max(8, Math.sin(ang) * 60);
    sun.position.set(sx, sy, 30); sun.target.position.set(0, 0, 0);
    sunBall.position.set(sx * 3, Math.sin(ang) * 180, -160); sunBall.visible = !night && !grey && Math.sin(ang) > 0;
    moon.position.set(-80, 120, -200); moon.visible = S.sky === 'NIGHT' && !grey;
    scene.fog = S.weather === 'fog' ? new THREE.Fog(0xc9ced6, 18, 90) : null;
    rain.visible = wet;
    cityWindows.forEach((w) => w.m.color.set(night && w.lit ? '#ffd98a' : '#2a3350'));
    floors.forEach((f) => f.panes.forEach((m) => m.color.copy(bottom).lerp(top, 0.4).multiplyScalar(night ? 0.7 : 1.05)));
    const dark = S.loadshed;
    lamps.forEach((m) => m.color.set(dark ? '#3a3a2a' : night ? '#ffe7a8' : '#fff7dc'));
    roomLight.intensity = dark ? 0.12 : night ? 1.0 : 0.45;
    roomLight.color.set(night ? '#ffd7a0' : '#fff4e0');
    masjidGlow.forEach((m) => m.color.set(S.salah || night ? '#ffd27a' : '#5a4a2a'));
    if (roofGroup) { roofGroup.userData.sign.material.color.set(night ? '#c7d2fe' : '#6366f1'); roofGroup.userData.crescent.visible = S.event === 'ramadan' || S.event === 'eid'; }
    if (pcSign) pcSign.color.set(S.pcOnline ? '#22c55e' : '#7f1d1d');
    const yaw = qiblaYaw(); qiblaMats.forEach((m) => { m.rotation.z = -yaw; });
    if (screenTex) screenTex.redraw(drawScreen);
    if (plugTex) plugTex.redraw(drawPlugs);
    if (routineTex) routineTex.redraw(drawRoutine);
    if (jarFill) { const v = Math.max(0.04, Math.min(1, S.jar)); jarFill.scale.y = v * 0.66; jarFill.position.y = 0.02 + v * 0.33; jarFill.material = M(v > 0.5 ? '#22c55e' : v > 0.2 ? '#f59e0b' : '#ef4444'); }
    if (inboxStack) { const n = Math.min(12, S.approvals || 0); inboxStack.visible = n > 0; inboxStack.scale.y = Math.max(1, n * 2); inboxStack.position.y = 0.06 + n * 0.02; }
    if (changesStack) { const n = Math.min(12, S.changes || 0); changesStack.visible = n > 0; changesStack.scale.y = Math.max(1, n * 2); changesStack.position.y = 0.06 + n * 0.02; }
    setQuality();
  }
  function setQuality() {
    const low = !!S.low;
    renderer.shadowMap.enabled = !low; sun.castShadow = !low;
    const pr = low ? 1 : Math.min(window.devicePixelRatio || 1, 1.75);
    if (pr !== pixelRatio) { pixelRatio = pr; renderer.setPixelRatio(pr); renderer.setSize(innerWidth, innerHeight); }
  }

  // ─────────────── projecting the cards ───────────────
  const tmp = new V3();
  function placeLabel(el, obj, y, show) {
    if (!show) { el.style.display = 'none'; return; }
    tmp.set(obj.x, obj.y + y, obj.z).project(camera);
    if (tmp.z > 1 || tmp.x < -1.2 || tmp.x > 1.2 || tmp.y < -1.2 || tmp.y > 1.2) { el.style.display = 'none'; return; }
    el.style.display = 'block';
    el.style.left = ((tmp.x + 1) / 2 * innerWidth) + 'px'; el.style.top = ((1 - tmp.y) / 2 * innerHeight) + 'px';
  }
  function updateLabels(t) {
    const overview = view.mode === 'diorama' && view.zoom > 1.7;
    const close = view.mode === 'explore' || view.focus || view.zoom < 1.25;
    for (const a of agents.values()) {
      const onFloor = view.mode === 'explore' ? a.floor === player.floor : a.floor === view.floor;
      const show = onFloor && !overview;
      const needs = a.d.status === 'needs';
      a.card.style.fontSize = close ? '11px' : '9.5px';
      placeLabel(a.card, { x: a.pos.x, y: a.pos.y + a.c.body.position.y, z: a.pos.z }, 1.95, show && (close || needs || a.d.status === 'working' || a.d.status === 'done'));
      let bubble = '';
      if (a.d.status === 'asleep' && !a.path.length) bubble = 'z z z';
      else if (S.meeting && S.meeting.speaking === a.id && a.place.mode === 'table' && !a.path.length) bubble = '💬';
      a.bubble.textContent = bubble;
      placeLabel(a.bubble, { x: a.pos.x + 0.35, y: a.pos.y, z: a.pos.z }, 2.4 + Math.sin(t * 3) * 0.05, show && !!bubble);
    }
    dog.bark.textContent = dog.barking ? 'Woof!' : dog.sleeping ? 'zz' : '';
    const dogShow = (view.mode === 'explore' ? dog.floor === player.floor : dog.floor === view.floor) && (dog.barking || dog.sleeping);
    placeLabel(dog.bark, { x: dog.pos.x, y: floors[dog.floor].y, z: dog.pos.z }, 0.95, dogShow);
    if (you) { if (!you.card.innerHTML) you.card.innerHTML = '🙂 <b>You</b>'; placeLabel(you.card, player.pos, 1.95, view.mode === 'explore'); }
  }

  // ─────────────── loop ───────────────
  let last = performance.now(), paused = false, acc = 0;
  function frame(now) {
    requestAnimationFrame(frame);
    if (paused) { last = now; return; }
    const idle = now - lastActive > 4000 && view.mode === 'diorama' && confetti.t <= 0;
    const fps = S.low ? 20 : idle ? 30 : 60;
    acc += now - last; const dt0 = Math.min(0.1, (now - last) / 1000); last = now;
    if (acc < 1000 / fps - 2) return;
    const dt = Math.min(0.1, acc / 1000); acc = 0; void dt0;
    const t = now / 1000;
    for (const a of agents.values()) {
      animateAgent(a, t, dt);
      if (a.hop > 0) { a.hop -= dt; a.c.body.position.y += Math.abs(Math.sin(a.hop * 8)) * 0.3; }
    }
    animateDog(t, dt);
    animateConfetti(dt);
    if (view.mode === 'explore' && you) movePlayer(dt);
    if (gongGroup) { gongSwing = Math.max(0, gongSwing - dt * 0.4); gongGroup.userData.disc.rotation.x = Math.sin(t * 9) * 0.35 * gongSwing; }
    cars.forEach((c) => { c.x += c.dir * c.speed * dt; if (c.x > 70) c.x = -70; if (c.x < -70) c.x = 70; c.g.position.set(c.x, 0, c.lane); c.g.rotation.y = c.dir > 0 ? 0 : Math.PI; });
    blinkers.forEach((b) => { const on = b.slow ? (t % 1.6) < 0.3 : Math.sin(t * 5 + b.p) > 0.2; b.m.color.set(on ? (b.slow ? '#ef4444' : '#22c55e') : '#123018'); });
    if (rain.visible) { const p = rain.geometry.attributes.position; for (let i = 0; i < p.count; i++) { let y = p.getY(i) - dt * 22; if (y < 0) y = 40; p.setY(i, y); } p.needsUpdate = true; }
    if (S.weather === 'storm') hemi.intensity = (Math.random() < 0.004) ? 3 : Math.max(0.45, hemi.intensity * 0.9);
    if (toastT > 0) { toastT -= dt; if (toastT <= 0) document.getElementById('toast').style.opacity = 0; }
    updateCamera(dt);
    updateLabels(t);
    renderer.render(scene, camera);
  }

  // ─────────────── API for Atlas ───────────────
  let built = false;
  function build() {
    S.rooms.forEach((r, i) => buildFloor(i, r));
    buildRoof(S.rooms.length);
    const yc = character(S.you || '#f97316'); scene.add(yc.g); yc.g.visible = false;
    you = { c: yc, card: cardEl({ id: 'you' }) };
    you.card.style.pointerEvents = 'none';
    built = true;
  }
  const HQ = {
    update(json) {
      try {
        const n = typeof json === 'string' ? JSON.parse(json) : json;
        const first = !built;
        Object.assign(S, n);
        if (!built) build();
        updateAgentData();
        applyAmbience();
        if (lastCelebrate >= 0 && S.celebrate > lastCelebrate) celebrate('🎉 ' + (S.celebrateText || 'A task is done'));
        lastCelebrate = S.celebrate;
        if (first) { camera.position.set(30, 30, 40); B.ready(); }
      } catch (e) { B.log(String(e && e.stack || e)); }
    },
    goRoom(i) { setFloor(i, true); },
    focusAgent(id) {
      const a = agents.get(id); if (!a) return;
      if (view.mode === 'explore') { setFloor(a.floor, true); player.pos.set(a.pos.x + 0.2, floors[a.floor].y, a.pos.z + 1.6); player.yaw = Math.PI; }
      else { view.floor = a.floor; view.zoom = Math.min(view.zoom, 1); view.focus = a.pos.clone(); }
      B.room(a.floor); touchActive();
    },
    clearFocus() { view.focus = null; touchActive(); },
    setMode(m) {
      view.mode = m === 'explore' ? 'explore' : 'diorama';
      const on = view.mode === 'explore';
      camera.fov = on ? 62 : 30; camera.updateProjectionMatrix();
      ['joy', 'jump'].forEach((id) => { document.getElementById(id).style.display = on ? (id === 'jump' ? 'flex' : 'block') : 'none'; });
      if (!on) document.getElementById('act').style.display = 'none';
      if (you) you.c.g.visible = on;
      if (on) { player.floor = view.floor; player.pos.set(0.8, floors[view.floor].y, view.floor === 0 ? 2.4 : 0.1); player.yaw = Math.PI; player.look = 0.35; view.focus = null; }
      touchActive();
    },
    setInsets(top, bottom) { document.body.style.setProperty('--top', (top + 8) + 'px'); document.body.style.setProperty('--bottom', (bottom + 16) + 'px'); },
    pause(p) { paused = !!p; if (!p) touchActive(); },
    celebrate(msg) { celebrate(msg); },
    toast(s) { toast(s); }
  };
  window.HQ = HQ;

  addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
  requestAnimationFrame(frame);
  if (!window.AtlasHQ) {
    // opened in a normal browser: show a demo office
    HQ.update({
      agents: [
        { id: 'lead', name: 'Atlas', emoji: '🧭', color: '#6366f1', room: 0, slot: 0, status: 'working', pose: 'talk', card: 'Plan the week', line: 'Asking Planner…' },
        { id: 'scout', name: 'Scout', emoji: '🔎', color: '#0ea5e9', room: 4, slot: 0, status: 'working', pose: 'web', card: 'Laptop prices', line: 'Searching the web' },
        { id: 'planner', name: 'Planner', emoji: '🗓️', color: '#10b981', room: 1, slot: 1, status: 'needs', card: 'Family dinner', line: 'Needs your OK' },
        { id: 'analyst', name: 'Hisaab', emoji: '📊', color: '#14b8a6', room: 2, slot: 0, status: 'working', pose: 'money', card: 'Spending', line: 'Reading bank SMS' },
        { id: 'critic', name: 'Critic', emoji: '🧐', color: '#ef4444', room: 0, slot: 1, status: 'done', card: 'Review', line: 'Done' },
        { id: 'writer', name: 'Quill', emoji: '✍️', color: '#ec4899', room: 4, slot: 1, status: 'idle' },
        { id: 'operator', name: 'Operator', emoji: '🤖', color: '#f59e0b', room: 5, slot: 0, status: 'asleep' }],
      needs: ['planner'], approvals: 2, changes: 3, jar: 0.7, summary: '3 working · 1 needs you', prayer: 'Asr in 42 min', routine: 'Morning brief at 7:30',
      plugs: [{ name: 'Hermes', ok: true }, { name: 'Scrapling', ok: false }, { name: 'Notion', ok: true }], sky: 'GOLDEN', hour: 16, celebrate: 0
    });
  }
})();
