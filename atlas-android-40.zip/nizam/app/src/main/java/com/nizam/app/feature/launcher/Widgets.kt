package com.nizam.app.feature.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/**
 * Widgets on the home screen: Atlas's own (drawn in the current theme) and any Android widget from
 * your apps. Stored as a list: "atlas:<kind>" or "app:<appWidgetId>".
 */
object HomeWidgets {
    val ATLAS = listOf("clock" to "Clock & date", "weather" to "Weather", "prayer" to "Next prayer", "battery" to "Battery",
        "media" to "Now playing", "tasks" to "Tasks", "companion" to "Companion", "screentime" to "Screen time", "quote" to "Quote", "atlas" to "Ask Atlas")
    const val HOST_ID = 4711
    private var host: AppWidgetHost? = null
    fun host(c: Context): AppWidgetHost = host ?: AppWidgetHost(c.applicationContext, HOST_ID).also { host = it }

    fun list(c: Context): List<String> = Launcher.get(c, "widgets", "atlas:clock,atlas:weather,atlas:prayer,atlas:media,atlas:battery").split(',').filter { it.isNotBlank() }
    fun save(c: Context, l: List<String>) = Launcher.set(c, "widgets", l.joinToString(","))
    fun add(c: Context, w: String) = save(c, list(c) + w)
    fun remove(c: Context, w: String) {
        if (w.startsWith("app:")) runCatching { host(c).deleteAppWidgetId(w.removePrefix("app:").toInt()) }
        save(c, list(c) - w)
    }
    fun move(c: Context, w: String, d: Int) { val l = list(c).toMutableList(); val i = l.indexOf(w); val j = i + d
        if (i >= 0 && j in l.indices) { l.removeAt(i); l.add(j, w); save(c, l) } }
}

@Composable
fun WidgetCard(theme: HomeTheme, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    Box(modifier.fillMaxWidth().clip(RoundedCornerShape(theme.corner)).background(theme.panel)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(16.dp)) { content() }
}

@Composable
fun WidgetView(key: String, theme: HomeTheme, editing: Boolean, info: HomeInfo, onChanged: () -> Unit, openAtlas: () -> Unit) {
    val c = LocalContext.current
    Box {
        if (key.startsWith("app:")) {
            val id = key.removePrefix("app:").toIntOrNull()
            val pinfo = id?.let { AppWidgetManager.getInstance(c).getAppWidgetInfo(it) }
            if (id != null && pinfo != null) Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(theme.corner))) {
                AndroidView({ ctx -> HomeWidgets.host(ctx).createView(ctx.applicationContext, id, pinfo).apply { setAppWidget(id, pinfo) } },
                    Modifier.fillMaxWidth().height(maxOf(pinfo.minHeight, 110).coerceAtMost(420).let { (it / c.resources.displayMetrics.density).dp }.coerceAtLeast(110.dp)))
            } else WidgetCard(theme) { Text("This widget's app was removed.", color = theme.onPanel) }
        } else AtlasWidget(key.removePrefix("atlas:"), theme, info, openAtlas)
        if (editing) Row(Modifier.align(Alignment.TopEnd).padding(6.dp).clip(RoundedCornerShape(50)).background(Color70)) {
            Icon(Icons.Rounded.KeyboardArrowUp, "Move up", Modifier.clickable { HomeWidgets.move(c, key, -1); onChanged() }.padding(6.dp), tint = androidx.compose.ui.graphics.Color.White)
            Icon(Icons.Rounded.KeyboardArrowDown, "Move down", Modifier.clickable { HomeWidgets.move(c, key, 1); onChanged() }.padding(6.dp), tint = androidx.compose.ui.graphics.Color.White)
            Icon(Icons.Rounded.Close, "Remove", Modifier.clickable { HomeWidgets.remove(c, key); onChanged() }.padding(6.dp), tint = androidx.compose.ui.graphics.Color.White)
        }
    }
}

private val Color70 = androidx.compose.ui.graphics.Color(0xB3000000)

/** Live facts the home screen shows (filled by the launcher). */
data class HomeInfo(val weather: String = "", val temp: String = "", val prayer: String = "", val prayerIn: String = "",
                    val tasks: List<String> = emptyList(), val quote: String = "", val screenMin: Long = 0)

@Composable
private fun AtlasWidget(kind: String, t: HomeTheme, info: HomeInfo, openAtlas: () -> Unit) {
    val c = LocalContext.current
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalTime.now(); delay(15_000) } }
    when (kind) {
        "clock" -> WidgetCard(t) {
            Column {
                Text(now.format(DateTimeFormatter.ofPattern(if (android.text.format.DateFormat.is24HourFormat(c)) "HH:mm" else "h:mm")),
                    color = t.onPanel, fontSize = 52.sp, fontFamily = t.font, fontWeight = if (t.clock == "ios") FontWeight.Light else FontWeight.Normal)
                Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = t.onPanel.copy(alpha = 0.7f), fontFamily = t.font)
            }
        }
        "weather" -> WidgetCard(t) { Row(verticalAlignment = Alignment.CenterVertically) {
            Text(info.temp.ifBlank { "—" }, color = t.onPanel, fontSize = 40.sp, fontFamily = t.font, fontWeight = FontWeight.Light)
            Column(Modifier.padding(start = 14.dp)) {
                Text(info.weather.ifBlank { "Weather" }.replaceFirstChar { it.uppercase() }, color = t.onPanel, fontFamily = t.font, fontWeight = FontWeight.SemiBold)
                Text("Updated every 30 min", color = t.onPanel.copy(alpha = 0.6f), fontSize = 12.sp, fontFamily = t.font)
            }
        } }
        "prayer" -> WidgetCard(t) { Column {
            Text("Next prayer", color = t.accent, fontSize = 12.sp, fontFamily = t.font, fontWeight = FontWeight.SemiBold)
            Text(info.prayer.ifBlank { "—" }, color = t.onPanel, fontSize = 26.sp, fontFamily = t.font)
            if (info.prayerIn.isNotBlank()) Text("in ${info.prayerIn}", color = t.onPanel.copy(alpha = 0.7f), fontFamily = t.font)
        } }
        "battery" -> {
            val i = remember(now) { c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }
            val pct = i?.let { it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / it.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1) } ?: 0
            val charging = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING
            WidgetCard(t) { Column {
                Text("Battery${if (charging) " · charging" else ""}", color = t.onPanel.copy(alpha = 0.7f), fontSize = 12.sp, fontFamily = t.font)
                Text("$pct%", color = t.onPanel, fontSize = 30.sp, fontFamily = t.font)
                LinearProgressIndicator(progress = { pct / 100f }, color = if (pct < 20) androidx.compose.ui.graphics.Color(0xFFFF453A) else t.accent,
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)))
            } }
        }
        "media" -> {
            var tick by remember { mutableStateOf(0) }
            LaunchedEffect(Unit) { while (true) { delay(3000); tick++ } }
            val mc = remember(tick) { Controls.media(c) }
            val md = mc?.metadata
            WidgetCard(t) { Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(md?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Nothing playing", color = t.onPanel, fontFamily = t.font,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(md?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: "Music from any app shows here", color = t.onPanel.copy(alpha = 0.7f),
                        fontSize = 12.sp, fontFamily = t.font, maxLines = 1)
                }
                if (mc != null) {
                    val playing = mc.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
                    Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(34.dp).clickable { mc.transportControls.skipToPrevious() }, tint = t.onPanel)
                    Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/pause", Modifier.size(40.dp).clickable {
                        if (playing) mc.transportControls.pause() else mc.transportControls.play(); tick++ }, tint = t.onPanel)
                    Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(34.dp).clickable { mc.transportControls.skipToNext() }, tint = t.onPanel)
                }
            } }
        }
        "tasks" -> WidgetCard(t) { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Tasks", color = t.accent, fontSize = 12.sp, fontFamily = t.font, fontWeight = FontWeight.SemiBold)
            if (info.tasks.isEmpty()) Text("All clear.", color = t.onPanel, fontFamily = t.font)
            info.tasks.take(4).forEach { Text("○  $it", color = t.onPanel, fontFamily = t.font, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        } }
        "companion" -> WidgetCard(t) { Row(verticalAlignment = Alignment.CenterVertically) {
            val pet = remember { com.nizam.app.feature.companion.Companion.load(c) }
            com.nizam.app.feature.companion.Creature(pet, com.nizam.app.feature.companion.Companion.Mood.HAPPY, 0, Modifier.size(72.dp))
            Text(if (pet.hatched) "${pet.name} says hi!" else "Your egg is waiting on Atlas's Today screen.", color = t.onPanel, fontFamily = t.font, modifier = Modifier.padding(start = 10.dp))
        } }
        "screentime" -> WidgetCard(t) { Column {
            Text("Screen time today", color = t.onPanel.copy(alpha = 0.7f), fontSize = 12.sp, fontFamily = t.font)
            Text(if (info.screenMin > 0) "${info.screenMin / 60}h ${info.screenMin % 60}m" else "—", color = t.onPanel, fontSize = 28.sp, fontFamily = t.font)
        } }
        "quote" -> WidgetCard(t) { Text(info.quote.ifBlank { "“Take benefit of five before five.”" }, color = t.onPanel, fontFamily = t.font) }
        else -> WidgetCard(t, onClick = openAtlas) { Text("✦  Ask Atlas anything…", color = t.onPanel, fontFamily = t.font) }
    }
}
