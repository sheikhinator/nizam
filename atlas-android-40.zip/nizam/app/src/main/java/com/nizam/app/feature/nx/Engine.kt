package com.nizam.app.feature.nx

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.nizam.app.AppContainer
import com.nizam.app.feature.brain2.Calc
import com.nizam.app.feature.next.JsonStore
import com.nizam.app.feature.notes.MarkdownView
import com.nizam.app.net.Ai
import com.nizam.app.ui.components.Feedback
import com.nizam.app.ui.design.AtlasScreen
import com.nizam.app.ui.design.Button
import com.nizam.app.ui.design.Capsule
import com.nizam.app.ui.design.EmptySpec
import com.nizam.app.ui.design.EmptyState
import com.nizam.app.ui.design.Group
import com.nizam.app.ui.design.Hub
import com.nizam.app.ui.design.ListRow
import com.nizam.app.ui.design.SectionHeader
import com.nizam.app.ui.design.Space
import com.nizam.app.ui.design.pressable
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

enum class K { TEXT, LONG, NUMBER, DATE, CHOICE }

/** One input on a tool: a line, a paragraph, a number (lakh/crore understood), a date or a choice. */
data class F(val key: String, val label: String, val kind: K = K.TEXT, val hint: String = "", val options: List<String> = emptyList(), val default: String = "", val optional: Boolean = false)

sealed class Spec(val id: String, val title: String, val blurb: String, val icon: ImageVector, val hub: Hub, val words: String)

/** Ask-and-answer tool: fill the fields, get one written result (saved, shareable, readable aloud, printable). */
class AiSpec(id: String, title: String, blurb: String, icon: ImageVector, hub: Hub, words: String = "",
             val fields: List<F>, val system: String, val web: Boolean = false, val button: String = "Go", val tokens: Int = 1400,
             val prompt: (Map<String, String>) -> String) : Spec(id, title, blurb, icon, hub, words)

/** A conversation with a character or expert. [setup] fields shape who they are. */
class ChatSpec(id: String, title: String, blurb: String, icon: ImageVector, hub: Hub, words: String = "",
               val setup: List<F> = emptyList(), val web: Boolean = false, val opener: String = "",
               val persona: (Map<String, String>) -> String) : Spec(id, title, blurb, icon, hub, words)

/** A ledger or log kept on the phone. [summary] is the line at the top; [line] titles each entry. */
class LogSpec(id: String, title: String, blurb: String, icon: ImageVector, hub: Hub, words: String = "",
              val fields: List<F>, val sealed: Boolean = false,
              val line: (JSONObject) -> Pair<String, String> = { o -> o.optString("_0") to "" },
              val summary: (List<JSONObject>) -> List<String> = { emptyList() }) : Spec(id, title, blurb, icon, hub, words)

/** A calculator: inputs become variables, each output is an expression worked out on the phone. */
class CalcSpec(id: String, title: String, blurb: String, icon: ImageVector, hub: Hub, words: String = "",
               val inputs: List<F>, val outputs: List<Pair<String, String>>, val note: String = "") : Spec(id, title, blurb, icon, hub, words)

/** Useful official links in one place. */
class LinkSpec(id: String, title: String, blurb: String, icon: ImageVector, hub: Hub, words: String = "",
               val links: List<Triple<String, String, String>>) : Spec(id, title, blurb, icon, hub, words)

/** A hand-built screen. */
class ScreenSpec(id: String, title: String, blurb: String, icon: ImageVector, hub: Hub, words: String = "",
                 val content: @Composable (AppContainer, (String) -> Unit) -> Unit) : Spec(id, title, blurb, icon, hub, words)

object Share {
    fun text(c: Context, text: String, subject: String = "Atlas") {
        c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, subject)
            .putExtra(Intent.EXTRA_TEXT, text), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun file(c: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(c, c.packageName + ".fileprovider", f)
        c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun out(c: Context, name: String) = File(c.cacheDir, "share").apply { mkdirs() }.let { File(it, name) }
    fun open(c: Context, url: String) = runCatching {
        c.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Plain, clean A4 PDFs from text: letters, CVs, invoices, reports. */
object Pdf {
    fun fromText(c: Context, title: String, body: String): File {
        val doc = PdfDocument()
        val w = 595; val h = 842; val m = 50f
        val head = Paint().apply { textSize = 18f; isFakeBoldText = true; isAntiAlias = true }
        val p = Paint().apply { textSize = 11f; isAntiAlias = true }
        val bold = Paint(p).apply { isFakeBoldText = true }
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, 1).create())
        var y = m + 10
        var n = 1
        fun newPage() { doc.finishPage(page); n++; page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create()); y = m }
        if (title.isNotBlank()) { page.canvas.drawText(title, m, y, head); y += 30 }
        body.lines().forEach { raw ->
            val isHead = raw.startsWith("#")
            val line = raw.trimStart('#', ' ').replace("**", "").replace(Regex("^[-*] "), "• ")
            val paint = if (isHead) bold else p
            if (line.isBlank()) { y += 8; return@forEach }
            val words = line.split(' ')
            var cur = StringBuilder()
            for (word in words) {
                val tryLine = if (cur.isEmpty()) word else "$cur $word"
                if (paint.measureText(tryLine) > w - 2 * m && cur.isNotEmpty()) {
                    if (y > h - m) newPage()
                    page.canvas.drawText(cur.toString(), m, y, paint); y += 16; cur = StringBuilder(word)
                } else cur = StringBuilder(tryLine)
            }
            if (cur.isNotEmpty()) { if (y > h - m) newPage(); page.canvas.drawText(cur.toString(), m, y, paint); y += if (isHead) 20 else 16 }
        }
        doc.finishPage(page)
        val f = Share.out(c, title.ifBlank { "Atlas" }.replace(Regex("[^A-Za-z0-9 _-]"), "").take(40).trim().ifBlank { "Atlas" } + ".pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }
}

@Composable
fun FieldInput(f: F, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    when (f.kind) {
        K.CHOICE -> Column(modifier) {
            Text(f.label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(Space.s), modifier = Modifier.padding(top = 4.dp)) {
                items(f.options.size) { i -> val o = f.options[i]; Capsule(o, value == o) { onChange(o) } }
            }
        }
        else -> OutlinedTextField(value, onChange, modifier.fillMaxWidth().let { if (f.kind == K.LONG) it.heightIn(min = 110.dp) else it },
            label = { Text(f.label + if (f.optional) " (optional)" else "") },
            placeholder = if (f.hint.isBlank()) null else { { Text(f.hint) } },
            singleLine = f.kind != K.LONG,
            keyboardOptions = if (f.kind == K.NUMBER) KeyboardOptions(keyboardType = KeyboardType.Text) else KeyboardOptions.Default)
    }
}

@Composable
private fun rememberSpeaker(): com.nizam.app.feature.voice.Speaker {
    val ctx = LocalContext.current
    val s = remember { com.nizam.app.feature.voice.Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { s.release() } }
    return s
}

@Composable
fun ResultActions(title: String, text: String) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    Row(Modifier.padding(horizontal = Space.page, vertical = Space.s), horizontalArrangement = Arrangement.spacedBy(Space.s)) {
        Capsule("Copy", false) {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText(title, text))
            Feedback.show("Copied")
        }
        Capsule("Share", false) { Share.text(ctx, text, title) }
        Capsule("Listen", false) { speaker.speak(text.replace(Regex("[#*_`>]"), "")) }
        Capsule("PDF", false) { runCatching { Share.file(ctx, Pdf.fromText(ctx, title, text), "application/pdf") }.onFailure { Feedback.show("Couldn't make the PDF") } }
    }
}

@Composable
fun Md(text: String) {
    val ctx = LocalContext.current
    SelectionContainer { Column { MarkdownView(text, onLink = {}, onTag = {}, onUrl = { Share.open(ctx, it) }, onToggleTask = {}, embed = { null }) } }
}

@Composable
fun AiToolScreen(spec: AiSpec, container: AppContainer) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val values = remember { mutableStateMapOf<String, String>().apply { spec.fields.forEach { put(it.key, it.default) } } }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    val store = remember { JsonStore(ctx, "nx_${spec.id}") }
    var history by remember { mutableStateOf(store.all().reversed()) }
    val ready = spec.fields.all { it.optional || values[it.key].orEmpty().isNotBlank() }
    AtlasScreen(title = spec.title, subtitle = spec.blurb, hub = spec.hub) {
        item("form") {
            Group(Modifier.padding(horizontal = Space.page, vertical = Space.s)) {
                spec.fields.forEach { f -> FieldInput(f, values[f.key].orEmpty(), { values[f.key] = it }, Modifier.padding(bottom = Space.s)) }
                Button(onClick = {
                    busy = true; result = null
                    val snapshot = values.toMap()
                    scope.launch {
                        runCatching { Ai.generate(container.settingsRepository, spec.prompt(snapshot), system = spec.system, maxOutputTokens = spec.tokens, useWeb = spec.web) }
                            .onSuccess { r ->
                                result = r
                                store.add(JSONObject().put("in", snapshot.values.filter { it.isNotBlank() }.joinToString(" · ").take(120)).put("out", r).put("t", System.currentTimeMillis()))
                                store.all().let { all -> if (all.size > 25) store.save(all.takeLast(25)) }
                                history = store.all().reversed()
                            }
                            .onFailure { Feedback.show(it.message ?: "Couldn't do that") }
                        busy = false
                    }
                }, enabled = ready && !busy) { Text(if (busy) "Working…" else spec.button) }
            }
        }
        result?.let { r ->
            item("out") { Group(Modifier.padding(horizontal = Space.page, vertical = Space.s)) { Md(r) } }
            item("act") { ResultActions(spec.title, r) }
        }
        if (history.isNotEmpty()) item("hh") { SectionHeader("Earlier") }
        history.forEach { h ->
            item(h.optString("id")) {
                ListRow(h.optString("in").ifBlank { spec.title }, supporting = h.optString("out").replace(Regex("[#*_]"), "").take(90), icon = Icons.Outlined.History,
                    trailing = { Text("✕", Modifier.padding(Space.s).pressable { store.remove(h.optString("id")); history = store.all().reversed() }, color = MaterialTheme.colorScheme.onSurfaceVariant) }) {
                    result = h.optString("out")
                }
            }
        }
    }
}

@Composable
fun ChatToolScreen(spec: ChatSpec, container: AppContainer) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val setup = remember { mutableStateMapOf<String, String>().apply { spec.setup.forEach { put(it.key, it.default) } } }
    var started by remember { mutableStateOf(spec.setup.isEmpty()) }
    val msgs = remember { mutableStateListOf<Pair<Boolean, String>>().apply { if (spec.setup.isEmpty() && spec.opener.isNotBlank()) add(false to spec.opener) } }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun send(text: String) {
        if (text.isBlank()) return
        msgs += true to text; input = ""; busy = true
        val convo = msgs.takeLast(16).joinToString("\n") { (me, t) -> (if (me) "User: " else "You: ") + t }
        scope.launch {
            runCatching {
                Ai.generate(container.settingsRepository, "$convo\nYou:", system = spec.persona(setup.toMap()) +
                    "\nStay in role. Reply conversationally, usually under 150 words. Match the user's language (English, Urdu or Roman Urdu).",
                    maxOutputTokens = 700, useWeb = spec.web)
            }.onSuccess { msgs += false to it.trim().removePrefix("You:").trim() }.onFailure { Feedback.show(it.message ?: "No reply") }
            busy = false
        }
    }
    AtlasScreen(title = spec.title + (spec.setup.firstOrNull()?.let { setup[it.key]?.takeIf { v -> started && v.isNotBlank() }?.let { v -> " · $v" } } ?: ""),
        subtitle = spec.blurb, hub = spec.hub, actions = {
            if (started && msgs.isNotEmpty()) Text("Share", Modifier.padding(Space.s).pressable {
                Share.text(ctx, msgs.joinToString("\n\n") { (me, t) -> (if (me) "Me: " else "${spec.title}: ") + t }, spec.title)
            }, style = MaterialTheme.typography.labelLarge)
        }) {
        if (!started) {
            item("setup") {
                Group(Modifier.padding(horizontal = Space.page, vertical = Space.s)) {
                    spec.setup.forEach { f -> FieldInput(f, setup[f.key].orEmpty(), { setup[f.key] = it }, Modifier.padding(bottom = Space.s)) }
                    Button(onClick = { started = true; if (spec.opener.isNotBlank()) send(spec.opener.replace("{0}", setup[spec.setup.first().key].orEmpty())) },
                        enabled = spec.setup.all { it.optional || setup[it.key].orEmpty().isNotBlank() }) { Text("Begin") }
                }
            }
            return@AtlasScreen
        }
        msgs.forEachIndexed { i, (me, t) ->
            item("m$i") {
                Box(Modifier.fillMaxWidth().padding(horizontal = Space.page, vertical = 4.dp), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
                    Box(Modifier.widthIn(max = 320.dp).background(if (me) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)) {
                        if (me) Text(t, style = MaterialTheme.typography.bodyMedium) else Md(t)
                    }
                }
            }
        }
        if (busy) item("typing") { Text("…", Modifier.padding(horizontal = Space.page), style = MaterialTheme.typography.titleLarge) }
        item("in") {
            Row(Modifier.padding(horizontal = Space.page, vertical = Space.s), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.s)) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Say something") }, maxLines = 4)
                Button(onClick = { send(input.trim()) }, enabled = input.isNotBlank() && !busy) { Text("Send") }
            }
        }
    }
}

/** Reads a number the way people type it: "2.5 lakh", "45,000", "3k". */
fun num(s: String?): Double = s?.takeIf { it.isNotBlank() }?.let { runCatching { Calc.eval(it) }.getOrNull() } ?: 0.0
fun rs(v: Double) = (if (v < 0) "−Rs " else "Rs ") + "%,d".format(kotlin.math.abs(v).toLong())

@Composable
fun LogToolScreen(spec: LogSpec) {
    val ctx = LocalContext.current
    val store = remember { JsonStore(ctx, "nxlog_${spec.id}", spec.sealed) }
    var list by remember { mutableStateOf(store.all().reversed()) }
    val values = remember { mutableStateMapOf<String, String>().apply { spec.fields.forEach { put(it.key, it.default.ifBlank { if (it.kind == K.DATE) java.time.LocalDate.now().toString() else "" }) } } }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<String?>(null) }
    fun reset() { spec.fields.forEach { values[it.key] = it.default.ifBlank { if (it.kind == K.DATE) java.time.LocalDate.now().toString() else "" } }; editing = null }
    val summary = remember(list) { runCatching { spec.summary(list) }.getOrDefault(emptyList()) }
    AtlasScreen(title = spec.title, subtitle = spec.blurb, hub = spec.hub, actions = {
        Text(if (adding) "Close" else "Add", Modifier.padding(Space.s).pressable { adding = !adding; if (!adding) reset() }, style = MaterialTheme.typography.labelLarge, color = spec.hub.tint())
    }) {
        if (summary.isNotEmpty()) item("sum") {
            Group(Modifier.padding(horizontal = Space.page, vertical = Space.s)) {
                summary.forEachIndexed { i, s -> Text(s, style = if (i == 0) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
                    fontWeight = if (i == 0) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.padding(vertical = 2.dp)) }
            }
        }
        if (adding || list.isEmpty()) item("form") {
            Group(Modifier.padding(horizontal = Space.page, vertical = Space.s)) {
                spec.fields.forEach { f -> FieldInput(f, values[f.key].orEmpty(), { values[f.key] = it }, Modifier.padding(bottom = Space.s)) }
                Button(onClick = {
                    val o = JSONObject(); spec.fields.forEachIndexed { i, f -> o.put(f.key, values[f.key].orEmpty().trim()); if (i == 0) o.put("_0", values[f.key].orEmpty().trim()) }
                    val id = editing
                    if (id != null) store.update(id) { e -> o.keys().forEach { k -> e.put(k, o.get(k)) } } else store.add(o.put("t", System.currentTimeMillis()))
                    list = store.all().reversed(); reset(); adding = false
                }, enabled = spec.fields.all { it.optional || values[it.key].orEmpty().isNotBlank() }) { Text(if (editing != null) "Save" else "Add") }
            }
        }
        if (list.isEmpty() && !adding) item("e") { EmptyState(EmptySpec(spec.icon, "Nothing yet", "Add the first entry above.")) }
        list.forEach { o ->
            item(o.optString("id")) {
                val (a, b) = runCatching { spec.line(o) }.getOrDefault(o.optString("_0") to "")
                ListRow(a, supporting = b.ifBlank { null }, icon = spec.icon, tint = spec.hub.tint(), trailing = {
                    Text("✕", Modifier.padding(Space.s).pressable { store.remove(o.optString("id")); list = store.all().reversed() }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }) {
                    spec.fields.forEach { f -> values[f.key] = o.optString(f.key) }; editing = o.optString("id"); adding = true
                }
            }
        }
    }
}

@Composable
fun CalcToolScreen(spec: CalcSpec) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("nxcalc_${spec.id}", 0) }
    val values = remember { mutableStateMapOf<String, String>().apply { spec.inputs.forEach { put(it.key, prefs.getString(it.key, null) ?: it.default) } } }
    val vars = spec.inputs.associate { f ->
        f.key.lowercase() to (if (f.kind == K.CHOICE) f.options.indexOf(values[f.key]).coerceAtLeast(0).toDouble() else num(values[f.key]))
    }
    val results = spec.outputs.map { (label, expr) ->
        label to runCatching { Calc.fmt(Calc.eval(expr, vars)) }.getOrElse { "—" }
    }
    AtlasScreen(title = spec.title, subtitle = spec.blurb, hub = spec.hub) {
        item("in") {
            Group(Modifier.padding(horizontal = Space.page, vertical = Space.s)) {
                spec.inputs.forEach { f -> FieldInput(f, values[f.key].orEmpty(), { values[f.key] = it; prefs.edit().putString(f.key, it).apply() }, Modifier.padding(bottom = Space.s)) }
            }
        }
        item("out") {
            Group(Modifier.padding(horizontal = Space.page, vertical = Space.s)) {
                results.forEachIndexed { i, (label, v) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(v, style = if (i == results.lastIndex) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold, color = if (i == results.lastIndex) spec.hub.tint() else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
        item("share") { Row(Modifier.padding(horizontal = Space.page)) { Capsule("Share result", false) {
            Share.text(ctx, spec.title + "\n" + spec.inputs.joinToString("\n") { "${it.label}: ${values[it.key]}" } + "\n\n" + results.joinToString("\n") { "${it.first}: ${it.second}" })
        } } }
        if (spec.note.isNotBlank()) item("note") {
            Text(spec.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(Space.page))
        }
    }
}

@Composable
fun LinkToolScreen(spec: LinkSpec) {
    val ctx = LocalContext.current
    AtlasScreen(title = spec.title, subtitle = spec.blurb, hub = spec.hub) {
        spec.links.forEach { (t, d, url) -> item(url) { ListRow(t, supporting = d, icon = spec.icon, tint = spec.hub.tint()) { Share.open(ctx, url) } } }
    }
}

@Composable
fun NxScreen(id: String, container: AppContainer, open: (String) -> Unit) {
    when (val s = Nx.find(id)) {
        is AiSpec -> AiToolScreen(s, container)
        is ChatSpec -> ChatToolScreen(s, container)
        is LogSpec -> LogToolScreen(s)
        is CalcSpec -> CalcToolScreen(s)
        is LinkSpec -> LinkToolScreen(s)
        is ScreenSpec -> s.content(container, open)
        null -> AtlasScreen(title = "Not found") { item("x") { Text("This tool isn't available.", Modifier.padding(Space.page)) } }
    }
}

internal fun LazyListScope.gap(key: String) = item(key) { Box(Modifier.padding(Space.s)) }
