package com.nizam.app.feature.agent

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import com.nizam.app.ui.design.OutlinedButton
import com.nizam.app.ui.design.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.Tones
import com.nizam.app.feature.voice.Speaker
import com.nizam.app.feature.voice.speechIntent
import com.nizam.app.ui.theme.DisplayFamily
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun CuratorScreen(container: AppContainer) {
    val scope = remember { kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob()) }
    val context = LocalContext.current
    val turns by container.agentMemory.turns().collectAsState(initial = emptyList())
    val suggestions by container.curatorRepository.active().collectAsState(initial = emptyList())

    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var useWeb by remember { mutableStateOf(false) }
    var speakBack by remember { mutableStateOf(false) }
    var autoApprove by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<List<Pair<String, JSONObject>>>(emptyList()) }
    var lastSteps by remember { mutableStateOf<List<AgentLoop.Step>>(emptyList()) }

    val speaker = remember { Speaker(context) }
    DisposableEffect(Unit) { onDispose { speaker.release() } }

    val listener = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) draft = spoken
        }
    }

    var media by remember { mutableStateOf<List<com.nizam.app.feature.mcp.McpPart>>(emptyList()) }
    var attachments by remember { mutableStateOf<List<com.nizam.app.feature.attach.Attachment>>(emptyList()) }
    var busyLabel by remember { mutableStateOf<String?>(null) }
    var streaming by remember { mutableStateOf("") }

    // Open the connection to the AI and build the app snapshot before the first message is typed
    androidx.compose.runtime.LaunchedEffect(Unit) {
        runCatching { com.nizam.app.net.Router.warm(container.settingsRepository, context) }
        runCatching { Snapshot.of(container) }
    }

    fun send(message: String) {
        val files = attachments
        if (message.isBlank() && files.isEmpty()) return
        scope.launch {
            busy = true
            val label = com.nizam.app.feature.attach.Attachments.label(files)
            container.agentMemory.addTurn(true, listOf(message.trim(), label).filter { it.isNotBlank() }.joinToString("\n"))
            draft = ""
            attachments = emptyList()
            val servers = com.nizam.app.feature.mcp.Mcp.servers(context).filter { it.enabled }.map { it.name }
            val lane = com.nizam.app.net.Router.classify(message, useWeb, files.isNotEmpty(), servers)
            // Fast lane: questions stream straight back, files included, with no agent round-trips
            val chatReply: String? = if (lane != com.nizam.app.net.Router.Lane.CHAT) null else runCatching {
                LocalCommands.tryRun(container, message) ?: Converse.chat(container, message, files) { streaming += it }
            }.getOrNull()
            streaming = ""
            val outcome = if (chatReply != null) AgentLoop.Outcome(chatReply, emptyList()) else runCatching {
                // The agent is text-only, so files are read first and handed over as notes.
                val request = if (files.isEmpty()) message else {
                    busyLabel = "Reading ${if (files.size == 1) files[0].name else "${files.size} files"}"
                    val notes = com.nizam.app.feature.attach.Attachments.digest(container.settingsRepository, files, message)
                    busyLabel = null
                    message.ifBlank { "Look at what I attached and help me with it." } + "\n\n" + notes
                }
                container.agentLoop.run(request, useWeb, autoApprove)
            }.getOrElse { e ->
                AgentLoop.Outcome("That failed: ${com.nizam.app.ui.components.Feedback.friendly(e)}", emptyList())
            }
            lastSteps = outcome.steps
            pending = outcome.pendingApproval
            // The model sometimes narrates an action it never took ("Settings opened.") — catch it.
            // only a first-person past-tense claim counts — "opening the link" is not a claim
            val claimed = Regex(
                "\\b(i(?:'ve| have)?)\\s+(opened|set|sent|called|added|created|logged|deleted|started|scheduled)\\b|" +
                    "^(done|opened|added|created|logged|deleted)\\b",
                setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE)
            ).containsMatchIn(outcome.reply)
            val unbacked = claimed && outcome.steps.isEmpty() && outcome.pendingApproval.isEmpty()
            val body = buildString {
                append(outcome.reply)
                if (unbacked) append("\n\n⚠ No action was actually run — try asking again more directly.")
                if (outcome.steps.isNotEmpty()) {
                    append("\n\n")
                    append(outcome.steps.joinToString("\n") {
                        (if (it.ok) "✓ " else "✕ ") + it.summary
                    })
                }
            }
            container.agentMemory.addTurn(false, body)
            if (files.isNotEmpty()) runCatching { com.nizam.app.feature.jarvis.BrainFiles.remember(context, files, outcome.reply) }
            media = com.nizam.app.feature.mcp.Mcp.lastParts.filter { it.kind != "text" }
            if (speakBack) speaker.speak(outcome.reply)
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 18.dp)) {
        ModuleTitle("Curator", "Your agent — it can act, search the web, and speak")

        if (media.isNotEmpty()) MediaStrip(media) { media = emptyList() }

        if (turns.isNotEmpty()) {
            Text("new chat", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable(role = Role.Button) { scope.launch { container.agentMemory.clearChat() } }
                    .padding(vertical = 4.dp))
        }

        if (pending.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Needs your approval", style = MaterialTheme.typography.titleMedium)
                    pending.forEach { (name, args) ->
                        Text("• $name ${args.toString().take(90)}",
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            scope.launch {
                                val done = pending.map { (name, args) ->
                                    val r = Actions.run(container, name, args)
                                    (if (r.ok) "✓ " else "✕ ") + r.summary
                                }
                                container.agentMemory.addTurn(false, done.joinToString("\n"))
                                pending = emptyList()
                            }
                        }) { Text("Approve") }
                        OutlinedButton(onClick = { pending = emptyList() }) { Text("Cancel") }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        val listState = androidx.compose.foundation.lazy.rememberLazyListState()
        androidx.compose.runtime.LaunchedEffect(turns.size, streaming.length / 60, busy) {
            val n = listState.layoutInfo.totalItemsCount
            if (n > 0) listState.animateScrollToItem(n - 1)
        }
        LazyColumn(Modifier.weight(1f), state = listState) {
            if (turns.isEmpty()) {
                item {
                    suggestions.take(3).forEach { s ->
                        val tones = Tones.forKey(s.moduleKey)
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = tones.tone.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        ) {
                            Row(Modifier.padding(14.dp)) {
                                Text(s.emoji, style = MaterialTheme.typography.titleLarge)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(s.title, style = MaterialTheme.typography.titleMedium)
                                    Text(s.body, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    listOf(
                        "Build me a module to track my bike's fuel",
                        "What should I do today?",
                        "Make the theme deep blue and gold",
                        "Search the web for a good beginner Arabic course"
                    ).forEach { idea ->
                        Text(
                            "✦  $idea",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { send(idea) }.padding(vertical = 8.dp)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            busy = true
                            runCatching { container.curatorRepository.refreshSuggestions() }
                            busy = false
                        }
                    }) { Text("🔄  Refresh suggestions") }
                }
            }

            items(turns, key = { it.id }) { turn ->
                if (turn.fromUser) {
                    com.nizam.app.feature.council.UserBubble(turn.text)
                } else {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                        androidx.compose.foundation.layout.Box(
                            Modifier.size(34.dp).background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                                androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) { Text("✦", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Atlas", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(4.dp))
                            androidx.compose.foundation.layout.Box(
                                Modifier
                                    .background(
                                        MaterialTheme.colorScheme.surface,
                                        androidx.compose.foundation.shape.RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)
                                    )
                                    .padding(horizontal = 14.dp, vertical = 11.dp)
                            ) { com.nizam.app.ui.components.ChatText(turn.text) }
                        }
                    }
                }
            }
            if (streaming.isNotBlank()) {
                item {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                        androidx.compose.foundation.layout.Box(
                            Modifier.size(34.dp).background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                                androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) { Text("✦", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Atlas", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(4.dp))
                            com.nizam.app.ui.components.ChatText(streaming)
                        }
                    }
                }
            } else if (busy) {
                item {
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.padding(start = 44.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        com.nizam.app.ui.components.Thinking(label = busyLabel)
                    }
                }
            }
        }

        com.nizam.app.ui.components.Composer(
            draft = draft, onDraft = { draft = it },
            attachments = attachments, onAttachments = { attachments = it },
            busy = busy,
            placeholder = if (attachments.isEmpty()) "Tell Atlas what to do…" else "Ask about these files…",
            onSend = { send(draft) },
            onMic = { listener.launch(speechIntent()) },
            toggles = listOf(
                com.nizam.app.ui.components.ComposerToggle("Web", "Search the web while answering",
                    androidx.compose.material.icons.Icons.Filled.Language, useWeb) { useWeb = it },
                com.nizam.app.ui.components.ComposerToggle("Voice", "Read replies aloud",
                    androidx.compose.material.icons.Icons.Filled.VolumeUp, speakBack) { speakBack = it; if (!it) speaker.stop() },
                com.nizam.app.ui.components.ComposerToggle("Auto", "Run actions without asking first",
                    androidx.compose.material.icons.Icons.Filled.Bolt, autoApprove) { autoApprove = it }
            )
        )
    }
}


/** Images, audio and files a connected tool returned with its answer. */
@androidx.compose.runtime.Composable
private fun MediaStrip(parts: List<com.nizam.app.feature.mcp.McpPart>, onDismiss: () -> Unit) {
    val c = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.material3.Surface(
        shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("FROM THE TOOL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            parts.forEach { part ->
                when (part.kind) {
                    "image" -> part.file?.let { f ->
                        val bmp = androidx.compose.runtime.remember(f.path) {
                            runCatching {
                                android.graphics.BitmapFactory.decodeFile(f.path)
                                    ?.let { bm -> bm.asImageBitmap() }
                            }.getOrNull()
                        }
                        bmp?.let {
                            androidx.compose.foundation.Image(it, "tool image",
                                contentScale = androidx.compose.ui.layout.ContentScale.FillWidth,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
                        }
                    }
                    "audio" -> part.file?.let { f ->
                        Text("▸ Play audio", color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable(role = Role.Button) {
                                runCatching { android.media.MediaPlayer().apply { setDataSource(f.path); prepare(); start() } }
                            }.padding(vertical = 8.dp))
                    }
                    else -> Text(part.file?.name ?: part.uri, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable(role = Role.Button) {
                            runCatching {
                                val uri = part.file?.let {
                                    androidx.core.content.FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", it)
                                } ?: android.net.Uri.parse(part.uri)
                                c.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW)
                                    .setDataAndType(uri, part.mime.ifBlank { "*/*" })
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION))
                            }
                        }.padding(vertical = 6.dp))
                }
            }
            Text("dismiss", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.clickable(role = Role.Button) { onDismiss() }.padding(top = 6.dp))
        }
    }
}
