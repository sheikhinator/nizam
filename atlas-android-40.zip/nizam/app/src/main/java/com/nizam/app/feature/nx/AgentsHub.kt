package com.nizam.app.feature.nx

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Extension
import com.nizam.app.ui.design.Hub

/** Agent teams, the connector catalogue and the approval inbox, reachable from search, hubs and the agent. */
object AgentsHub {
    val all: List<Spec> = listOf(
        ScreenSpec("crew", "Agent teams", "A lead that delegates to specialists who work in parallel", Icons.Outlined.Groups, Hub.Work,
            "agents team crew multi agent delegate researcher planner writer operator") { c, _ -> com.nizam.app.feature.agent.CrewScreen(c) },
        ScreenSpec("connectors", "Connectors", "250+ apps and services Atlas can use", Icons.Outlined.Extension, Hub.Tools,
            "connect integrations apps api notion github slack gmail zapier home assistant mcp") { c, _ -> com.nizam.app.feature.connect.ConnectorsScreen(c) },
    )
}
