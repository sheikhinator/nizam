package com.nizam.app.feature.maps

import android.Manifest
import android.content.Intent
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Directions
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.nizam.app.core.ChipRow
import com.nizam.app.ui.components.Feedback
import com.nizam.app.ui.design.Button
import com.nizam.app.ui.design.Label
import com.nizam.app.ui.design.OutlinedButton
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.ScaleBarOverlay
import org.osmdroid.views.overlay.TilesOverlay
import org.osmdroid.views.overlay.compass.CompassOverlay
import org.osmdroid.views.overlay.compass.InternalCompassOrientationProvider
import org.osmdroid.views.overlay.gestures.RotationGestureOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/** Lets search and the agent open Maps on a query. */
object MapsNav { @Volatile var query: String? = null }

private val CATEGORIES = listOf("Food" to "restaurant", "Petrol" to "fuel", "Mosque" to "mosque", "ATM" to "atm", "Pharmacy" to "pharmacy",
    "Hospital" to "hospital", "Parking" to "parking", "Hotels" to "hotel", "Café" to "cafe", "Grocery" to "supermarket")
private val KAABA = GeoPoint(21.4225, 39.8262)

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun MapsScreen() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val accent = MaterialTheme.colorScheme.primary
    var style by remember { mutableStateOf(MapPrefs.style(c)) }
    var miles by remember { mutableStateOf(MapPrefs.miles(c)) }
    var voice by remember { mutableStateOf(MapPrefs.voice(c)) }
    var mode by remember { mutableStateOf(MapPrefs.mode(c)) }
    var traffic by remember { mutableStateOf(false) }
    var qibla by remember { mutableStateOf(false) }
    var layers by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    var suggestions by remember { mutableStateOf<List<Place>>(emptyList()) }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }
    var selected by remember { mutableStateOf<Place?>(null) }
    var route by remember { mutableStateOf<Route?>(null) }
    var routing by remember { mutableStateOf(false) }
    var navigating by remember { mutableStateOf(false) }
    var stepIdx by remember { mutableStateOf(0) }
    var speed by remember { mutableStateOf(0f) }
    var hasPerm by remember { mutableStateOf(androidx.core.content.ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) }
    val askPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> hasPerm = r.values.any { it } }
    LaunchedEffect(Unit) { if (!hasPerm) askPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }

    // one MapView, configured once
    val map = remember {
        Configuration.getInstance().load(c, c.getSharedPreferences("osmdroid", 0))
        Configuration.getInstance().userAgentValue = c.packageName
        Configuration.getInstance().tileDownloadThreads = 4.toShort()
        Configuration.getInstance().tileFileSystemCacheMaxBytes = 300L * 1024 * 1024
        MapView(c).apply {
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            isTilesScaledToDpi = true
            minZoomLevel = 3.0; maxZoomLevel = 20.0
            isVerticalMapRepetitionEnabled = false
            setScrollableAreaLimitLatitude(MapView.getTileSystem().maxLatitude, MapView.getTileSystem().minLatitude, 0)
            controller.setZoom(15.0)
            controller.setCenter(MapPrefs.last(c) ?: GeoPoint(31.5204, 74.3587))
            overlays.add(RotationGestureOverlay(this).apply { isEnabled = true })
            overlays.add(ScaleBarOverlay(this).apply { setAlignBottom(true); setScaleBarOffset(40, 220) })
            overlays.add(CompassOverlay(c, InternalCompassOrientationProvider(c), this).apply { enableCompass() })
        }
    }
    val me = remember { MyLocationNewOverlay(GpsMyLocationProvider(c).apply { locationUpdateMinTime = 1000; locationUpdateMinDistance = 2f }, map)
        .apply { isDrawAccuracyEnabled = true } }
    val routeLine = remember { Polyline(map).apply { outlinePaint.strokeWidth = 14f; outlinePaint.strokeCap = android.graphics.Paint.Cap.ROUND } }
    val qiblaLine = remember { Polyline(map).apply { outlinePaint.strokeWidth = 5f; outlinePaint.color = android.graphics.Color.rgb(61, 170, 109) } }
    val trafficOverlay = remember { mutableStateOf<TilesOverlay?>(null) }
    val pins = remember { mutableListOf<Marker>() }

    fun select(p: Place, zoom: Boolean = true) {
        selected = p; route = null; focused = false
        if (zoom) map.controller.animateTo(p.point, 16.5, 700L)
        pins.forEach { map.overlays.remove(it) }; pins.clear()
        pins += Marker(map).apply { position = p.point; title = p.name; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM) }
        map.overlays.addAll(pins); map.invalidate()
    }
    fun showResults(list: List<Place>) {
        results = list; selected = null; route = null
        pins.forEach { map.overlays.remove(it) }; pins.clear()
        list.forEach { p -> pins += Marker(map).apply { position = p.point; title = p.name; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            setOnMarkerClickListener { _, _ -> select(p, zoom = false); true } } }
        map.overlays.addAll(pins)
        if (list.size > 1) runCatching { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(list.map { it.point }).increaseByScale(1.3f), true, 80) }
        else list.firstOrNull()?.let { select(it) }
        map.invalidate()
    }
    fun box(): DoubleArray = map.boundingBox.let { doubleArrayOf(it.lonWest, it.latNorth, it.lonEast, it.latSouth) }
    fun search(q: String) = scope.launch {
        if (q.isBlank()) return@launch
        MapPrefs.addRecent(c, q); focused = false
        val list = Geo.search(q, box())
        if (list.isEmpty()) Feedback.show("Nothing found for “$q”") else showResults(list)
    }
    fun directions(to: Place) = scope.launch {
        val from = me.myLocation ?: run { Feedback.show("Waiting for your location…"); return@launch }
        routing = true
        runCatching { Geo.route(from, to.point, mode) }.onSuccess { r ->
            route = r; stepIdx = 0
            routeLine.setPoints(r.points); routeLine.outlinePaint.color = accent.toArgb()
            if (routeLine !in map.overlays) map.overlays.add(0, routeLine)
            runCatching { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(r.points).increaseByScale(1.25f), true, 120) }
            map.invalidate()
        }.onFailure { Feedback.show("Couldn't get directions: ${Feedback.friendly(it)}") }
        routing = false
    }
    fun clearRoute() { route = null; navigating = false; map.overlays.remove(routeLine); me.disableFollowLocation(); map.invalidate() }

    // style, paper tint, traffic and Qibla
    LaunchedEffect(style, dark) {
        map.setTileSource(MapStyles.source(if (dark && (style == "Paper" || style == "Minimal")) "Dark" else style))
        map.overlayManager.tilesOverlay.setColorFilter(if (style == "Paper" && !dark) ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
            0.98f, 0f, 0f, 0f, 6f,  0f, 0.95f, 0f, 0f, 2f,  0f, 0f, 0.84f, 0f, -4f,  0f, 0f, 0f, 1f, 0f))) else null)
        map.overlayManager.tilesOverlay.loadingBackgroundColor = if (dark) android.graphics.Color.rgb(20, 22, 26) else android.graphics.Color.rgb(242, 238, 228)
        map.overlayManager.tilesOverlay.loadingLineColor = android.graphics.Color.TRANSPARENT
        map.invalidate()
    }
    LaunchedEffect(traffic) {
        trafficOverlay.value?.let { map.overlays.remove(it); it.onDetach(map) }; trafficOverlay.value = null
        if (traffic) {
            val key = c.getSharedPreferences("maps", 0).getString("tomtom", "").orEmpty()
            if (key.isBlank()) { traffic = false; Feedback.show("Live traffic needs a free TomTom key — add it in Settings › API keys"); return@LaunchedEffect }
            val src = TemplateTiles("tomtom-traffic", "https://api.tomtom.com/traffic/map/4/tile/flow/relative0/{z}/{x}/{y}.png?key=$key&tileSize=256", 20, "© TomTom")
            val ov = TilesOverlay(MapTileProviderBasic(c, src), c).apply { loadingBackgroundColor = android.graphics.Color.TRANSPARENT; loadingLineColor = android.graphics.Color.TRANSPARENT }
            map.overlays.add(0, ov); trafficOverlay.value = ov; map.invalidate()
        }
    }
    LaunchedEffect(qibla, hasPerm) {
        map.overlays.remove(qiblaLine)
        while (qibla) {
            me.myLocation?.let { qiblaLine.setPoints(listOf(it, KAABA)); if (qiblaLine !in map.overlays) map.overlays.add(qiblaLine); map.invalidate() }
            delay(5000)
        }
        map.invalidate()
    }
    // my location + long-press to drop a pin
    LaunchedEffect(hasPerm) {
        if (!hasPerm) return@LaunchedEffect
        if (me !in map.overlays) map.overlays.add(me)
        me.enableMyLocation()
        me.runOnFirstFix { map.post { if (MapPrefs.last(c) == null || selected == null) me.myLocation?.let { map.controller.animateTo(it, 16.0, 800L); MapPrefs.setLast(c, it) } } }
    }
    DisposableEffect(Unit) {
        map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint?) = false.also { focused = false }
            override fun longPressHelper(p: GeoPoint?): Boolean { p ?: return false; scope.launch { select(Geo.reverse(p), zoom = false) }; return true }
        }))
        MapsNav.query?.let { q -> MapsNav.query = null; query = q; search(q) }
        onDispose { map.mapCenter?.let { MapPrefs.setLast(c, GeoPoint(it.latitude, it.longitude)) }; me.disableMyLocation(); map.onDetach() }
    }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e -> when (e) { Lifecycle.Event.ON_RESUME -> map.onResume(); Lifecycle.Event.ON_PAUSE -> map.onPause(); else -> {} } }
        lifecycle.addObserver(obs); onDispose { lifecycle.removeObserver(obs) }
    }
    // live suggestions while typing
    LaunchedEffect(query, focused) {
        suggestions = emptyList()
        if (focused && query.trim().length >= 2) { delay(250); suggestions = Geo.suggest(query.trim(), me.myLocation ?: map.mapCenter as? GeoPoint) }
    }
    // turn-by-turn: follow, advance steps, speak
    val tts = remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) { val t = TextToSpeech(c) { }; tts.value = t; onDispose { t.shutdown() } }
    LaunchedEffect(navigating) {
        if (!navigating) return@LaunchedEffect
        me.enableFollowLocation(); map.controller.setZoom(18.0)
        var spoken = -1
        while (navigating) {
            val r = route ?: break
            val here = me.myLocation
            speed = me.lastFix?.speed ?: 0f
            if (here != null && stepIdx < r.steps.size) {
                val next = r.steps[stepIdx]
                val d = here.distanceToAsDouble(next.point)
                if (d < 25 && stepIdx < r.steps.lastIndex) stepIdx++
                else if (voice && d < 180 && spoken != stepIdx) { spoken = stepIdx
                    tts.value?.speak("In ${Geo.distance(d, miles)}, ${next.text}", TextToSpeech.QUEUE_FLUSH, null, "nav") }
                if (stepIdx == r.steps.lastIndex && d < 30) { tts.value?.speak("You've arrived", TextToSpeech.QUEUE_FLUSH, null, "nav"); navigating = false }
            }
            delay(1500)
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView({ map }, Modifier.fillMaxSize())

        // ── top: search, or the next turn while navigating ──
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            if (navigating && route != null) {
                val r = route!!; val next = r.steps.getOrNull(stepIdx)
                Surface(shape = RoundedCornerShape(18.dp), color = accent, modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(18.dp))) {
                    Column(Modifier.padding(16.dp)) {
                        Text(next?.text ?: "Follow the route", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimary)
                        me.myLocation?.let { h -> next?.let { Text(Geo.distance(h.distanceToAsDouble(it.point), miles), style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)) } }
                    }
                }
            } else {
                Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(28.dp))) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Box(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            if (query.isEmpty()) Text("Search places, addresses, “pharmacy”…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
                            BasicTextField(query, { query = it; focused = true }, singleLine = true, textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                                cursorBrush = SolidColor(accent), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { search(query) }),
                                modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) focused = true })
                        }
                        if (query.isNotEmpty()) Icon(Icons.Rounded.Close, "Clear", Modifier.clickable { query = ""; results = emptyList(); pins.forEach { map.overlays.remove(it) }; pins.clear(); map.invalidate() })
                    }
                }
                // suggestions / recents / saved
                AnimatedVisibility(focused && (suggestions.isNotEmpty() || query.isBlank()), enter = fadeIn(), exit = fadeOut()) {
                    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth().padding(top = 6.dp).shadow(4.dp, RoundedCornerShape(18.dp))) {
                        Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                            val here = me.myLocation
                            if (query.isBlank()) {
                                MapPrefs.saved(c).forEach { p -> PlaceRow(p, here, miles, if (p.kind.isNotBlank()) p.kind else "Saved") { select(p) } }
                                MapPrefs.recents(c).forEach { r -> Text(r, Modifier.fillMaxWidth().clickable { query = r; search(r) }.padding(horizontal = 18.dp, vertical = 12.dp)) }
                            } else suggestions.forEach { p -> PlaceRow(p, here, miles, null) { query = p.name; select(p) } }
                        }
                    }
                }
                if (!focused && selected == null && route == null)
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CATEGORIES.forEach { (label, q) -> Pill(label) { query = label; scope.launch {
                            val list = Geo.search(q, box()); if (list.isEmpty()) Feedback.show("No $label in this area — zoom out and try again") else showResults(list) } } }
                    }
            }
        }

        // ── right: layers, Qibla, my location ──
        Column(Modifier.align(Alignment.CenterEnd).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Fab(Icons.Rounded.Layers, "Map style and layers") { layers = true }
            Fab(Icons.Rounded.Explore, "Qibla direction", on = qibla) { qibla = !qibla; if (qibla) Feedback.show("The green line points to the Kaaba") }
            Fab(Icons.Rounded.MyLocation, "My location") {
                if (!hasPerm) askPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                else me.myLocation?.let { map.controller.animateTo(it, 17.0, 600L); map.mapOrientation = 0f } ?: Feedback.show("Finding you…")
            }
        }

        // ── bottom: place card, results list, or directions ──
        val here = me.myLocation
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
            AnimatedVisibility(route != null, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                route?.let { r -> Sheet {
                    if (navigating) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                val arrive = LocalTime.now().plusSeconds(r.durationS.toLong()).format(DateTimeFormatter.ofPattern("h:mm a"))
                                Text("${Geo.duration(r.durationS)} · arrive $arrive", style = MaterialTheme.typography.titleMedium)
                                Text("${Geo.distance(r.distanceM, miles)} · ${if (miles) "${(speed * 2.237).toInt()} mph" else "${(speed * 3.6).toInt()} km/h"}",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            OutlinedButton(onClick = { navigating = false; me.disableFollowLocation() }) { Text("End") }
                        }
                    } else {
                        ChipRow(listOf("Drive", "Bike", "Walk"), mode, { mode = it; MapPrefs.setMode(c, it); selected?.let { s -> directions(s) } })
                        Text("${Geo.duration(r.durationS)}  ·  ${Geo.distance(r.distanceM, miles)}", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 8.dp))
                        Text("Arrive ${LocalTime.now().plusSeconds(r.durationS.toLong()).format(DateTimeFormatter.ofPattern("h:mm a"))} · to ${selected?.name.orEmpty()}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 10.dp)) {
                            Button(onClick = { navigating = true; stepIdx = 0 }) { Icon(Icons.Rounded.Navigation, null); Text(" Start") }
                            OutlinedButton(onClick = { clearRoute() }) { Text("Close") }
                        }
                        Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
                            r.steps.forEach { s -> Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                                Text(s.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                if (s.distanceM > 0) Text(Geo.distance(s.distanceM, miles), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }; HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)) }
                        }
                    }
                } }
            }
            AnimatedVisibility(route == null && selected != null, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                selected?.let { p -> Sheet {
                    var saved by remember(p) { mutableStateOf(MapPrefs.saved(c).any { it.name == p.name }) }
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(listOfNotNull(p.kind.ifBlank { null }?.replace('_', ' ')?.replaceFirstChar { it.uppercase() },
                                here?.let { Geo.distance(it.distanceToAsDouble(p.point), miles) + " away" }, p.detail.ifBlank { null }).joinToString(" · "),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
                        }
                        Icon(Icons.Rounded.Close, "Close", Modifier.clickable { selected = null })
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !routing, onClick = { directions(p) }) { Icon(Icons.Rounded.Directions, null); Text(if (routing) " Finding route…" else " Directions") }
                        OutlinedButton(onClick = { if (saved) MapPrefs.unsave(c, p) else MapPrefs.save(c, p); saved = !saved; Feedback.show(if (saved) "Saved" else "Removed") }) {
                            Icon(if (saved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder, null); Text(if (saved) " Saved" else " Save") }
                        OutlinedButton(onClick = { MapPrefs.save(c, p.copy(kind = "Home")); Feedback.show("Set as Home") }) { Text("Home") }
                        OutlinedButton(onClick = { MapPrefs.save(c, p.copy(kind = "Work")); Feedback.show("Set as Work") }) { Text("Work") }
                        OutlinedButton(onClick = { c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,
                            "${p.name}\nhttps://www.openstreetmap.org/?mlat=${p.point.latitude}&mlon=${p.point.longitude}#map=17/${p.point.latitude}/${p.point.longitude}"), "Share place")) }) {
                            Icon(Icons.Rounded.Share, null); Text(" Share") }
                        OutlinedButton(onClick = { runCatching { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${p.point.latitude},${p.point.longitude}?q=${p.point.latitude},${p.point.longitude}(${Uri.encode(p.name)})"))) } }) {
                            Text("Open in…") }
                    }
                } }
            }
            AnimatedVisibility(route == null && selected == null && results.size > 1 && !focused, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                Sheet {
                    Label("${results.size} results")
                    Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) { results.forEach { p -> PlaceRow(p, here, miles, null) { select(p) } } }
                }
            }
        }
    }

    if (layers) androidx.compose.material3.ModalBottomSheet(onDismissRequest = { layers = false }) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Label("Map style")
            ChipRow(MapStyles.NAMES, style, { style = it; MapPrefs.setStyle(c, it) })
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp)) {
                Column(Modifier.weight(1f)) { Text("Live traffic", style = MaterialTheme.typography.titleSmall)
                    Text("Green flows, red is slow (TomTom, free key)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                Switch(traffic, { traffic = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                Text("Qibla line", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f)); Switch(qibla, { qibla = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                Text("Spoken directions", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f)); Switch(voice, { voice = it; MapPrefs.setVoice(c, it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                Text("Miles instead of kilometres", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f)); Switch(miles, { miles = it; MapPrefs.setMiles(c, it) })
            }
            Label("Default travel mode", Modifier.padding(top = 12.dp))
            ChipRow(listOf("Drive", "Bike", "Walk"), mode, { mode = it; MapPrefs.setMode(c, it) })
            OutlinedButton(onClick = { runCatching { org.osmdroid.tileprovider.modules.SqlTileWriter().purgeCache() }; Feedback.show("Map cache cleared") },
                modifier = Modifier.padding(top = 14.dp)) { Text("Clear saved map tiles") }
            Text("Map data © OpenStreetMap contributors · tiles © CARTO, Esri, OpenTopoMap · routing OSRM · search Photon & Nominatim",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 14.dp))
        }
    }
}

@Composable
private fun Sheet(content: @Composable () -> Unit) {
    Surface(shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth().shadow(12.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 20.dp)) {
            Box(Modifier.align(Alignment.CenterHorizontally).size(width = 36.dp, height = 4.dp).clip(CircleShape).background(MaterialTheme.colorScheme.outlineVariant))
            Spacer(Modifier.size(10.dp))
            content()
        }
    }
}

@Composable
private fun PlaceRow(p: Place, here: GeoPoint?, miles: Boolean, tag: String?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(listOfNotNull(tag, p.name).joinToString(" · "), style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (p.detail.isNotBlank()) Text(p.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        here?.let { Text(Geo.distance(it.distanceToAsDouble(p.point), miles), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 8.dp)) }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surface, modifier = Modifier.shadow(3.dp, RoundedCornerShape(50)).clickable(onClick = onClick)) {
        Text(text, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
    }
}

@Composable
private fun Fab(icon: ImageVector, label: String, on: Boolean = false, onClick: () -> Unit) {
    Surface(shape = CircleShape, color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        modifier = Modifier.size(48.dp).shadow(6.dp, CircleShape).clickable(onClick = onClick)) {
        Box(contentAlignment = Alignment.Center) { Icon(icon, label, tint = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface) }
    }
}
