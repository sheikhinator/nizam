package com.nizam.app.feature.launcher

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.MainActivity
import com.nizam.app.feature.phone.AtlasNotificationListener
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
private fun Scrim(onClose: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onClose)) {
        AnimatedVisibility(true, enter = slideInVertically { -it / 3 } + fadeIn()) {
            Box(Modifier.fillMaxSize().systemBarsPadding().clickable(enabled = false) {}) { content() }
        }
    }
}

@Composable
private fun PanelTitle(text: String, t: HomeTheme, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, fontFamily = t.font, modifier = Modifier.weight(1f))
        if (action != null) TextButton(onClick = onAction) { Text(action, color = t.accent) }
    }
}

// ── Notification Center ─────────────────────────────────────────────────────────────────────────
@Composable
fun NotificationCenter(t: HomeTheme, onClose: () -> Unit) {
    val c = LocalContext.current
    val v by AtlasNotificationListener.version.collectAsState()
    val list = remember(v) { AtlasNotificationListener.active() }
    Scrim(onClose) {
        Column(Modifier.fillMaxSize()) {
            PanelTitle("Notifications", t, if (list.isNotEmpty()) "Clear all" else null) { AtlasNotificationListener.dismissAll() }
            if (!AtlasNotificationListener.connected) Column(Modifier.padding(20.dp).clip(RoundedCornerShape(t.corner)).background(t.panel).padding(16.dp)) {
                Text("Let Atlas read notifications to show them here.", color = t.onPanel, fontFamily = t.font)
                TextButton(onClick = { c.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Allow", color = t.accent) }
            }
            TextButton(onClick = { Controls.systemShade(c, false); onClose() }, modifier = Modifier.padding(horizontal = 12.dp)) { Text("Open Android's notification shade", color = Color.White.copy(alpha = 0.8f)) }
            if (list.isEmpty() && AtlasNotificationListener.connected) Text("You're all caught up.", color = Color.White.copy(alpha = 0.7f), fontFamily = t.font, modifier = Modifier.padding(20.dp))
            LazyColumn(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                list.groupBy { it.packageName }.forEach { (pkg, ns) ->
                    item(key = pkg) {
                        val appName = remember(pkg) { runCatching { c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg) }
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(t.corner)).background(t.panel).padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(appName.uppercase(), color = t.onPanel.copy(alpha = 0.6f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Icon(Icons.Rounded.Close, "Dismiss all from $appName", Modifier.size(18.dp).clickable { ns.forEach { AtlasNotificationListener.dismiss(it.key) } }, tint = t.onPanel.copy(alpha = 0.6f))
                            }
                            ns.take(5).forEach { n ->
                                val ex = n.notification.extras
                                Column(Modifier.fillMaxWidth().clickable { AtlasNotificationListener.open(c, n.key); onClose() }.padding(top = 8.dp)) {
                                    Row { Text(ex.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty(), color = t.onPanel, fontWeight = FontWeight.SemiBold,
                                        fontFamily = t.font, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(android.text.format.DateUtils.getRelativeTimeSpanString(n.postTime).toString(), color = t.onPanel.copy(alpha = 0.5f), fontSize = 11.sp) }
                                    Text(ex.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty(), color = t.onPanel.copy(alpha = 0.8f),
                                        fontFamily = t.font, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            if (ns.size > 5) Text("+${ns.size - 5} more", color = t.accent, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

// ── Control Center ──────────────────────────────────────────────────────────────────────────────
@Composable
fun ControlCenter(t: HomeTheme, activity: LauncherActivity, onClose: () -> Unit) {
    val c = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(2000); tick++ } }
    var torch by remember { mutableStateOf(Controls.torchIsOn()) }
    var dnd by remember(tick) { mutableStateOf(Controls.dndOn(c)) }
    var vol by remember { mutableFloatStateOf(Controls.volume(c)) }
    var bright by remember { mutableFloatStateOf(Controls.brightness(c)) }
    val heat = remember(tick) { Xos.heat(c) }
    val gt = remember { Xos.gt(c) }
    val xos = remember { Xos.features(c) }
    Scrim(onClose) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(t, Icons.Rounded.Wifi, "Wi-Fi", Modifier.weight(1f)) { Controls.wifi(c) }
                Tile(t, Icons.Rounded.SignalCellularAlt, "Mobile data", Modifier.weight(1f)) { Controls.internet(c) }
                Tile(t, Icons.Rounded.Bluetooth, "Bluetooth", Modifier.weight(1f)) { Controls.bluetooth(c) }
                Tile(t, Icons.Rounded.AirplanemodeActive, "Airplane", Modifier.weight(1f)) { Controls.airplane(c) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(t, Icons.Rounded.FlashlightOn, "Torch", Modifier.weight(1f), on = torch) { torch = Controls.torch(c) }
                Tile(t, Icons.Rounded.DoNotDisturbOn, "Focus", Modifier.weight(1f), on = dnd) { dnd = Controls.dnd(c) }
                Tile(t, Icons.Rounded.ScreenRotation, "Rotate", Modifier.weight(1f), on = Controls.autoRotate(c)) { Controls.toggleRotate(c); tick++ }
                Tile(t, Icons.Rounded.Vibration, "Ring mode", Modifier.weight(1f)) { com.nizam.app.ui.components.Feedback.show(Controls.cycleRinger(c)) }
            }
            // media
            val mc = remember(tick) { Controls.media(c) }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(t.corner)).background(t.panel).padding(14.dp)) {
                val md = mc?.metadata
                Text(md?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Not playing", color = t.onPanel, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(md?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST).orEmpty(), color = t.onPanel.copy(alpha = 0.7f), fontSize = 12.sp, maxLines = 1)
                if (mc != null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    val playing = mc.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
                    Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(36.dp).clickable { mc.transportControls.skipToPrevious() }, tint = t.onPanel)
                    Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/pause", Modifier.size(42.dp).clickable {
                        if (playing) mc.transportControls.pause() else mc.transportControls.play(); tick++ }, tint = t.onPanel)
                    Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(36.dp).clickable { mc.transportControls.skipToNext() }, tint = t.onPanel)
                }
            }
            SliderRow(t, Icons.Rounded.LightMode, bright) { bright = it; Controls.setBrightness(c, it) }
            SliderRow(t, Icons.Rounded.VolumeUp, vol) { vol = it; Controls.setVolume(c, it) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(t, Icons.Rounded.PhotoCamera, "Camera", Modifier.weight(1f)) { Controls.camera(c); onClose() }
                Tile(t, Icons.Rounded.Timer, "Timer", Modifier.weight(1f)) { Controls.timer(c) }
                Tile(t, Icons.Rounded.Calculate, "Calculator", Modifier.weight(1f)) { Controls.calculator(c) }
                Tile(t, Icons.Rounded.QrCodeScanner, "Scan QR", Modifier.weight(1f)) { Controls.qr(c) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(t, Icons.Rounded.Screenshot, "Screenshot", Modifier.weight(1f)) { onClose(); activity.window.decorView.postDelayed({ Controls.screenshot(c) }, 400) }
                Tile(t, Icons.Rounded.Lock, "Lock", Modifier.weight(1f)) { onClose(); Controls.lock(c) }
                Tile(t, Icons.Rounded.CastConnected, "Cast", Modifier.weight(1f)) { Controls.cast(c) }
                Tile(t, Icons.Rounded.BatterySaver, "Saver", Modifier.weight(1f)) { Controls.batterySaver(c) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(t, Icons.Rounded.LocationOn, "Location", Modifier.weight(1f)) { Controls.location(c) }
                Tile(t, Icons.Rounded.WifiTethering, "Hotspot", Modifier.weight(1f)) { Controls.hotspot(c) }
                Tile(t, Icons.Rounded.ViewAgenda, "Split screen", Modifier.weight(1f)) { onClose(); Controls.splitScreen(c) }
                Tile(t, Icons.Rounded.PowerSettingsNew, "Power", Modifier.weight(1f)) { onClose(); Controls.powerMenu(c) }
            }
            // Infinix GT 50 Pro
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(t.corner)).background(t.panel).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Thermostat, null, tint = when (heat.status) { "Cool" -> Color(0xFF3DAA6D); "Warm" -> Color(0xFFE0A030); else -> Color(0xFFFF453A) })
                    Text("  ${"%.1f".format(heat.tempC)}°C · ${heat.status}", color = t.onPanel, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { val n = Controls.freeMemory(c); com.nizam.app.ui.components.Feedback.show("Cooling down — stopped $n background apps") }) { Text("Cool down", color = t.accent) }
                }
                if (gt.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    gt.forEach { f -> Chip(t, f.label) { runCatching { c.startActivity(f.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.onFailure {
                        com.nizam.app.ui.components.Feedback.show("XOS doesn't let apps open ${f.label} directly on this build") } } }
                } else Text("GT lights, game mode and triggers: open XOS Settings › Special functions", color = t.onPanel.copy(alpha = 0.6f), fontSize = 12.sp)
            }
            // XOS
            Text("XOS", color = Color.White.copy(alpha = 0.8f), fontWeight = FontWeight.SemiBold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                xos.forEach { f -> Chip(t, f.label) { runCatching { c.startActivity(f.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } } }
            }
            TextButton(onClick = { Controls.systemShade(c, true); onClose() }) { Text("Open Android quick settings", color = Color.White.copy(alpha = 0.8f)) }
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun Tile(t: HomeTheme, icon: ImageVector, label: String, modifier: Modifier, on: Boolean = false, onClick: () -> Unit) {
    Column(modifier.aspectRatio(1f).clip(RoundedCornerShape(t.corner)).background(if (on) t.accent else t.panel).clickable(onClick = onClick).padding(10.dp),
        verticalArrangement = Arrangement.SpaceBetween) {
        Icon(icon, label, tint = if (on) Color.White else t.onPanel)
        Text(label, color = if (on) Color.White else t.onPanel, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontFamily = t.font)
    }
}

@Composable
private fun SliderRow(t: HomeTheme, icon: ImageVector, v: Float, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(t.corner)).background(t.panel).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = t.onPanel)
        Slider(v, onChange, Modifier.weight(1f).padding(start = 10.dp), colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = t.accent))
    }
}

@Composable
private fun Chip(t: HomeTheme, label: String, onClick: () -> Unit) {
    Text(label, color = t.onPanel, fontSize = 13.sp, fontFamily = t.font, modifier = Modifier.clip(RoundedCornerShape(50)).background(t.panel)
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp))
}

// ── Spotlight ───────────────────────────────────────────────────────────────────────────────────
@Composable
fun Spotlight(t: HomeTheme, apps: List<LApp>, open: (LApp) -> Unit, onClose: () -> Unit, askAtlas: (String) -> Unit) {
    val c = LocalContext.current
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val recent = remember { Launcher.recent(c).mapNotNull { p -> apps.firstOrNull { it.pkg == p } } }
    var contacts by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    LaunchedEffect(q) {
        contacts = if (q.length < 2) emptyList() else runCatching {
            c.contentResolver.query(android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null)?.use { cur ->
                val out = mutableListOf<Pair<String, String>>(); while (cur.moveToNext() && out.size < 5) out += cur.getString(0) to cur.getString(1); out }.orEmpty()
        }.getOrElse { emptyList() }
    }
    val math = remember(q) { if (q.any { it in "+-*/×÷" } && q.any { it.isDigit() }) runCatching { eval(q.replace('×', '*').replace('÷', '/')) }.getOrNull() else null }
    val hits = apps.filter { q.isNotBlank() && (it.label.contains(q, true) || it.pkg.contains(q, true)) }.take(8)
    val screens = com.nizam.app.ui.screens.search.DESTINATIONS.filter { q.length >= 2 && (it.name.contains(q, true) || it.words.contains(q, true)) }.take(4)
    Scrim(onClose) {
        Column(Modifier.fillMaxSize().imePadding().padding(16.dp)) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(t.panel).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Search, null, tint = t.onPanel.copy(alpha = 0.7f))
                BasicTextField(q, { q = it }, singleLine = true, textStyle = TextStyle(color = t.onPanel, fontSize = 18.sp, fontFamily = t.font), cursorBrush = SolidColor(t.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { hits.firstOrNull()?.let { open(it); onClose() } ?: askAtlas(q) }),
                    modifier = Modifier.weight(1f).padding(start = 10.dp).focusRequester(focus),
                    decorationBox = { inner -> if (q.isEmpty()) Text("Search apps, contacts, Atlas, the web", color = t.onPanel.copy(alpha = 0.5f), fontSize = 18.sp); inner() })
            }
            Column(Modifier.verticalScroll(rememberScrollState()).padding(top = 12.dp)) {
                if (q.isBlank() && recent.isNotEmpty()) {
                    Text("Siri suggestions".let { "Suggestions" }, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        recent.take(4).forEach { a -> Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { open(a); onClose() }) {
                            AppIconView(a, t, 56.dp); Text(a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, modifier = Modifier.width(70.dp)) } }
                    }
                }
                math?.let { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(t.panel).padding(14.dp)) {
                    Text("= ${if (it % 1.0 == 0.0) it.toLong().toString() else "%.6g".format(it)}", color = t.onPanel, fontSize = 24.sp, fontFamily = t.font) } }
                hits.forEach { a -> Row(Modifier.fillMaxWidth().clickable { open(a); onClose() }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIconView(a, t, 40.dp); Text(a.label, color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(start = 12.dp)) } }
                contacts.forEach { (n, num) -> Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Person, null, tint = Color.White); Text(n, color = Color.White, modifier = Modifier.weight(1f).padding(start = 12.dp))
                    Icon(Icons.Rounded.Call, "Call", Modifier.clickable { c.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.padding(8.dp), tint = t.accent)
                    Icon(Icons.Rounded.Message, "Message", Modifier.clickable { c.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.padding(8.dp), tint = t.accent)
                } }
                screens.forEach { d -> Text("${d.emoji}  ${d.name} — in Atlas", color = Color.White, modifier = Modifier.fillMaxWidth().clickable {
                    c.startActivity(Intent(c, MainActivity::class.java).putExtra("route", d.route).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); onClose() }.padding(vertical = 10.dp)) }
                if (q.isNotBlank()) {
                    Text("✦  Ask Atlas: “$q”", color = t.accent, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { askAtlas(q) }.padding(vertical = 12.dp))
                    Text("🔎  Search the web", color = Color.White, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable {
                        c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); onClose() }.padding(vertical = 12.dp))
                    Text("🧭  Find on the map", color = Color.White, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable {
                        com.nizam.app.feature.maps.MapsNav.query = q
                        c.startActivity(Intent(c, MainActivity::class.java).putExtra("route", com.nizam.app.ui.nav.Routes.MAPS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); onClose() }.padding(vertical = 12.dp))
                }
            }
        }
    }
}

/** Tiny calculator for Spotlight: + - * / ( ) and decimals. */
private fun eval(s: String): Double {
    var i = 0; val t = s.filter { !it.isWhitespace() }
    fun num(): Double { val st = i; while (i < t.length && (t[i].isDigit() || t[i] == '.')) i++; return t.substring(st, i).toDouble() }
    lateinit var expr: () -> Double
    fun factor(): Double = when { i < t.length && t[i] == '(' -> { i++; val v = expr(); i++; v }; i < t.length && t[i] == '-' -> { i++; -factor() }; else -> num() }
    fun term(): Double { var v = factor(); while (i < t.length && (t[i] == '*' || t[i] == '/')) { val o = t[i++]; val r = factor(); v = if (o == '*') v * r else v / r }; return v }
    expr = { var v = term(); while (i < t.length && (t[i] == '+' || t[i] == '-')) { val o = t[i++]; val r = term(); v = if (o == '+') v + r else v - r }; v }
    return expr()
}

// ── App Library ─────────────────────────────────────────────────────────────────────────────────
@Composable
fun AppLibrary(t: HomeTheme, apps: List<LApp>, badges: Map<String, Int>, open: (LApp) -> Unit, onLong: (LApp) -> Unit) {
    val c = LocalContext.current
    var q by remember { mutableStateOf("") }
    var running by remember { mutableStateOf<List<Controls.Used>>(emptyList()) }
    LaunchedEffect(Unit) { if (Controls.hasUsage(c)) running = Controls.recentlyUsed(c).take(8) }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(14.dp)).background(t.panel).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Search, null, tint = t.onPanel.copy(alpha = 0.7f))
            BasicTextField(q, { q = it }, singleLine = true, textStyle = TextStyle(color = t.onPanel, fontSize = 16.sp, fontFamily = t.font), cursorBrush = SolidColor(t.accent),
                modifier = Modifier.weight(1f).padding(start = 10.dp), decorationBox = { inner -> if (q.isEmpty()) Text("App Library", color = t.onPanel.copy(alpha = 0.5f)); inner() })
        }
        if (q.isNotBlank()) LazyColumn(Modifier.weight(1f)) {
            items(apps.filter { it.label.contains(q, true) }, key = { it.pkg + it.activity }) { a ->
                Row(Modifier.fillMaxWidth().combinedClickableCompat({ open(a) }, { onLong(a) }).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIconView(a, t, 40.dp, badges[a.pkg] ?: 0); Text(a.label, color = Color.White, modifier = Modifier.padding(start = 12.dp)) }
            }
        } else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (running.isNotEmpty()) item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(t.corner)).background(t.panel).padding(12.dp)) {
                    Text("Running & recent — tap × to stop", color = t.onPanel.copy(alpha = 0.7f), fontSize = 12.sp)
                    running.forEach { u -> apps.firstOrNull { it.pkg == u.pkg }?.let { a ->
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            AppIconView(a, t, 32.dp)
                            Text("${a.label} · ${u.minutesToday} min today", color = t.onPanel, fontSize = 13.sp, modifier = Modifier.weight(1f).padding(start = 10.dp).clickable { open(a) })
                            Icon(Icons.Rounded.Close, "Stop ${a.label}", Modifier.clickable { Controls.closeApp(c, a.pkg); running = running - u }.padding(6.dp), tint = t.onPanel)
                        } } }
                }
            }
            val groups = apps.groupBy { it.category }.toList().sortedWith(compareBy({ if (it.first == "XOS") 0 else 1 }, { -it.second.size }))
            items(groups.chunked(2), key = { it.joinToString { g -> g.first } }) { pair -> Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { (cat, list) -> Column(Modifier.weight(1f).clip(RoundedCornerShape(t.corner)).background(t.panel.copy(alpha = 0.6f)).padding(10.dp)) {
                    list.take(4).chunked(2).forEach { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        r.forEach { a -> Box(Modifier.padding(4.dp).combinedClickableCompat({ open(a) }, { onLong(a) })) { AppIconView(a, t, 50.dp, badges[a.pkg] ?: 0) } } } }
                    Text("$cat · ${list.size}", color = t.onPanel, fontSize = 12.sp, fontFamily = t.font, modifier = Modifier.padding(top = 4.dp),
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            } }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

// ── App menu (long-press) ───────────────────────────────────────────────────────────────────────
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun AppMenu(activity: LauncherActivity, app: LApp, t: HomeTheme, layout: Launcher.Layout?, onDismiss: () -> Unit, onLayout: (Launcher.Layout) -> Unit, onChanged: () -> Unit) {
    val c = LocalContext.current
    val shortcuts = remember(app.pkg) { Launcher.shortcuts(c, app.pkg) }
    var rename by remember { mutableStateOf<String?>(null) }
    var iconPick by remember { mutableStateOf(false) }
    val photo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching { val f = java.io.File(c.filesDir, "icon_${app.pkg}.png")
            c.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }; IconOverrides.set(c, app.pkg, f.absolutePath) }
        onChanged(); onDismiss()
    }
    androidx.compose.material3.ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF1C1C1E)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { AppIconView(app, t, 48.dp)
                Text(app.label, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 14.dp)) }
            shortcuts.forEach { s -> MenuRow(Icons.Rounded.Launch, s.shortLabel?.toString() ?: "Shortcut") { Launcher.startShortcut(c, s); onDismiss() } }
            if (shortcuts.isNotEmpty()) HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Color.White.copy(alpha = 0.1f))
            val l = layout
            if (l != null) {
                val onHome = l.pages.flatten().contains(app.pkg); val inDock = app.pkg in l.dock
                if (!onHome && !inDock) MenuRow(Icons.Rounded.AddBox, "Add to home screen") { onLayout(l.copy(pages = if (l.pages.isEmpty()) listOf(listOf(app.pkg)) else l.pages.dropLast(1) + listOf(l.pages.last() + app.pkg))); onDismiss() }
                if (!inDock && l.dock.size < 5) MenuRow(Icons.Rounded.Dock, "Add to dock") { onLayout(l.copy(dock = l.dock + app.pkg, pages = l.pages.map { it - app.pkg }.filter { it.isNotEmpty() })); onDismiss() }
                if (onHome) MenuRow(Icons.Rounded.RemoveCircleOutline, "Remove from home (stays in App Library)") { onLayout(l.copy(pages = l.pages.map { it - app.pkg }.filter { it.isNotEmpty() })); onDismiss() }
            }
            MenuRow(Icons.Rounded.Edit, "Rename") { rename = app.label }
            MenuRow(Icons.Rounded.Palette, "Change icon") { iconPick = true }
            MenuRow(Icons.Rounded.VisibilityOff, "Hide app") { Launcher.setHidden(c, app.pkg, true); layout?.let { onLayout(it.copy(pages = it.pages.map { p -> p - app.pkg }.filter { p -> p.isNotEmpty() }, dock = it.dock - app.pkg)) }; onChanged(); onDismiss() }
            MenuRow(Icons.Rounded.StopCircle, "Stop app") { Controls.closeApp(c, app.pkg); onDismiss() }
            MenuRow(Icons.Rounded.Info, "App info") { Controls.appInfo(c, app.pkg); onDismiss() }
            MenuRow(Icons.Rounded.Share, "Share") { Controls.share(c, app.pkg, app.label); onDismiss() }
            MenuRow(Icons.Rounded.Storefront, "Store page") { Controls.storePage(c, app.pkg); onDismiss() }
            MenuRow(Icons.Rounded.Delete, "Uninstall", Color(0xFFFF453A)) { Controls.uninstall(c, app.pkg); onDismiss() }
        }
    }
    rename?.let { r -> androidx.compose.material3.AlertDialog(onDismissRequest = { rename = null }, title = { Text("Rename") },
        text = { com.nizam.app.ui.design.OutlinedTextField(r, { rename = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { Launcher.rename(c, app.pkg, r); rename = null; onChanged(); onDismiss() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { Launcher.rename(c, app.pkg, null); rename = null; onChanged(); onDismiss() }) { Text("Reset") } }) }
    if (iconPick) androidx.compose.material3.AlertDialog(onDismissRequest = { iconPick = false }, title = { Text("Icon for ${app.label}") },
        text = { Column {
            val glyphs = listOf("💬", "🎵", "🎬", "📷", "📰", "🛍", "🏦", "🎮", "🧭", "📚", "✅", "⚙️", "❤️", "✈️", "🚗", "💡")
            val colours = listOf("#0A84FF", "#30D158", "#FF453A", "#FF9F0A", "#BF5AF2", "#64D2FF", "#1C1C1E", "#8A6D3B")
            var colour by remember { mutableStateOf(colours.first()) }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { colours.forEach { h ->
                Box(Modifier.size(30.dp).clip(CircleShape).background(Color(android.graphics.Color.parseColor(h))).clickable { colour = h }) } }
            glyphs.chunked(8).forEach { r -> Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { r.forEach { g ->
                Text(g, fontSize = 24.sp, modifier = Modifier.clickable { IconOverrides.set(c, app.pkg, g, colour); iconPick = false; onChanged(); onDismiss() }) } } }
            TextButton(onClick = { photo.launch("image/*") }) { Text("Use a photo") }
            TextButton(onClick = { IconOverrides.set(c, app.pkg, null); iconPick = false; onChanged(); onDismiss() }) { Text("Original icon") }
        } }, confirmButton = {})
}

@Composable
private fun MenuRow(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint); Text(label, color = tint, fontSize = 16.sp, modifier = Modifier.padding(start = 14.dp))
    }
}

// ── Widget picker ───────────────────────────────────────────────────────────────────────────────
@Composable
fun WidgetPicker(activity: LauncherActivity, t: HomeTheme, onChanged: () -> Unit, onClose: () -> Unit) {
    val c = LocalContext.current
    Scrim(onClose) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            PanelTitle("Add a widget", t)
            HomeWidgets.ATLAS.forEach { (k, name) -> Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(t.corner)).background(t.panel)
                .clickable { HomeWidgets.add(c, "atlas:$k"); onChanged(); onClose() }.padding(16.dp)) { Text(name, color = t.onPanel, fontFamily = t.font) } }
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp).clip(RoundedCornerShape(t.corner)).background(t.accent)
                .clickable { onClose(); activity.addAndroidWidget() }.padding(16.dp)) { Text("Widgets from your apps…", color = Color.White, fontWeight = FontWeight.SemiBold) }
        }
    }
}

// ── Atlas on the home screen: talk or type, and it acts ─────────────────────────────────────────
@Composable
fun AtlasSheet(container: com.nizam.app.AppContainer, t: HomeTheme, initial: String, onClose: () -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(initial) }
    var reply by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val auto = Launcher.get(c, "atlasAuto", "on") == "on"
    fun run(text: String) {
        if (text.isBlank()) return
        busy = true; reply = null
        scope.launch {
            val out = runCatching { container.agentMemory.addTurn(true, text); container.agentLoop.run(text, false, auto) }
            reply = out.fold({ o -> buildString {
                append(o.reply)
                if (o.steps.isNotEmpty()) append("\n\n" + o.steps.joinToString("\n") { (if (it.ok) "✓ " else "✕ ") + it.summary })
                if (o.pendingApproval.isNotEmpty()) append("\n\nNeeds your OK in Atlas — open Atlas to approve.")
            } }, { "Couldn't do that: ${com.nizam.app.ui.components.Feedback.friendly(it)}" })
            reply?.let { container.agentMemory.addTurn(false, it) }
            busy = false
        }
    }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { q = it; run(it) }
    }
    LaunchedEffect(Unit) { if (initial.isNotBlank()) run(initial) }
    Scrim(onClose) {
        Column(Modifier.fillMaxSize().imePadding().padding(16.dp), verticalArrangement = Arrangement.Bottom) {
            reply?.let { Text(it, color = t.onPanel, fontFamily = t.font, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(t.corner)).background(t.panel)
                .verticalScroll(rememberScrollState()).padding(16.dp)) }
            if (busy) Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = t.accent); Text("  Atlas is on it…", color = Color.White) }
            Text("Try: “open WhatsApp and message Ali I'm late”, “turn on the torch”, “what's on my screen”, “set a timer for 10 minutes”",
                color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(t.panel).padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(q, { q = it }, singleLine = true, textStyle = TextStyle(color = t.onPanel, fontSize = 17.sp, fontFamily = t.font), cursorBrush = SolidColor(t.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { run(q); q = "" }),
                    modifier = Modifier.weight(1f).padding(vertical = 10.dp), decorationBox = { inner -> if (q.isEmpty()) Text("Tell Atlas what to do…", color = t.onPanel.copy(alpha = 0.5f), fontSize = 17.sp); inner() })
                Icon(Icons.Rounded.Mic, "Speak", Modifier.clickable { speech.launch(com.nizam.app.feature.voice.speechIntent()) }.padding(8.dp), tint = t.accent)
                Icon(Icons.Rounded.ArrowUpward, "Send", Modifier.clickable { run(q); q = "" }.padding(8.dp), tint = t.onPanel)
            }
        }
    }
}
