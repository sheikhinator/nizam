package com.nizam.app.feature.hq

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

// A small 3D renderer for Atlas HQ, in plain Kotlin: flat-shaded triangles, sorted back to front and
// handed to the canvas in one call. No WebView and no GL surface, so it draws wherever Compose draws.

/** A 4×4 transform (row-major); points are columns: p' = M·p. */
class M4(val m: FloatArray = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)) {
    fun mul(o: M4): M4 {
        val r = FloatArray(16)
        for (i in 0 until 4) for (j in 0 until 4) {
            var s = 0f
            for (k in 0 until 4) s += m[i * 4 + k] * o.m[k * 4 + j]
            r[i * 4 + j] = s
        }
        return M4(r)
    }
    companion object {
        val I = M4()
        fun t(x: Float, y: Float, z: Float) = M4(floatArrayOf(1f, 0f, 0f, x, 0f, 1f, 0f, y, 0f, 0f, 1f, z, 0f, 0f, 0f, 1f))
        fun s(x: Float, y: Float, z: Float) = M4(floatArrayOf(x, 0f, 0f, 0f, 0f, y, 0f, 0f, 0f, 0f, z, 0f, 0f, 0f, 0f, 1f))
        fun ry(a: Float): M4 { val c = cos(a); val s = sin(a); return M4(floatArrayOf(c, 0f, s, 0f, 0f, 1f, 0f, 0f, -s, 0f, c, 0f, 0f, 0f, 0f, 1f)) }
        fun rx(a: Float): M4 { val c = cos(a); val s = sin(a); return M4(floatArrayOf(1f, 0f, 0f, 0f, 0f, c, -s, 0f, 0f, s, c, 0f, 0f, 0f, 0f, 1f)) }
        fun rz(a: Float): M4 { val c = cos(a); val s = sin(a); return M4(floatArrayOf(c, -s, 0f, 0f, s, c, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)) }
    }
}

const val EMIT: Int = 1      // lit by itself (screens, lamps, windows)
const val TWO: Int = 2       // seen from both sides

/** Triangles in world space: three corners, a normal, a colour and flags each. */
class Mesh(cap: Int = 256) {
    var n = 0
    var v = FloatArray(cap * 9)
    var nr = FloatArray(cap * 3)
    var col = IntArray(cap)
    var fl = IntArray(cap)
    var mat: M4 = M4.I

    fun clear() { n = 0; mat = M4.I }
    private fun grow() {
        val c = col.size * 2
        v = v.copyOf(c * 9); nr = nr.copyOf(c * 3); col = col.copyOf(c); fl = fl.copyOf(c)
    }
    inline fun with(t: M4, block: () -> Unit) { val old = mat; mat = old.mul(t); block(); mat = old }

    fun tri(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float, cx: Float, cy: Float, cz: Float,
            nx: Float, ny: Float, nz: Float, color: Int, flags: Int = 0) {
        if (n == col.size) grow()
        val m = mat.m
        val o = n * 9
        fun put(i: Int, x: Float, y: Float, z: Float) {
            v[o + i] = m[0] * x + m[1] * y + m[2] * z + m[3]
            v[o + i + 1] = m[4] * x + m[5] * y + m[6] * z + m[7]
            v[o + i + 2] = m[8] * x + m[9] * y + m[10] * z + m[11]
        }
        put(0, ax, ay, az); put(3, bx, by, bz); put(6, cx, cy, cz)
        var tx = m[0] * nx + m[1] * ny + m[2] * nz
        var ty = m[4] * nx + m[5] * ny + m[6] * nz
        var tz = m[8] * nx + m[9] * ny + m[10] * nz
        val l = sqrt(tx * tx + ty * ty + tz * tz).takeIf { it > 1e-6f } ?: 1f
        tx /= l; ty /= l; tz /= l
        nr[n * 3] = tx; nr[n * 3 + 1] = ty; nr[n * 3 + 2] = tz
        col[n] = color; fl[n] = flags
        n++
    }
    fun quad(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float, cx: Float, cy: Float, cz: Float, dx: Float, dy: Float, dz: Float,
             nx: Float, ny: Float, nz: Float, color: Int, flags: Int = 0) {
        tri(ax, ay, az, bx, by, bz, cx, cy, cz, nx, ny, nz, color, flags)
        tri(ax, ay, az, cx, cy, cz, dx, dy, dz, nx, ny, nz, color, flags)
    }

    /** A box centred on (x, y, z). */
    fun box(w: Float, h: Float, d: Float, x: Float, y: Float, z: Float, color: Int, flags: Int = 0, bottom: Boolean = false) {
        val a = w / 2; val b = h / 2; val c = d / 2
        val x0 = x - a; val x1 = x + a; val y0 = y - b; val y1 = y + b; val z0 = z - c; val z1 = z + c
        quad(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0f, 1f, 0f, color, flags)              // top
        quad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0f, 0f, 1f, color, flags)              // front
        quad(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0f, 0f, -1f, color, flags)             // back
        quad(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 1f, 0f, 0f, color, flags)              // right
        quad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1f, 0f, 0f, color, flags)             // left
        if (bottom) quad(x0, y0, z0, x0, y0, z1, x1, y0, z1, x1, y0, z0, 0f, -1f, 0f, color, flags)
    }

    /** A cylinder (or a cone when [rt] is 0) standing on its centre (x, y−h/2, z). */
    fun cyl(rt: Float, rb: Float, h: Float, x: Float, y: Float, z: Float, color: Int, seg: Int = 8, flags: Int = 0) {
        val y0 = y - h / 2; val y1 = y + h / 2
        for (i in 0 until seg) {
            val a0 = i * 6.2831855f / seg; val a1 = (i + 1) * 6.2831855f / seg; val am = (a0 + a1) / 2
            val c0 = cos(a0); val s0 = sin(a0); val c1 = cos(a1); val s1 = sin(a1)
            quad(x + c0 * rb, y0, z + s0 * rb, x + c1 * rb, y0, z + s1 * rb, x + c1 * rt, y1, z + s1 * rt, x + c0 * rt, y1, z + s0 * rt,
                cos(am), (rb - rt) / h * 0.5f, sin(am), color, flags)
            if (rt > 0f) tri(x, y1, z, x + c1 * rt, y1, z + s1 * rt, x + c0 * rt, y1, z + s0 * rt, 0f, 1f, 0f, color, flags)
        }
    }

    fun sphere(r: Float, x: Float, y: Float, z: Float, color: Int, seg: Int = 8, rings: Int = 5, sy: Float = 1f, flags: Int = 0) {
        for (j in 0 until rings) {
            val p0 = Math.PI.toFloat() * j / rings - 1.5707964f; val p1 = Math.PI.toFloat() * (j + 1) / rings - 1.5707964f
            for (i in 0 until seg) {
                val a0 = i * 6.2831855f / seg; val a1 = (i + 1) * 6.2831855f / seg
                fun px(p: Float, a: Float) = x + cos(p) * cos(a) * r
                fun py(p: Float) = y + sin(p) * r * sy
                fun pz(p: Float, a: Float) = z + cos(p) * sin(a) * r
                val pm = (p0 + p1) / 2; val am = (a0 + a1) / 2
                quad(px(p0, a0), py(p0), pz(p0, a0), px(p0, a1), py(p0), pz(p0, a1), px(p1, a1), py(p1), pz(p1, a1), px(p1, a0), py(p1), pz(p1, a0),
                    cos(pm) * cos(am), sin(pm), cos(pm) * sin(am), color, flags)
            }
        }
    }

    /** A flat rectangle facing up, cut into tiles so it sorts well. */
    fun floor(w: Float, d: Float, x: Float, y: Float, z: Float, color: Int, tile: Float = 1f, flags: Int = 0) {
        val nx = max(1, (w / tile).toInt()); val nz = max(1, (d / tile).toInt())
        val tw = w / nx; val td = d / nz
        for (i in 0 until nx) for (k in 0 until nz) {
            val x0 = x - w / 2 + i * tw; val z0 = z - d / 2 + k * td
            quad(x0, y, z0, x0 + tw, y, z0, x0 + tw, y, z0 + td, x0, y, z0 + td, 0f, 1f, 0f, color, flags)
        }
    }
    /** A flat disc facing up. */
    fun disc(r: Float, x: Float, y: Float, z: Float, color: Int, seg: Int = 10, flags: Int = 0, sx: Float = 1f) {
        for (i in 0 until seg) {
            val a0 = i * 6.2831855f / seg; val a1 = (i + 1) * 6.2831855f / seg
            tri(x, y, z, x + cos(a1) * r * sx, y, z + sin(a1) * r, x + cos(a0) * r * sx, y, z + sin(a0) * r, 0f, 1f, 0f, color, flags)
        }
    }
    /** A rectangle standing up, facing +z. */
    fun front(w: Float, h: Float, x: Float, y: Float, z: Float, color: Int, flags: Int = 0) =
        quad(x - w / 2, y - h / 2, z, x + w / 2, y - h / 2, z, x + w / 2, y + h / 2, z, x - w / 2, y + h / 2, z, 0f, 0f, 1f, color, flags)
    /** A rectangle standing up, facing +x. */
    fun side(d: Float, h: Float, x: Float, y: Float, z: Float, color: Int, flags: Int = 0) =
        quad(x, y - h / 2, z + d / 2, x, y - h / 2, z - d / 2, x, y + h / 2, z - d / 2, x, y + h / 2, z + d / 2, 1f, 0f, 0f, color, flags)
}

/** Sun, sky and room light. */
class Light(var sx: Float = 0.5f, var sy: Float = 0.8f, var sz: Float = 0.3f,
            var sun: Int = 0xFFFFFF, var sunK: Float = 0.75f, var amb: Int = 0xDDE6F5, var ambK: Float = 0.55f) {
    fun norm() { val l = sqrt(sx * sx + sy * sy + sz * sz); sx /= l; sy /= l; sz /= l }
}

class Cam {
    var ex = 0f; var ey = 0f; var ez = 0f
    var fx = 0f; var fy = 0f; var fz = -1f
    var rx = 1f; var ry = 0f; var rz = 0f
    var ux = 0f; var uy = 1f; var uz = 0f
    var w = 1f; var h = 1f; var fov = 30f
    val focal get() = (h / 2) / tan(Math.toRadians(fov / 2.0).toFloat())

    fun look(x: Float, y: Float, z: Float, tx: Float, ty: Float, tz: Float) {
        ex = x; ey = y; ez = z
        fx = tx - x; fy = ty - y; fz = tz - z
        var l = sqrt(fx * fx + fy * fy + fz * fz); fx /= l; fy /= l; fz /= l
        // right = forward × up
        rx = -fz; ry = 0f; rz = fx
        l = sqrt(rx * rx + rz * rz).takeIf { it > 1e-5f } ?: 1f; rx /= l; rz /= l
        // up = right × forward
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx
    }
    /** Screen x, y and depth of a point; depth ≤ 0 means behind the camera. */
    fun project(x: Float, y: Float, z: Float, out: FloatArray) {
        val dx = x - ex; val dy = y - ey; val dz = z - ez
        val d = dx * fx + dy * fy + dz * fz
        out[2] = d
        if (d <= 0.01f) { out[0] = -1e5f; out[1] = -1e5f; return }
        val f = focal / d
        out[0] = w / 2 + (dx * rx + dy * ry + dz * rz) * f
        out[1] = h / 2 - (dx * ux + dy * uy + dz * uz) * f
    }
}

/** Everything ready for one canvas call: screen corners and a colour per corner. */
class Frame {
    var verts = FloatArray(6 * 4096)
    var colors = IntArray(3 * 4096)
    var tris = 0
    fun clear() { tris = 0 }
    fun ensure(extra: Int) {
        val need = (tris + extra)
        if (need * 6 > verts.size) { val c = max(need, tris * 2) ; verts = verts.copyOf(c * 6); colors = colors.copyOf(c * 3) }
    }
}

class Renderer {
    val frame = Frame()
    private var sx = FloatArray(6 * 2048)
    private var cc = IntArray(2048)
    private var keys = LongArray(2048)
    private var cnt = 0
    private val p = FloatArray(3)

    fun begin() { frame.clear() }

    /** Projects, lights and sorts one layer of meshes, then appends it to the frame (far to near). */
    fun layer(cam: Cam, light: Light, vararg meshes: Mesh) {
        cnt = 0
        val margin = 80f
        for (m in meshes) {
            val v = m.v; val nr = m.nr
            for (t in 0 until m.n) {
                val o = t * 9
                val fl = m.fl[t]
                // facing away?
                val nx = nr[t * 3]; val ny = nr[t * 3 + 1]; val nz = nr[t * 3 + 2]
                val facing = nx * (cam.ex - v[o]) + ny * (cam.ey - v[o + 1]) + nz * (cam.ez - v[o + 2])
                if (fl and TWO == 0 && facing <= 0f) continue
                if (cnt == cc.size) { sx = sx.copyOf(cnt * 12); cc = cc.copyOf(cnt * 2); keys = keys.copyOf(cnt * 2) }
                val so = cnt * 6
                var depth = 0f; var behind = false
                var minX = 1e9f; var maxX = -1e9f; var minY = 1e9f; var maxY = -1e9f
                for (k in 0 until 3) {
                    cam.project(v[o + k * 3], v[o + k * 3 + 1], v[o + k * 3 + 2], p)
                    if (p[2] < 0.12f) { behind = true; break }
                    sx[so + k * 2] = p[0]; sx[so + k * 2 + 1] = p[1]; depth += p[2]
                    minX = min(minX, p[0]); maxX = max(maxX, p[0]); minY = min(minY, p[1]); maxY = max(maxY, p[1])
                }
                if (behind) continue
                if (maxX < -margin || minX > cam.w + margin || maxY < -margin || minY > cam.h + margin) continue
                cc[cnt] = shade(m.col[t], fl, nx, ny, nz, facing < 0f, light)
                val dk = (depth / 3f * 256f).toLong().coerceIn(0L, 0x7FFFFFFFL)
                keys[cnt] = (dk shl 32) or cnt.toLong()
                cnt++
            }
        }
        java.util.Arrays.sort(keys, 0, cnt)
        frame.ensure(cnt)
        val out = frame.verts; val oc = frame.colors
        var t = frame.tris
        for (i in cnt - 1 downTo 0) {
            val idx = (keys[i] and 0xFFFFFFFFL).toInt()
            val so = idx * 6
            System.arraycopy(sx, so, out, t * 6, 6)
            val c = cc[idx]
            oc[t * 3] = c; oc[t * 3 + 1] = c; oc[t * 3 + 2] = c
            t++
        }
        frame.tris = t
    }

    private fun shade(base: Int, fl: Int, nx0: Float, ny0: Float, nz0: Float, flip: Boolean, l: Light): Int {
        if (fl and EMIT != 0) return base or 0xFF000000.toInt()
        val s = if (flip) -1f else 1f
        val nx = nx0 * s; val ny = ny0 * s; val nz = nz0 * s
        val d = max(0f, nx * l.sx + ny * l.sy + nz * l.sz)
        // three flat bands: the cartoon look
        val band = when { d > 0.6f -> 1f; d > 0.25f -> 0.72f; d > 0.02f -> 0.45f; else -> 0.2f }
        val sky = 0.85f + 0.15f * ny          // up-facing surfaces catch a little more sky
        fun ch(shift: Int): Int {
            val b = (base shr shift) and 0xFF
            val a = ((l.amb shr shift) and 0xFF) / 255f * l.ambK * sky
            val su = ((l.sun shr shift) and 0xFF) / 255f * l.sunK * band
            return (b * (a + su)).toInt().coerceIn(0, 255)
        }
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
}

fun mix(a: Int, b: Int, t: Float): Int {
    fun c(s: Int) = (((a shr s) and 0xFF) * (1 - t) + ((b shr s) and 0xFF) * t).toInt().coerceIn(0, 255)
    return (c(16) shl 16) or (c(8) shl 8) or c(0)
}
fun hexColor(s: String, fallback: Int = 0x6366F1): Int = runCatching { s.removePrefix("#").take(6).toInt(16) }.getOrDefault(fallback)
fun absf(x: Float) = abs(x)
