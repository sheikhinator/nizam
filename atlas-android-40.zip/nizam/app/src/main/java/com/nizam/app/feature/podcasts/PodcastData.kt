package com.nizam.app.feature.podcasts

import android.content.Context
import android.util.Xml
import com.nizam.app.net.Http
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.net.URLEncoder

data class Show(val feed: String, val title: String, val author: String, val image: String?, val description: String = "", val episodeCount: Int = 0)
data class Episode(
    val id: String, val feed: String, val show: String, val title: String, val audio: String,
    val published: String, val durationSec: Int, val description: String, val image: String?
)

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

/** Discovery through Apple's free, keyless podcast directory. */
object PodcastDirectory {
    suspend fun search(query: String, limit: Int = 25): List<Show> {
        val r = JSONObject(Http.getJson("https://itunes.apple.com/search?media=podcast&limit=$limit&term=${enc(query)}"))
            .optJSONArray("results") ?: JSONArray()
        return (0 until r.length()).map { r.getJSONObject(it) }.mapNotNull { o ->
            val feed = o.optString("feedUrl"); if (feed.isBlank()) return@mapNotNull null
            Show(feed, o.optString("collectionName"), o.optString("artistName"),
                o.optString("artworkUrl600").ifBlank { o.optString("artworkUrl100") }.ifBlank { null },
                o.optJSONArray("genres")?.let { g -> (0 until g.length()).joinToString(" · ") { g.optString(it) } }.orEmpty(),
                o.optInt("trackCount"))
        }
    }

    /** Apple's top-podcast chart; country is a two-letter code like pk, us, gb. */
    suspend fun charts(country: String = "pk", limit: Int = 30): List<Show> {
        val entries = JSONObject(Http.getJson("https://itunes.apple.com/${country.lowercase()}/rss/toppodcasts/limit=$limit/json"))
            .optJSONObject("feed")?.optJSONArray("entry") ?: return emptyList()
        // the chart has no feed URLs, so each entry is resolved by lookup
        return (0 until entries.length()).map { entries.getJSONObject(it) }.mapNotNull { e ->
            val id = e.optJSONObject("id")?.optJSONObject("attributes")?.optString("im:id") ?: return@mapNotNull null
            val name = e.optJSONObject("im:name")?.optString("label").orEmpty()
            val art = e.optJSONArray("im:image")?.optJSONObject(2)?.optString("label")
            Show("itunes:$id", name, e.optJSONObject("im:artist")?.optString("label").orEmpty(), art)
        }
    }

    /** Turns a chart entry (itunes:ID) into a real feed. */
    suspend fun resolve(show: Show): Show {
        if (!show.feed.startsWith("itunes:")) return show
        val o = JSONObject(Http.getJson("https://itunes.apple.com/lookup?id=${show.feed.removePrefix("itunes:")}"))
            .optJSONArray("results")?.optJSONObject(0) ?: return show
        return show.copy(feed = o.optString("feedUrl"), description = o.optJSONArray("genres")
            ?.let { g -> (0 until g.length()).joinToString(" · ") { g.optString(it) } }.orEmpty(),
            episodeCount = o.optInt("trackCount"))
    }
}

/** Reads a podcast RSS feed into a show and its episodes. */
object Rss {
    private fun seconds(raw: String): Int {
        val t = raw.trim(); if (t.isBlank()) return 0
        return if (t.contains(":")) t.split(":").map { it.toIntOrNull() ?: 0 }
            .fold(0) { acc, v -> acc * 60 + v } else t.toIntOrNull() ?: 0
    }

    suspend fun load(feed: String): Pair<Show, List<Episode>> {
        val xml = Http.getText(feed)
        val parser = Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(xml.reader())
        }
        var showTitle = ""; var showAuthor = ""; var showImage: String? = null; var showDesc = ""
        val episodes = mutableListOf<Episode>()
        var inItem = false
        var title = ""; var audio = ""; var published = ""; var duration = ""; var desc = ""; var image: String? = null; var guid = ""
        var text = ""
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.lowercase()
                    when {
                        name == "item" -> { inItem = true; title = ""; audio = ""; published = ""; duration = ""; desc = ""; image = null; guid = "" }
                        name == "enclosure" && inItem -> audio = parser.getAttributeValue(null, "url").orEmpty()
                        name == "itunes:image" -> {
                            val href = parser.getAttributeValue(null, "href")
                            if (inItem) image = href else if (showImage == null) showImage = href
                        }
                    }
                    text = ""
                }
                XmlPullParser.TEXT -> text += parser.text
                XmlPullParser.END_TAG -> {
                    val name = parser.name.lowercase(); val value = text.trim()
                    if (inItem) when (name) {
                        "title" -> if (title.isBlank()) title = value
                        "pubdate" -> published = value
                        "itunes:duration" -> duration = value
                        "description", "itunes:summary" -> if (desc.isBlank()) desc = value.replace(Regex("<[^>]+>"), "").trim()
                        "guid" -> guid = value
                        "item" -> {
                            inItem = false
                            if (audio.isNotBlank()) episodes += Episode(guid.ifBlank { audio }, feed, showTitle, title, audio,
                                published.take(16), seconds(duration), desc.take(4000), image)
                        }
                    } else when (name) {
                        "title" -> if (showTitle.isBlank()) showTitle = value
                        "itunes:author" -> if (showAuthor.isBlank()) showAuthor = value
                        "description" -> if (showDesc.isBlank()) showDesc = value.replace(Regex("<[^>]+>"), "").trim()
                        "url" -> if (showImage == null && value.startsWith("http") && value.contains(Regex("\\.(jpg|jpeg|png)", RegexOption.IGNORE_CASE))) showImage = value
                    }
                }
            }
            event = parser.next()
        }
        val show = Show(feed, showTitle, showAuthor, showImage, showDesc, episodes.size)
        return show to episodes.map { it.copy(show = showTitle) }
    }
}

/** Subscriptions, progress, Up Next, stars and downloads — all local. */
class PodcastStore(private val c: Context) {
    private val f = File(c.filesDir, "podcasts.json")
    private fun load() = runCatching { JSONObject(f.readText()) }.getOrElse { JSONObject() }
    private fun save(o: JSONObject) = f.writeText(o.toString())

    fun shows(): List<Show> = load().optJSONArray("shows")?.let { a -> (0 until a.length()).map { a.getJSONObject(it) }.map {
        Show(it.optString("feed"), it.optString("title"), it.optString("author"), it.optString("image").ifBlank { null },
            it.optString("description"), it.optInt("count")) } } ?: emptyList()
    fun subscribed(feed: String) = shows().any { it.feed == feed }
    fun toggle(show: Show) {
        val kept = shows().filter { it.feed != show.feed }
        val list = if (kept.size == shows().size) kept + show else kept
        save(load().put("shows", JSONArray().apply { list.forEach {
            put(JSONObject().put("feed", it.feed).put("title", it.title).put("author", it.author)
                .put("image", it.image ?: "").put("description", it.description).put("count", it.episodeCount)) } }))
    }

    fun position(id: String) = load().optJSONObject("pos")?.optJSONObject(id)?.optLong("pos") ?: 0L
    fun duration(id: String) = load().optJSONObject("pos")?.optJSONObject(id)?.optLong("dur") ?: 0L
    fun played(id: String): Boolean { val d = duration(id); return d > 0 && position(id) > d * 0.95 }
    fun savePosition(ep: Episode, pos: Long, dur: Long) {
        val o = load(); val p = o.optJSONObject("pos") ?: JSONObject()
        p.put(ep.id, JSONObject().put("pos", pos).put("dur", dur).put("at", System.currentTimeMillis())
            .put("title", ep.title).put("show", ep.show).put("audio", ep.audio).put("image", ep.image ?: "").put("feed", ep.feed))
        save(o.put("pos", p))
    }
    fun inProgress(): List<JSONObject> = load().optJSONObject("pos")?.let { p -> p.keys().asSequence().map { p.getJSONObject(it).put("id", it) }.toList() }
        ?.filter { val d = it.optLong("dur"); d > 0 && it.optLong("pos") > 30_000 && it.optLong("pos") < d * 0.95 }
        ?.sortedByDescending { it.optLong("at") } ?: emptyList()

    fun starred(): Set<String> = load().optJSONArray("starred")?.let { a -> (0 until a.length()).map { a.optString(it) }.toSet() } ?: emptySet()
    fun star(id: String) { val s = starred().toMutableSet(); if (!s.add(id)) s.remove(id); save(load().put("starred", JSONArray(s.toList()))) }

    fun queue(): List<Episode> = load().optJSONArray("queue")?.let { a -> (0 until a.length()).map { a.getJSONObject(it) }.map { ep(it) } } ?: emptyList()
    fun setQueue(list: List<Episode>) = save(load().put("queue", JSONArray().apply { list.forEach { put(json(it)) } }))
    fun enqueue(e: Episode, next: Boolean) {
        val q = queue().filter { it.id != e.id }
        setQueue(if (next) listOf(e) + q else q + e)
    }

    private fun json(e: Episode) = JSONObject().put("id", e.id).put("feed", e.feed).put("show", e.show).put("title", e.title)
        .put("audio", e.audio).put("published", e.published).put("dur", e.durationSec).put("desc", e.description).put("image", e.image ?: "")
    private fun ep(o: JSONObject) = Episode(o.optString("id"), o.optString("feed"), o.optString("show"), o.optString("title"),
        o.optString("audio"), o.optString("published"), o.optInt("dur"), o.optString("desc"), o.optString("image").ifBlank { null })

    fun downloadDir() = File(c.filesDir, "podcasts").apply { mkdirs() }
    fun downloaded(e: Episode) = File(downloadDir(), e.id.hashCode().toString() + ".mp3").takeIf { it.exists() }
    suspend fun download(e: Episode): File = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val out = File(downloadDir(), e.id.hashCode().toString() + ".mp3")
        val part = File(downloadDir(), e.id.hashCode().toString() + ".part")      // a half-finished file never counts as downloaded
        val key = "podcast:${e.id.hashCode()}"
        try {
            val conn = (java.net.URL(e.audio).openConnection() as java.net.HttpURLConnection).apply {
                instanceFollowRedirects = true; connectTimeout = 20_000; readTimeout = 60_000; setRequestProperty("User-Agent", "Atlas/1.0")
            }
            if (conn.responseCode !in 200..299) throw IllegalStateException("The podcast server said HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            com.nizam.app.net.Transfers.progress(c, key, "Podcast · ${e.title}", -1)
            conn.inputStream.use { input -> part.outputStream().use { o ->
                val buf = ByteArray(1 shl 16); var done = 0L; var shown = -1
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    val pct = if (total > 0) (done * 100 / total).toInt() else -1
                    if (pct != shown) { shown = pct; com.nizam.app.net.Transfers.progress(c, key, "Podcast · ${e.title}", pct, "${done / 1_048_576} MB") }
                }
            } }
            part.renameTo(out)
            com.nizam.app.net.Transfers.done(c, key, e.title, "Downloaded — plays offline in Podcasts.")
        } catch (ex: Exception) {
            part.delete()
            com.nizam.app.net.Transfers.failed(c, key, e.title, com.nizam.app.ui.components.Feedback.friendly(ex))
            throw ex
        }
        out
    }
    fun downloads(): List<File> = downloadDir().listFiles()?.toList() ?: emptyList()

    // ── bookmarks: a moment plus your own note ──
    fun bookmarks(episodeId: String): List<Pair<Long, String>> =
        load().optJSONObject("marks")?.optJSONArray(episodeId)?.let { a ->
            (0 until a.length()).map { a.getJSONObject(it) }.map { it.optLong("at") to it.optString("note") }
        }?.sortedBy { it.first } ?: emptyList()
    fun addBookmark(episodeId: String, at: Long, note: String) {
        val o = load(); val marks = o.optJSONObject("marks") ?: JSONObject()
        val list = marks.optJSONArray(episodeId) ?: JSONArray()
        marks.put(episodeId, list.put(JSONObject().put("at", at).put("note", note)))
        save(o.put("marks", marks))
    }
    fun allBookmarks(): List<Triple<String, Long, String>> = load().optJSONObject("marks")?.let { m ->
        m.keys().asSequence().flatMap { id -> bookmarks(id).map { Triple(id, it.first, it.second) } }.toList()
    } ?: emptyList()

    // ── per-show playback settings ──
    fun showSpeed(feed: String) = load().optJSONObject("showspeed")?.optDouble(feed, 0.0)?.toFloat() ?: 0f
    fun setShowSpeed(feed: String, v: Float) {
        val o = load(); save(o.put("showspeed", (o.optJSONObject("showspeed") ?: JSONObject()).put(feed, v.toDouble())))
    }
    fun skipIntro(feed: String) = load().optJSONObject("skipintro")?.optInt(feed, 0) ?: 0
    fun setSkipIntro(feed: String, seconds: Int) {
        val o = load(); save(o.put("skipintro", (o.optJSONObject("skipintro") ?: JSONObject()).put(feed, seconds)))
    }
    fun autoDownload(feed: String) = load().optJSONArray("autodl")?.let { a -> (0 until a.length()).any { a.optString(it) == feed } } ?: false
    fun toggleAutoDownload(feed: String) {
        val set = (load().optJSONArray("autodl")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()).toMutableSet()
        if (!set.add(feed)) set.remove(feed)
        save(load().put("autodl", JSONArray(set.toList())))
    }

    // ── listening stats ──
    fun addListened(seconds: Int, atSpeed: Float) {
        val o = load(); val st = o.optJSONObject("stats") ?: JSONObject()
        st.put("seconds", st.optLong("seconds") + seconds)
        st.put("saved", st.optLong("saved") + (seconds * (atSpeed - 1f)).toLong().coerceAtLeast(0))
        save(o.put("stats", st))
    }
    fun stats(): Pair<Long, Long> = load().optJSONObject("stats")?.let { it.optLong("seconds") to it.optLong("saved") } ?: (0L to 0L)
}
