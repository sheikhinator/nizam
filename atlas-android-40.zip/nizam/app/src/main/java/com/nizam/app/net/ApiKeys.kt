package com.nizam.app.net

import android.content.Context
import com.nizam.app.BuildConfig
import com.nizam.app.data.prefs.SettingsRepository
import kotlinx.coroutines.flow.first

/**
 * Every API key Atlas uses, in one place, each with an on/off switch. Keys can come built in (from
 * the build's secrets — see BuildConfig.KEY_*), so a fresh install already has them; you can still
 * change or switch any of them off here. Switching off tucks the key away (it isn't lost) and Atlas
 * behaves as if it isn't set; switching on puts it back.
 */
object ApiKeys {
    class Slot(
        val id: String, val label: String, val what: String, val builtIn: String,
        val read: suspend (Context, SettingsRepository) -> String,
        val write: suspend (Context, SettingsRepository, String) -> Unit
    )

    private fun sp(c: Context, file: String) = c.getSharedPreferences(file, 0)
    private fun spSlot(id: String, label: String, what: String, builtIn: String, file: String, key: String) = Slot(id, label, what, builtIn,
        { c, _ -> sp(c, file).getString(key, "").orEmpty() }, { c, _, v -> sp(c, file).edit().putString(key, v.trim()).apply() })

    val SLOTS = listOf(
        Slot("gemini", "Gemini", "Google's AI — chat, vision, web answers", BuildConfig.KEY_GEMINI,
            { _, s -> s.geminiApiKey.first() }, { _, s, v -> s.setGeminiApiKey(v) }),
        Slot("openrouter", "OpenRouter", "Hundreds of models behind one key", BuildConfig.KEY_OPENROUTER,
            { _, s -> s.openRouterKey.first() }, { _, s, v -> s.setOpenRouterKey(v) }),
        Slot("custom", "Custom provider", "Any OpenAI-compatible endpoint (Groq, DeepSeek, local…)", BuildConfig.KEY_CUSTOM,
            { _, s -> s.customKey.first() }, { _, s, v -> s.setCustomKey(v) }),
        spSlot("fast", "Fast lane", "The quick model for simple questions", BuildConfig.KEY_FAST, "router", "fast_key"),
        Slot("hadith", "Hadith API", "hadithapi.com collections", BuildConfig.KEY_HADITH,
            { _, s -> s.hadithApiKey.first() }, { _, s, v -> s.setHadithApiKey(v) }),
        spSlot("tmdb", "TMDB", "Film details, trending and posters in Cinema", BuildConfig.KEY_TMDB, "cinema", "tmdb"),
        spSlot("omdb", "OMDb", "IMDb, Rotten Tomatoes and Metacritic scores", BuildConfig.KEY_OMDB, "cinema", "omdb"),
        spSlot("jamendo", "Jamendo", "Free music catalogue in Music › Discover", BuildConfig.KEY_JAMENDO, "music", "jamendo"),
        spSlot("tomtom", "TomTom", "Live traffic on Maps (free key at developer.tomtom.com)", BuildConfig.KEY_TOMTOM, "maps", "tomtom"),
        spSlot("hf", "Hugging Face", "Gated offline models (Gemma, Llama)", BuildConfig.KEY_HF, "local_model", "hf_token"),
    )

    private fun state(c: Context) = sp(c, "api_keys")
    fun enabled(c: Context, id: String) = state(c).getBoolean("on_$id", true)

    suspend fun value(c: Context, s: SettingsRepository, slot: Slot): String =
        if (enabled(c, slot.id)) slot.read(c, s) else state(c).getString("off_${slot.id}", "").orEmpty()

    suspend fun set(c: Context, s: SettingsRepository, slot: Slot, v: String) {
        if (enabled(c, slot.id)) slot.write(c, s, v) else state(c).edit().putString("off_${slot.id}", v.trim()).apply()
    }

    suspend fun setEnabled(c: Context, s: SettingsRepository, slot: Slot, on: Boolean) {
        if (on == enabled(c, slot.id)) return
        if (on) { slot.write(c, s, state(c).getString("off_${slot.id}", "").orEmpty()); state(c).edit().remove("off_${slot.id}").putBoolean("on_${slot.id}", true).apply() }
        else { state(c).edit().putString("off_${slot.id}", slot.read(c, s)).putBoolean("on_${slot.id}", false).apply(); slot.write(c, s, "") }
    }

    /** First run of a build that carries keys: fill any empty, switched-on slot with its built-in key (and the endpoints that go with them). */
    suspend fun seed(c: Context, s: SettingsRepository) {
        val marker = "seeded_" + (BuildConfig.KEY_GEMINI + BuildConfig.KEY_OPENROUTER + BuildConfig.KEY_CUSTOM + BuildConfig.KEY_FAST +
            BuildConfig.KEY_TMDB + BuildConfig.KEY_HF).hashCode()
        if (state(c).getBoolean(marker, false)) return
        SLOTS.forEach { slot -> if (slot.builtIn.isNotBlank() && enabled(c, slot.id) && slot.read(c, s).isBlank()) slot.write(c, s, slot.builtIn) }
        if (BuildConfig.KEY_CUSTOM_URL.isNotBlank() && s.customUrl.first().isBlank())
            s.setCustomEndpoint(BuildConfig.KEY_CUSTOM_URL, s.customKey.first(), BuildConfig.KEY_CUSTOM_MODEL)
        if (BuildConfig.KEY_FAST_URL.isNotBlank() && sp(c, "router").getString("fast_url", "").isNullOrBlank())
            sp(c, "router").edit().putString("fast_url", BuildConfig.KEY_FAST_URL).putString("fast_model", BuildConfig.KEY_FAST_MODEL).apply()
        state(c).edit().putBoolean(marker, true).apply()
    }

    fun mask(k: String) = if (k.length <= 8) "•".repeat(k.length) else k.take(4) + "••••" + k.takeLast(4)
}
