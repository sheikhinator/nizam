package com.nizam.app.feature.agent

import com.nizam.app.AppContainer
import com.nizam.app.feature.attach.Attachment
import com.nizam.app.net.Router
import com.nizam.app.net.Streaming

/**
 * The fast path: a question answered in one streamed call, with the user's live data as context.
 *
 * The router sends only non-action messages here. If the model still sees that doing something is
 * needed, it answers with the single word ACT, which never reaches the screen, and the caller hands
 * the message to the full agent instead.
 */
object Converse {

    private const val SYSTEM = """You are Atlas, the user's personal chief of staff living in their life app.
Answer directly, specifically and briefly, using their real data below. Never invent numbers you
weren't given. Plain conversational language; markdown only when it genuinely helps (lists, steps).

If answering properly would require DOING something — changing their app, the phone, sending,
opening, creating, logging, searching the web or using a connected tool — reply with exactly the
word ACT and nothing else. Never pretend you did an action."""

    /** Streams an answer through [onDelta]. Returns the full answer, or null when the agent should act. */
    suspend fun chat(
        c: AppContainer,
        message: String,
        attachments: List<Attachment> = emptyList(),
        extraContext: String = "",
        onDelta: (String) -> Unit
    ): String? {
        val prompt = buildString {
            appendLine(c.agentMemory.recall())
            appendLine()
            appendLine("Their app right now:")
            appendLine(Snapshot.of(c))
            if (extraContext.isNotBlank()) { appendLine(); appendLine(extraContext) }
            appendLine()
            appendLine("Conversation so far:")
            appendLine(c.agentMemory.history(10))
            appendLine()
            append("Them: ").append(message.ifBlank { "Look at what I attached and help me with it." })
        }
        // Hold the first few characters back until we know it isn't the ACT hand-off signal
        val held = StringBuilder()
        var released = false
        val full = Streaming.reply(
            c.settingsRepository, prompt, SYSTEM,
            maxTokens = if (attachments.isEmpty()) 1200 else 2400,
            attachments = attachments, context = c.appContext, lane = Router.Lane.CHAT
        ) { piece ->
            if (released) onDelta(piece)
            else {
                held.append(piece)
                val t = held.trimStart()
                if (t.length >= 4 && !t.startsWith("ACT")) { released = true; onDelta(held.toString()) }
            }
        }
        if (full.trim().trimEnd('.', '!').equals("ACT", ignoreCase = false)) return null
        if (!released) onDelta(held.toString())
        return full.trim()
    }
}
