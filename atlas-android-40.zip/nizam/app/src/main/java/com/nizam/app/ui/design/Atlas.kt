package com.nizam.app.ui.design

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

/*
 * Atlas's design language, in one file. Minimal and quiet: soft filled surfaces instead of outlines,
 * one accent colour, space instead of dividers, and a light spring when something is pressed.
 * Screens use these through the same names they always did, so the whole app changes at once.
 */

/** A soft, filled text field — no outline, no underline. Drop-in for Material's OutlinedTextField. */
@Composable
fun OutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    readOnly: Boolean = false,
    textStyle: TextStyle = MaterialTheme.typography.bodyLarge,
    label: (@Composable () -> Unit)? = null,
    placeholder: (@Composable () -> Unit)? = null,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
    isError: Boolean = false,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    singleLine: Boolean = false,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    minLines: Int = 1
) {
    val c = MaterialTheme.colorScheme
    TextField(
        value = value, onValueChange = onValueChange,
        modifier = modifier.padding(vertical = 4.dp),
        enabled = enabled, readOnly = readOnly, textStyle = textStyle,
        label = label, placeholder = placeholder, leadingIcon = leadingIcon, trailingIcon = trailingIcon,
        isError = isError, visualTransformation = visualTransformation,
        keyboardOptions = keyboardOptions, keyboardActions = keyboardActions,
        singleLine = singleLine, maxLines = maxLines, minLines = minLines,
        shape = MaterialTheme.shapes.small,
        colors = TextFieldDefaults.colors(
            focusedContainerColor = c.surfaceVariant, unfocusedContainerColor = c.surfaceVariant,
            disabledContainerColor = c.surfaceVariant.copy(alpha = 0.5f), errorContainerColor = c.errorContainer,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent, errorIndicatorColor = Color.Transparent,
            focusedLabelColor = c.primary, unfocusedLabelColor = c.onSurfaceVariant,
            focusedPlaceholderColor = c.onSurfaceVariant.copy(alpha = 0.7f), unfocusedPlaceholderColor = c.onSurfaceVariant.copy(alpha = 0.7f),
            cursorColor = c.primary
        )
    )
}

/** The secondary button: a soft tint of the accent, no border. Drop-in for Material's OutlinedButton. */
@Composable
fun OutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) {
    val c = MaterialTheme.colorScheme
    androidx.compose.material3.Button(
        onClick = onClick, modifier = modifier, enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = c.primaryContainer, contentColor = c.primary,
            disabledContainerColor = c.surfaceVariant, disabledContentColor = c.onSurfaceVariant
        ),
        elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp, 0.dp, 0.dp, 0.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
        content = content
    )
}

/** Pressed things shrink a touch and spring back, with a light tick — feedback without decoration. */
fun Modifier.pressable(enabled: Boolean = true, haptic: Boolean = true, role: Role = Role.Button, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.97f else 1f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "press")
    val feel = LocalHapticFeedback.current
    this.scale(s).clickable(interactionSource = source, indication = null, enabled = enabled, role = role) {
        if (haptic) feel.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        onClick()
    }
}

/** A quiet grouped block: rounded, a whisper lighter than the page, no border. */
@Composable
fun Group(modifier: Modifier = Modifier, padding: PaddingValues = PaddingValues(16.dp), content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.surface).padding(padding),
        content = content
    )
}

/** Small, calm section label. */
@Composable
fun Label(text: String, modifier: Modifier = Modifier) = Text(
    text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
    modifier = modifier.padding(top = 20.dp, bottom = 8.dp)
)

/**
 * A segmented control: the options sit in one soft track and a raised thumb slides to the chosen
 * one. Used for up to four short options; longer lists become a scrolling row of capsules.
 */
@Composable
fun Segmented(options: List<String>, selected: String?, onSelect: (String) -> Unit, labels: (String) -> String, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    val index = options.indexOf(selected).coerceAtLeast(0)
    BoxWithConstraints(
        modifier.fillMaxWidth().padding(vertical = 6.dp).height(38.dp)
            .clip(RoundedCornerShape(12.dp)).background(c.surfaceVariant).padding(3.dp)
    ) {
        val w = maxWidth / options.size
        val x by animateDpAsState(w * index, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow), label = "thumb")
        Box(Modifier.offset(x = x).width(w).fillMaxHeight().clip(RoundedCornerShape(10.dp))
            .background(if (selected in options) c.surface else Color.Transparent))
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            options.forEach { o ->
                val on = o == selected
                val tint by animateColorAsState(if (on) c.onSurface else c.onSurfaceVariant, label = "seg")
                Box(Modifier.weight(1f).fillMaxHeight().pressable(haptic = true, role = Role.Tab) { onSelect(o) },
                    contentAlignment = Alignment.Center) {
                    Text(labels(o), style = MaterialTheme.typography.labelLarge.copy(fontWeight = if (on) androidx.compose.ui.text.font.FontWeight.SemiBold
                        else androidx.compose.ui.text.font.FontWeight.Medium), color = tint, maxLines = 1)
                }
            }
        }
    }
}

/** A capsule: filled when chosen, a soft tint when not. */
@Composable
fun Capsule(text: String, on: Boolean, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (on) c.onSurface else c.surfaceVariant, label = "cap")
    val fg by animateColorAsState(if (on) c.background else c.onSurface, label = "capText")
    Box(Modifier.clip(RoundedCornerShape(50)).background(bg).pressable(role = Role.Tab, onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, style = MaterialTheme.typography.labelLarge.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Medium), color = fg, maxLines = 1)
    }
}
