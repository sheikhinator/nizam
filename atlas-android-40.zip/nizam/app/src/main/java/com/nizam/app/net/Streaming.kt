package com.nizam.app.net

import com.nizam.app.data.prefs.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Streamed replies. The wait is the same; the *felt* wait is not — words appear as they're generated
 * instead of after the whole answer lands.
 *
 * Gemini streams from :streamGenerateContent?alt=sse; OpenAI-compatible providers from the same
 * chat/completions endpoint with stream=true. Both use SSE framing, with different payload shapes.
 */
object Streaming {

    suspend fun reply(
        settings: SettingsRepository,
        prompt: String,
        system: String = "",
        maxTokens: Int = 1200,
        attachments: List<com.nizam.app.feature.attach.Attachment> = emptyList(),
        onDelta: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        when (settings.aiProvider.first()) {
            "GEMINI" -> gemini(settings, prompt, system, maxTokens, attachments, onDelta)
            else -> openAi(settings, prompt, system, maxTokens, attachments, onDelta)
        }
    }

    private fun sse(url: String, body: String, headers: Map<String, String>, onLine: (String) -> Unit) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 20000
            readTimeout = 120000
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "text/event-stream")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        if (conn.responseCode !in 200..299) {
            val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            throw IllegalStateException("HTTP ${conn.responseCode}: ${err.take(300)}")
        }
        conn.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (line.startsWith("data:")) onLine(line.removePrefix("data:").trim())
            }
        }
        conn.disconnect()
    }

    private suspend fun gemini(
        settings: SettingsRepository, prompt: String, system: String, maxTokens: Int,
        attachments: List<com.nizam.app.feature.attach.Attachment>, onDelta: (String) -> Unit
    ): String {
        val key = settings.geminiApiKey.first()
        val model = settings.geminiModel.first()
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse&key=$key"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", if (attachments.isEmpty()) JSONArray().put(JSONObject().put("text", prompt))
                    else com.nizam.app.feature.attach.Attachments.geminiParts(prompt, attachments))))
            .put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens))
        if (system.isNotBlank()) body.put("systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        val full = StringBuilder()
        sse(url, body.toString(), emptyMap()) { data ->
            runCatching {
                val parts = JSONObject(data).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts") ?: return@runCatching
                for (i in 0 until parts.length()) {
                    val piece = parts.getJSONObject(i).optString("text")
                    if (piece.isNotEmpty()) { full.append(piece); onDelta(piece) }
                }
            }
        }
        return full.toString()
    }

    private suspend fun openAi(
        settings: SettingsRepository, prompt: String, system: String, maxTokens: Int,
        attachments: List<com.nizam.app.feature.attach.Attachment>, onDelta: (String) -> Unit
    ): String {
        val custom = settings.aiProvider.first() == "CUSTOM"
        val url = if (custom) settings.customUrl.first().trimEnd('/') + "/chat/completions"
        else "https://openrouter.ai/api/v1/chat/completions"
        val key = if (custom) settings.customKey.first() else settings.openRouterKey.first()
        val model = if (custom) settings.customModel.first() else settings.openRouterModel.first()
        val messages = JSONArray()
        if (system.isNotBlank()) messages.put(JSONObject().put("role", "system").put("content", system))
        messages.put(JSONObject().put("role", "user").put("content",
            if (attachments.isEmpty()) prompt
            // images and PDF pages go as image parts; a text-only model still gets extracted text
            else if (com.nizam.app.feature.attach.Attachments.needsVision(attachments))
                com.nizam.app.feature.attach.Attachments.openAiContent(prompt, attachments)
            else com.nizam.app.feature.attach.Attachments.promptWithText(prompt, attachments)))
        val cap = if (url.contains("groq.com")) minOf(maxTokens, 1024) else maxTokens
        val body = JSONObject().put("model", model).put("messages", messages)
            .put("max_tokens", cap).put("stream", true)
        val full = StringBuilder()
        sse(url, body.toString(), mapOf("Authorization" to "Bearer $key")) { data ->
            if (data == "[DONE]") return@sse
            runCatching {
                val piece = JSONObject(data).optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("delta")?.optString("content").orEmpty()
                if (piece.isNotEmpty()) { full.append(piece); onDelta(piece) }
            }
        }
        return full.toString()
    }
}
