package com.nizam.app.feature.agentic

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nizam.app.ui.design.OrbState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// The Atlas ship: the faceted diamond from the app icon, grown wings and engines, hovering in a field of stars.

private val Coral = Color(0xFFE0603A)
private val CoralLight = Color(0xFFF08A5D)
private val CoralDark = Color(0xFFA4452A)
private val CoralDeep = Color(0xFF7A2F1B)
private val Amber = Color(0xFFF2A65A)
private val Plasma = Color(0xFF4CC9F0)

private fun poly(a: Offset, b: Offset, c: Offset, d: Offset? = null): Path = Path().apply { moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(c.x, c.y); if (d != null) lineTo(d.x, d.y); close() }

@Composable
fun AtlasShip(state: OrbState, diameter: Dp, level: Float = 0f, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "ship")
    val bob by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val flick by t.animateFloat(0f, 1f, infiniteRepeatable(tween(120, easing = LinearEasing), RepeatMode.Reverse), label = "flick")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    val spin by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart), label = "spin")
    val power by animateFloatAsState(when (state) {
        OrbState.Thinking, OrbState.Working -> 1f; OrbState.Speaking -> 0.75f; OrbState.Listening -> 0.55f; OrbState.Idle -> 0.3f
    }, tween(500), label = "power")

    Canvas(modifier.size(diameter)) {
        val d = size.minDimension
        val cx = size.width / 2f
        val cy = size.height / 2f + (bob - 0.5f) * d * 0.05f
        val roll = (bob - 0.5f) * 3.5f

        // glow behind the hull
        drawCircle(Brush.radialGradient(listOf(Amber.copy(alpha = 0.16f + 0.22f * power + 0.15f * level), Color.Transparent), Offset(cx, cy), d * 0.62f), d * 0.62f, Offset(cx, cy))

        // listening: a scanner beam sweeps down from the keel
        if (state == OrbState.Listening) {
            val top = cy + 0.22f * d; val spread = 0.30f * d + 0.12f * d * level
            drawPath(poly(Offset(cx, top), Offset(cx - spread, cy + 0.66f * d), Offset(cx + spread, cy + 0.66f * d)),
                Brush.verticalGradient(listOf(Plasma.copy(alpha = 0.34f), Color.Transparent), top, cy + 0.66f * d))
            val ly = top + (cy + 0.64f * d - top) * spin
            drawLine(Plasma.copy(alpha = 0.55f * (1f - spin)), Offset(cx - spread * spin, ly), Offset(cx + spread * spin, ly), d * 0.006f)
        }

        // hover shadow
        drawOval(Color.Black.copy(alpha = 0.22f), Offset(cx - 0.2f * d, cy + 0.46f * d - (bob - 0.5f) * d * 0.02f), Size(0.4f * d, 0.045f * d))

        rotate(roll, Offset(cx, cy)) {
            drawEngines(cx, cy, d, power, flick)
            drawHull(cx, cy, d, power, pulse, state == OrbState.Speaking)
        }

        // thinking: three motes circle the ship
        if (state == OrbState.Thinking || state == OrbState.Working) {
            for (i in 0..2) {
                val a = (spin + i / 3f) * 2f * PI.toFloat()
                val x = cx + cos(a) * 0.42f * d; val y = cy + sin(a) * 0.14f * d - 0.02f * d
                drawCircle(Plasma.copy(alpha = 0.9f), d * 0.012f, Offset(x, y))
                drawCircle(Plasma.copy(alpha = 0.25f), d * 0.03f, Offset(x, y))
            }
        }
    }
}

private fun DrawScope.drawEngines(cx: Float, cy: Float, d: Float, power: Float, flick: Float) {
    val len = d * (0.05f + 0.17f * power) * (0.85f + 0.3f * flick)
    val w = d * (0.022f + 0.012f * power)
    for (x in listOf(cx - 0.13f * d, cx + 0.13f * d, cx)) {
        val y = if (x == cx) cy + 0.25f * d else cy + 0.15f * d
        val l = if (x == cx) len * 0.8f else len
        drawPath(poly(Offset(x - w, y), Offset(x, y + l), Offset(x + w, y)), Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.95f), Amber.copy(alpha = 0.8f), Color.Transparent), y, y + l))
        drawCircle(Plasma.copy(alpha = 0.18f * power), d * 0.05f, Offset(x, y + l * 0.35f))
    }
}

private fun DrawScope.drawHull(cx: Float, cy: Float, d: Float, power: Float, pulse: Float, speaking: Boolean) {
    val t = Offset(cx, cy - 0.30f * d); val r = Offset(cx + 0.17f * d, cy); val b = Offset(cx, cy + 0.26f * d); val l = Offset(cx - 0.17f * d, cy); val c = Offset(cx, cy)
    // wings
    val lw = poly(Offset(cx - 0.15f * d, cy - 0.05f * d), Offset(cx - 0.47f * d, cy + 0.15f * d), Offset(cx - 0.12f * d, cy + 0.13f * d))
    val rw = poly(Offset(cx + 0.15f * d, cy - 0.05f * d), Offset(cx + 0.47f * d, cy + 0.15f * d), Offset(cx + 0.12f * d, cy + 0.13f * d))
    drawPath(lw, Coral.copy(alpha = 0.92f)); drawPath(rw, CoralDark.copy(alpha = 0.95f))
    drawPath(poly(Offset(cx - 0.47f * d, cy + 0.15f * d), Offset(cx - 0.12f * d, cy + 0.13f * d), Offset(cx - 0.14f * d, cy + 0.185f * d)), CoralDeep)
    drawPath(poly(Offset(cx + 0.47f * d, cy + 0.15f * d), Offset(cx + 0.12f * d, cy + 0.13f * d), Offset(cx + 0.14f * d, cy + 0.185f * d)), CoralDeep)
    // navigation lights on the wing tips
    for (x in listOf(cx - 0.47f * d, cx + 0.47f * d)) {
        val a = 0.5f + 0.5f * pulse
        drawCircle(Plasma.copy(alpha = 0.25f * a), d * 0.035f, Offset(x, cy + 0.15f * d))
        drawCircle(Plasma.copy(alpha = 0.95f * a), d * 0.011f, Offset(x, cy + 0.15f * d))
    }
    // faceted body
    drawPath(poly(t, l, c), CoralLight); drawPath(poly(t, r, c), Coral); drawPath(poly(l, b, c), CoralDark); drawPath(poly(r, b, c), CoralDeep)
    val rim = if (speaking) 0.65f + 0.35f * pulse else 0.85f
    drawPath(poly(t, r, b, l), Amber.copy(alpha = rim), style = Stroke(d * 0.010f))
    drawLine(Color.White.copy(alpha = 0.22f), t, b, d * 0.005f)
    // cockpit
    val g = 0.45f + 0.55f * (if (speaking) pulse else 0.6f + 0.4f * power)
    drawCircle(Brush.radialGradient(listOf(Amber.copy(alpha = 0.55f * g), Color.Transparent), Offset(cx, cy - 0.04f * d), d * 0.16f), d * 0.16f, Offset(cx, cy - 0.04f * d))
    drawPath(poly(Offset(cx, cy - 0.13f * d), Offset(cx + 0.052f * d, cy - 0.04f * d), Offset(cx, cy + 0.05f * d), Offset(cx - 0.052f * d, cy - 0.04f * d)), Amber)
    drawPath(poly(Offset(cx, cy - 0.10f * d), Offset(cx + 0.026f * d, cy - 0.04f * d), Offset(cx, cy + 0.01f * d), Offset(cx - 0.026f * d, cy - 0.04f * d)), Color.White.copy(alpha = 0.55f * g))
}

/** Stars that drift past slowly, twinkle, and stretch into streaks when Atlas is thinking, as if the ship were making a jump. */
@Composable
fun Starfield(intensity: Float, animated: Boolean, modifier: Modifier = Modifier) {
    val stars = remember { val r = kotlin.random.Random(11); List(80) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.5f + r.nextFloat() * 1.5f, 0.2f + r.nextFloat() * 0.8f) } }
    val t = rememberInfiniteTransition(label = "stars")
    val ph by (if (animated) t.animateFloat(0f, 1f, infiniteRepeatable(tween(70000, easing = LinearEasing)), label = "ph") else remember { mutableStateOf(0f) })
    val tw by (if (animated) t.animateFloat(0f, 1f, infiniteRepeatable(tween(3600), RepeatMode.Reverse), label = "tw") else remember { mutableStateOf(0.5f) })
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val tint = if (dark) Color(0xFFFFE9D6) else MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        stars.forEachIndexed { i, s ->
            val depth = s[3]
            val y = ((s[1] + ph * depth) % 1f) * size.height
            val x = s[0] * size.width
            val a = (0.25f + 0.55f * depth) * (0.6f + 0.4f * abs(sin((tw + i * 0.13f) * PI.toFloat())))
            val streak = intensity * depth * 0.09f * size.height
            if (streak > 2f) drawLine(tint.copy(alpha = a), Offset(x, y), Offset(x, y - streak), s[2].dp.toPx())
            else drawCircle(tint.copy(alpha = a), s[2].dp.toPx() * 0.7f, Offset(x, y))
        }
    }
}
