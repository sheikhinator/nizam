package com.nizam.app.feature.agentic

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nizam.app.R
import com.nizam.app.ui.design.OrbState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private val Coral = Color(0xFFE0603A)
private val Amber = Color(0xFFF2A65A)

/** The Atlas mark itself: the faceted diamond from the app icon, alive. Its aperture glows when Atlas speaks or thinks. */
@Composable
fun AtlasMark(state: OrbState, diameter: Dp, level: Float = 0f, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "mark")
    val breathe by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "p")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "s")
    val power by animateFloatAsState(when (state) {
        OrbState.Thinking, OrbState.Working -> 1f; OrbState.Speaking -> 0.8f; OrbState.Listening -> 0.6f; OrbState.Idle -> 0.25f
    }, tween(500), label = "pw")
    Box(modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val d = size.minDimension; val ctr = center
            drawCircle(Brush.radialGradient(listOf(Amber.copy(alpha = 0.10f + 0.20f * power + 0.15f * level), Color.Transparent), ctr, d * 0.62f), d * 0.62f, ctr)
            drawCircle(Coral.copy(alpha = 0.16f + 0.10f * power), d * 0.46f, ctr, style = Stroke(d * 0.004f))
            if (state == OrbState.Thinking || state == OrbState.Working) rotate(spin, ctr) {
                for (i in 0..2) drawArc(Amber.copy(alpha = 0.85f), i * 120f, 38f, false, Offset(ctr.x - d * 0.46f, ctr.y - d * 0.46f), Size(d * 0.92f, d * 0.92f), style = Stroke(d * 0.012f, cap = StrokeCap.Round))
            }
            if (state == OrbState.Listening) drawCircle(Amber.copy(alpha = 0.35f), d * (0.46f + 0.06f * level), ctr, style = Stroke(d * 0.006f))
        }
        Image(painterResource(R.drawable.ic_launcher_foreground), "Atlas",
            Modifier.fillMaxSize().graphicsLayer { val s = 1.45f + 0.03f * breathe + 0.06f * level + (if (state == OrbState.Speaking) 0.03f * pulse else 0f); scaleX = s; scaleY = s })
        Canvas(Modifier.fillMaxSize()) {
            val g = when (state) {
                OrbState.Speaking -> 0.35f + 0.5f * pulse
                OrbState.Thinking, OrbState.Working -> 0.3f + 0.4f * pulse
                OrbState.Listening -> 0.3f + 0.7f * level
                OrbState.Idle -> 0.12f + 0.10f * breathe
            }
            val r = size.minDimension * 0.14f
            drawCircle(Brush.radialGradient(listOf(Amber.copy(alpha = g), Color.Transparent), center, r), r, center)
        }
    }
}

/** Stars that drift past slowly and twinkle. [warp] stretches them into streaks, used only for the jump between screens. */
@Composable
fun Starfield(intensity: Float, animated: Boolean, modifier: Modifier = Modifier, warp: Float = 0f) {
    val stars = remember { val r = kotlin.random.Random(11); List(70) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.5f + r.nextFloat() * 1.3f, 0.2f + r.nextFloat() * 0.8f) } }
    val t = rememberInfiniteTransition(label = "stars")
    val ph by (if (animated) t.animateFloat(0f, 1f, infiniteRepeatable(tween(90000, easing = LinearEasing)), label = "ph") else remember { mutableStateOf(0f) })
    val tw by (if (animated) t.animateFloat(0f, 1f, infiniteRepeatable(tween(3600), RepeatMode.Reverse), label = "tw") else remember { mutableStateOf(0.5f) })
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val tint = if (dark) Color(0xFFFFE9D6) else MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        stars.forEachIndexed { i, s ->
            val depth = s[3]
            val y = ((s[1] + ph * depth) % 1f) * size.height
            val x = s[0] * size.width
            val a = (0.22f + 0.45f * depth + 0.2f * intensity) * (0.6f + 0.4f * abs(sin((tw + i * 0.13f) * PI.toFloat())))
            val streak = warp * depth * 0.09f * size.height
            if (streak > 2f) drawLine(tint.copy(alpha = a.coerceAtMost(1f)), Offset(x, y), Offset(x, y - streak), s[2].dp.toPx())
            else drawCircle(tint.copy(alpha = a.coerceAtMost(1f)), s[2].dp.toPx() * 0.7f, Offset(x, y))
        }
    }
}
