package com.nizam.app.feature.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.AdaptiveIconDrawable
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Home-screen themes. Each one restyles everything on the home screen at once — icon shape and
 * treatment, fonts, clock, dock, panels and widgets. Your own choices (accent, icon shape, icon style,
 * per-app icons) sit on top of whichever theme you pick.
 */
data class HomeTheme(
    val name: String,
    val iconShape: String,          // squircle, circle, rounded, square, teardrop
    val iconStyle: String,          // original, themed (one colour), mono (Nothing-style)
    val accent: Color,
    val panel: Color,               // panels, widgets, dock
    val onPanel: Color,
    val text: Color,                // labels on the wallpaper
    val font: FontFamily,
    val clock: String,              // ios, pixel, nothing, minimal
    val corner: Dp,                 // widget/panel corner radius
    val dock: Boolean,
    val labels: Boolean,
    val list: Boolean = false       // Minimal: text list instead of icons
)

object HomeThemes {
    val NAMES = listOf("iOS", "Pixel", "Android", "Nothing", "Minimal", "Atlas Paper")

    fun base(name: String): HomeTheme = when (name) {
        "Pixel" -> HomeTheme(name, "circle", "themed", Color(0xFFA8C7FA), Color(0xE61F1F24), Color(0xFFE3E3E8), Color.White, FontFamily.SansSerif, "pixel", 28.dp, false, true)
        "Android" -> HomeTheme(name, "rounded", "original", Color(0xFF3DDC84), Color(0xE0202124), Color(0xFFE8EAED), Color.White, FontFamily.SansSerif, "pixel", 20.dp, true, true)
        "Nothing" -> HomeTheme(name, "circle", "mono", Color(0xFFD71921), Color(0xF20A0A0A), Color.White, Color.White, FontFamily.Monospace, "nothing", 24.dp, false, true)
        "Minimal" -> HomeTheme(name, "circle", "original", Color(0xFFEDEFF5), Color(0xCC000000), Color.White, Color.White, FontFamily.SansSerif, "minimal", 16.dp, false, true, list = true)
        "Atlas Paper" -> HomeTheme(name, "squircle", "themed", Color(0xFF8A6D3B), Color(0xF2F4EFE3), Color(0xFF2B2620), Color(0xFF2B2620), FontFamily.Serif, "ios", 26.dp, true, true)
        else -> HomeTheme("iOS", "squircle", "original", Color(0xFF0A84FF), Color(0xB31C1C1E), Color.White, Color.White, FontFamily.SansSerif, "ios", 26.dp, true, true)
    }

    /** The chosen theme with your overrides applied. */
    fun current(c: Context): HomeTheme {
        val t = base(Launcher.get(c, "theme", "iOS"))
        return t.copy(
            iconShape = Launcher.get(c, "iconShape", t.iconShape).ifBlank { t.iconShape },
            iconStyle = Launcher.get(c, "iconStyle", t.iconStyle).ifBlank { t.iconStyle },
            accent = Launcher.get(c, "accent", "").takeIf { it.isNotBlank() }?.let { runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull() } ?: t.accent,
            labels = Launcher.get(c, "labels", "").ifBlank { if (t.labels) "on" else "off" } == "on",
            dock = Launcher.get(c, "dock", "").ifBlank { if (t.dock) "on" else "off" } == "on",
            list = Launcher.get(c, "layoutMode", "").ifBlank { if (t.list) "list" else "grid" } == "list"
        )
    }

    fun shape(name: String): Shape = when (name) {
        "circle" -> CircleShape
        "square" -> RoundedCornerShape(4.dp)
        "rounded" -> RoundedCornerShape(22)
        "teardrop" -> RoundedCornerShape(topStart = 50, topEnd = 50, bottomEnd = 12, bottomStart = 50)
        else -> RoundedCornerShape(28)
    }
}

/** Per-app icon overrides: a built-in glyph + colour, or your own picture. */
object IconOverrides {
    fun get(c: Context, pkg: String): Pair<String, String>? = Launcher.get(c, "icon_$pkg", "").takeIf { it.isNotBlank() }
        ?.split('|')?.let { it.getOrElse(0) { "" } to it.getOrElse(1) { "#0A84FF" } }
    fun set(c: Context, pkg: String, glyphOrPath: String?, colour: String = "#0A84FF") =
        Launcher.set(c, "icon_$pkg", if (glyphOrPath.isNullOrBlank()) "" else "$glyphOrPath|$colour")
}

/** Android 13+ monochrome ("themed") icon layer when the app provides one. */
private suspend fun monochrome(c: Context, app: LApp, px: Int): ImageBitmap? = withContext(Dispatchers.IO) {
    if (Build.VERSION.SDK_INT < 33) return@withContext null
    runCatching {
        val d = c.packageManager.getApplicationIcon(app.pkg)
        (d as? AdaptiveIconDrawable)?.monochrome?.toBitmap(px, px, Bitmap.Config.ARGB_8888)?.asImageBitmap()
    }.getOrNull()
}

/** One app icon, drawn the way the current theme (and your overrides) say. */
@Composable
fun AppIconView(app: LApp, theme: HomeTheme, size: Dp, badge: Int = 0) {
    val c = LocalContext.current
    var bmp by remember(app.pkg) { mutableStateOf(Launcher.cachedIcon(app.pkg)) }
    var mono by remember(app.pkg, theme.iconStyle) { mutableStateOf<ImageBitmap?>(null) }
    val override = remember(app.pkg) { IconOverrides.get(c, app.pkg) }
    LaunchedEffect(app.pkg, theme.iconStyle) {
        if (bmp == null) bmp = Launcher.icon(c, app)
        if (theme.iconStyle != "original") mono = monochrome(c, app, 144)
    }
    val shape = HomeThemes.shape(theme.iconShape)
    Box(Modifier.size(size)) {
        Box(Modifier.size(size).shadow(if (theme.name == "iOS") 4.dp else 0.dp, shape).clip(shape).background(
            when {
                override != null -> runCatching { Color(android.graphics.Color.parseColor(override.second)) }.getOrDefault(theme.accent)
                theme.iconStyle == "mono" -> Color(0xFF1A1A1A)
                theme.iconStyle == "themed" -> theme.accent.copy(alpha = 0.22f).compositeOver(theme.panel)
                else -> Color.Transparent
            }), contentAlignment = Alignment.Center) {
            when {
                override != null && override.first.startsWith("/") -> runCatching { android.graphics.BitmapFactory.decodeFile(override.first)?.asImageBitmap() }.getOrNull()
                    ?.let { Image(it, app.label, Modifier.size(size), contentScale = androidx.compose.ui.layout.ContentScale.Crop) }
                override != null -> com.nizam.app.ui.components.AppGlyphs.forEmoji(override.first)?.let { androidx.compose.material3.Icon(it, app.label, Modifier.size(size * 0.55f), tint = Color.White) }
                    ?: Text(override.first, fontSize = (size.value * 0.45f).sp)
                theme.iconStyle != "original" && mono != null -> Image(mono!!, app.label, Modifier.size(size * 1.3f),
                    colorFilter = ColorFilter.tint(if (theme.iconStyle == "mono") Color.White else theme.accent))
                theme.iconStyle != "original" && bmp != null -> Image(bmp!!, app.label, Modifier.size(size * 0.62f),
                    colorFilter = ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(0f) }))
                bmp != null -> Image(bmp!!, app.label, Modifier.size(size))
            }
        }
        if (badge > 0) Box(Modifier.align(Alignment.TopEnd).size(if (badge > 9) 22.dp else 18.dp).clip(CircleShape)
            .background(if (theme.name == "Nothing") theme.accent else Color(0xFFFF3B30)), contentAlignment = Alignment.Center) {
            Text(if (badge > 99) "99" else "$badge", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private fun Color.compositeOver(bg: Color): Color {
    val a = alpha
    return Color(red * a + bg.red * (1 - a), green * a + bg.green * (1 - a), blue * a + bg.blue * (1 - a), 1f)
}
