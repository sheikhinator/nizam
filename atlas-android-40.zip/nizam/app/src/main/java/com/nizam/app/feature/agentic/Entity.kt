package com.nizam.app.feature.agentic

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.feature.ask.Commands
import com.nizam.app.feature.ask.Intent
import com.nizam.app.feature.dash.Dash
import com.nizam.app.feature.next.Activity
import com.nizam.app.feature.nx.PlanEngine
import com.nizam.app.feature.platform2.Suggestions
import com.nizam.app.ui.design.AtlasOrb
import com.nizam.app.ui.design.OrbState
import com.nizam.app.ui.screens.hubs.HubRegistry
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

/** The single-interface mode: when on, Atlas opens to one entity and nothing else. The classic screens are still all there, one long-press away. */
object EntityMode {
    private var state by mutableStateOf<Boolean?>(null)
    private fun p(c: Context) = c.getSharedPreferences("agentic", 0)
    fun on(c: Context): Boolean { if (state == null) state = p(c).getBoolean("entity_mode", true); return state == true }
    fun set(c: Context, v: Boolean) { state = v; p(c).edit().putBoolean("entity_mode", v).apply() }
}

private data class Msg(
    val mine: Boolean,
    val text: String,
    val comps: JSONArray? = null,
    val chips: List<Pair<String, String>> = emptyList(),
    val pending: Intent? = null,
)

private data class Reply(val say: String, val comps: JSONArray?, val openQuery: String, val act: Intent?)

private fun greeting(): String = when (LocalTime.now().hour) { in 4..11 -> "Good morning."; in 12..16 -> "Good afternoon."; in 17..20 -> "Good evening."; else -> "Hello." }

private suspend fun briefing(container: AppContainer): String {
    val parts = ArrayList<String>()
    runCatching {
        val now = LocalTime.now().let { it.hour * 60 + it.minute }
        PlanEngine.prayers(container).filter { it.startMin > now }.minByOrNull { it.startMin }?.let { parts += "${it.label} is at %02d:%02d".format(it.startMin / 60, it.startMin % 60) }
    }
    runCatching { val d = Dash.load(container); if (d.openTasks > 0) parts += "${d.openTasks} open task${if (d.openTasks == 1) "" else "s"}" }
    return greeting() + if (parts.isEmpty()) " What would you like to do?" else " " + parts.joinToString(", ") + "."
}

private suspend fun context(container: AppContainer): String {
    val d = runCatching { Dash.load(container) }.getOrNull()
    val spent7 = d?.txns?.filter { it.kind == "EXPENSE" && it.localDate >= LocalDate.now().minusDays(7).toString() }?.sumOf { it.amount } ?: 0.0
    return "Now: ${LocalDate.now()} ${LocalTime.now().withSecond(0).withNano(0)}. Open tasks: ${d?.openTasks ?: 0}. Spent in the last 7 days: Rs ${spent7.toLong()}. Streak: ${d?.sum?.streak ?: 0} days."
}

private fun parseAct(o: JSONObject?): Intent? {
    o ?: return null
    return when (o.optString("type")) {
        "expense" -> o.optDouble("amount", 0.0).takeIf { it > 0 }?.let { Intent.Expense(it, o.optString("category").ifBlank { "Other" }, o.optString("note")) }
        "income" -> o.optDouble("amount", 0.0).takeIf { it > 0 }?.let { Intent.Income(it, o.optString("note")) }
        "task" -> o.optString("title").takeIf { it.isNotBlank() }?.let { t -> Intent.AddTask(t, when (o.optString("due")) { "today" -> LocalDate.now(); "tomorrow" -> LocalDate.now().plusDays(1); else -> null }) }
        else -> null
    }
}

private suspend fun think(container: AppContainer, history: List<Msg>, said: String): Reply? {
    val convo = history.takeLast(6).joinToString("\n") { (if (it.mine) "User: " else "Atlas: ") + it.text.take(300) }
    val o = StructuredAi.obj(container,
        "You are Atlas, the user's one and only interface to their phone and life. ${context(container)}\nRecent conversation:\n$convo\nUser: $said\n\n" +
            "Reply with: say = what you tell them, plain and warm, a few lines at most; " +
            "components = an array (empty if not needed) of cards to show: {\"type\":\"stat\",\"label\",\"value\"}, {\"type\":\"list\",\"title\",\"items\":[strings]}, {\"type\":\"bar\",\"title\",\"items\":[{\"label\",\"value\":number}]}; " +
            "open_query = the name of a tool or screen to open right now (empty unless they clearly want one); " +
            "act = an object if they are asking you to record something: {\"type\":\"expense\",\"amount\":number,\"category\",\"note\"} or {\"type\":\"income\",\"amount\",\"note\"} or {\"type\":\"task\",\"title\",\"due\":\"today\"|\"tomorrow\"|\"\"}, otherwise an empty object. " +
            "Never say you already did an action; recording needs their confirmation. Use only numbers given in the data. If you are unsure what they want, ask one short question.",
        listOf("say", "components", "open_query", "act"), "You are a calm, capable personal assistant. Be brief.", 700) ?: return null
    return Reply(o.optString("say"), o.optJSONArray("components"), o.optString("open_query"), parseAct(o.optJSONObject("act")))
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EntityScreen(container: AppContainer, onOpen: (String) -> Unit, onClassic: () -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    val speak = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input = it }
    }

    LaunchedEffect(Unit) {
        EntityMode.set(c, true)
        if (msgs.isEmpty()) {
            val hello = briefing(container)
            val tips = runCatching { Suggestions.compute(container) }.getOrDefault(emptyList())
            msgs += Msg(false, hello + tips.firstOrNull()?.let { "\n" + it.text }.orEmpty(), chips = tips.map { it.label to it.route })
        }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    fun say(text: String, comps: JSONArray? = null, chips: List<Pair<String, String>> = emptyList(), pending: Intent? = null) { msgs += Msg(false, text, comps, chips, pending) }

    fun send(textIn: String) {
        val text = textIn.trim(); if (text.isBlank() || busy) return
        msgs += Msg(true, text); input = ""; busy = true
        scope.launch {
            try {
                AgentHalo.begin("Listening to you")
                val cmd = Commands.parse(text)
                when {
                    cmd is Intent.OpenTool -> { say("Opening ${cmd.title}."); onOpen(cmd.route) }
                    cmd != null -> say("Here's what I'll do. Hold to confirm.", pending = cmd)
                    else -> {
                        val r = think(container, msgs.toList(), text)
                        if (r == null) {
                            val guess = HubRegistry.search(text).firstOrNull()
                            say("I couldn't reach my brain just now. I can still do plain commands like \"spent 500 on lunch\", \"add task call Ali tomorrow\" or \"open prayer\".",
                                chips = listOfNotNull(guess?.let { it.title to it.route }))
                        } else {
                            val target = r.openQuery.takeIf { it.isNotBlank() }?.let { HubRegistry.search(it).firstOrNull() }
                            say(r.say.ifBlank { if (r.act != null) "Here's what I'll record." else "Done." }, r.comps, pending = r.act)
                            if (target != null) { say("Opening ${target.title}."); onOpen(target.route) }
                        }
                    }
                }
            } finally { AgentHalo.end(); busy = false }
        }
    }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 18.dp)) {
        Column(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Column(Modifier.combinedClickable(onClick = {}, onLongClick = { menu = true })) {
                AtlasOrb(if (busy) OrbState.Thinking else OrbState.Idle, diameter = if (msgs.size > 1) 76.dp else 140.dp)
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(msgs.size) { i ->
                val m = msgs[i]
                if (m.mine) Text(m.text, Modifier.fillMaxWidth(), textAlign = TextAlign.End, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(m.text, style = MaterialTheme.typography.bodyLarge)
                    m.comps?.let { GenUi(it, onOpen) }
                    if (m.chips.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { m.chips.take(3).forEach { (label, route) -> FilterChip(selected = false, onClick = { onOpen(route) }, label = { Text(label) }) } }
                    m.pending?.let { p ->
                        var state by remember { mutableStateOf("ask") }
                        when (state) {
                            "ask" -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Card { Text(Commands.describe(p), style = MaterialTheme.typography.titleSmall) }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    HoldToConfirm("Hold to confirm") {
                                        state = "done"
                                        scope.launch { runCatching { Commands.run(container, p) { r -> onOpen(r) } }.onSuccess { say("Done. You can undo it from Mission control.") }.onFailure { say("Couldn't do that: ${it.message}") } }
                                    }
                                    TextButton(onClick = { state = "no" }) { Text("Cancel") }
                                }
                            }
                            "done" -> Text("✓ ${Commands.describe(p)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            else -> Text("Cancelled.", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(input, { input = it }, placeholder = { Text("Talk to Atlas") }, modifier = Modifier.weight(1f), maxLines = 3)
            TextButton(onClick = {
                runCatching { speak.launch(android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .also { i -> com.nizam.app.feature.future.Lang.speechTag(c)?.let { i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, it) } }) }
            }) { Text("🎙") }
            TextButton(enabled = input.isNotBlank() && !busy, onClick = { send(input) }) { Text("Send") }
        }
    }

    if (menu) AlertDialog(onDismissRequest = { menu = false },
        title = { Text("Atlas") },
        text = { Text("You normally never need this. Classic Atlas brings back the tabs and every screen. Say \"entity mode\" or use the Entity shortcut to come back.") },
        confirmButton = { TextButton(onClick = { menu = false; EntityMode.set(c, false); Activity.log(c, "Atlas", "Switched to classic view", true); onClassic() }) { Text("Classic Atlas") } },
        dismissButton = { TextButton(onClick = { menu = false }) { Text("Stay") } })
}
