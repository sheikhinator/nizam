package com.nizam.app.feature.agentic

import android.content.Context
import android.content.ContextWrapper
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.nizam.app.feature.agent.Actions
import com.nizam.app.feature.phone.PhoneActions
import com.nizam.app.net.Ai
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.material3.Slider
import androidx.core.content.ContextCompat
import com.nizam.app.ui.design.Instruments
import com.nizam.app.ui.design.SoundFx
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.feature.ask.Commands
import com.nizam.app.feature.ask.Intent
import com.nizam.app.feature.dash.Dash
import com.nizam.app.feature.next.Activity
import com.nizam.app.feature.nx.PlanEngine
import com.nizam.app.feature.platform2.Suggestions
import com.nizam.app.ui.design.AtlasOrb
import com.nizam.app.ui.design.OrbState
import com.nizam.app.ui.screens.hubs.HubRegistry
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

/** The single-interface mode: when on, Atlas opens to one entity and nothing else. The classic screens are still all there, one long-press away. */
object EntityMode {
    private var state by mutableStateOf<Boolean?>(null)
    private fun p(c: Context) = c.getSharedPreferences("agentic", 0)
    fun on(c: Context): Boolean { if (state == null) state = p(c).getBoolean("entity_mode", true); return state == true }
    fun set(c: Context, v: Boolean) { state = v; p(c).edit().putBoolean("entity_mode", v).apply() }
}

internal data class Msg(
    val mine: Boolean,
    val text: String,
    val comps: JSONArray? = null,
    val chips: List<Pair<String, String>> = emptyList(),
    val pending: Intent? = null,
    val approvals: List<Pair<String, JSONObject>> = emptyList(),
)

/** The conversation outlives the screen, so opening a tool and coming back does not wipe it. It resets after 30 quiet minutes. */
internal object EntitySession {
    val msgs = mutableStateListOf<Msg>()
    var lastAt = 0L
}

private data class Reply(val say: String, val comps: JSONArray?, val openQuery: String, val act: Intent?)

private fun userName(c: Context) = c.getSharedPreferences("agentic", 0).getString("entity_name", "").orEmpty()

private fun greeting(name: String): String {
    val g = when (LocalTime.now().hour) { in 4..11 -> "Good morning"; in 12..16 -> "Good afternoon"; in 17..20 -> "Good evening"; else -> "Hello" }
    return if (name.isBlank()) "$g." else "$g, $name."
}

private fun persona(c: Context): String {
    val n = userName(c)
    return "You are Atlas, the user's personal AI: a composed, quick-witted butler-strategist in the manner of Jarvis and Alfred. " +
        "Speak the way a person talks: short natural sentences, no markdown, no emojis, no bullet lists unless asked. " +
        "Know the world: use the web when a question needs current facts. Anticipate: end with the next useful step when there is one. " +
        "Never claim you did something you did not do; anything that changes things needs the user's approval." +
        (if (n.isNotBlank()) " Address the user as $n now and then, not in every sentence." else "")
}

private suspend fun briefing(container: AppContainer): String {
    val parts = ArrayList<String>()
    runCatching {
        val now = LocalTime.now().let { it.hour * 60 + it.minute }
        PlanEngine.prayers(container).filter { it.startMin > now }.minByOrNull { it.startMin }?.let { parts += "${it.label} is at %02d:%02d".format(it.startMin / 60, it.startMin % 60) }
    }
    runCatching { val d = Dash.load(container); if (d.openTasks > 0) parts += "${d.openTasks} open task${if (d.openTasks == 1) "" else "s"}" }
    return greeting(userName(container.appContext)) + if (parts.isEmpty()) " How may I help?" else " " + parts.joinToString(", ") + "."
}

/** Things worth saying unprompted while the app is open. Rule-based, so it costs no AI quota. */
private suspend fun proactive(container: AppContainer): String? {
    val c = container.appContext
    val p = c.getSharedPreferences("entity_said", 0)
    fun fresh(key: String, cooldownMs: Long): Boolean { val now = System.currentTimeMillis(); if (now - p.getLong(key, 0L) < cooldownMs) return false; p.edit().putLong(key, now).apply(); return true }
    runCatching {
        val now = LocalTime.now().let { it.hour * 60 + it.minute }
        PlanEngine.prayers(container).filter { it.startMin > now && it.startMin - now <= 15 }.minByOrNull { it.startMin }?.let {
            if (fresh("pray_${it.label}_${LocalDate.now()}", 20 * 3_600_000L)) return "${it.label} is in ${it.startMin - now} minutes."
        }
    }
    runCatching {
        val nowMs = System.currentTimeMillis()
        val overdue = container.taskRepository.all().first().count { it.completedAt == null && it.due != null && it.due < nowMs - 3_600_000L }
        if (overdue > 0 && fresh("overdue", 4 * 3_600_000L)) return "You have $overdue overdue task${if (overdue == 1) "" else "s"}. Shall I help you sort them?"
    }
    runCatching {
        Suggestions.compute(container).firstOrNull()?.let { if (fresh("sug_${it.id}_${LocalDate.now()}", 20 * 3_600_000L)) return it.text }
    }
    return null
}

/** Background nudges: a morning briefing and an evening review, spoken in the same voice as the entity but delivered as notifications. */
object EntityPulse {
    suspend fun check(c: Context, container: AppContainer) {
        val p = c.getSharedPreferences("entity_pulse", 0)
        val today = LocalDate.now().toString()
        val h = LocalTime.now().hour
        val name = userName(c)
        if (h in 6..10 && p.getString("morning", "") != today) {
            p.edit().putString("morning", today).apply()
            val d = runCatching { Dash.load(container) }.getOrNull()
            val body = buildString {
                append(greeting(name)).append(' ')
                runCatching { PlanEngine.prayers(container).minByOrNull { it.startMin }?.let { append("Fajr was at %02d:%02d. ".format(it.startMin / 60, it.startMin % 60)) } }
                if ((d?.openTasks ?: 0) > 0) append("${d?.openTasks} tasks are waiting. ")
                append("Tap to plan the day.")
            }
            com.nizam.app.feature.notify.Notifications.post(c, com.nizam.app.feature.notify.Notifications.CHANNEL_NUDGE, 270, "Atlas · morning briefing", body)
        }
        if (h in 20..22 && p.getString("evening", "") != today) {
            p.edit().putString("evening", today).apply()
            val d = runCatching { Dash.load(container) }.getOrNull()
            val open = d?.openTasks ?: 0
            com.nizam.app.feature.notify.Notifications.post(c, com.nizam.app.feature.notify.Notifications.CHANNEL_NUDGE, 271, "Atlas · evening review",
                (if (open > 0) "$open tasks are still open. " else "A clear list tonight. ") + "Shall we wrap up the day?")
        }
    }
}

private suspend fun context(container: AppContainer): String {
    val d = runCatching { Dash.load(container) }.getOrNull()
    val spent7 = d?.txns?.filter { it.kind == "EXPENSE" && it.localDate >= LocalDate.now().minusDays(7).toString() }?.sumOf { it.amount } ?: 0.0
    return "Now: ${LocalDate.now()} ${LocalTime.now().withSecond(0).withNano(0)}. Open tasks: ${d?.openTasks ?: 0}. Spent in the last 7 days: Rs ${spent7.toLong()}. Streak: ${d?.sum?.streak ?: 0} days."
}

private fun parseAct(o: JSONObject?): Intent? {
    o ?: return null
    return when (o.optString("type")) {
        "expense" -> o.optDouble("amount", 0.0).takeIf { it > 0 }?.let { Intent.Expense(it, o.optString("category").ifBlank { "Other" }, o.optString("note")) }
        "income" -> o.optDouble("amount", 0.0).takeIf { it > 0 }?.let { Intent.Income(it, o.optString("note")) }
        "task" -> o.optString("title").takeIf { it.isNotBlank() }?.let { t -> Intent.AddTask(t, when (o.optString("due")) { "today" -> LocalDate.now(); "tomorrow" -> LocalDate.now().plusDays(1); else -> null }) }
        else -> null
    }
}

private suspend fun think(container: AppContainer, history: List<Msg>, said: String): Reply? {
    val convo = history.takeLast(6).joinToString("\n") { (if (it.mine) "User: " else "Atlas: ") + it.text.take(300) }
    val o = StructuredAi.obj(container,
        "You are Atlas, the user's one and only interface to their phone and life. ${context(container)}\nRecent conversation:\n$convo\nUser: $said\n\n" +
            "Reply with: say = what you tell them, plain and warm, a few lines at most; " +
            "components = an array (empty if not needed) of cards to show: {\"type\":\"stat\",\"label\",\"value\"}, {\"type\":\"list\",\"title\",\"items\":[strings]}, {\"type\":\"bar\",\"title\",\"items\":[{\"label\",\"value\":number}]}; " +
            "open_query = the name of a tool or screen to open right now (empty unless they clearly want one); " +
            "act = an object if they are asking you to record something: {\"type\":\"expense\",\"amount\":number,\"category\",\"note\"} or {\"type\":\"income\",\"amount\",\"note\"} or {\"type\":\"task\",\"title\",\"due\":\"today\"|\"tomorrow\"|\"\"}, otherwise an empty object. " +
            "Never say you already did an action; recording needs their confirmation. Use only numbers given in the data. If you are unsure what they want, ask one short question.",
        listOf("say", "components", "open_query", "act"), "You are a calm, capable personal assistant. Be brief.", 700) ?: return null
    return Reply(o.optString("say"), o.optJSONArray("components"), o.optString("open_query"), parseAct(o.optJSONObject("act")))
}


// ───────────────────────── Visual pieces ─────────────────────────

/** Slow drifting light behind everything. It brightens while Atlas is thinking or listening. */
@Composable
private fun Aurora(intensity: Float, animated: Boolean, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "aurora")
    val a by (if (animated) t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a") else remember { mutableStateOf(0.5f) })
    val b by (if (animated) t.animateFloat(0f, 1f, infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse), label = "b") else remember { mutableStateOf(0.5f) })
    Canvas(modifier) {
        val w = size.width; val h = size.height
        fun blob(col: Color, cx: Float, cy: Float, r: Float, al: Float) = drawCircle(Brush.radialGradient(listOf(col.copy(alpha = al), Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
        blob(c.primary, w * (0.2f + 0.5f * a), h * (0.18f + 0.1f * b), w * 0.9f, 0.14f + 0.12f * intensity)
        blob(c.tertiary, w * (0.8f - 0.5f * b), h * (0.55f + 0.1f * a), w * 0.8f, 0.10f + 0.10f * intensity)
        blob(c.secondary, w * (0.5f + 0.3f * a), h * (0.9f - 0.12f * b), w * 0.9f, 0.08f + 0.08f * intensity)
    }
}

/** Soft rings that spread from the orb while Atlas listens, thinks or speaks. */
@Composable
private fun Rings(active: Boolean, diameter: Dp, color: Color) {
    val t = rememberInfiniteTransition(label = "rings")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearOutSlowInEasing)), label = "p")
    val alpha by animateFloatAsState(if (active) 1f else 0f, tween(500), label = "ra")
    Canvas(Modifier.requiredSize(diameter * 2.2f)) {
        val base = size.minDimension / 2f / 2.2f
        for (i in 0..2) {
            val ph = (p + i / 3f) % 1f
            drawCircle(color.copy(alpha = (1f - ph) * 0.35f * alpha), base * (1f + ph * 1.1f), center, style = Stroke(2.dp.toPx()))
        }
    }
}

/** Text that writes itself in, so a reply feels spoken rather than dropped on the screen. */
@Composable
private fun RevealText(text: String, animate: Boolean, style: TextStyle, modifier: Modifier = Modifier, align: TextAlign = TextAlign.Start) {
    var shown by remember(text) { mutableStateOf(if (animate) 0 else text.length) }
    LaunchedEffect(text, animate) {
        if (!animate) { shown = text.length; return@LaunchedEffect }
        val step = maxOf(1, text.length / 70)
        while (shown < text.length) { shown = minOf(text.length, shown + step); delay(18) }
    }
    Box(modifier) {
        Text(text, style = style, color = Color.Transparent, textAlign = align)
        Text(text.take(shown), style = style, textAlign = align)
    }
}

/** Fades, rises and settles in once. */
@Composable
private fun Arrive(content: @Composable () -> Unit) {
    val st = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(st, enter = fadeIn(tween(420)) + slideInVertically(tween(420, easing = FastOutSlowInEasing)) { it / 5 } + scaleIn(tween(420), initialScale = 0.97f)) { content() }
}

@Composable
private fun Thinking() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 6.dp)) {
        repeat(3) { i ->
            val s by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(520), RepeatMode.Reverse, initialStartOffset = StartOffset(i * 160)), label = "d$i")
            Box(Modifier.size(8.dp).graphicsLayer { alpha = s; scaleX = 0.7f + 0.3f * s; scaleY = 0.7f + 0.3f * s }.clip(CircleShape).background(MaterialTheme.colorScheme.primary))
        }
    }
}

@Composable
private fun RoundBtn(icon: ImageVector, desc: String, hot: Boolean, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val pulse by rememberInfiniteTransition(label = "pb").animateFloat(1f, 1.12f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "pbp")
    Box(Modifier.size(46.dp).graphicsLayer { val s = if (hot) pulse else 1f; scaleX = s; scaleY = s }.clip(CircleShape)
        .background(if (hot) c.error else c.primary).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = if (hot) c.onError else c.onPrimary)
    }
}

// ───────────────────────── The entity ─────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EntityScreen(container: AppContainer, onOpen: (String) -> Unit, onClassic: () -> Unit) {
    val c = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val animated = remember { Instruments.animated(c) }
    val prefs = remember { c.getSharedPreferences("agentic", 0) }
    val msgs = EntitySession.msgs
    remember { if (System.currentTimeMillis() - EntitySession.lastAt > 30 * 60_000L) msgs.clear(); EntitySession.lastAt = System.currentTimeMillis(); 0 }
    var jump by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var level by remember { mutableStateOf(0f) }
    var voiceOn by remember { mutableStateOf(prefs.getBoolean("entity_voice", true)) }
    var handsFree by remember { mutableStateOf(prefs.getBoolean("entity_hands_free", true)) }
    var hasMic by remember { mutableStateOf(ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    var wantListen by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    // opening a tool is a short jump: the stars stretch, the ship surges forward, then the screen changes
    fun go(route: String) {
        if (jump) return
        if (!animated) { onOpen(route); return }
        jump = true
        scope.launch { delay(430); onOpen(route) }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> hasMic = ok; if (ok) wantListen = true }

    // the voice: the phone's own engine, at a speed and pitch you choose
    val tts = remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    var queued by remember { mutableStateOf<String?>(null) }
    var voiceRate by remember { mutableStateOf(prefs.getFloat("entity_rate", 1.0f)) }
    var voicePitch by remember { mutableStateOf(prefs.getFloat("entity_pitch", 1.0f)) }
    var voiceName by remember { mutableStateOf(prefs.getString("entity_voice_name", "").orEmpty()) }
    val utterances = remember { java.util.concurrent.atomic.AtomicInteger(0) }
    val main = remember { android.os.Handler(android.os.Looper.getMainLooper()) }
    fun applyVoice(t: TextToSpeech) {
        runCatching {
            val chosen = if (voiceName.isNotBlank()) t.voices?.firstOrNull { it.name == voiceName } else null
            if (chosen != null) t.voice = chosen else t.language = java.util.Locale.getDefault()
            t.setSpeechRate(voiceRate); t.setPitch(voicePitch)
        }
    }
    fun speakNow(t: TextToSpeech, text: String) {
        val clean = text.replace(Regex("[*#_`>~]"), "").replace(Regex("\\s+"), " ").trim(); if (clean.isBlank()) return
        applyVoice(t)
        if (clean.any { it in '؀'..'ۿ' }) runCatching { t.language = java.util.Locale("ur", "PK") }
        val sentences = clean.take(900).split(Regex("(?<=[.!?۔])\\s+")).filter { it.isNotBlank() }
        t.stop(); utterances.set(0)
        sentences.forEachIndexed { i, sentence ->
            utterances.incrementAndGet()
            t.speak(sentence, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "entity${System.nanoTime()}_$i")
        }
    }
    DisposableEffect(Unit) {
        var ref: TextToSpeech? = null
        ref = TextToSpeech(c) { status ->
            main.post {
                val t = ref
                if (status == TextToSpeech.SUCCESS && t != null) {
                    applyVoice(t)
                    ttsReady = true
                    queued?.let { q -> queued = null; speakNow(t, q) }
                }
            }
        }
        ref.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { main.post { speaking = true } }
            override fun onDone(id: String?) { main.post { if (utterances.decrementAndGet() <= 0) { utterances.set(0); speaking = false; if (handsFree && hasMic) wantListen = true } } }
            @Deprecated("") override fun onError(id: String?) { main.post { if (utterances.decrementAndGet() <= 0) { utterances.set(0); speaking = false } } }
        })
        tts.value = ref
        onDispose { runCatching { ref.stop(); ref.shutdown() } }
    }
    fun speakOut(text: String) { val t = tts.value; if (t == null || !ttsReady) { queued = text; return }; speakNow(t, text) }

    fun say(text: String, comps: JSONArray? = null, chips: List<Pair<String, String>> = emptyList(), pending: Intent? = null, approvals: List<Pair<String, JSONObject>> = emptyList()) {
        msgs += Msg(false, text, comps, chips, pending, approvals)
        EntitySession.lastAt = System.currentTimeMillis()
        while (msgs.size > 60) msgs.removeAt(0)
        if (voiceOn) speakOut(text)
    }

    var job by remember { mutableStateOf<Job?>(null) }
    LaunchedEffect(busy) { if (busy) { while (true) { delay(300); if (AgentHalo.halted) { job?.cancel(); break } } } }

    /** "open X": an exactly named Atlas screen, then an installed app, then a close screen match; never a loose guess. */
    fun tryOpen(nameIn: String): Boolean {
        val name = nameIn.trim().trimEnd('.', '!', '?')
        if (name.length < 2) return false
        val low = name.lowercase()
        val exact = HubRegistry.search(name).firstOrNull { it.title.equals(name, true) }
        if (exact != null) { say("Opening ${exact.title}."); go(exact.route); return true }
        val app = runCatching { PhoneActions.openApp(c, name) }.getOrNull()
        if (app != null && app.ok) { say(app.message); return true }
        val words = low.split(" ").filter { it.length >= 4 }
        val partial = HubRegistry.search(name).firstOrNull { f -> val t = f.title.lowercase(); t.contains(low) || low.contains(t) || (words.isNotEmpty() && words.all { it in t }) }
        if (partial != null) { say("Opening ${partial.title}."); go(partial.route); return true }
        return false
    }

    fun send(textIn: String) {
        val text = textIn.trim(); if (text.isBlank() || busy) return
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); SoundFx.tick(c)
        tts.value?.stop(); speaking = false; wantListen = false
        msgs += Msg(true, text); input = ""; busy = true
        job = scope.launch {
            try {
                AgentHalo.begin("Thinking")
                val low = text.lowercase().trim().trimEnd('.', '!', '?')
                val named = Regex("^(?:call me|my name is)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text.trim())
                val openAsk = Regex("^(?:please\\s+)?(?:open|launch|start|go to)\\s+(?:the\\s+)?(.+?)(?:\\s+(?:app|please|now|for me))*$", RegexOption.IGNORE_CASE).find(text.trim())
                when {
                    named != null -> { val n = named.groupValues[1].trim().trimEnd('.', '!'); prefs.edit().putString("entity_name", n).apply(); say("Very well, $n. I shall remember it.") }
                    low in setOf("stop talking", "be quiet", "mute", "quiet", "silence", "shut up") -> { voiceOn = false; prefs.edit().putBoolean("entity_voice", false).apply(); tts.value?.stop(); say("Of course. I'll keep to text until you say \"talk to me\".") }
                    low in setOf("talk to me", "voice on", "speak", "unmute", "start talking") -> { voiceOn = true; prefs.edit().putBoolean("entity_voice", true).apply(); say("Voice is back on.") }
                    low in setOf("classic mode", "show menus", "classic atlas", "show me the menus") -> { say("Switching to classic Atlas."); EntityMode.set(c, false); onClassic() }
                    openAsk != null && tryOpen(openAsk.groupValues[1]) -> {}
                    else -> {
                        val cmd = Commands.parse(text).takeIf { it !is Intent.OpenTool }
                        when {
                            cmd != null -> say("Here's what I'll do. Hold to confirm.", pending = cmd)
                            Regex("(?i)\\b(how('s| is| am| are) my|show me my|my summary|overview|status of|report on|chart|breakdown|compare)\\b").containsMatchIn(text) -> {
                                val r = think(container, msgs.toList(), text)
                                if (r == null) say("I couldn't build that view just now. Ask me in your own words and I'll answer directly.")
                                else {
                                    val target = r.openQuery.takeIf { it.isNotBlank() }?.let { q -> HubRegistry.search(q).firstOrNull { f -> f.title.equals(q, true) || f.title.contains(q, true) } }
                                    say(r.say.ifBlank { if (r.act != null) "Here's what I'll record." else "Done." }, r.comps, pending = r.act)
                                    if (target != null) { say("Opening ${target.title}."); go(target.route) }
                                }
                            }
                            else -> {
                                // the full assistant: knows the world (web), uses every Atlas tool, and asks before anything that changes things
                                runCatching { container.agentMemory.addTurn(true, text) }
                                var failure: Throwable? = null
                                val out = try { withTimeoutOrNull(80_000) { container.agentLoop.run(persona(c) + "\n\nThe user says: " + text, useWeb = true, autoApprove = false) } }
                                    catch (t: CancellationException) { throw t } catch (t: Throwable) { failure = t; null }
                                val steps = out?.steps?.joinToString("\n") { (if (it.ok) "✓ " else "✕ ") + it.summary }.orEmpty()
                                if (out != null && (out.reply.isNotBlank() || out.pendingApproval.isNotEmpty() || steps.isNotBlank())) {
                                    runCatching { container.agentMemory.addTurn(false, out.reply) }
                                    say(out.reply.ifBlank { if (out.pendingApproval.isNotEmpty()) "I need your approval first." else "Done." }, approvals = out.pendingApproval)
                                    if (steps.isNotBlank()) msgs += Msg(false, steps)
                                } else {
                                    // the tool-using path failed or timed out: answer plainly from the model, with the web
                                    val convo = msgs.takeLast(8).joinToString("\n") { (if (it.mine) "User: " else "Atlas: ") + it.text.take(300) }
                                    val plain = try { withTimeoutOrNull(50_000) { Ai.generate(container.settingsRepository, persona(c) + "\n\nConversation so far:\n" + convo, null, 700, useWeb = true) } }
                                        catch (t: CancellationException) { throw t } catch (t: Throwable) { failure = t; null }
                                    if (plain != null && plain.isNotBlank()) say(plain)
                                    else say(if (failure != null) "I couldn't get an answer: ${com.nizam.app.ui.components.Feedback.friendly(failure)}" else "That took too long and I gave up. Try again, or ask something shorter.")
                                }
                            }
                        }
                    }
                }
            } catch (e: CancellationException) { say("Stopped."); throw e }
            finally { AgentHalo.end(); busy = false }
        }
    }

    // listening, live: the words appear as you speak and the ship's engines swell with your voice
    val recognizer = remember { if (SpeechRecognizer.isRecognitionAvailable(c)) SpeechRecognizer.createSpeechRecognizer(c) else null }
    DisposableEffect(recognizer) {
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { level = ((v + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { level = 0f }
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) { b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { input = it } }
            override fun onResults(b: Bundle?) {
                listening = false; level = 0f
                val said = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (said.isNotBlank()) send(said)
            }
            override fun onError(e: Int) { listening = false; level = 0f }
        })
        onDispose { runCatching { recognizer?.destroy() } }
    }
    fun startListening(auto: Boolean) {
        if (listening || busy) return
        if (!hasMic) { if (!auto) permission.launch(Manifest.permission.RECORD_AUDIO); return }
        if (recognizer == null) { if (!auto) com.nizam.app.ui.components.Feedback.show("Speech recognition isn't available on this phone"); return }
        input = ""; listening = true
        if (!auto) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        recognizer.startListening(android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .also { i -> com.nizam.app.feature.future.Lang.speechTag(c)?.let { i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, it) } })
    }
    fun toggleListen() {
        if (busy) { AgentHalo.stop(); return }
        if (listening) { recognizer?.stopListening(); listening = false; return }
        tts.value?.stop(); speaking = false
        startListening(false)
    }
    LaunchedEffect(wantListen) { if (wantListen) { wantListen = false; startListening(true) } }

    // never keep the mic or the voice going once Atlas leaves the screen
    DisposableEffect(Unit) {
        var ctx: Context = c
        while (ctx is ContextWrapper && ctx !is LifecycleOwner) ctx = ctx.baseContext
        val owner = ctx as? LifecycleOwner
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) { tts.value?.stop(); runCatching { recognizer?.cancel() }; listening = false; speaking = false; level = 0f } }
        owner?.lifecycle?.addObserver(obs)
        onDispose { owner?.lifecycle?.removeObserver(obs) }
    }

    // speak first: greet out loud, then keep an eye on things and speak up when something matters
    LaunchedEffect(Unit) {
        EntityMode.set(c, true)
        if (msgs.isEmpty()) {
            val hello = briefing(container)
            val tips = runCatching { Suggestions.compute(container) }.getOrDefault(emptyList())
            say(hello + tips.firstOrNull()?.let { " " + it.text }.orEmpty(), chips = tips.map { it.label to it.route })
        }
        while (true) {
            delay(75_000)
            if (!busy && !listening && !speaking && !menu) proactive(container)?.let { say(it) }
        }
    }
    LaunchedEffect(msgs.size, busy) { val n = msgs.size + (if (busy) 1 else 0); if (n > 0) list.animateScrollToItem(n - 1) }

    val big = msgs.size <= 1 && !busy
    val jumpP by animateFloatAsState(if (jump) 1f else 0f, tween(430, easing = FastOutSlowInEasing), label = "jump")
    val shipD by animateDpAsState(if (big) 210.dp else 104.dp, spring(dampingRatio = 0.78f, stiffness = 110f), label = "shipD")
    val area by animateDpAsState(if (big) 330.dp else 150.dp, spring(dampingRatio = 0.85f, stiffness = 110f), label = "area")
    val inten by animateFloatAsState(if (busy || listening || speaking) 1f else 0f, tween(700), label = "inten")
    val entrance = remember { Animatable(0.5f) }
    LaunchedEffect(Unit) { entrance.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 60f)) }
    val shipState = when { listening -> OrbState.Listening; busy -> OrbState.Thinking; speaking -> OrbState.Speaking; else -> OrbState.Idle }

    Box(Modifier.fillMaxSize()) {
        if (cs.background.luminance() < 0.5f) Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xCC05080F), Color(0x99101A33), Color(0xCC05080F)))))
        Aurora(inten, animated, Modifier.fillMaxSize())
        Starfield(inten, animated, Modifier.fillMaxSize(), warp = jumpP * 1.8f)
        if (jumpP > 0.01f) Box(Modifier.fillMaxSize().background(cs.primary.copy(alpha = 0.22f * jumpP)))
        Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 20.dp)) {
            Box(Modifier.fillMaxWidth().height(area), contentAlignment = Alignment.Center) {
                Rings(active = busy || listening || speaking, diameter = shipD * 0.8f, color = cs.primary)
                Box(Modifier.graphicsLayer { val sc = entrance.value * (1f + 0.9f * jumpP); scaleX = sc; scaleY = sc; alpha = ((entrance.value - 0.5f) / 0.5f).coerceIn(0f, 1f) * (1f - jumpP) }
                    .combinedClickable(onClick = { toggleListen() }, onLongClick = { menu = true })) {
                    AtlasMark(shipState, shipD, level)
                }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                items(msgs.size) { i ->
                    val m = msgs[i]
                    if (m.mine) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Box(Modifier.clip(RoundedCornerShape(18.dp)).background(cs.primary.copy(alpha = 0.14f)).padding(horizontal = 14.dp, vertical = 8.dp)) {
                            Text(m.text, style = MaterialTheme.typography.bodyMedium, color = cs.onSurface)
                        }
                    } else Arrive {
                        val first = msgs.size == 1
                        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = if (first) Alignment.CenterHorizontally else Alignment.Start) {
                            RevealText(m.text, animate = animated && i == msgs.lastIndex,
                                style = if (first) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.bodyLarge,
                                align = if (first) TextAlign.Center else TextAlign.Start)
                            m.comps?.let { GenUi(it) { r -> go(r) } }
                            if (m.chips.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { m.chips.take(3).forEach { (label, route) -> FilterChip(selected = false, onClick = { go(route) }, label = { Text(label) }) } }
                            if (m.approvals.isNotEmpty()) {
                                var st by remember { mutableStateOf("ask") }
                                when (st) {
                                    "ask" -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Card {
                                            Text("Before I do this", style = MaterialTheme.typography.titleSmall)
                                            m.approvals.forEach { (name, args) ->
                                                val detail = args.keys().asSequence().joinToString(", ") { k -> "$k: ${args.optString(k).take(50)}" }
                                                Text(name.replace('_', ' ').replaceFirstChar { it.uppercase() } + if (detail.isNotBlank()) " · $detail" else "", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                            }
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            HoldToConfirm("Hold to approve") {
                                                st = "done"; SoundFx.done(c)
                                                scope.launch {
                                                    val done = m.approvals.map { (name, args) -> val r = Actions.run(container, name, args); (if (r.ok) "✓ " else "✕ ") + r.summary }
                                                    say(done.joinToString("\n"))
                                                }
                                            }
                                            TextButton(onClick = { st = "no" }) { Text("Cancel") }
                                        }
                                    }
                                    "done" -> Text("✓ Approved", style = MaterialTheme.typography.labelMedium, color = cs.primary)
                                    else -> Text("Cancelled.", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                                }
                            }
                            m.pending?.let { p ->
                                var state by remember { mutableStateOf("ask") }
                                when (state) {
                                    "ask" -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Card { Text(Commands.describe(p), style = MaterialTheme.typography.titleSmall) }
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            HoldToConfirm("Hold to confirm") {
                                                state = "done"; SoundFx.done(c)
                                                scope.launch { runCatching { Commands.run(container, p) { r -> go(r) } }.onSuccess { say("Done. You can undo it from Mission control.") }.onFailure { say("Couldn't do that: ${it.message}") } }
                                            }
                                            TextButton(onClick = { state = "no" }) { Text("Cancel") }
                                        }
                                    }
                                    "done" -> Text("✓ ${Commands.describe(p)}", style = MaterialTheme.typography.labelMedium, color = cs.primary)
                                    else -> Text("Cancelled.", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                if (busy) item { Thinking() }
                item { Spacer(Modifier.height(8.dp)) }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp, top = 6.dp).clip(RoundedCornerShape(30.dp)).background(cs.surface.copy(alpha = 0.92f))
                .border(1.dp, cs.outline.copy(alpha = 0.45f), RoundedCornerShape(30.dp)).padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).padding(vertical = 8.dp)) {
                    if (input.isEmpty()) Text(if (listening) "Listening…" else "Talk to Atlas", style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant)
                    BasicTextField(input, { input = it }, textStyle = MaterialTheme.typography.bodyLarge.copy(color = cs.onSurface), cursorBrush = SolidColor(cs.primary), maxLines = 4,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { send(input) }), modifier = Modifier.fillMaxWidth())
                }
                Crossfade(input.isNotBlank() && !listening, label = "action") { hasText ->
                    if (hasText) RoundBtn(Icons.Filled.ArrowUpward, "Send", false) { send(input) } else RoundBtn(Icons.Filled.Mic, if (listening) "Stop listening" else "Speak", listening) { toggleListen() }
                }
            }
        }
    }

    if (menu) AlertDialog(onDismissRequest = { menu = false },
        title = { Text("Atlas") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Speak replies aloud", Modifier.weight(1f))
                    Switch(voiceOn, { voiceOn = it; prefs.edit().putBoolean("entity_voice", it).apply(); if (!it) tts.value?.stop() })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Hands-free: listen after I speak", Modifier.weight(1f))
                    Switch(handsFree, { handsFree = it; prefs.edit().putBoolean("entity_hands_free", it).apply() })
                }
                Text("Voice speed ${"%.1f".format(voiceRate)}x", style = MaterialTheme.typography.labelMedium)
                Slider(voiceRate, { voiceRate = it }, valueRange = 0.6f..1.6f, onValueChangeFinished = { prefs.edit().putFloat("entity_rate", voiceRate).apply() })
                Text("Voice pitch ${"%.1f".format(voicePitch)}", style = MaterialTheme.typography.labelMedium)
                Slider(voicePitch, { voicePitch = it }, valueRange = 0.6f..1.4f, onValueChangeFinished = { prefs.edit().putFloat("entity_pitch", voicePitch).apply() })
                Row {
                    TextButton(onClick = {
                        val t = tts.value
                        val all = t?.voices?.filter { it.locale.language == java.util.Locale.getDefault().language && !it.isNetworkConnectionRequired }?.sortedBy { it.name }.orEmpty()
                        if (all.isNotEmpty()) { val i = all.indexOfFirst { it.name == voiceName }; voiceName = all[(i + 1) % all.size].name; prefs.edit().putString("entity_voice_name", voiceName).apply() }
                        t?.let { speakNow(it, "Good evening. This is how I sound.") }
                    }) { Text(if (voiceName.isBlank()) "Change voice" else "Voice: ${voiceName.takeLast(14)}") }
                    TextButton(onClick = { tts.value?.let { speakNow(it, "Good evening. This is how I sound.") } }) { Text("Test") }
                }
                TextButton(onClick = { menu = false; go(com.nizam.app.ui.nav.Routes.SETTINGS) }) { Text("Settings and API keys") }
                Text("Say \"call me …\" to set your name. Say \"stop talking\" or \"talk to me\" to switch the voice. Classic Atlas brings back the tabs and every screen.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = { menu = false; EntityMode.set(c, false); Activity.log(c, "Atlas", "Switched to classic view", true); onClassic() }) { Text("Classic Atlas") } },
        dismissButton = { TextButton(onClick = { menu = false }) { Text("Stay") } })
}
