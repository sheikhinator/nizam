package com.nizam.app.feature.future

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Secrets sealed with a key that lives in the phone's secure hardware (Android Keystore): 2FA seeds,
 * documents, recall memory. The key can't be copied off the phone, so a stolen backup is unreadable.
 */
object Sealed {
    private const val ALIAS = "atlas_sealed_v1"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build())
        }.generateKey()
    }

    fun seal(bytes: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        return c.iv + c.doFinal(bytes)
    }

    fun open(blob: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, blob.copyOfRange(0, 12))) }
        return c.doFinal(blob, 12, blob.size - 12)
    }

    fun sealText(s: String): String = Base64.encodeToString(seal(s.toByteArray()), Base64.NO_WRAP)
    fun openText(s: String): String = runCatching { String(open(Base64.decode(s, Base64.NO_WRAP))) }.getOrDefault("")
}

/** A small encrypted list of JSON records, kept in the app's private storage. */
class SealedList(private val c: Context, private val name: String) {
    private val file get() = java.io.File(c.filesDir, "sealed_$name.bin")

    @Synchronized fun all(): List<JSONObject> = runCatching {
        if (!file.exists()) return emptyList()
        val a = JSONArray(String(Sealed.open(file.readBytes())))
        (0 until a.length()).map { a.getJSONObject(it) }
    }.getOrElse { emptyList() }

    @Synchronized fun save(list: List<JSONObject>) {
        file.writeBytes(Sealed.seal(JSONArray().apply { list.forEach { put(it) } }.toString().toByteArray()))
    }

    fun add(o: JSONObject) = save(all() + o)
    fun remove(id: String) = save(all().filter { it.optString("id") != id })
    fun update(id: String, change: (JSONObject) -> Unit) = save(all().map { if (it.optString("id") == id) it.also(change) else it })
}
