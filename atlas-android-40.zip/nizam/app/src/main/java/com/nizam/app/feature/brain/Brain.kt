package com.nizam.app.feature.brain

import android.content.Context
import com.nizam.app.AppContainer
import com.nizam.app.feature.council.CouncilStore
import com.nizam.app.feature.insight.ExperimentStore
import com.nizam.app.net.Ai
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import kotlin.math.ln

/** One searchable thing you've written, decided or been told. */
data class Doc(val source: String, val title: String, val text: String, val date: String = "")
data class Hit(val doc: Doc, val score: Double)

/**
 * The second brain. Search runs entirely on the phone (TF-IDF over everything you've saved);
 * only the final "ask" sends the handful of best-matching snippets to the AI — never the lot.
 */
object Brain {
    private val stop = setOf("the","and","for","that","this","with","what","did","was","are","you","your","have",
        "has","but","not","from","about","how","why","when","who","which","they","them","then","than","into","its")

    fun tokens(s: String) = s.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in stop }

    suspend fun corpus(c: AppContainer, context: Context): List<Doc> = buildList {
        c.noteRepository.all().first().forEach { add(Doc("Note", it.title, it.body)) }
        c.diaryRepository.entries().first().forEach { add(Doc("Diary", it.localDate, it.body, it.localDate)) }
        c.bookRepository.all().first().filter { it.notes.isNotBlank() }.forEach { add(Doc("Book", it.title, it.notes)) }
        c.taskRepository.all().first().forEach { add(Doc("Task", it.title, it.notes)) }
        c.courseRepository.allLessons().first().forEach { add(Doc("Lesson", it.title, it.title)) }
        c.agentMemory.notes().first().forEach { add(Doc("Memory", it.kind, it.text)) }
        CouncilStore(context).load().filter { it.speaker != "USER" }.forEach {
            add(Doc(if (it.kind == "VERDICT") "Verdict" else "Council", it.speaker, it.text + " " + it.dissent))
        }
        DecisionStore(context).all().forEach {
            add(Doc("Decision", it.decision, "${it.decision}. Expected: ${it.expectation}. Outcome: ${it.outcome}", it.date))
        }
        com.nizam.app.feature.memory.ReadLater.all(context).forEach { add(Doc("Article", it.title, it.text.take(6000), it.saved)) }
        com.nizam.app.feature.mind.Ideas.all(context).forEach { add(Doc("Idea", it.title, it.title + " " + it.research)) }
        ExperimentStore(context).all().forEach { add(Doc("Experiment", it.title, it.title + " " + it.verdict, it.start)) }
        // What Atlas itself has seen and done: chats, bot threads, files, autopilots, receipts, messages
        runCatching {
            c.agentMemory.turns().first().groupBy { it.localDate }.forEach { (day, turns) ->
                add(Doc("Chat", "Chat with Atlas", turns.joinToString("\n") { (if (it.fromUser) "Me: " else "Atlas: ") + it.text }.take(6000), day))
            }
        }
        runCatching {
            com.nizam.app.feature.bots.Bots.all(context).forEach { b ->
                val t = com.nizam.app.feature.bots.Bots.turns(context, b.id)
                if (t.isNotEmpty()) add(Doc("Bot", b.name, t.takeLast(40).joinToString("\n") { (if (it.fromUser) "Me: " else "${b.name}: ") + it.text }.take(6000)))
            }
        }
        com.nizam.app.feature.jarvis.BrainFiles.all(context).forEach { (name, date, text) -> add(Doc("File", name, text, date)) }
        com.nizam.app.feature.jarvis.Autopilot.all(context).forEach { p ->
            add(Doc("Autopilot", p.goal, p.steps.joinToString("\n") { "${it.title}: ${it.result}" }.take(6000)))
        }
        com.nizam.app.feature.jarvis.Receipts.all(context).forEach { r ->
            add(Doc("Receipt", r.optString("merchant"), "${r.optString("merchant")} ${r.optDouble("total")} ${r.optString("category")} " +
                r.optJSONArray("items")?.toString().orEmpty() + if (r.optInt("warrantyMonths") > 0) " warranty ${r.optInt("warrantyMonths")} months" else "",
                r.optString("date")))
        }
        (0L until 14L).map { LocalDate.now().minusDays(it) }.forEach { d ->
            val msgs = com.nizam.app.feature.jarvis.Timeline.day(context, d).filter { it.kind == "message" || it.kind == "call" }
            if (msgs.isNotEmpty()) add(Doc("Messages", "Messages on $d", msgs.joinToString("\n") { "${it.time} ${it.title}: ${it.detail}" }.take(6000), d.toString()))
        }
    }

    fun search(query: String, docs: List<Doc>, limit: Int = 12): List<Hit> {
        val q = tokens(query).distinct()
        if (q.isEmpty()) return emptyList()
        val docTokens = docs.map { tokens(it.title + " " + it.text) }
        val df = q.associateWith { t -> docTokens.count { t in it }.coerceAtLeast(1) }
        val n = docs.size.toDouble()
        return docs.indices.mapNotNull { i ->
            val toks = docTokens[i]
            if (toks.isEmpty()) return@mapNotNull null
            var score = 0.0
            q.forEach { t ->
                val tf = toks.count { it == t }
                // prefix match catches "prayed" for "prayer" without a stemmer
                val partial = if (tf == 0) toks.count { it.startsWith(t.take(5)) } * 0.5 else 0.0
                if (tf > 0 || partial > 0) score += (tf + partial) / toks.size.toDouble() * ln(1 + n / df.getValue(t))
            }
            if (score > 0) Hit(docs[i], score) else null
        }.sortedByDescending { it.score }.take(limit)
    }

    suspend fun ask(c: AppContainer, question: String, hits: List<Hit>): String {
        if (hits.isEmpty()) return "Nothing you've saved mentions that yet."
        val sources = hits.take(8).mapIndexed { i, h ->
            "[${i + 1}] ${h.doc.source}${if (h.doc.date.isNotBlank()) " (${h.doc.date})" else ""} — ${h.doc.title}: ${h.doc.text.take(700)}"
        }.joinToString("\n")
        return Ai.generate(
            settings = c.settingsRepository,
            prompt = "Answer the question using ONLY these excerpts from the user's own notes, diary, decisions and " +
                "advice. Cite sources like [2]. If they don't answer it, say so plainly — do not fill gaps from " +
                "general knowledge.\n\n$sources\n\nQuestion: $question",
            system = "You answer questions about a person's own saved records, faithfully and briefly.",
            maxOutputTokens = 1200
        )
    }
}

// ── Decision journal ─────────────────────────────────────────────────────────
data class Decision(
    val id: Long, val date: String, val decision: String, val expectation: String,
    val confidence: Int, val reviewOn: String, val outcome: String = "", val score: String = ""
)

class DecisionStore(context: Context) {
    private val file = File(context.filesDir, "decisions.json")
    fun all(): List<Decision> = runCatching { JSONArray(file.readText()) }.getOrElse { JSONArray() }.let { a ->
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Decision(o.optLong("id"), o.optString("date"), o.optString("decision"), o.optString("expectation"),
                o.optInt("confidence", 70), o.optString("reviewOn"), o.optString("outcome"), o.optString("score"))
        }
    }
    fun save(list: List<Decision>) = file.writeText(JSONArray().apply {
        list.forEach {
            put(JSONObject().put("id", it.id).put("date", it.date).put("decision", it.decision)
                .put("expectation", it.expectation).put("confidence", it.confidence).put("reviewOn", it.reviewOn)
                .put("outcome", it.outcome).put("score", it.score))
        }
    }.toString())
    fun due() = all().filter { it.score.isBlank() && it.reviewOn.isNotBlank() && it.reviewOn <= LocalDate.now().toString() }
}

/**
 * How good is your judgment, actually? For each confidence band, how often you turned out right.
 * Well-calibrated means your 80% calls come true about 80% of the time.
 */
object Calibration {
    data class Band(val label: String, val stated: Int, val right: Double, val n: Int)
    fun bands(list: List<Decision>): List<Band> {
        val scored = list.filter { it.score.isNotBlank() }
        return listOf(50..69, 70..84, 85..100).mapNotNull { r ->
            val inBand = scored.filter { it.confidence in r }
            if (inBand.isEmpty()) null
            else Band("${r.first}–${r.last}%", (r.first + r.last) / 2,
                inBand.sumOf { when (it.score) { "RIGHT" -> 1.0; "PARTLY" -> 0.5; else -> 0.0 } } / inBand.size, inBand.size)
        }
    }
}
