package com.nizam.app.feature.music

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.nizam.app.core.ChipRow
import com.nizam.app.ui.components.Feedback
import com.nizam.app.ui.components.Thinking
import com.nizam.app.ui.design.Group
import com.nizam.app.ui.design.Label
import com.nizam.app.ui.design.OutlinedButton
import com.nizam.app.ui.design.OutlinedTextField
import com.nizam.app.ui.design.rememberWorkScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun time(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

/** Album art: web images through Coil, local art decoded off the main thread, a soft note otherwise. */
@Composable
fun TrackArt(t: Track?, modifier: Modifier, corner: Int = 8) {
    val c = LocalContext.current
    var bmp by remember(t?.id, t?.art) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(t?.id, t?.art) { if (t != null && !t.art.startsWith("http")) bmp = withContext(Dispatchers.IO) { MusicArt.bitmap(c, t) } }
    Box(modifier.clip(RoundedCornerShape(corner.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        when {
            t != null && t.art.startsWith("http") -> AsyncImage(t.art, t.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            bmp != null -> Image(bmp!!.asImageBitmap(), t?.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            else -> Icon(Icons.Filled.MusicNote, null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
        }
    }
}

@Composable
fun MusicScreen() {
    val c = LocalContext.current
    val scope = rememberWorkScope()
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(c, perm) == PackageManager.PERMISSION_GRANTED) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var reload by remember { mutableIntStateOf(0) }
    var tracks by remember { mutableStateOf<List<Track>?>(null) }
    LaunchedEffect(granted, reload) { tracks = runCatching { MusicLibrary.all(c) }.getOrElse { emptyList() } }
    var tab by remember { mutableStateOf("Home") }
    var nowPlaying by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Track?>(null) }
    var openAlbum by remember { mutableStateOf<String?>(null) }
    var openArtist by remember { mutableStateOf<String?>(null) }
    var openPlaylist by remember { mutableStateOf<Playlist?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(horizontal = 18.dp)) {
                Text("Music", style = MaterialTheme.typography.displaySmall, modifier = Modifier.padding(top = 20.dp, bottom = 10.dp))
                ChipRow(listOf("Home", "Songs", "Albums", "Artists", "Playlists", "Discover"), tab,
                    { tab = it; openAlbum = null; openArtist = null; openPlaylist = null })
                DownloadBar()
            }
            val all = tracks
            if (!granted) Column(Modifier.padding(18.dp)) {
                Text("Allow Atlas to see the music on your phone, and it becomes your library.", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { ask.launch(perm) }, modifier = Modifier.padding(top = 8.dp)) { Text("Allow music access") }
            }
            if (all == null) { Thinking(label = "Reading your music", modifier = Modifier.padding(18.dp)); return@Column }
            val onMenu: (Track) -> Unit = { editing = it }
            Box(Modifier.weight(1f)) {
                when {
                    openAlbum != null -> TrackList(all.filter { it.album == openAlbum }.sortedBy { it.trackNo }, openAlbum!!, { openAlbum = null }, onMenu) { reload++ }
                    openArtist != null -> TrackList(all.filter { it.artist == openArtist }, openArtist!!, { openArtist = null }, onMenu) { reload++ }
                    openPlaylist != null -> { val p = openPlaylist!!
                        TrackList(p.trackIds.mapNotNull { id -> all.firstOrNull { it.id == id } }, p.name, { openPlaylist = null }, onMenu) { reload++ } }
                    tab == "Home" -> HomeTab(all, { nowPlaying = true }, { openAlbum = it }, { openPlaylist = it }, onMenu)
                    tab == "Songs" -> TrackList(all, null, null, onMenu) { reload++ }
                    tab == "Albums" -> Groups(all.groupBy { it.album.ifBlank { "Unknown album" } }) { openAlbum = it }
                    tab == "Artists" -> Groups(all.groupBy { it.artist.ifBlank { "Unknown artist" } }) { openArtist = it }
                    tab == "Playlists" -> PlaylistsTab(all) { openPlaylist = it }
                    else -> DiscoverTab { reload++ }
                }
            }
            MiniPlayer { nowPlaying = true }
        }
        AnimatedVisibility(nowPlaying, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            NowPlaying(onClose = { nowPlaying = false }, onEdit = { editing = it })
        }
        editing?.let { t -> TrackSheet(t, onClose = { editing = null }, onChanged = { reload++ }) }
    }
    BackHandler(nowPlaying) { nowPlaying = false }
}

@Composable
private fun DownloadBar() {
    val p by MusicSources.progress.collectAsState()
    val cur = p ?: return
    if (cur.state == "done") return
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(if (cur.state == "failed") "Download failed: ${cur.error}" else "Downloading ${cur.title} · ${cur.percent}%",
            style = MaterialTheme.typography.bodySmall,
            color = if (cur.state == "failed") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
        if (cur.state == "downloading") LinearProgressIndicator(progress = { cur.percent / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            trackColor = MaterialTheme.colorScheme.surfaceVariant)
    }
}

// ── Home ─────────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun HomeTab(all: List<Track>, openPlayer: () -> Unit, openAlbum: (String) -> Unit, openPlaylist: (Playlist) -> Unit, onMenu: (Track) -> Unit) {
    val c = LocalContext.current
    val byId = remember(all) { all.associateBy { it.id } }
    val recent = remember(all) { MusicLibrary.recent(c).mapNotNull { byId[it] }.take(12) }
    val liked = remember(all) { MusicLibrary.liked(c).mapNotNull { byId[it] } }
    val top = remember(all) { MusicLibrary.plays(c).entries.sortedByDescending { it.value }.mapNotNull { byId[it.key] }.take(12) }
    val albums = remember(all) { all.filter { it.album.isNotBlank() }.groupBy { it.album }.entries.shuffled().take(10) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            if (all.isEmpty()) {
                Text("No music yet. Allow access to your phone's music, import files, or find free music in Discover.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
                return@item
            }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { MusicPlayback.play(c, all.shuffled()); openPlayer() }) { Text("Shuffle all ${all.size}") }
                if (liked.isNotEmpty()) OutlinedButton(onClick = { MusicPlayback.play(c, liked); openPlayer() }) { Text("Liked · ${liked.size}") }
            }
        }
        if (recent.isNotEmpty()) item { Shelf("Recently played", recent) { i -> MusicPlayback.play(c, recent, i); openPlayer() } }
        if (top.isNotEmpty()) item { Shelf("On repeat", top) { i -> MusicPlayback.play(c, top, i); openPlayer() } }
        if (albums.isNotEmpty()) item {
            Label("Albums")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(albums.size) { i -> val (name, list) = albums[i]
                    Column(Modifier.width(132.dp).clickable(role = Role.Button) { openAlbum(name) }) {
                        TrackArt(list.first(), Modifier.size(132.dp), 12)
                        Text(name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                        Text(list.first().artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
            }
        }
        item {
            val lists = MusicLibrary.playlists(c)
            if (lists.isNotEmpty()) {
                Label("Your playlists")
                lists.forEach { p -> Text("${p.name} · ${p.trackIds.size}", style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.fillMaxWidth().clickable(role = Role.Button) { openPlaylist(p) }.padding(vertical = 10.dp)) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Shelf(title: String, list: List<Track>, onPlay: (Int) -> Unit) {
    Label(title)
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(list.size) { i -> val t = list[i]
            Column(Modifier.width(120.dp).clickable(role = Role.Button) { onPlay(i) }) {
                TrackArt(t, Modifier.size(120.dp), 12)
                Text(t.title, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                Text(t.artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

// ── Lists ────────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun TrackList(list: List<Track>, title: String?, onBack: (() -> Unit)?, onMenu: (Track) -> Unit, changed: () -> Unit) {
    val c = LocalContext.current
    var query by remember { mutableStateOf("") }
    val shown = remember(list, query) { if (query.isBlank()) list else list.filter {
        it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) } }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            if (onBack != null) Text("‹ Back", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.clickable(role = Role.Button) { onBack() }.padding(vertical = 8.dp))
            if (title != null) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                    TrackArt(list.firstOrNull(), Modifier.size(96.dp), 12)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.headlineSmall, maxLines = 2)
                        Text("${list.size} songs · ${time(list.sumOf { it.durationMs })}", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(enabled = list.isNotEmpty(), onClick = { MusicPlayback.play(c, list) }) { Text("Play") }
                    OutlinedButton(enabled = list.isNotEmpty(), onClick = { MusicPlayback.play(c, list.shuffled()) }) { Text("Shuffle") }
                }
            } else OutlinedTextField(query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search ${list.size} songs") })
        }
        itemsIndexed(shown, key = { _, t -> t.id }) { i, t -> TrackRow(t, onClick = { MusicPlayback.play(c, shown, i) }, onMenu = { onMenu(t) }) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun TrackRow(t: Track, onClick: () -> Unit, onMenu: () -> Unit) {
    val playing = MusicPlayback.current?.id == t.id
    Row(Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TrackArt(t, Modifier.size(48.dp), 6)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            Text(listOf(t.artist, t.album).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onMenu) { Icon(Icons.Filled.MoreVert, "More", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun Groups(groups: Map<String, List<Track>>, open: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        val keys = groups.keys.sortedBy { it.lowercase() }
        items(keys.size) { i -> val k = keys[i]; val list = groups.getValue(k)
            Row(Modifier.fillMaxWidth().clickable(role = Role.Button) { open(k) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TrackArt(list.first(), Modifier.size(56.dp), 8)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(k, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${list.size} songs", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun PlaylistsTab(all: List<Track>, open: (Playlist) -> Unit) {
    val c = LocalContext.current
    var lists by remember { mutableStateOf(MusicLibrary.playlists(c)) }
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.weight(1f), placeholder = { Text("New playlist") })
            Spacer(Modifier.width(8.dp))
            Button(enabled = name.isNotBlank(), onClick = {
                MusicLibrary.savePlaylists(c, lists + Playlist(System.currentTimeMillis(), name.trim(), emptyList()))
                lists = MusicLibrary.playlists(c); name = ""
            }) { Text("Create") }
        }
        val liked = MusicLibrary.liked(c)
        Row(Modifier.fillMaxWidth().clickable(role = Role.Button) {
            open(Playlist(-1, "Liked songs", all.filter { it.id in liked }.map { it.id }))
        }.padding(vertical = 12.dp)) {
            Text("♥  Liked songs", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text("${liked.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        lists.forEach { p ->
            Row(Modifier.fillMaxWidth().clickable(role = Role.Button) { open(p) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(p.name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Text("${p.trackIds.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Delete", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.clickable(role = Role.Button) { MusicLibrary.savePlaylists(c, lists - p); lists = MusicLibrary.playlists(c) }.padding(start = 16.dp))
            }
        }
    }
}

// ── Discover: free catalogues, any link, your files, and the big services ───────────────────────

@Composable
private fun DiscoverTab(changed: () -> Unit) {
    val c = LocalContext.current
    val scope = rememberWorkScope()
    var source by remember { mutableStateOf("Internet Archive") }
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Track>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var inside by remember { mutableStateOf<Track?>(null) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch { val n = MusicSources.import(c, uris); Feedback.show("Imported $n songs"); changed() }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Group(Modifier.padding(top = 8.dp)) {
            Text("Your files", style = MaterialTheme.typography.titleMedium)
            Text("MP3, M4A, FLAC, OGG, WAV — copied into Atlas with their tags and art.", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { importer.launch(arrayOf("audio/*")) }, modifier = Modifier.padding(top = 8.dp)) { Text("Import music") }
        }
        Label("Find music")
        ChipRow(listOf("Internet Archive", "Jamendo", "Any link", "Streaming apps"), source, { source = it; results = null; inside = null })
        if (source == "Jamendo") {
            var key by remember { mutableStateOf(MusicSources.jamendoKey(c)) }
            OutlinedTextField(key, { key = it; MusicSources.setJamendoKey(c, it) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Jamendo client id (free at developer.jamendo.com)") })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(q, { q = it }, singleLine = true, modifier = Modifier.weight(1f), placeholder = { Text(when (source) {
                "Any link" -> "https://…/song.mp3 or a .m3u playlist"; "Streaming apps" -> "Song, artist or album"; else -> "Artist, song, genre…" }) })
            Spacer(Modifier.width(8.dp))
            Button(enabled = q.isNotBlank() && !busy, onClick = {
                inside = null
                if (source == "Streaming apps") return@Button
                busy = true
                scope.launch {
                    results = runCatching { when (source) {
                        "Jamendo" -> MusicSources.jamendo(c, q)
                        "Any link" -> MusicSources.fromLink(q.trim())
                        else -> MusicSources.archive(q)
                    } }.onFailure { Feedback.failed("Searching", it) }.getOrElse { emptyList() }
                    busy = false
                }
            }) { Text(if (source == "Any link") "Open" else "Search") }
        }
        if (source == "Streaming apps") {
            Text("Search in the service's own app, where your account and subscription live.", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
            MusicSources.STREAMING.forEach { (name, pattern) ->
                Text(name, style = MaterialTheme.typography.bodyLarge, color = if (q.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth().clickable(enabled = q.isNotBlank(), role = Role.Button) {
                        runCatching { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(pattern.format(Uri.encode(q)))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }.padding(vertical = 10.dp))
            }
        }
        if (busy) Thinking(label = "Searching")
        val shown = inside?.let { null } ?: results
        inside?.let { item ->
            Text("‹ Results", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.clickable { inside = null }.padding(vertical = 8.dp))
            var files by remember(item.id) { mutableStateOf<List<Track>?>(null) }
            LaunchedEffect(item.id) { files = runCatching { MusicSources.archiveFiles(item) }.getOrElse { emptyList() } }
            val fs = files
            if (fs == null) Thinking(label = "Opening ${item.title}")
            else {
                if (fs.isEmpty()) Text("No MP3 files in this item.", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (fs.isNotEmpty()) Button(onClick = { MusicPlayback.play(c, fs) }) { Text("Play all") }
                    if (fs.isNotEmpty()) OutlinedButton(onClick = { fs.forEach { MusicSources.download(c, it) }; Feedback.show("Downloading ${fs.size} songs") }) { Text("Download all") }
                }
                fs.forEachIndexed { i, t -> OnlineRow(t, onPlay = { MusicPlayback.play(c, fs, i) }) }
            }
        }
        shown?.let { list ->
            if (list.isEmpty()) Text("Nothing found.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            list.forEachIndexed { i, t ->
                if (t.source == "archive" && t.uri.isBlank()) OnlineRow(t, onPlay = { inside = t }, openLabel = "Open")
                else OnlineRow(t, onPlay = { MusicPlayback.play(c, list.filter { it.uri.isNotBlank() }, list.filter { it.uri.isNotBlank() }.indexOf(t).coerceAtLeast(0)) })
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun OnlineRow(t: Track, onPlay: () -> Unit, openLabel: String = "Play") {
    val c = LocalContext.current
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TrackArt(t, Modifier.size(48.dp), 6)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).clickable(role = Role.Button, onClick = onPlay)) {
            Text(t.title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(listOf(t.artist, if (t.durationMs > 0) time(t.durationMs) else "").filter { it.isNotBlank() }.joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
        Text(openLabel, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.clickable(role = Role.Button, onClick = onPlay).padding(8.dp))
        if (t.uri.startsWith("http")) Text("Save", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.clickable(role = Role.Button) { MusicSources.download(c, t); Feedback.show("Downloading ${t.title}") }.padding(8.dp))
    }
}

// ── Mini player ─────────────────────────────────────────────────────────────────────────────────

@Composable
private fun MiniPlayer(open: () -> Unit) {
    val t = MusicPlayback.current ?: return
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).clickable(role = Role.Button, onClick = open)) {
        val d = MusicPlayback.durationMs
        LinearProgressIndicator(progress = { if (d > 0) MusicPlayback.positionMs / d.toFloat() else 0f }, modifier = Modifier.fillMaxWidth().height(2.dp),
            trackColor = Color.Transparent)
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TrackArt(t, Modifier.size(42.dp), 6)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(t.title, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            IconButton(onClick = { MusicPlayback.toggle() }) {
                Icon(if (MusicPlayback.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (MusicPlayback.isPlaying) "Pause" else "Play")
            }
            IconButton(onClick = { MusicPlayback.next() }) { Icon(Icons.Filled.SkipNext, "Next") }
        }
    }
}

// ── Now playing ─────────────────────────────────────────────────────────────────────────────────

@Composable
private fun NowPlaying(onClose: () -> Unit, onEdit: (Track) -> Unit) {
    val c = LocalContext.current
    val t = MusicPlayback.current
    var pane by remember { mutableStateOf("Art") }
    var tint by remember { mutableStateOf<Color?>(null) }
    LaunchedEffect(t?.id, t?.art) {
        tint = withContext(Dispatchers.IO) { MusicArt.tint(MusicArt.bitmap(c, t, 64))?.let { Color(it) } }
    }
    val base = MaterialTheme.colorScheme.background
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf((tint ?: MaterialTheme.colorScheme.primary).copy(alpha = 0.55f), base, base)))
            .statusBarsPadding().padding(horizontal = 22.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Close", Modifier.size(30.dp)) }
            Text(t?.album?.ifBlank { "Now playing" } ?: "Now playing", style = MaterialTheme.typography.labelMedium,
                textAlign = TextAlign.Center, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (t != null) IconButton(onClick = { onEdit(t) }) { Icon(Icons.Filled.MoreVert, "Edit and more") }
        }
        if (t == null) { Text("Nothing playing", Modifier.padding(24.dp)); return@Column }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            when (pane) {
                "Lyrics" -> LyricsPane(t)
                "Queue" -> QueuePane()
                else -> TrackArt(t, Modifier.fillMaxWidth().aspectRatio(1f), 16)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 16.dp)) {
            Column(Modifier.weight(1f)) {
                Text(t.title, style = MaterialTheme.typography.headlineSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            var liked by remember(t.id) { mutableStateOf(t.id in MusicLibrary.liked(c)) }
            IconButton(onClick = { MusicLibrary.toggleLike(c, t.id); liked = !liked }) {
                Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like",
                    tint = if (liked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        var dragging by remember { mutableStateOf(false) }
        var dragTo by remember { mutableFloatStateOf(0f) }
        val d = MusicPlayback.durationMs.coerceAtLeast(1)
        Slider(value = if (dragging) dragTo else (MusicPlayback.positionMs.toFloat() / d).coerceIn(0f, 1f),
            onValueChange = { dragging = true; dragTo = it },
            onValueChangeFinished = { MusicPlayback.seek((dragTo * d).toLong()); dragging = false },
            colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.onSurface, activeTrackColor = MaterialTheme.colorScheme.onSurface,
                inactiveTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)))
        Row {
            Text(time(if (dragging) (dragTo * d).toLong() else MusicPlayback.positionMs), style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
            Text(time(MusicPlayback.durationMs), style = MaterialTheme.typography.labelSmall)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { MusicPlayback.setShuffle(!MusicPlayback.shuffle) }) {
                Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (MusicPlayback.shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { MusicPlayback.previous() }, modifier = Modifier.size(56.dp)) { Icon(Icons.Filled.SkipPrevious, "Previous", Modifier.size(36.dp)) }
            Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface).clickable(role = Role.Button) { MusicPlayback.toggle() },
                contentAlignment = Alignment.Center) {
                Icon(if (MusicPlayback.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play or pause", Modifier.size(38.dp),
                    tint = MaterialTheme.colorScheme.background)
            }
            IconButton(onClick = { MusicPlayback.next() }, modifier = Modifier.size(56.dp)) { Icon(Icons.Filled.SkipNext, "Next", Modifier.size(36.dp)) }
            IconButton(onClick = { MusicPlayback.cycleRepeat() }) {
                Icon(if (MusicPlayback.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Repeat",
                    tint = if (MusicPlayback.repeat != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        ChipRow(listOf("Art", "Lyrics", "Queue"), pane, { pane = it }, modifier = Modifier.padding(bottom = 18.dp))
    }
}

@Composable
private fun LyricsPane(t: Track) {
    val c = LocalContext.current
    val scope = rememberWorkScope()
    var text by remember(t.id) { mutableStateOf(MusicLibrary.lyrics(c, t.id)) }
    var busy by remember(t.id) { mutableStateOf(false) }
    var editing by remember(t.id) { mutableStateOf(false) }
    LaunchedEffect(t.id) {
        if (text.isBlank()) { busy = true; Lyrics.fetch(t)?.let { text = it; MusicLibrary.setLyrics(c, t.id, it) }; busy = false }
    }
    if (editing) {
        Column(Modifier.fillMaxSize()) {
            OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f).fillMaxWidth(), placeholder = { Text("Paste or write lyrics — [mm:ss] timestamps make them follow the song") })
            Button(onClick = { MusicLibrary.setLyrics(c, t.id, text); editing = false }) { Text("Save lyrics") }
        }
        return
    }
    val lines = remember(text) { Lyrics.parse(text) }
    when {
        busy -> Thinking(label = "Finding lyrics")
        text.isBlank() -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("No lyrics found for this song.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
                OutlinedButton(onClick = { scope.launch { busy = true; Lyrics.fetch(t)?.let { text = it; MusicLibrary.setLyrics(c, t.id, it) }; busy = false } }) { Text("Try again") }
                OutlinedButton(onClick = { editing = true }) { Text("Add them") }
            }
        }
        lines.isNotEmpty() -> {
            // time-synced: the current line glows and stays centred
            val pos = MusicPlayback.positionMs
            val at = lines.indexOfLast { it.ms <= pos + 250 }.coerceAtLeast(0)
            val state = rememberLazyListState()
            LaunchedEffect(at) { state.animateScrollToItem((at - 3).coerceAtLeast(0)) }
            LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
                itemsIndexed(lines) { i, l ->
                    Text(l.text.ifBlank { "♪" }, fontSize = 24.sp, lineHeight = 32.sp,
                        fontWeight = if (i == at) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (i == at) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f),
                        modifier = Modifier.fillMaxWidth().clickable { MusicPlayback.seek(l.ms) }.padding(vertical = 6.dp))
                }
                item { Text("Edit lyrics", color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { editing = true }.padding(vertical = 16.dp)) }
            }
        }
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Text(text, style = MaterialTheme.typography.bodyLarge.copy(fontSize = 20.sp, lineHeight = 30.sp))
            Text("Edit lyrics", color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { editing = true }.padding(vertical = 16.dp))
        }
    }
}

@Composable
private fun QueuePane() {
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(MusicPlayback.queue) { i, t ->
            Row(Modifier.fillMaxWidth().clickable { MusicPlayback.jump(i) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                TrackArt(t, Modifier.size(40.dp), 6)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium,
                        color = if (i == MusicPlayback.index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    Text(t.artist, maxLines = 1, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (i != MusicPlayback.index) Text("Remove", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.clickable { MusicPlayback.removeAt(i) }.padding(8.dp))
            }
        }
    }
}

// ── Track sheet: actions, tag editor, cover, auto-fill ──────────────────────────────────────────

@Composable
private fun TrackSheet(t: Track, onClose: () -> Unit, onChanged: () -> Unit) {
    val c = LocalContext.current
    val scope = rememberWorkScope()
    var title by remember { mutableStateOf(t.title) }
    var artist by remember { mutableStateOf(t.artist) }
    var album by remember { mutableStateOf(t.album) }
    var year by remember { mutableStateOf(t.year) }
    var genre by remember { mutableStateOf(t.genre) }
    var trackNo by remember { mutableStateOf(if (t.trackNo > 0) t.trackNo.toString() else "") }
    var art by remember { mutableStateOf(t.art) }
    var matches by remember { mutableStateOf<List<MetaMatch>?>(null) }
    var menu by remember { mutableStateOf(false) }
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val bytes = withContext(Dispatchers.IO) { c.contentResolver.openInputStream(uri)?.use { it.readBytes() } } ?: return@launch
            art = MusicArt.saveArt(c, t.id, bytes)
        }
    }
    val edited = t.copy(title = title.trim(), artist = artist.trim(), album = album.trim(), year = year.trim(), genre = genre.trim(),
        trackNo = trackNo.toIntOrNull() ?: 0, art = art)
    BackHandler { onClose() }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).clickable(onClick = onClose), contentAlignment = Alignment.BottomCenter) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(MaterialTheme.colorScheme.background)
            .clickable(enabled = false) {}.verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clickable(role = Role.Button) { pickCover.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    TrackArt(edited, Modifier.size(72.dp), 10)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text("Tap the art to change it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Actions") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Play next") }, { MusicPlayback.enqueue(c, t, true); menu = false; Feedback.show("Plays next") })
                        DropdownMenuItem({ Text("Add to queue") }, { MusicPlayback.enqueue(c, t, false); menu = false; Feedback.show("Added to queue") })
                        MusicLibrary.playlists(c).forEach { p ->
                            DropdownMenuItem({ Text("Add to ${p.name}") }, { MusicLibrary.addToPlaylist(c, p.id, t.id); menu = false; Feedback.show("Added to ${p.name}") })
                        }
                        DropdownMenuItem({ Text(if (t.id in MusicLibrary.liked(c)) "Unlike" else "Like") }, { MusicLibrary.toggleLike(c, t.id); menu = false })
                        if (t.uri.startsWith("http")) DropdownMenuItem({ Text("Download") }, { MusicSources.download(c, t); menu = false })
                        MusicSources.STREAMING.take(2).forEach { (name, pattern) ->
                            DropdownMenuItem({ Text("Open in $name") }, {
                                runCatching { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(pattern.format(Uri.encode("${t.artist} ${t.title}")))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                menu = false })
                        }
                        if (t.source != "device") DropdownMenuItem({ Text("Delete from Atlas", color = MaterialTheme.colorScheme.error) },
                            { MusicLibrary.deleteOwn(c, t); menu = false; onChanged(); onClose() })
                    }
                }
            }
            Label("Tags")
            OutlinedTextField(title, { title = it }, singleLine = true, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(artist, { artist = it }, singleLine = true, label = { Text("Artist") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(album, { album = it }, singleLine = true, label = { Text("Album") }, modifier = Modifier.fillMaxWidth())
            Row {
                OutlinedTextField(year, { year = it.filter(Char::isDigit).take(4) }, singleLine = true, label = { Text("Year") }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(trackNo, { trackNo = it.filter(Char::isDigit).take(3) }, singleLine = true, label = { Text("Track") }, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(genre, { genre = it }, singleLine = true, label = { Text("Genre") }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    scope.launch {
                        MusicLibrary.edit(c, edited)
                        MusicPlayback.refreshTrack(edited)
                        // Atlas's own MP3s get the tags written into the file too
                        val path = Uri.parse(edited.uri).path
                        if (edited.source != "device" && path != null && path.endsWith(".mp3", true)) runCatching {
                            val cover = withContext(Dispatchers.IO) { runCatching {
                                if (art.startsWith("http")) java.net.URL(art).readBytes() else if (art.isNotBlank()) c.contentResolver.openInputStream(Uri.parse(art))?.use { it.readBytes() } else null
                            }.getOrNull() }
                            withContext(Dispatchers.IO) { Id3.write(java.io.File(path), edited, cover) }
                        }
                        Feedback.show("Saved"); onChanged(); onClose()
                    }
                }) { Text("Save") }
                OutlinedButton(onClick = {
                    matches = null
                    scope.launch { matches = runCatching { MusicMeta.search("$artist $title".trim()) }.getOrElse { emptyList() } }
                }) { Text("Auto-fill") }
            }
            matches?.let { list ->
                Label("Matches — tap one to use its tags and cover")
                if (list.isEmpty()) Text("No matches. Try editing the title or artist first.", style = MaterialTheme.typography.bodySmall)
                list.forEach { m ->
                    Row(Modifier.fillMaxWidth().clickable(role = Role.Button) {
                        title = m.title; artist = m.artist; album = m.album; art = m.cover
                        scope.launch { MusicMeta.year(m.artist, m.album).takeIf { it.isNotBlank() }?.let { year = it } }
                        matches = null
                    }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(m.cover, m.album, Modifier.size(44.dp).clip(RoundedCornerShape(6.dp)))
                        Spacer(Modifier.width(10.dp))
                        Column { Text(m.title, style = MaterialTheme.typography.bodyMedium); Text("${m.artist} · ${m.album}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
                Text("Metadata and covers from Deezer's public catalogue.", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (t.source == "device") Text("Edits to your phone's own files are kept in Atlas; files Atlas downloaded or imported get the tags written in.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp))
            HorizontalDivider(Modifier.padding(top = 12.dp), color = Color.Transparent)
        }
    }
}
