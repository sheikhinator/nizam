package com.nizam.app.ui.screens.modules

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Text
import kotlinx.coroutines.launch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.runtime.LaunchedEffect
import com.nizam.app.ui.design.pressable
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.feature.dynamic.parseColour
import com.nizam.app.ui.nav.Routes
import com.nizam.app.ui.theme.DisplayFamily
import com.nizam.app.ui.theme.Spine

private data class Tile(
    val emoji: String,
    val name: String,
    val route: String,
    val colour: Color,
    val group: String,
    val dynamicKey: String? = null      // set for modules you (or the Curator) created
)

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ModulesScreen(container: AppContainer, onOpen: (String) -> Unit) {
    val specs by container.dynamicRepository.specs().collectAsState(initial = emptyList())
    var filter by remember { mutableStateOf("All") }

    val core = listOf(

        Tile("⚖️", "Council", Routes.COUNCIL, Spine.Diary, "Daily"),

        Tile("✅", "Tasks", Routes.TASKS, Spine.Tasks, "Daily"),
        Tile("🕌", "Prayer", Routes.PRAYER, Spine.Prayer, "Faith"),
        Tile("🤲", "Deen", Routes.DEEN, Spine.Prayer, "Faith"),
        Tile("📖", "Quran", Routes.QURAN, Spine.Scripture, "Faith"),
        Tile("📜", "Hadith", Routes.HADITH, Spine.Scripture, "Faith"),

        Tile("💰", "Finance", Routes.FINANCE, Spine.Finance, "Money"),
        Tile("🥗", "Diet", Routes.DIET, Spine.Diet, "Body"),
        Tile("🏋️", "Gym", Routes.GYM, Spine.Gym, "Body"),

        Tile("🎓", "Courses", Routes.COURSES, Spine.Learning, "Mind"),
        Tile("🧠", "Learning", Routes.LEARNING, Spine.Learning, "Mind"),
        Tile("🗒️", "Notes", Routes.NOTES, Spine.Notes, "Mind"),
        Tile("📚", "Library", Routes.LIBRARY, Spine.Library, "Mind"),
        Tile("✍️", "Diary", Routes.DIARY, Spine.Diary, "Mind"),
        Tile("💬", "Quotes", Routes.QUOTES, Spine.Diary, "Mind"),
        Tile("🎥", "Rep counter", Routes.REPS, Spine.Gym, "Body"),
        Tile("📸", "Snap plate", Routes.PLATE, Spine.Diet, "Body"),
        Tile("🎧", "Voice coach", Routes.COACH, Spine.Gym, "Body"),
        Tile("🗣", "Language", Routes.LANGUAGE, Spine.Learning, "Mind"),
        Tile("🌤", "Daily life", Routes.DAILY, Spine.Diet, "Daily"),
        Tile("🏘", "Pixel Town", Routes.TOWN, Spine.Gym, "Tools"),
        Tile("🔒", "Vault", Routes.VAULT, Spine.Gym, "Tools"),
        Tile("🛠", "Tools", Routes.TOOLS, Spine.Gym, "Tools"),
        Tile("🏦", "Auto-logging", Routes.AUTOMONEY, Spine.Gym, "Money"),
        Tile("📷", "Scanner", Routes.SCAN, Spine.Gym, "Tools"),
        Tile("🧰", "Toolkit", Routes.TOOLKIT, Spine.Gym, "Tools"),
        Tile("🌐", "Browser", Routes.BROWSER, Spine.Notes, "Tools"),
        Tile("📰", "News", Routes.NEWS, Spine.Finance, "Tools"),
        Tile("⛑️", "Survival", Routes.SURVIVAL, Spine.Survival, "Tools")
    )

    val dynamic = specs.map {
        Tile(it.emoji, it.name, Routes.dynamic(it.key), parseColour(it.colorHex, Spine.Notes), "Tracked", it.key)
    }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val hidden by container.settingsRepository.hiddenTiles.collectAsState(initial = emptySet())
    val savedOrder by container.settingsRepository.tileOrder.collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<Tile?>(null) }

    // Your order first, then anything new appended — so a freshly created module never vanishes
    val all = (core + dynamic).let { tiles ->
        val byRoute = tiles.associateBy { it.route }
        val areas = listOf("Daily", "Body", "Mind", "Money", "Faith", "Tracked", "Tools")
        val natural = tiles.sortedBy { areas.indexOf(it.group).let { i -> if (i < 0) 99 else i } }
        savedOrder.mapNotNull { byRoute[it] } + natural.filterNot { it.route in savedOrder }
    }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var focusOn by remember { mutableStateOf(com.nizam.app.feature.wellbeing.FocusPillars.on(ctx)) }
    var pillars by remember { mutableStateOf(com.nizam.app.feature.wellbeing.FocusPillars.chosen(ctx)) }
    var pickPillars by remember { mutableStateOf(false) }
    // Focus Mode: fewer things on screen, by design — research says people keep apps that stay simple
    val visible = (if (editing) all else all.filterNot { it.route in hidden })
        .filter { editing || !focusOn || it.group in pillars }

    fun move(tile: Tile, delta: Int) {
        val order = all.map { it.route }.toMutableList()
        val i = order.indexOf(tile.route)
        val j = (i + delta).coerceIn(0, order.lastIndex)
        if (i == j) return
        order.removeAt(i); order.add(j, tile.route)
        scope.launch { container.settingsRepository.setTileOrder(order) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Life", style = MaterialTheme.typography.displaySmall, modifier = Modifier.weight(1f))
            Text(
                if (editing) "Done" else "Edit",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable(role = androidx.compose.ui.semantics.Role.Button) { editing = !editing }
                    .padding(8.dp)
            )
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            com.nizam.app.ui.design.Capsule(if (focusOn) "Focus · ${pillars.size} areas" else "Focus mode", focusOn) {
                focusOn = !focusOn; com.nizam.app.feature.wellbeing.FocusPillars.save(ctx, focusOn, pillars); if (focusOn) pickPillars = true
            }
            if (focusOn) Text("  change", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.clickable { pickPillars = !pickPillars })
        }
        if (pickPillars && focusOn) {
            Text("Show only what you're working on right now:", style = MaterialTheme.typography.labelMedium)
            com.nizam.app.core.MultiChipRow(com.nizam.app.feature.wellbeing.FocusPillars.ALL, pillars, { g ->
                pillars = if (g in pillars) pillars - g else pillars + g
                com.nizam.app.feature.wellbeing.FocusPillars.save(ctx, focusOn, pillars)
            })
        }
        if (editing) {
            Text(
                "‹ › move a module. Hide tucks it away (nothing is lost); delete removes only modules you created.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        confirmDelete?.let { tile ->
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Delete ${tile.name} and every entry in it?", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(top = 8.dp)) {
                        Text("Delete", color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.clickable {
                                scope.launch {
                                    container.dynamicRepository.spec(tile.dynamicKey ?: "")
                                        ?.let { container.dynamicRepository.deleteModule(it) }
                                    confirmDelete = null
                                }
                            })
                        Text("Keep it", modifier = Modifier.clickable { confirmDelete = null })
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        val areas = listOf("Daily", "Body", "Mind", "Money", "Faith", "Tracked", "Tools")
            .filter { a -> visible.any { it.group == a } }
        if (areas.isNotEmpty()) {
            val pager = androidx.compose.foundation.pager.rememberPagerState { areas.size }
            val swipe = androidx.compose.runtime.rememberCoroutineScope()
            // a category strip that follows your swipe, and swipes when you tap it
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(areas) { area ->
                    val i = areas.indexOf(area)
                    com.nizam.app.ui.design.Capsule(area, pager.currentPage == i) { swipe.launch { pager.animateScrollToPage(i) } }
                }
            }
            Spacer(Modifier.height(10.dp))
            androidx.compose.foundation.pager.HorizontalPager(
                pager, Modifier.fillMaxSize(), pageSpacing = 16.dp,
                verticalAlignment = androidx.compose.ui.Alignment.Top      // pages were centring, leaving a huge gap
            ) { page ->
                val tiles = visible.filter { it.group == areas[page] }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 10.dp, bottom = 110.dp)
                ) {
            itemsIndexed(tiles) { index, tile ->
                // iOS home-screen feel: icons arrive in a quick cascade, press down with a spring, and wiggle while editing
                val appear = remember { androidx.compose.animation.core.Animatable(0f) }
                LaunchedEffect(tile.route) { kotlinx.coroutines.delay(index * 28L); appear.animateTo(1f, androidx.compose.animation.core.spring(0.62f, 380f)) }
                val angle = if (editing) androidx.compose.animation.core.rememberInfiniteTransition(label = "wiggle").animateFloat(-2.2f, 2.2f,
                    androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(130 + (index % 3) * 20),
                        androidx.compose.animation.core.RepeatMode.Reverse), label = "a").value else 0f
                Column(
                    Modifier.fillMaxWidth()
                        .graphicsLayer { alpha = appear.value; scaleX = 0.6f + 0.4f * appear.value; scaleY = scaleX; translationY = (1f - appear.value) * 40f
                            rotationZ = if (editing) angle else 0f }
                        .alpha(if (editing && tile.route in hidden) 0.4f else 1f)
                        .pressable { if (!editing) onOpen(tile.route) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    com.nizam.app.ui.components.AppIcon(tile.emoji, tile.colour, 60.dp)
                    Text(
                        tile.name,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(top = 7.dp)
                    )
                    if (editing) Row(horizontalArrangement = Arrangement.Center) {
                        Text("‹", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { move(tile, -1) }.padding(horizontal = 5.dp))
                        Text(if (tile.route in hidden) "show" else "hide",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable {
                                scope.launch {
                                    container.settingsRepository.setHiddenTiles(
                                        if (tile.route in hidden) hidden - tile.route else hidden + tile.route)
                                }
                            }.padding(4.dp))
                        Text("›", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { move(tile, 1) }.padding(horizontal = 5.dp))
                    }
                    if (editing && tile.dynamicKey != null) Text("delete",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.clickable { confirmDelete = tile }.padding(2.dp))
                }
            }
                }
            }
        }

    }
}
