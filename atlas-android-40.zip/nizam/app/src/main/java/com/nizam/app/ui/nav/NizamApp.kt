package com.nizam.app.ui.nav

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.outlined.Today as OutlinedToday
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.outlined.AutoAwesome as OutlinedAutoAwesome
import androidx.compose.material.icons.outlined.Person as OutlinedPerson
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nizam.app.AppContainer
import com.nizam.app.feature.agent.CuratorScreen
import com.nizam.app.feature.browser.BrowserScreen
import com.nizam.app.feature.council.CouncilScreen
import com.nizam.app.feature.profile.ProfileScreen
import com.nizam.app.feature.town.TownScreen
import com.nizam.app.ui.screens.me.MeScreen
import com.nizam.app.ui.screens.apps.AppsScreen
import com.nizam.app.ui.screens.hub.AtlasHub
import com.nizam.app.feature.finale.FinaleScreen
import com.nizam.app.feature.bots.BotNav
import com.nizam.app.feature.bots.BotThreadScreen
import com.nizam.app.feature.bots.BotsScreen
import com.nizam.app.ui.screens.hub.GrowHub
import com.nizam.app.ui.screens.hub.StoryHub
import com.nizam.app.ui.screens.hub.UnderstandHub
import com.nizam.app.ui.screens.hub.WellbeingHub
import com.nizam.app.feature.podcasts.PodcastNav
import com.nizam.app.feature.podcasts.PodcastShowScreen
import com.nizam.app.feature.podcasts.PodcastsScreen
import com.nizam.app.feature.podcasts.PodcastPlayerScreen
import com.nizam.app.feature.iptv.IptvScreen
import com.nizam.app.feature.iptv.IptvPlayerScreen
import com.nizam.app.feature.insight.UnderstandScreen
import com.nizam.app.feature.brain.BrainScreen
import com.nizam.app.feature.brain.DayScreen
import com.nizam.app.feature.shield.ShieldScreen
import com.nizam.app.feature.planner.PlannerScreen
import com.nizam.app.feature.language.LanguageScreen
import com.nizam.app.feature.scan.ScanScreen
import com.nizam.app.feature.growth.GrowthScreen
import com.nizam.app.feature.presence.DrivingScreen
import com.nizam.app.feature.attention.AttentionScreen
import com.nizam.app.feature.cinema.CinemaNav
import com.nizam.app.feature.mind.MindScreen
import com.nizam.app.feature.daily.DailyScreen
import com.nizam.app.feature.platform.PlatformScreen
import com.nizam.app.feature.wellbeing.CalmScreen
import com.nizam.app.feature.body.BedsideScreen
import com.nizam.app.feature.commit.CommitScreen
import com.nizam.app.feature.work.MeetingScreen
import com.nizam.app.feature.lab.LabScreen
import com.nizam.app.feature.lab.MirrorScreen
import com.nizam.app.feature.presence.PresenceScreen
import com.nizam.app.feature.final.StudioScreen
import com.nizam.app.feature.final.RulesScreen
import com.nizam.app.feature.agent.WorkforceScreen
import com.nizam.app.feature.mcp.PlaygroundScreen
import com.nizam.app.feature.money.AutoMoneyScreen
import com.nizam.app.feature.agent.SchedulesScreen
import com.nizam.app.feature.reflect.ReflectScreen
import com.nizam.app.feature.world.NightCompanionScreen
import com.nizam.app.feature.world.PeopleScreen
import com.nizam.app.feature.body.FlipFocusScreen
import com.nizam.app.feature.body.RepCounterScreen
import com.nizam.app.feature.body.SmartWakeScreen
import com.nizam.app.feature.body.SnapPlateScreen
import com.nizam.app.feature.body.VoiceCoachScreen
import com.nizam.app.feature.wellbeing.FutureYouScreen
import com.nizam.app.feature.wellbeing.PauseSettingsScreen
import com.nizam.app.feature.wellbeing.ReframeScreen
import com.nizam.app.feature.memory.MemoryScreen
import com.nizam.app.feature.cinema.MediaCenterScreen
import com.nizam.app.feature.cinema.MetaScreen
import com.nizam.app.feature.cinema.FilmScreen
import com.nizam.app.feature.cinema.PlayerScreen
import com.nizam.app.feature.presence.RehearsalScreen
import com.nizam.app.feature.presence.VoiceHubScreen
import com.nizam.app.feature.presence.VoiceJournalScreen
import com.nizam.app.feature.phone.PhoneControlScreen
import com.nizam.app.feature.diary.DiaryScreen
import com.nizam.app.feature.diet.DietScreen
import com.nizam.app.feature.finance.FinanceScreen
import com.nizam.app.feature.gym.GymScreen
import com.nizam.app.feature.hadith.HadithScreen
import com.nizam.app.feature.learning.LearningScreen
import com.nizam.app.feature.library.LibraryScreen
import com.nizam.app.feature.learning.CoursesScreen
import com.nizam.app.feature.missions.MissionsScreen
import com.nizam.app.feature.news.NewsScreen
import com.nizam.app.feature.dynamic.DynamicModuleScreen
import com.nizam.app.feature.dynamic.ModuleSettingsScreen
import com.nizam.app.feature.self.SelfScreen
import com.nizam.app.feature.toolkit.ToolkitScreen
import com.nizam.app.feature.vault.VaultScreen
import com.nizam.app.feature.progress.InsightsScreen
import com.nizam.app.feature.notes.NotesScreen
import com.nizam.app.feature.prayer.PrayerScreen
import com.nizam.app.feature.quotes.QuotesScreen
import com.nizam.app.feature.quran.QuranScreen
import com.nizam.app.feature.survival.SurvivalScreen
import com.nizam.app.ui.screens.modules.ModulesScreen
import com.nizam.app.ui.screens.search.SearchScreen
import com.nizam.app.ui.screens.settings.SettingsScreen
import com.nizam.app.ui.screens.tasks.TasksScreen
import com.nizam.app.ui.screens.today.TodayScreen

object Routes {
    const val TODAY = "today"
    const val MODULES = "modules"
    const val SEARCH = "search"
    const val SETTINGS = "settings"
    const val TASKS = "tasks"
    const val PRAYER = "prayer"
    const val FINANCE = "finance"
    const val DIET = "diet"
    const val GYM = "gym"
    const val NOTES = "notes"
    const val LIBRARY = "library"
    const val DIARY = "diary"
    const val QURAN = "quran"
    const val HADITH = "hadith"
    const val LEARNING = "learning"
    const val SURVIVAL = "survival"
    const val QUOTES = "quotes"
    const val COURSES = "courses"
    const val ASSISTANT = "assistant"
    const val BROWSER = "browser"
    const val PHONE = "phone"
    const val COUNCIL = "council"
    const val PROFILE = "profile"
    const val TOWN = "town"
    const val ME = "me"
    const val APPS = "apps"
    const val PODCASTS = "podcasts"
    const val PODCAST_SHOW = "podcastshow"
    const val PODCAST_PLAYER = "podcastplayer"
    const val IPTV = "iptv"
    const val IPTV_PLAYER = "iptvplayer"
    const val UNDERSTAND = "understand"
    const val BRAIN = "brain"
    const val DAY = "day"
    const val SHIELD = "shield"
    const val PLAN = "plan"
    const val LANGUAGE = "language"
    const val SCAN = "scan"
    const val GROWTH = "growth"
    const val VOICE = "voice"
    const val DRIVE = "drive"
    const val VOICE_JOURNAL = "voicejournal"
    const val REHEARSE = "rehearse"
    const val ATTENTION = "attention"
    const val CINEMA = "cinema"
    const val FILM = "film"
    const val PLAYER = "player"
    const val META = "meta"
    const val MIND = "mind"
    const val MEMORY = "memory"
    const val DAILY = "daily"
    const val TOOLS = "tools"
    const val PAUSE = "pause"
    const val CALM = "calm"
    const val FUTURE = "future"
    const val REFRAME = "reframe"
    const val REPS = "reps"
    const val PLATE = "plate"
    const val COACH = "coach"
    const val FLIP = "flip"
    const val BEDSIDE = "bedside"
    const val WAKE = "smartwake"
    const val COMMIT = "commit"
    const val MEETING = "meeting"
    const val AUTOMONEY = "automoney"
    const val SCHEDULES = "schedules"
    const val LAB = "lab"
    const val PLAYGROUND = "playground"
    const val MIRROR = "mirror"
    const val PRESENCE = "presence"
    const val STUDIO = "studio"
    const val RULES = "rules"
    const val WORKFORCE = "workforce"
    const val JARVIS = "jarvis"
    const val BARAKAH = "barakah"
    const val LIFESIM = "lifesim"
    const val COURT = "court"
    const val CALLCOACH = "callcoach"
    const val RECEIPTS = "receipts"
    const val DEEN = "deen"
    const val MODELS = "models"
    const val ATLAS_HUB = "atlashub"
    const val UNDERSTAND_HUB = "understandhub"
    const val STORY_HUB = "storyhub"
    const val GROW_HUB = "growhub"
    const val WELLBEING_HUB = "wellbeinghub"
    const val YOU = "you"
    const val BOTS = "bots"
    const val BOT_THREAD = "botthread"
    const val REFLECT = "reflect"
    const val PEOPLE = "people"
    const val NIGHT = "night"
    const val NEWS = "news"
    const val INSIGHTS = "insights"
    const val MISSIONS = "missions"
    const val SELF = "self"
    const val AGENT = "agent"
    const val VAULT = "vault"
    const val TOOLKIT = "toolkit"
    const val DYNAMIC = "module/{key}"
    const val MODULE_SETTINGS = "module-settings/{key}"
    fun moduleSettings(key: String) = "module-settings/$key"
    fun dynamic(key: String) = "module/$key"
}

private data class BottomItem(val route: String, val label: String, val icon: ImageVector, val idle: ImageVector)

// Outlined when idle, filled when chosen — the only signal the tab bar needs.
private val bottomItems = listOf(
    BottomItem(Routes.TODAY, "Today", Icons.Filled.Today, Icons.Outlined.OutlinedToday),
    BottomItem(Routes.MODULES, "Life", Icons.Filled.GridView, Icons.Outlined.OutlinedGridView),
    BottomItem(Routes.ATLAS_HUB, "Atlas", Icons.Filled.AutoAwesome, Icons.Outlined.OutlinedAutoAwesome),
    BottomItem(Routes.ME, "Me", Icons.Filled.Person, Icons.Outlined.OutlinedPerson)
)

@Composable
fun NizamApp(container: AppContainer, startOnCurator: Boolean = false) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val tabRoutes = bottomItems.map { it.route }.toSet()
    val onSubScreen = currentRoute != null && currentRoute !in tabRoutes

    val snackbarHost = remember { androidx.compose.material3.SnackbarHostState() }
    val feedbackScope = rememberCoroutineScope()
    androidx.compose.runtime.LaunchedEffect(Unit) { com.nizam.app.ui.components.Feedback.attach(snackbarHost, feedbackScope) }
    Scaffold(
        snackbarHost = { androidx.compose.material3.SnackbarHost(snackbarHost) },
        topBar = {
            if (onSubScreen && currentRoute != Routes.PLAYER && currentRoute != Routes.BEDSIDE && currentRoute != Routes.IPTV_PLAYER) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 4.dp, end = 12.dp, top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "Back", modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = {
                        navController.navigate(Routes.TODAY) {
                            popUpTo(Routes.TODAY) { inclusive = false }
                            launchSingleTop = true
                        }
                    }) {
                        Icon(Icons.Outlined.OutlinedToday, contentDescription = "Back to today",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        bottomBar = {
            if (currentRoute != Routes.PLAYER && currentRoute != Routes.BEDSIDE && currentRoute != Routes.IPTV_PLAYER) {
            Column {
            androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 0.5.dp)
            NavigationBar(containerColor = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
                bottomItems.forEach { item ->
                    val chosen = currentRoute == item.route
                    NavigationBarItem(
                        colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onSurface,
                            selectedTextColor = MaterialTheme.colorScheme.onSurface,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = androidx.compose.ui.graphics.Color.Transparent
                        ),
                        selected = chosen,
                        onClick = {
                            if (currentRoute != item.route) {
                                navController.navigate(item.route) {
                                    popUpTo(Routes.TODAY) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(if (chosen) item.icon else item.idle, contentDescription = item.label) },
                        label = { Text(item.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            }
        }
        }
    ) { innerPadding ->
        val ease = androidx.compose.animation.core.CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)
        fun isTab(r: String?) = r in tabRoutes
        NavHost(
            // Between tabs: a soft cross-fade. Into a screen: a short glide with a fade. Nothing bouncy.
            enterTransition = {
                if (isTab(initialState.destination.route) && isTab(targetState.destination.route))
                    androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220))
                else androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(320, easing = ease)) { it / 8 } +
                    androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260))
            },
            exitTransition = { androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)) },
            popEnterTransition = { androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220)) },
            popExitTransition = {
                androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(280, easing = ease)) { it / 8 } +
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(220))
            },
            navController = navController,
            startDestination = if (startOnCurator) Routes.ASSISTANT else Routes.TODAY,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.TODAY) {
                TodayScreen(container = container, onOpen = { navController.navigate(it) })
            }
            composable(Routes.MODULES) {
                ModulesScreen(container = container, onOpen = { navController.navigate(it) })
            }
            composable(Routes.SEARCH) { SearchScreen(container) }
            composable(Routes.SETTINGS) { SettingsScreen(container) { navController.navigate(it) } }
            composable(Routes.TASKS) { TasksScreen(container) }
            composable(Routes.PRAYER) { PrayerScreen(container) }
            composable(Routes.FINANCE) { FinanceScreen(container) }
            composable(Routes.DIET) { DietScreen(container) }
            composable(Routes.GYM) { GymScreen(container) }
            composable(Routes.NOTES) { NotesScreen(container) }
            composable(Routes.LIBRARY) { LibraryScreen(container) }
            composable(Routes.DIARY) { DiaryScreen(container) }
            composable(Routes.QURAN) { QuranScreen(container) }
            composable(Routes.HADITH) { HadithScreen(container) }
            composable(Routes.LEARNING) { LearningScreen(container) }
            composable(Routes.SURVIVAL) { SurvivalScreen(container) }
            composable(Routes.QUOTES) { QuotesScreen(container) }
            composable(Routes.COURSES) { CoursesScreen(container) }
            composable(Routes.ASSISTANT) { CuratorScreen(container) }
            composable(Routes.BROWSER) { BrowserScreen(container) }
            composable(Routes.PHONE) { PhoneControlScreen(container) }
            composable(Routes.COUNCIL) { CouncilScreen(container) }
            composable(Routes.PROFILE) { ProfileScreen(container) }
            composable(Routes.TOWN) { TownScreen(container) }
            composable(Routes.UNDERSTAND) { UnderstandScreen(container) }
            composable(Routes.BRAIN) { BrainScreen(container) }
            composable(Routes.DAY) { DayScreen(container) }
            composable(Routes.SHIELD) { ShieldScreen() }
            composable(Routes.PLAN) { PlannerScreen(container) }
            composable(Routes.LANGUAGE) { LanguageScreen(container) }
            composable(Routes.SCAN) { ScanScreen(container) }
            composable(Routes.GROWTH) { GrowthScreen(container) }
            composable(Routes.VOICE) { VoiceHubScreen(container) { navController.navigate(it) } }
            composable(Routes.DRIVE) { DrivingScreen(container) }
            composable(Routes.VOICE_JOURNAL) { VoiceJournalScreen(container) }
            composable(Routes.REHEARSE) { RehearsalScreen(container) }
            composable(Routes.ATTENTION) { AttentionScreen(container) }
            composable(Routes.CINEMA) {
                MediaCenterScreen(
                    onMeta = { type, id -> CinemaNav.metaType = type; CinemaNav.metaId = id; navController.navigate(Routes.META) },
                    onPlay = { navController.navigate(Routes.PLAYER) },
                    onTmdbFilm = { CinemaNav.filmId = it; navController.navigate(Routes.FILM) }
                )
            }
            composable(Routes.META) { MetaScreen(onPlay = { navController.navigate(Routes.PLAYER) }) }
            composable(Routes.FILM) {
                FilmScreen(
                    onFilm = { CinemaNav.filmId = it; navController.navigate(Routes.FILM) },
                    onPlay = { navController.navigate(Routes.PLAYER) }
                )
            }
            composable(Routes.PLAYER) { PlayerScreen() }
            composable(Routes.MIND) { MindScreen(container) }
            composable(Routes.MEMORY) { MemoryScreen(container) }
            composable(Routes.DAILY) { DailyScreen(container) }
            composable(Routes.TOOLS) { PlatformScreen(container) }
            composable(Routes.PAUSE) { PauseSettingsScreen() }
            composable(Routes.CALM) { CalmScreen() }
            composable(Routes.FUTURE) { FutureYouScreen(container) }
            composable(Routes.REFRAME) { ReframeScreen(container) }
            composable(Routes.REPS) { RepCounterScreen(container) }
            composable(Routes.PLATE) { SnapPlateScreen(container) }
            composable(Routes.COACH) { VoiceCoachScreen(container) }
            composable(Routes.FLIP) { FlipFocusScreen() }
            composable(Routes.BEDSIDE) { BedsideScreen(container) { navController.popBackStack() } }
            composable(Routes.WAKE) { SmartWakeScreen() }
            composable(Routes.COMMIT) { CommitScreen(container) }
            composable(Routes.MEETING) { MeetingScreen(container) }
            composable(Routes.AUTOMONEY) { AutoMoneyScreen(container) }
            composable(Routes.SCHEDULES) { SchedulesScreen() }
            composable(Routes.LAB) { LabScreen(container) }
            composable(Routes.MIRROR) { MirrorScreen(container) }
            composable(Routes.PRESENCE) { PresenceScreen(container) }
            composable(Routes.STUDIO) { StudioScreen(container) }
            composable(Routes.RULES) { RulesScreen(container) }
            composable(Routes.WORKFORCE) { WorkforceScreen(container) }
            composable(Routes.JARVIS) { com.nizam.app.feature.jarvis.JarvisScreen(container) }
            composable(Routes.BARAKAH) { com.nizam.app.feature.jarvis.BarakahScreen(container) }
            composable(Routes.LIFESIM) { com.nizam.app.feature.jarvis.LifeSimScreen(container) }
            composable(Routes.COURT) { com.nizam.app.feature.jarvis.DecisionCourtScreen(container) }
            composable(Routes.CALLCOACH) { com.nizam.app.feature.jarvis.CallCoachScreen(container) }
            composable(Routes.RECEIPTS) { com.nizam.app.feature.jarvis.ReceiptsScreen(container) }
            composable(Routes.DEEN) { com.nizam.app.feature.deen.DeenScreen(container) }
            composable(Routes.MODELS) { com.nizam.app.ui.screens.settings.ModelsScreen() }
            composable(Routes.PLAYGROUND) { PlaygroundScreen(container) }
            composable(Routes.REFLECT) { ReflectScreen(container) }
            composable(Routes.PEOPLE) { PeopleScreen(container) { navController.navigate(it) } }
            composable(Routes.NIGHT) { NightCompanionScreen(container) }
            composable(Routes.APPS) { AppsScreen { navController.navigate(it) } }
            composable(Routes.ATLAS_HUB) { AtlasHub { navController.navigate(it) } }
            composable(Routes.YOU) { FinaleScreen(container) }
            composable(Routes.BOTS) { BotsScreen { id -> BotNav.openId = id; navController.navigate(Routes.BOT_THREAD) } }
            composable(Routes.BOT_THREAD) { BotThreadScreen(container) { navController.popBackStack() } }
            composable(Routes.UNDERSTAND_HUB) { UnderstandHub { navController.navigate(it) } }
            composable(Routes.STORY_HUB) { StoryHub { navController.navigate(it) } }
            composable(Routes.GROW_HUB) { GrowHub { navController.navigate(it) } }
            composable(Routes.WELLBEING_HUB) { WellbeingHub { navController.navigate(it) } }
            composable(Routes.PODCASTS) {
                PodcastsScreen(
                    onShow = { feed, title -> PodcastNav.feed = feed; PodcastNav.title = title; navController.navigate(Routes.PODCAST_SHOW) },
                    onOpenPlayer = { navController.navigate(Routes.PODCAST_PLAYER) }
                )
            }
            composable(Routes.PODCAST_SHOW) { PodcastShowScreen { navController.navigate(Routes.PODCAST_PLAYER) } }
            composable(Routes.PODCAST_PLAYER) { PodcastPlayerScreen() }
            composable(Routes.IPTV) { IptvScreen { navController.navigate(Routes.IPTV_PLAYER) } }
            composable(Routes.IPTV_PLAYER) { IptvPlayerScreen() }
            composable(Routes.ME) { MeScreen(container) { navController.navigate(it) } }
            composable(Routes.NEWS) { NewsScreen(container) }
            composable(Routes.INSIGHTS) { InsightsScreen(container) }
            composable(Routes.MISSIONS) { MissionsScreen(container) }
            composable(Routes.SELF) { SelfScreen(container) }
            composable(Routes.AGENT) { CuratorScreen(container) }
            composable(Routes.VAULT) { VaultScreen(container) }
            composable(Routes.TOOLKIT) { ToolkitScreen(container) }
            composable(
                route = Routes.DYNAMIC,
                arguments = listOf(androidx.navigation.navArgument("key") {
                    type = androidx.navigation.NavType.StringType
                })
            ) { entry ->
                DynamicModuleScreen(
                    container = container,
                    moduleKey = entry.arguments?.getString("key").orEmpty(),
                    onSettings = { navController.navigate(Routes.moduleSettings(it)) }
                )
            }
            composable(
                route = Routes.MODULE_SETTINGS,
                arguments = listOf(androidx.navigation.navArgument("key") {
                    type = androidx.navigation.NavType.StringType
                })
            ) { entry ->
                ModuleSettingsScreen(
                    container = container,
                    moduleKey = entry.arguments?.getString("key").orEmpty(),
                    onDeleted = {
                        navController.navigate(Routes.MODULES) {
                            popUpTo(Routes.MODULES) { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}
