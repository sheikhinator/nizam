package com.nizam.app.feature.hq

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.nizam.app.AppContainer
import com.nizam.app.feature.agent.ApprovalInbox
import com.nizam.app.feature.agent.Crew
import com.nizam.app.ui.components.Feedback
import com.nizam.app.ui.design.Capsule
import com.nizam.app.ui.design.rememberWorkScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Called from the 3D page (on a WebView thread); hops to the main thread. */
/** What went right or wrong while the 3D office started, shown if it doesn't appear. */
private class HqDiag {
    var pageStarted by mutableStateOf(false)
    var pageFinished by mutableStateOf(false)
    var jsReady by mutableStateOf(false)
    var rendered by mutableStateOf<String?>(null)
    val errors = androidx.compose.runtime.mutableStateListOf<String>()
    fun err(s: String) { if (errors.size < 8 && s !in errors) errors += s.take(220) }
}

private const val HQ_HOST = "appassets.androidplatform.net"

private class HqBridge(val onTap: (String, String) -> Unit, val onReady: () -> Unit, val onRoom: (Int) -> Unit, val onHaptic: (Int) -> Unit,
                       val onRendered: (String) -> Unit = {}, val onError: (String) -> Unit = {}) {
    private val main = Handler(Looper.getMainLooper())
    @JavascriptInterface fun rendered(info: String) { main.post { onRendered(info) } }
    @JavascriptInterface fun tap(kind: String, id: String) { main.post { onTap(kind, id) } }
    @JavascriptInterface fun ready() { main.post { onReady() } }
    @JavascriptInterface fun room(i: Int) { main.post { onRoom(i) } }
    @JavascriptInterface fun haptic(ms: Int) { main.post { onHaptic(ms) } }
    @JavascriptInterface fun log(s: String) {
        android.util.Log.w("AtlasHQ", s)
        if (s.startsWith("JS:")) main.post { onError(s.removePrefix("JS:").trim()) }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HqScreen(container: AppContainer, open: (String) -> Unit) {
    val c = LocalContext.current
    val work = rememberWorkScope()
    var web by remember { mutableStateOf<WebView?>(null) }
    var ready by remember { mutableStateOf(false) }
    var room by remember { mutableIntStateOf(0) }
    var explore by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf<Pair<String, String>?>(null) }
    var views by remember { mutableStateOf<List<Hq.View>>(emptyList()) }
    var summary by remember { mutableStateOf("") }
    var needIdx by remember { mutableIntStateOf(0) }
    val diag = remember { HqDiag() }
    var reloads by remember { mutableIntStateOf(0) }
    var slow by remember { mutableStateOf(false) }
    val version = Crew.version
    fun js(s: String) { web?.evaluateJavascript(s, null) }

    val bridge = remember {
        HqBridge(
            onTap = { k, id -> if (k != "pet" && k != "screen") sheet = k to id },
            onReady = { ready = true; diag.jsReady = true },
            onRendered = { diag.rendered = it },
            onError = { diag.err(it) },
            onRoom = { room = it },
            onHaptic = { ms -> web?.performHapticFeedback(if (ms > 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.CLOCK_TICK) })
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF0B1020))) {
        AndroidView(factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.allowFileAccess = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = true
                setBackgroundColor(0xFF0B1020.toInt())
                addJavascriptInterface(bridge, "AtlasHQ")
                // the office's files are served from the app over an https address: some WebViews block file:// scripts
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, req: android.webkit.WebResourceRequest): android.webkit.WebResourceResponse? {
                        val u = req.url
                        if (u.host != HQ_HOST) return null
                        val path = u.path.orEmpty().trimStart('/')
                        val mime = when { path.endsWith(".js") -> "application/javascript"; path.endsWith(".html") -> "text/html"; path.endsWith(".css") -> "text/css"; else -> "application/octet-stream" }
                        return runCatching { android.webkit.WebResourceResponse(mime, "utf-8", ctx.assets.open(path)) }
                            .getOrElse { diag.err("Missing file: $path"); android.webkit.WebResourceResponse("text/plain", "utf-8", 404, "Not found", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0))) }
                    }
                    override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) { diag.pageStarted = true }
                    override fun onPageFinished(view: WebView, url: String?) { diag.pageFinished = true }
                    override fun onReceivedError(view: WebView, req: android.webkit.WebResourceRequest, err: android.webkit.WebResourceError) {
                        diag.err("Load error ${err.errorCode}: ${err.description} (${req.url.lastPathSegment})")
                    }
                    override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                        diag.err("The 3D page crashed${if (detail.didCrash()) "" else " (out of memory)"} — tap Reload"); web = null; return true
                    }
                }
                webChromeClient = object : android.webkit.WebChromeClient() {
                    override fun onConsoleMessage(m: android.webkit.ConsoleMessage): Boolean {
                        if (m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR) diag.err("${m.message()} (${m.sourceId().substringAfterLast('/')}:${m.lineNumber()})")
                        return true
                    }
                }
                loadUrl("https://$HQ_HOST/hq/index.html")
                web = this
            }
        }, modifier = Modifier.fillMaxSize())

        // top: title, summary and the floors
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Atlas HQ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Text(summary.ifBlank { "Opening the office…" }, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                RoundButton(if (explore) "🎥" else "🚶", if (explore) "Diorama" else "Explore") {
                    explore = !explore; js("HQ.setMode('${if (explore) "explore" else "diorama"}')")
                    if (explore) Feedback.show("Explore: left stick walks, drag to look, walk up to things")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Hq.ROOMS.forEachIndexed { i, r ->
                    val here = views.filter { it.room == i }
                    val alert = here.any { it.status == "needs" }
                    val busy = here.count { it.status == "working" }
                    Box(Modifier.clip(RoundedCornerShape(50)).background(if (room == i) Color.White else Color(0xCC111827))
                        .border(if (alert) 2.dp else 0.dp, if (alert) Color(0xFFEF4444) else Color.Transparent, RoundedCornerShape(50))
                        .clickable { room = i; js("HQ.goRoom($i)") }.padding(horizontal = 12.dp, vertical = 7.dp)) {
                        Text("${r.emoji} ${r.name}" + (if (busy > 0) " · $busy" else ""), color = if (room == i) Color(0xFF111827) else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // right rail
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            RoundButton("🤝", "Table") { sheet = "table" to "" }
            RoundButton("📥", "Inbox") { sheet = "inbox" to "" }
            RoundButton("🧾", "Changes") { sheet = "changes" to "" }
            RoundButton("➕", "Hire") { open("nx/crew") }
        }

        LaunchedEffect(reloads) { slow = false; delay(6000); slow = true }
        if (slow && diag.rendered == null || diag.rendered == "nogl") {
            Column(Modifier.align(Alignment.Center).padding(24.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xF01F2937)).padding(16.dp)) {
                Text("The 3D office didn't start", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                val wv = remember { runCatching { WebView.getCurrentWebViewPackage()?.let { "${it.packageName} ${it.versionName}" } }.getOrNull() ?: "unknown" }
                listOf(
                    "Page loading" to diag.pageStarted, "Page loaded" to diag.pageFinished, "3D engine ready" to diag.jsReady,
                    "Office drawn" to (diag.rendered != null && diag.rendered != "nogl"), "Graphics (WebGL)" to (diag.rendered != "nogl")
                ).forEach { (k, ok) -> Text("${if (ok) "✅" else "❌"} $k", color = Color.White, fontSize = 13.sp) }
                Text("WebView: $wv", color = Color(0xFFCBD5E1), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                diag.errors.forEach { Text("• $it", color = Color(0xFFFCA5A5), fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp)) }
                Text("Screenshot this and send it to me if Reload doesn't fix it.", color = Color(0xFFCBD5E1), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                Button(onClick = {
                    diag.errors.clear(); diag.pageStarted = false; diag.pageFinished = false; diag.jsReady = false; diag.rendered = null
                    ready = false; reloads++; web?.reload()
                }, modifier = Modifier.padding(top = 8.dp)) { Text("Reload") }
            }
        }

        // bottom: who needs me
        val waiting = Hq.needs(views)
        val urgent = waiting.count { it.status == "needs" }
        Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp)
            .shadow(10.dp, RoundedCornerShape(50)).clip(RoundedCornerShape(50))
            .background(if (urgent > 0) Color(0xFFEF4444) else if (waiting.isNotEmpty()) Color(0xFF16A34A) else Color(0xE6111827))
            .clickable {
                if (waiting.isEmpty()) { Feedback.show("Nobody needs you right now"); return@clickable }
                val v = waiting[needIdx % waiting.size]; needIdx++
                js("HQ.focusAgent('${v.id}')"); sheet = "agent" to v.id
            }.padding(horizontal = 20.dp, vertical = 12.dp)) {
            Text(when {
                urgent > 0 -> "✋ Who needs me · $urgent"
                waiting.isNotEmpty() -> "✅ ${waiting.size} finished · read"
                else -> "☕ All quiet"
            }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }

    // pause the 3D office whenever the screen isn't showing
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) { Lifecycle.Event.ON_PAUSE -> web?.evaluateJavascript("HQ && HQ.pause(true)", null); Lifecycle.Event.ON_RESUME -> web?.evaluateJavascript("HQ && HQ.pause(false)", null); else -> {} }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); web?.destroy(); web = null }
    }

    // feed the office: a fresh picture every 1.5 s, or straight away when the team changes
    LaunchedEffect(ready) {
        // the page builds the office on its first update, so only send once it has loaded
        var last = ""
        while (true) {
            val snap = runCatching { withContext(Dispatchers.IO) { Hq.snapshot(container) } }.getOrNull()
            if (snap != null) {
                val s = snap.toString()
                if (ready && s != last) { last = s; web?.evaluateJavascript("window.HQ && HQ.update(${JSONObject.quote(s)})", null) }
                views = withContext(Dispatchers.IO) { Hq.views(c) }
                summary = snap.optString("summary")
            }
            delay(if (ready) 1500 else 400)
        }
    }
    LaunchedEffect(ready) { if (ready) { js("HQ.setInsets(140, 80)"); withContext(Dispatchers.IO) { Hq.refreshPlugs(c) } } }
    LaunchedEffect(version) { if (ready) views = withContext(Dispatchers.IO) { Hq.views(c) } }

    // ───────────── sheets ─────────────
    val s = sheet ?: return
    when (s.first) {
        "jar" -> { sheet = null; open("nx/agentbudget") }
        "plugs" -> { sheet = null; open("nx/connectors") }
        "routines" -> { sheet = null; open("schedules") }
        "pc" -> { sheet = null; open("nx/laptop") }
        else -> ModalBottomSheet(onDismissRequest = { sheet = null; js("HQ.clearFocus()") }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
                when (s.first) {
                    "agent" -> AgentSheet(container, s.second, views, open) { sheet = null }
                    "elevator" -> {
                        Text("🛗 Elevator", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(10.dp))
                        Hq.ROOMS.forEachIndexed { i, r ->
                            val here = views.filter { it.room == i }
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { room = i; js("HQ.goRoom($i)"); sheet = null }.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text("${r.emoji}  ${r.name}", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Text(here.joinToString(" ") { it.emoji }, fontSize = 16.sp)
                            }
                        }
                    }
                    "table" -> TableSheet(container, views) { sheet = null }
                    "inbox" -> InboxSheet(container)
                    "changes" -> ChangesSheet(container)
                }
            }
        }
    }
    // mark finished work as read once you open it
    if (s.first == "agent") LaunchedEffect(s.second) {
        views.firstOrNull { it.id == s.second && it.status == "done" }?.thread?.let { work.launch(Dispatchers.IO) { Hq.markSeen(c, it); Crew.version++ } }
    }
}

@Composable
private fun RoundButton(emoji: String, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(46.dp).shadow(6.dp, CircleShape).clip(CircleShape).background(Color(0xE6111827)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 20.sp)
        }
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun AgentSheet(container: AppContainer, id: String, views: List<Hq.View>, open: (String) -> Unit, close: () -> Unit) {
    val c = LocalContext.current
    val work = rememberWorkScope()
    val v = views.firstOrNull { it.id == id } ?: run { Text("This agent has left the office."); return }
    val a = remember(id) { Crew.agents(c).firstOrNull { it.id == id } }
    var text by remember { mutableStateOf("") }
    val version = Crew.version
    val thread = remember(v.thread, version) { v.thread?.let { Crew.thread(c, it) } }
    val approvals = remember(v.thread, version) {
        ApprovalInbox.pending(c).filter { (v.thread != null && it.optString("thread") == v.thread) || (a?.lead == true && it.optString("thread").isBlank()) }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(v.emoji, fontSize = 34.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(v.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("${v.role} · ${Hq.ROOMS[v.room].emoji} ${Hq.ROOMS[v.room].name}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
        val (label, col) = when (v.status) {
            "working" -> "Working" to Color(0xFF3B82F6); "needs" -> "Needs you" to Color(0xFFEF4444); "done" -> "Done" to Color(0xFF22C55E)
            "asleep" -> "Out of budget" to Color(0xFF6B7280); else -> "Free" to Color(0xFF9CA3AF)
        }
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(50)).background(col).padding(horizontal = 10.dp, vertical = 5.dp))
    }
    if (v.card.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(v.card, fontWeight = FontWeight.SemiBold); Text(v.line, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }

    approvals.forEach { ap ->
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x22EF4444)).padding(12.dp)) {
            Text("Approve: ${ap.optString("action").replace('_', ' ')}", fontWeight = FontWeight.Bold)
            Text("${ap.optString("risk")} risk · ${ap.optString("why")}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ap.optString("purpose").takeIf { it.isNotBlank() }?.let { Text(it, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                Button(onClick = { work.launch { val r = withContext(Dispatchers.IO) { ApprovalInbox.decide(container, ap.optString("id"), true) }; Feedback.show(r); Crew.version++ } }) { Text("Approve") }
                OutlinedButton(onClick = { work.launch { withContext(Dispatchers.IO) { ApprovalInbox.decide(container, ap.optString("id"), false) }; Feedback.show("Declined"); Crew.version++ } }) { Text("Decline") }
            }
        }
    }

    // the latest from its thread
    thread?.let { t ->
        val msgs = (t.optJSONArray("messages") ?: JSONArray()).let { arr -> (0 until arr.length()).map { arr.getJSONObject(it) } }
            .filter { it.optString("from") == id || it.optString("to") == id || it.optString("kind") == "final" }.takeLast(5)
        if (msgs.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("Latest", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            msgs.forEach { m ->
                val from = if (m.optString("from") == id) v.name else if (m.optString("from") == "you") "You" else Crew.agents(c).firstOrNull { it.id == m.optString("from") }?.name ?: "Atlas"
                Text("$from: ${m.optString("text").take(400)}", fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp), maxLines = 6, overflow = TextOverflow.Ellipsis)
            }
        }
    }

    Spacer(Modifier.height(12.dp))
    OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = { Text(if (v.status == "needs") "Answer ${v.name}…" else "Give ${v.name} a task…") }, maxLines = 4)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
        Button(enabled = text.isNotBlank(), onClick = {
            val live = v.thread != null && thread?.optString("status") in setOf("running", "needs you", "waiting", "idle")
            if (live) Crew.say(container, v.thread!!, "@${v.name} $text")
            else Crew.start(container, if (a?.lead == true) text else "Ask ${v.name} to handle this: $text", if (a?.lead == true) null else listOf("lead", id))
            Feedback.show("Sent to ${v.name}"); text = ""; Crew.version++
        }) { Text(if (v.status == "needs") "Answer" else "Send") }
        OutlinedButton(onClick = { if (text.isNotBlank()) { Hq.enqueue(container, text, id); text = ""; Feedback.show("Queued for ${v.name}") } }, enabled = text.isNotBlank()) { Text("Queue") }
        if (v.status == "working" && v.thread != null) TextButton(onClick = { Crew.stop(c, v.thread); Feedback.show("Stopped") }) { Text("Stop") }
    }
    Spacer(Modifier.height(12.dp))
    Text("Desk on floor", fontWeight = FontWeight.Bold, fontSize = 13.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Hq.ROOMS.forEachIndexed { i, r -> Capsule("${r.emoji} ${r.name}", v.room == i) { Hq.setRoom(c, id, i) } }
    }
    TextButton(onClick = { close(); open("nx/crew") }, modifier = Modifier.padding(top = 6.dp)) { Text("Open the team's full threads") }
}

@Composable
private fun TableSheet(container: AppContainer, views: List<Hq.View>, close: () -> Unit) {
    val c = LocalContext.current
    var pattern by remember { mutableStateOf(Hq.PATTERNS[0]) }
    var picked by remember { mutableStateOf(views.filter { !it.id.equals("lead") }.take(2).map { it.id }.toSet()) }
    var topic by remember { mutableStateOf("") }
    val live = remember(Crew.version) { Hq.tableThread(c)?.let { Crew.thread(c, it) }?.takeIf { it.optString("status") == "running" } }
    Text("🤝 Meeting table", style = MaterialTheme.typography.titleLarge)
    if (live != null) {
        Text("In session: ${live.optString("goal").substringAfter("Topic: ").take(120)}", fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        OutlinedButton(onClick = { Hq.endMeeting(c); Feedback.show("Meeting ended"); close() }, modifier = Modifier.padding(top = 8.dp)) { Text("End the meeting") }
        Spacer(Modifier.height(14.dp))
        Text("Or start another", fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
    Spacer(Modifier.height(8.dp))
    Hq.PATTERNS.forEach { p ->
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (p == pattern) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .clickable { pattern = p }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(p.emoji, fontSize = 22.sp); Spacer(Modifier.width(10.dp))
            Column { Text(p.name, fontWeight = FontWeight.SemiBold); Text(p.blurb, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
    Spacer(Modifier.height(8.dp))
    Text("Who sits down (the lead always chairs)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        views.filter { it.id != "lead" }.forEach { v -> Capsule("${v.emoji} ${v.name}", v.id in picked) { picked = if (v.id in picked) picked - v.id else if (picked.size < 5) picked + v.id else picked } }
    }
    OutlinedTextField(topic, { topic = it }, Modifier.fillMaxWidth().padding(top = 10.dp), placeholder = { Text("What should they work on?") }, maxLines = 4)
    Button(enabled = topic.isNotBlank() && picked.isNotEmpty(), modifier = Modifier.padding(top = 10.dp), onClick = {
        Hq.startMeeting(container, pattern, picked.toList(), topic); Feedback.show("${pattern.name} started — watch the table"); close()
    }) { Text("Start ${pattern.name.lowercase()}") }
}

@Composable
private fun InboxSheet(container: AppContainer) {
    val c = LocalContext.current
    val work = rememberWorkScope()
    val version = Crew.version
    var tick by remember { mutableIntStateOf(0) }
    val pending = remember(version, tick) { ApprovalInbox.pending(c) }
    val queue = remember(version, tick) { Hq.queued(c) }
    var text by remember { mutableStateOf("") }
    var limit by remember { mutableIntStateOf(Hq.limit(c)) }
    LazyColumn(Modifier.fillMaxWidth().height(520.dp)) {
        item { Text("📥 Inbox", style = MaterialTheme.typography.titleLarge) }
        item { Text("Approvals · ${pending.size}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
        if (pending.isEmpty()) item { Text("Nothing waiting for your OK.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        pending.forEach { ap -> item(ap.optString("id")) {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)) {
                Text("${ap.optString("source")}: ${ap.optString("action").replace('_', ' ')}", fontWeight = FontWeight.SemiBold)
                Text("${ap.optString("risk")} risk · ${ap.optString("why")}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    Button(onClick = { work.launch { Feedback.show(withContext(Dispatchers.IO) { ApprovalInbox.decide(container, ap.optString("id"), true) }); tick++; Crew.version++ } }) { Text("Approve") }
                    OutlinedButton(onClick = { work.launch { withContext(Dispatchers.IO) { ApprovalInbox.decide(container, ap.optString("id"), false) }; tick++; Crew.version++ } }) { Text("Decline") }
                }
            }
        } }
        item {
            Text("Task queue · ${queue.size}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
            Text("Drop tasks here and walk away. A team picks the next one up whenever fewer than $limit are running.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                listOf(0 to "Paused", 1 to "1 at once", 2 to "2", 3 to "3", 4 to "4").forEach { (n, l) -> Capsule(l, limit == n) { limit = n; Hq.setLimit(c, n); Hq.pump(container); tick++ } }
            }
            OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().padding(top = 8.dp), placeholder = { Text("A task for the team…") }, maxLines = 3)
            Button(enabled = text.isNotBlank(), modifier = Modifier.padding(top = 6.dp), onClick = { Hq.enqueue(container, text); text = ""; tick++; Feedback.show("Queued") }) { Text("Add to queue") }
        }
        queue.forEach { q -> item(q.optLong("at")) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("• " + q.optString("text"), Modifier.weight(1f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = { Hq.dequeue(c, q.optLong("at")); tick++ }) { Text("Remove") }
            }
        } }
    }
}

@Composable
private fun ChangesSheet(container: AppContainer) {
    val c = LocalContext.current
    val list = remember(Crew.version) { Hq.changes(c) }
    LazyColumn(Modifier.fillMaxWidth().height(480.dp)) {
        item {
            Text("🧾 What agents changed", style = MaterialTheme.typography.titleLarge)
            Text("The last 24 hours. Undo asks the team to reverse it, and anything risky still comes to you first.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (list.isEmpty()) item { Text("No changes yet today.", modifier = Modifier.padding(top = 12.dp)) }
        list.forEach { ch -> item("${ch.t}${ch.text.hashCode()}") {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(ch.who, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(ch.text, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Text(java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(ch.t)), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = {
                    Crew.start(container, "Undo this change the team made earlier, exactly and only this: \"${ch.text}\". Ask me before anything risky.")
                    Feedback.show("Asked the team to undo it")
                }) { Text("Undo") }
            }
        } }
    }
}
