package com.nizam.app.net

import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL

/**
 * Finding and downloading on-device models. Hugging Face is searched through its public API; any
 * other direct link works too. Downloads run in the background with a progress notification,
 * resume where they stopped (these files are hundreds of MB), and land in the models folder that
 * LocalModel runs from.
 *
 * Gated models (Gemma, Llama) need the licence accepted on huggingface.co once, plus a read token.
 */
data class HubModel(val id: String, val downloads: Int, val gated: Boolean, val updated: String)
data class HubFile(val path: String, val sizeMb: Long)
data class Download(val name: String, val done: Long, val total: Long, val state: String, val error: String = "") {
    val percent get() = if (total > 0) (done * 100 / total).toInt() else 0
}

object ModelHub {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val _download = MutableStateFlow<Download?>(null)
    val download: StateFlow<Download?> = _download

    /** Formats MediaPipe's LLM runtime loads. Newer .litertlm files need a newer runtime. */
    val SUPPORTED = listOf(".task", ".bin")

    fun token(c: Context) = c.getSharedPreferences("local_model", 0).getString("hf_token", "").orEmpty()
    fun setToken(c: Context, t: String) = c.getSharedPreferences("local_model", 0).edit().putString("hf_token", t.trim()).apply()

    private fun headers(c: Context) = token(c).takeIf { it.isNotBlank() }?.let { mapOf("Authorization" to "Bearer $it") } ?: emptyMap()

    /** Searches Hugging Face. [onlyPhoneReady] limits to litert-community, which converts models for phones. */
    suspend fun search(c: Context, query: String, onlyPhoneReady: Boolean): List<HubModel> {
        val q = java.net.URLEncoder.encode(query.trim(), "UTF-8")
        val url = "https://huggingface.co/api/models?limit=40&sort=downloads&direction=-1" +
            (if (onlyPhoneReady) "&author=litert-community" else "&filter=mediapipe") + (if (q.isNotBlank()) "&search=$q" else "")
        val arr = JSONArray(Http.getJson(url, headers(c)))
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map { o ->
            HubModel(o.optString("id").ifBlank { o.optString("modelId") }, o.optInt("downloads"),
                o.opt("gated").let { g -> g == true || (g is String && g != "false") }, o.optString("lastModified").take(10))
        }.filter { it.id.isNotBlank() }
    }

    /** The files in a model repo that Atlas can run, with sizes. */
    suspend fun files(c: Context, id: String): List<HubFile> {
        val arr = JSONArray(Http.getJson("https://huggingface.co/api/models/$id/tree/main?recursive=true", headers(c)))
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { it.optString("type") == "file" && SUPPORTED.any { ext -> it.optString("path").endsWith(ext, true) } }
            .map { HubFile(it.optString("path"), (it.optJSONObject("lfs")?.optLong("size") ?: it.optLong("size")) / 1_048_576) }
            .sortedBy { it.sizeMb }
    }

    fun urlFor(id: String, path: String) = "https://huggingface.co/$id/resolve/main/$path"

    fun cancel() { job?.cancel(); _download.value = _download.value?.copy(state = "cancelled") }

    /** Downloads to models/<name>.part, resuming if a partial file is there, then renames it into place. */
    fun start(c: Context, url: String, suggestedName: String? = null) {
        if (job?.isActive == true) return
        val app = c.applicationContext
        val name = (suggestedName ?: url.substringAfterLast('/').substringBefore('?'))
            .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "model.task" }
        val part = File(LocalModel.dir(app), "$name.part")
        val final = File(LocalModel.dir(app), name)
        job = scope.launch {
            var conn: HttpURLConnection? = null
            try {
                var have = if (part.exists()) part.length() else 0L
                _download.value = Download(name, have, 0, "starting")
                conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = true
                    connectTimeout = 20000; readTimeout = 60000
                    setRequestProperty("User-Agent", "Atlas/1.0")
                    headers(app).forEach { (k, v) -> setRequestProperty(k, v) }
                    if (have > 0) setRequestProperty("Range", "bytes=$have-")
                }
                val code = conn.responseCode
                if (code == 401 || code == 403) throw IllegalStateException(
                    "This model is gated. Accept its licence on huggingface.co, then add a read token below.")
                if (code !in 200..299) throw IllegalStateException("The server said HTTP $code")
                if (code == 200 && have > 0) { part.delete(); have = 0 }        // server ignored Range: start over
                val total = have + conn.contentLengthLong.coerceAtLeast(0)
                RandomAccessFile(part, "rw").use { out ->
                    out.seek(have)
                    conn.inputStream.use { input ->
                        val buf = ByteArray(1 shl 16)
                        var done = have
                        var lastShown = 0L
                        while (isActive) {
                            val n = input.read(buf); if (n < 0) break
                            out.write(buf, 0, n); done += n
                            if (done - lastShown > 4_000_000 || done == total) {
                                lastShown = done
                                _download.value = Download(name, done, total, "downloading")
                                notify(app, name, done, total)
                            }
                        }
                    }
                }
                if (!isActive) return@launch
                if (final.exists()) final.delete()
                part.renameTo(final)
                LocalModel.setActive(app, name)
                _download.value = Download(name, final.length(), final.length(), "done")
                notify(app, name, 1, 1, finished = true)
            } catch (e: Exception) {
                _download.value = Download(name, part.length(), 0, "failed", e.message ?: e.javaClass.simpleName)
                runCatching { NotificationManagerCompat.from(app).cancel(790) }
            } finally {
                conn?.disconnect()
            }
        }
    }

    private fun notify(c: Context, name: String, done: Long, total: Long, finished: Boolean = false) {
        val b = NotificationCompat.Builder(c, com.nizam.app.feature.notify.Notifications.CHANNEL_NUDGE)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(if (finished) "Offline model ready" else "Downloading $name")
            .setOnlyAlertOnce(true).setOngoing(!finished).setAutoCancel(finished)
        if (!finished) b.setProgress(100, if (total > 0) (done * 100 / total).toInt() else 0, total <= 0)
            .setContentText("${done / 1_048_576} of ${total / 1_048_576} MB")
        else b.setContentText("$name is ready. Atlas can now answer without internet.").setSmallIcon(android.R.drawable.stat_sys_download_done)
        runCatching { NotificationManagerCompat.from(c).notify(790, b.build()) }
    }
}
