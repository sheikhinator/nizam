package com.nizam.app.feature.launcher

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.nizam.app.feature.phone.AtlasAccessibilityService
import com.nizam.app.feature.phone.AtlasNotificationListener

/** Everything Control Center and the agent can switch: radios, torch, sound, screen, media, apps. */
object Controls {
    private fun start(c: Context, i: Intent) = runCatching { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)

    fun wifi(c: Context) = start(c, if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS))
    fun internet(c: Context) = start(c, if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIRELESS_SETTINGS))
    fun bluetooth(c: Context) = start(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    fun location(c: Context) = start(c, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
    fun airplane(c: Context) = start(c, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
    fun nfc(c: Context) = start(c, Intent(Settings.ACTION_NFC_SETTINGS))
    fun hotspot(c: Context) = start(c, Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")) || start(c, Intent(Settings.ACTION_WIRELESS_SETTINGS))
    fun volumePanel(c: Context) = start(c, if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_VOLUME) else Intent(Settings.ACTION_SOUND_SETTINGS))
    fun cast(c: Context) = start(c, Intent(Settings.ACTION_CAST_SETTINGS))
    fun batterySaver(c: Context) = start(c, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
    fun darkMode(c: Context) = start(c, Intent(Settings.ACTION_DISPLAY_SETTINGS))
    fun camera(c: Context) = start(c, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    fun video(c: Context) = start(c, Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA))
    fun timer(c: Context) = start(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_SKIP_UI, false))
    fun alarms(c: Context) = start(c, Intent(AlarmClock.ACTION_SHOW_ALARMS))
    fun calculator(c: Context) = start(c, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
    fun qr(c: Context) = start(c, Intent("android.intent.action.SCAN_QR").setPackage("com.google.android.gms")) || camera(c)

    @Volatile private var torchOn = false
    fun torch(c: Context, on: Boolean = !torchOn): Boolean = runCatching {
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return false
        cm.setTorchMode(id, on); torchOn = on; on
    }.getOrDefault(false)
    fun torchIsOn() = torchOn

    fun dnd(c: Context): Boolean {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) { start(c, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); return false }
        val on = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        return !on
    }
    fun dndOn(c: Context) = c.getSystemService(NotificationManager::class.java).currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL

    fun ringerMode(c: Context): Int = c.getSystemService(AudioManager::class.java).ringerMode
    fun cycleRinger(c: Context): String = runCatching {
        val am = c.getSystemService(AudioManager::class.java)
        am.ringerMode = when (am.ringerMode) { AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
            AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT; else -> AudioManager.RINGER_MODE_NORMAL }
        when (am.ringerMode) { AudioManager.RINGER_MODE_NORMAL -> "Ring"; AudioManager.RINGER_MODE_VIBRATE -> "Vibrate"; else -> "Silent" }
    }.getOrElse { start(c, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); "Allow Do Not Disturb access" }

    fun volume(c: Context): Float = c.getSystemService(AudioManager::class.java).let { it.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / it.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    fun setVolume(c: Context, f: Float) = c.getSystemService(AudioManager::class.java).let { it.setStreamVolume(AudioManager.STREAM_MUSIC, (f * it.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(), 0) }

    fun canWriteSettings(c: Context) = Settings.System.canWrite(c)
    fun brightness(c: Context): Float = runCatching { Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f }.getOrDefault(0.5f)
    fun setBrightness(c: Context, f: Float) {
        if (!canWriteSettings(c)) { start(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))); return }
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (f * 255).toInt().coerceIn(5, 255))
    }
    fun autoRotate(c: Context): Boolean = runCatching { Settings.System.getInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION) == 1 }.getOrDefault(true)
    fun toggleRotate(c: Context) {
        if (!canWriteSettings(c)) { start(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))); return }
        Settings.System.putInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (autoRotate(c)) 0 else 1)
    }

    /** Actions that need Atlas's accessibility service. */
    private fun global(c: Context, action: Int): Boolean {
        val s = AtlasAccessibilityService.instance ?: run {
            start(c, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            com.nizam.app.ui.components.Feedback.show("Turn on Atlas in Accessibility for lock, screenshot and recents")
            return false
        }
        return s.performGlobalAction(action)
    }
    fun lock(c: Context) = if (Build.VERSION.SDK_INT >= 28) global(c, android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) else false
    fun screenshot(c: Context) = if (Build.VERSION.SDK_INT >= 28) global(c, android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) else false
    fun recents(c: Context) = global(c, android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
    fun powerMenu(c: Context) = global(c, android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
    fun splitScreen(c: Context) = if (Build.VERSION.SDK_INT >= 24) global(c, android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN) else false

    /** Pulls down Android's own notification shade / quick settings. */
    @android.annotation.SuppressLint("WrongConstant", "PrivateApi")
    fun systemShade(c: Context, quickSettings: Boolean) = runCatching {
        val sb = c.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod(if (quickSettings) "expandSettingsPanel" else "expandNotificationsPanel").invoke(sb)
    }.isSuccess || (if (quickSettings) global(c, android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        else global(c, android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS))

    // ── media: whatever is playing anywhere ─────────────────────────────────────────────────────
    fun media(c: Context): MediaController? = runCatching {
        c.getSystemService(MediaSessionManager::class.java).getActiveSessions(ComponentName(c, AtlasNotificationListener::class.java)).firstOrNull()
    }.getOrNull()

    // ── running apps: see what's been used, stop what's in the background ───────────────────────
    fun hasUsage(c: Context): Boolean = runCatching {
        val ops = c.getSystemService(android.app.AppOpsManager::class.java)
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName) == android.app.AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)
    fun askUsage(c: Context) = start(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    data class Used(val pkg: String, val lastUsed: Long, val minutesToday: Long)
    fun recentlyUsed(c: Context): List<Used> = runCatching {
        val um = c.getSystemService(UsageStatsManager::class.java)
        val start = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        um.queryAndAggregateUsageStats(start, System.currentTimeMillis()).values
            .filter { it.packageName != c.packageName && it.totalTimeInForeground > 0 }
            .map { Used(it.packageName, it.lastTimeUsed, it.totalTimeInForeground / 60_000) }.sortedByDescending { it.lastUsed }
    }.getOrElse { emptyList() }

    /** Stops an app: frees it if it's in the background, and opens its page so you can Force stop it. */
    fun closeApp(c: Context, pkg: String, openInfo: Boolean = true) {
        runCatching { c.getSystemService(ActivityManager::class.java).killBackgroundProcesses(pkg) }
        if (openInfo) appInfo(c, pkg)
    }
    fun appInfo(c: Context, pkg: String) = start(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
    fun uninstall(c: Context, pkg: String) = start(c, Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    fun share(c: Context, pkg: String, label: String) = start(c, Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
        .putExtra(Intent.EXTRA_TEXT, "$label — https://play.google.com/store/apps/details?id=$pkg"), "Share app"))
    fun storePage(c: Context, pkg: String) = start(c, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
    fun freeMemory(c: Context): Int {
        val am = c.getSystemService(ActivityManager::class.java)
        val pkgs = recentlyUsed(c).map { it.pkg }.distinct()
        pkgs.forEach { runCatching { am.killBackgroundProcesses(it) } }
        return pkgs.size
    }

    fun setDefaultHome(c: Context) {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = c.getSystemService(android.app.role.RoleManager::class.java)
            if (rm.isRoleAvailable(android.app.role.RoleManager.ROLE_HOME) && !rm.isRoleHeld(android.app.role.RoleManager.ROLE_HOME) && c is android.app.Activity) {
                c.startActivityForResult(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_HOME), 77); return
            }
        }
        start(c, Intent(Settings.ACTION_HOME_SETTINGS))
    }
    fun isDefaultHome(c: Context): Boolean = c.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
        ?.activityInfo?.packageName == c.packageName
}
