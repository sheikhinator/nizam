package com.nizam.app.ui.screens.hubs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.ui.design.ActionTile
import com.nizam.app.ui.design.AtlasScreen
import com.nizam.app.ui.design.EmptySpec
import com.nizam.app.ui.design.EmptyState
import com.nizam.app.ui.design.Hub
import com.nizam.app.ui.design.ListRow
import com.nizam.app.ui.design.Radius
import com.nizam.app.ui.design.SectionHeader
import com.nizam.app.ui.design.Space
import com.nizam.app.ui.design.arrive
import com.nizam.app.ui.design.pressable
import com.nizam.app.ui.design.wash
import com.nizam.app.ui.nav.Routes

/**
 * The Life tab: a search box, what you used recently, the twelve hubs, and your own trackers.
 * Everything in Atlas is at most two taps from here.
 */
@Composable
fun LifeScreen(container: AppContainer, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    val specs by container.dynamicRepository.specs().collectAsState(initial = emptyList())
    val recent = remember { RecentFeatures.recent(ctx).mapNotNull { HubRegistry.byRoute(it) } }
    val results = remember(query) { HubRegistry.search(query) }

    AtlasScreen(title = "Life", subtitle = "Twelve hubs. Everything you do, in its place.",
        actions = {
            Icon(Icons.Outlined.Tune, "Arrange modules", tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.clip(Radius.chip).pressable { onOpen(Routes.MODULES_CLASSIC) }.padding(Space.s))
        }) {
        item("search") { SearchPill(query, { query = it }, Modifier.padding(horizontal = Space.page)) }

        if (query.isNotBlank()) {
            if (results.isEmpty()) item("none") {
                EmptyState(EmptySpec(Icons.Outlined.SearchOff, "Nothing called that yet",
                    "Try another word, or ask Atlas: it can reach every feature.", "Ask Atlas") { onOpen(Routes.ASSISTANT) })
            }
            results.forEachIndexed { i, f ->
                item("r-${f.route}") {
                    ListRow(f.title, Modifier.arrive(i), supporting = "${f.hub.label} · ${f.blurb}", icon = f.icon, tint = f.hub.tint()) { onOpen(f.route) }
                }
            }
            return@AtlasScreen
        }

        if (recent.isNotEmpty()) {
            item("recent-h") { SectionHeader("Jump back in") }
            item("recent") {
                LazyRow(contentPadding = PaddingValues(horizontal = Space.page), horizontalArrangement = Arrangement.spacedBy(Space.s)) {
                    items(recent, key = { it.route }) { f -> RecentChip(f) { onOpen(f.route) } }
                }
            }
        }

        item("hubs-h") { SectionHeader("Hubs") }
        Hub.entries.chunked(2).forEachIndexed { row, pair ->
            item("hubs-$row") {
                Row(Modifier.padding(horizontal = Space.page, vertical = Space.xs), horizontalArrangement = Arrangement.spacedBy(Space.s)) {
                    pair.forEachIndexed { i, hub ->
                        HubCard(hub, Modifier.weight(1f).arrive(row * 2 + i)) { onOpen(Routes.hub(hub.name)) }
                    }
                }
            }
        }

        item("trackers-h") { SectionHeader("Your trackers", action = "Manage") { onOpen(Routes.MODULES_CLASSIC) } }
        if (specs.isEmpty()) item("trackers-empty") {
            ListRow("Create a tracker", supporting = "Anything you want to count or log: ask Atlas to build one",
                icon = Icons.Outlined.Add) { onOpen(Routes.ASSISTANT) }
        }
        specs.forEach { spec ->
            item("t-${spec.key}") {
                val tint = runCatching { Color(android.graphics.Color.parseColor(spec.colorHex)) }.getOrDefault(MaterialTheme.colorScheme.primary)
                Row(Modifier.fillMaxWidth().pressable { onOpen(Routes.dynamic(spec.key)) }.padding(horizontal = Space.page, vertical = Space.s),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).clip(Radius.field).background(wash(tint, 0.2f)), contentAlignment = Alignment.Center) {
                        Text(spec.emoji, style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.width(Space.m))
                    Text(spec.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                }
            }
        }
        item("pad") { Spacer(Modifier.height(Space.xl)) }
    }
}

@Composable
private fun HubCard(hub: Hub, modifier: Modifier, onClick: () -> Unit) {
    val tint = hub.tint()
    val c = MaterialTheme.colorScheme
    val features = HubRegistry.of(hub)
    Column(modifier.aspectRatio(1.18f).clip(Radius.tile)
        .background(Brush.linearGradient(listOf(wash(tint, 0.22f), c.surface)))
        .pressable(onClick = onClick).padding(Space.l)) {
        if (com.nizam.app.ui.design.Style.s.hubIcons == "3D" && com.nizam.app.ui.design.Style.s.art)
            com.nizam.app.ui.design.Art3D(com.nizam.app.ui.design.Art.forHub(hub), 58.dp, float = false, shadow = false)
        else Box(Modifier.size(38.dp).clip(com.nizam.app.ui.design.hubShape(hub)).background(wash(tint, 0.3f)), contentAlignment = Alignment.Center) {
            Icon(hub.icon, null, tint = tint, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.weight(1f))
        Text(hub.label, style = MaterialTheme.typography.titleLarge)
        Text(features.take(3).joinToString(" · ") { it.title }, style = MaterialTheme.typography.bodySmall,
            color = c.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun RecentChip(f: Feature, onClick: () -> Unit) {
    val tint = f.hub.tint()
    Row(Modifier.clip(Radius.pill).background(MaterialTheme.colorScheme.surface).pressable(onClick = onClick)
        .padding(start = Space.s, end = Space.l, top = Space.s, bottom = Space.s), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(28.dp).clip(Radius.pill).background(wash(tint, 0.22f)), contentAlignment = Alignment.Center) {
            Icon(f.icon, null, tint = tint, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(Space.s))
        Text(f.title, style = MaterialTheme.typography.labelLarge, maxLines = 1)
    }
}

/** A rounded search field with a clear button. */
@Composable
fun SearchPill(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, hint: String = "Search every feature") {
    val c = MaterialTheme.colorScheme
    Row(modifier.fillMaxWidth().height(50.dp).clip(Radius.pill).background(c.surfaceVariant).padding(horizontal = Space.l),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Search, null, tint = c.onSurfaceVariant, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(Space.s))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(hint, style = MaterialTheme.typography.bodyLarge, color = c.onSurfaceVariant)
            BasicTextField(value, onChange, singleLine = true, textStyle = MaterialTheme.typography.bodyLarge.copy(color = c.onSurface),
                cursorBrush = SolidColor(c.primary), modifier = Modifier.fillMaxWidth())
        }
        if (value.isNotEmpty()) Icon(Icons.Outlined.Close, "Clear", tint = c.onSurfaceVariant,
            modifier = Modifier.size(20.dp).clip(Radius.pill).pressable { onChange("") })
    }
}

/** One hub: its four big tiles, then everything else it holds. */
@Composable
fun HubPage(hubName: String, onOpen: (String) -> Unit) {
    val hub = Hub.entries.firstOrNull { it.name == hubName } ?: Hub.Tools
    val ctx = LocalContext.current
    // what you use most rises to the top of "More"
    val more = remember(hub) { HubRegistry.more(hub).sortedByDescending { RecentFeatures.uses(ctx, it.route) } }
    val top = HubRegistry.top(hub)
    AtlasScreen(title = hub.label, hub = hub, subtitle = "${HubRegistry.of(hub).size} tools") {
        top.chunked(2).forEachIndexed { row, pair ->
            item("top-$row") {
                Row(Modifier.padding(horizontal = Space.page, vertical = Space.xs), horizontalArrangement = Arrangement.spacedBy(Space.s)) {
                    pair.forEachIndexed { i, f ->
                        ActionTile(f.icon, f.title, Modifier.weight(1f).arrive(row * 2 + i).then(com.nizam.app.ui.design.PeekMod(f.title, f.blurb, hub)), tint = hub.tint(), hint = f.blurb) { onOpen(f.route) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        if (more.isNotEmpty()) {
            item("more-h") { SectionHeader("More in ${hub.label}") }
            more.forEachIndexed { i, f ->
                item("m-${f.route}") { ListRow(f.title, Modifier.arrive(i + 4).then(com.nizam.app.ui.design.PeekMod(f.title, f.blurb, hub)), supporting = f.blurb, icon = f.icon, tint = hub.tint()) { onOpen(f.route) } }
            }
        }
    }
}
