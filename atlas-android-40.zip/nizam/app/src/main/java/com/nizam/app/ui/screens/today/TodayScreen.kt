package com.nizam.app.ui.screens.today

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Divider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nizam.app.AppContainer
import com.nizam.app.core.Tones
import com.nizam.app.core.fmtAmount
import com.nizam.app.core.hourToClock
import com.nizam.app.core.today
import com.nizam.app.core.vmFactory
import com.nizam.app.feature.diary.DiaryViewModel
import com.nizam.app.feature.diet.DietViewModel
import com.nizam.app.feature.finance.FinanceViewModel
import com.nizam.app.feature.gym.GymViewModel
import com.nizam.app.feature.learning.CourseViewModel
import com.nizam.app.feature.learning.LearningViewModel
import com.nizam.app.feature.missions.MissionsViewModel
import com.nizam.app.feature.prayer.PrayerViewModel
import com.nizam.app.feature.progress.Insight
import com.nizam.app.feature.progress.Insights
import com.nizam.app.feature.progress.ProgressSummary
import com.nizam.app.feature.progress.Xp
import com.nizam.app.feature.quotes.QuotesViewModel
import com.nizam.app.feature.quotes.quoteOfTheDay
import com.nizam.app.ui.nav.Routes
import com.nizam.app.ui.screens.tasks.TasksViewModel
import com.nizam.app.ui.theme.DisplayFamily
import com.nizam.app.ui.theme.MonoNumber
import com.nizam.app.ui.theme.Spine
import java.time.LocalDate
import java.time.LocalTime
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter

@Composable
fun TodayScreen(container: AppContainer, onOpen: (String) -> Unit) {
    val tasksVm: TasksViewModel = viewModel(
        factory = TasksViewModel.factory(container.taskRepository, container.habitRepository)
    )
    val prayerVm: PrayerViewModel = viewModel(
        key = "prayer",
        factory = vmFactory { PrayerViewModel(container.prayerRepository, container.settingsRepository) }
    )
    val financeVm: FinanceViewModel = viewModel(
        key = "finance", factory = vmFactory { FinanceViewModel(container.financeRepository) }
    )
    val dietVm: DietViewModel = viewModel(
        key = "diet", factory = vmFactory { DietViewModel(container.dietRepository) }
    )
    val gymVm: GymViewModel = viewModel(
        key = "gym", factory = vmFactory { GymViewModel(container.gymRepository) }
    )
    val diaryVm: DiaryViewModel = viewModel(
        key = "diary", factory = vmFactory { DiaryViewModel(container.diaryRepository) }
    )
    val learningVm: LearningViewModel = viewModel(
        key = "learning", factory = vmFactory { LearningViewModel(container.learningRepository) }
    )
    val quotesVm: QuotesViewModel = viewModel(
        key = "quotes", factory = vmFactory { QuotesViewModel(container.quoteRepository) }
    )
    val missionsVm: MissionsViewModel = viewModel(
        key = "missions", factory = vmFactory { MissionsViewModel(container.missionRepository) }
    )
    val courseVm: CourseViewModel = viewModel(
        key = "courses",
        factory = vmFactory { CourseViewModel(container.courseRepository, container.learningRepository) }
    )

    val tasks by tasksVm.tasks.collectAsState()
    val habits by tasksVm.habits.collectAsState()
    val habitEntries by tasksVm.todayEntries.collectAsState()
    val prayerDay by prayerVm.day.collectAsState()
    val lat by prayerVm.latitude.collectAsState()
    val lng by prayerVm.longitude.collectAsState()
    val method by prayerVm.methodName.collectAsState()
    val hanafi by prayerVm.hanafi.collectAsState()
    val month by financeVm.thisMonth.collectAsState()
    val meals by dietVm.items.collectAsState()
    val water by dietVm.water.collectAsState()
    val sets by gymVm.sets.collectAsState()
    val entries by diaryVm.entries.collectAsState()
    val due by learningVm.due.collectAsState()
    val quotes by quotesVm.quotes.collectAsState()
    val todaysLessons by courseVm.todaysLessons.collectAsState()
    val missions by missionsVm.todayMissions.collectAsState()
    val name by container.settingsRepository.displayName.collectAsState(initial = "")
    val kcalTarget by container.settingsRepository.kcalTarget.collectAsState(initial = 2200)
    val waterTarget by container.settingsRepository.waterTarget.collectAsState(initial = 3000)

    var summary by remember { mutableStateOf<ProgressSummary?>(null) }
    var insights by remember { mutableStateOf<List<Insight>>(emptyList()) }

    LaunchedEffect(tasks.size, sets.size, entries.size, todaysLessons.size, prayerDay, habitEntries.size) {
        val computed = Xp.summarise(container)
        summary = computed
        insights = Insights.compute(computed)
    }

    val date = LocalDate.now()
    val hijri = runCatching {
        HijrahDate.from(date).format(DateTimeFormatter.ofPattern("d MMMM y"))
    }.getOrElse { "" }
    val hour = LocalTime.now().hour
    val greeting = when {
        hour < 5 -> "Still up"
        hour < 12 -> "Morning"
        hour < 17 -> "Afternoon"
        hour < 21 -> "Evening"
        else -> "Night"
    } + if (name.isBlank()) "" else ", $name"

    val times = remember(lat, lng, method, hanafi) { prayerVm.times() }
    val nowHours = hour + LocalTime.now().minute / 60.0
    val upcoming = listOf(
        "Fajr" to times.fajr, "Dhuhr" to times.dhuhr, "Asr" to times.asr,
        "Maghrib" to times.maghrib, "Isha" to times.isha
    ).firstOrNull { it.second > nowHours }

    val openTasks = tasks.filter { it.completedAt == null }
    val prayerStatuses = prayerDay?.let {
        listOf(it.fajr, it.dhuhr, it.asr, it.maghrib, it.isha)
    } ?: List(5) { "NOT_PRAYED" }
    val spentToday = month.filter { it.kind == "EXPENSE" && it.localDate == today() }.sumOf { it.amount }
    val kcal = meals.sumOf { it.kcal }.toInt()
    val ml = water?.ml ?: 0
    val todaySets = sets.filter { it.localDate == today() }
    val quote = quoteOfTheDay(quotes)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(22.dp))

        val faceCode by container.settingsRepository.face.collectAsState(initial = "2-1-0-2-0-0-0")
        Row(verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.foundation.layout.Box(
                Modifier.clickable(role = androidx.compose.ui.semantics.Role.Button) { onOpen(Routes.PROFILE) }
            ) { com.nizam.app.feature.profile.FaceAvatar(com.nizam.app.feature.profile.Face.decode(faceCode), 52.dp) }
            Spacer(Modifier.width(12.dp))
            Text(
                greeting,
                style = MaterialTheme.typography.displaySmall.copy(fontFamily = DisplayFamily),
                modifier = Modifier.weight(1f)
            )
            androidx.compose.material3.IconButton(onClick = { onOpen(Routes.DAY) }) {
                androidx.compose.material3.Icon(
                    androidx.compose.material.icons.Icons.Filled.DateRange, contentDescription = "Past days",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                "⚙",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clickable(role = androidx.compose.ui.semantics.Role.Button) { onOpen(Routes.SETTINGS) }
                    .padding(8.dp)
            )
        }
        Text(
            date.format(DateTimeFormatter.ofPattern("EEEE d MMMM")) +
                if (hijri.isBlank()) "" else "  ·  $hijri",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(18.dp))

        summary?.let { s ->
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Level ${s.level}", style = MaterialTheme.typography.titleLarge)
                            Text(
                                s.title,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${s.streak} day streak", style = MonoNumber)
                            Text(
                                "+${s.today.xp} XP today",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { s.levelProgress.toFloat() / s.levelNeed.coerceAtLeast(1) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "${s.levelProgress} / ${s.levelNeed} to level ${s.level + 1}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        s.last30.reversed().forEach { day ->
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(if (day.active) (8 + (day.xp / 12).coerceAtMost(26)).dp else 6.dp)
                                    .background(
                                        if (day.active) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(2.dp)
                                    )
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        insights.firstOrNull()?.let { insight ->
            val tones = Tones.forKey(insight.id)
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = tones.tone.copy(alpha = 0.13f),
                modifier = Modifier.fillMaxWidth().clickable { onOpen(Routes.INSIGHTS) }
            ) {
                Row(Modifier.padding(16.dp)) {
                    Text(insight.glyph, style = MaterialTheme.typography.titleLarge, color = tones.accent)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(insight.headline, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(insight.body, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
        }

        Text(
            "TODAY",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(6.dp))

        com.nizam.app.feature.finale.CommandBar(container) { onOpen(com.nizam.app.ui.nav.Routes.ASSISTANT) }
        if (java.time.LocalTime.now().hour in 4..13) com.nizam.app.feature.body.EnergyCheck()
        val order by container.settingsRepository.homeSectionOrder.collectAsState(
            initial = com.nizam.app.data.prefs.SettingsRepository.DEFAULT_SECTIONS
        )
        val known = com.nizam.app.data.prefs.SettingsRepository.DEFAULT_SECTIONS
        // Honour the saved order; anything the saved list omits still appears at the end.
        (order.filter { it in known } + known.filterNot { it in order }).forEach { section ->
            when (section) {
                "MISSIONS" -> Line(
                    spine = Spine.Survival,
                    label = missions.firstOrNull { it.completedAt == null }?.title
                        ?: if (missions.isEmpty()) "No missions set for today" else "All missions cleared",
                    value = if (missions.isEmpty()) "—" else "${missions.count { it.completedAt != null }}/${missions.size}",
                    onClick = { onOpen(Routes.MISSIONS) }
                )
                "PRAYER" -> Line(
                    spine = Spine.Prayer,
                    label = if (upcoming != null) "${upcoming.first} at ${hourToClock(upcoming.second)}"
                    else "Isha passed",
                    value = "${prayerStatuses.count { it != "NOT_PRAYED" }}/5",
                    onClick = { onOpen(Routes.PRAYER) }
                )
                "COURSE" -> Line(
                    spine = Spine.Learning,
                    label = todaysLessons.firstOrNull { it.completedAt == null }?.title
                        ?: if (todaysLessons.isEmpty()) "No lesson scheduled" else "Today's lessons done",
                    value = if (todaysLessons.isEmpty()) "—"
                    else "${todaysLessons.count { it.completedAt != null }}/${todaysLessons.size}",
                    onClick = { onOpen(Routes.COURSES) }
                )
                "TASKS" -> Line(
                    spine = Spine.Tasks,
                    label = openTasks.firstOrNull()?.title ?: "Nothing open",
                    value = "${openTasks.size}",
                    onClick = { onOpen(Routes.TASKS) }
                )
                "HABITS" -> Line(
                    spine = Spine.Tasks, label = "Habits",
                    value = "${habitEntries.size}/${habits.size}",
                    onClick = { onOpen(Routes.TASKS) }
                )
                "DIET" -> Line(
                    spine = Spine.Diet, label = "Food and water",
                    value = "$kcal/$kcalTarget · $ml/$waterTarget",
                    onClick = { onOpen(Routes.DIET) }
                )
                "GYM" -> Line(
                    spine = Spine.Gym,
                    label = if (todaySets.isEmpty()) "No sets logged" else "Training logged",
                    value = "${todaySets.size}",
                    onClick = { onOpen(Routes.GYM) }
                )
                "FINANCE" -> Line(
                    spine = Spine.Finance, label = "Spent today",
                    value = fmtAmount(spentToday),
                    onClick = { onOpen(Routes.FINANCE) }
                )
                "LEARNING" -> Line(
                    spine = Spine.Learning, label = "Cards due",
                    value = "${due.size}",
                    onClick = { onOpen(Routes.LEARNING) }
                )
                "SELF" -> Line(
                    spine = Spine.Diary,
                    label = if (hour >= 20) "Close the day — evening review" else "Character and review",
                    value = "",
                    onClick = { onOpen(Routes.SELF) }
                )
                "NEWS" -> Line(
                    spine = Spine.Finance, label = "Headlines from Dawn",
                    value = "",
                    onClick = { onOpen(Routes.NEWS) }
                )
            }
        }

        quote?.let {
            Spacer(Modifier.height(20.dp))
            Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(Modifier.height(16.dp))
            Text(
                it.text,
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = DisplayFamily),
                modifier = Modifier.clickable(role = Role.Button) { onOpen(Routes.QUOTES) }
            )
            if (it.source.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    it.source,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(48.dp))
    }
}

@Composable
private fun Line(spine: androidx.compose.ui.graphics.Color, label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(3.dp).height(20.dp).background(spine, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        if (value.isNotBlank()) {
            Text(value, style = MonoNumber, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
}
