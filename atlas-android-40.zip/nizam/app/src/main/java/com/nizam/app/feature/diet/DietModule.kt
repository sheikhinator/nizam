package com.nizam.app.feature.diet

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import com.nizam.app.ui.design.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import com.nizam.app.ui.design.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import com.nizam.app.AppContainer
import com.nizam.app.core.AiPanel
import com.nizam.app.core.LineChart
import com.nizam.app.core.Point
import com.nizam.app.core.StatRow
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.today
import com.nizam.app.core.vmFactory
import com.nizam.app.ui.theme.Spine
import com.nizam.app.ui.theme.MonoNumber
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@Entity(tableName = "meal_item")
data class MealItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val localDate: String,
    val slot: String,
    val name: String,
    val kcal: Double,
    val protein: Double = 0.0,
    val carbs: Double = 0.0,
    val fat: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "water_log")
data class WaterLog(
    @PrimaryKey val localDate: String,
    val ml: Int
)

@Entity(tableName = "body_metric")
data class BodyMetric(
    @PrimaryKey val localDate: String,
    val weight: Double
)

@Dao
interface DietDao {
    @Query("SELECT * FROM meal_item WHERE localDate = :date ORDER BY id ASC")
    fun observeDay(date: String): Flow<List<MealItem>>

    @Query("SELECT DISTINCT localDate FROM meal_item WHERE localDate >= :from")
    fun observeLoggedDays(from: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: MealItem)

    @Delete
    suspend fun delete(item: MealItem)

    @Query("SELECT * FROM water_log WHERE localDate = :date")
    fun observeWater(date: String): Flow<WaterLog?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWater(log: WaterLog)

    @Query("SELECT * FROM body_metric ORDER BY localDate DESC LIMIT 30")
    fun observeWeights(): Flow<List<BodyMetric>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWeight(metric: BodyMetric)
}

class DietRepository(private val dao: DietDao) {
    fun day(date: String) = dao.observeDay(date)
    fun loggedDaysSince(from: String) = dao.observeLoggedDays(from)
    fun water(date: String) = dao.observeWater(date)
    fun weights() = dao.observeWeights()

    suspend fun add(slot: String, name: String, kcal: Double, protein: Double) {
        dao.insert(MealItem(localDate = today(), slot = slot, name = name, kcal = kcal, protein = protein))
    }
    suspend fun remove(item: MealItem) = dao.delete(item)
    suspend fun addWater(currentMl: Int, deltaMl: Int) {
        dao.upsertWater(WaterLog(today(), (currentMl + deltaMl).coerceAtLeast(0)))
    }
    suspend fun setWeight(kg: Double) = dao.upsertWeight(BodyMetric(today(), kg))
}

val SLOTS = listOf("Breakfast", "Lunch", "Dinner", "Snack")

class DietViewModel(private val repository: DietRepository) : ViewModel() {
    val items: StateFlow<List<MealItem>> = repository.day(today())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val water: StateFlow<WaterLog?> = repository.water(today())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val weights: StateFlow<List<BodyMetric>> = repository.weights()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(slot: String, name: String, kcal: String, protein: String) {
        val k = kcal.toDoubleOrNull() ?: return
        if (name.isBlank()) return
        viewModelScope.launch { repository.add(slot, name.trim(), k, protein.toDoubleOrNull() ?: 0.0) }
    }
    fun delete(item: MealItem) = viewModelScope.launch { repository.remove(item) }
    fun addWater(ml: Int) = viewModelScope.launch { repository.addWater(water.value?.ml ?: 0, ml) }
    fun setWeight(kg: String) {
        val value = kg.toDoubleOrNull() ?: return
        viewModelScope.launch { repository.setWeight(value) }
    }
}

@Composable
fun DietScreen(container: AppContainer) {
    val vm: DietViewModel = viewModel(factory = vmFactory { DietViewModel(container.dietRepository) })
    val items by vm.items.collectAsState()
    val water by vm.water.collectAsState()
    val weights by vm.weights.collectAsState()

    var slot by remember { mutableStateOf(SLOTS.first()) }
    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }

    val kcalTargetInt by container.settingsRepository.kcalTarget.collectAsState(initial = 2200)
    val waterTarget by container.settingsRepository.waterTarget.collectAsState(initial = 3000)
    val kcalTarget = kcalTargetInt.toDouble()
    val weightTrend = remember(weights) {
        weights.sortedBy { it.localDate }.map { Point(it.localDate.takeLast(5), it.weight) }
    }
    val weightChange = remember(weights) {
        if (weights.size < 2) "—" else {
            val sorted = weights.sortedBy { it.localDate }
            val delta = sorted.last().weight - sorted.first().weight
            (if (delta >= 0) "+" else "") + "%.1f kg".format(delta)
        }
    }
    val totalKcal = items.sumOf { it.kcal }
    val totalProtein = items.sumOf { it.protein }
    val ml = water?.ml ?: 0

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            Column(Modifier.fillMaxWidth()) {
        ModuleTitle("Diet", "Today")

        Text("${totalKcal.toInt()} / ${kcalTarget.toInt()} kcal", style = MonoNumber)
        Spacer(Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { (totalKcal / kcalTarget).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text("Protein ${totalProtein.toInt()} g", style = MonoNumber,
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Water $ml / $waterTarget ml", style = MonoNumber, modifier = Modifier.weight(1f))
            Button(onClick = { vm.addWater(250) }) { Text("+250") }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.addWater(-250) }) { Text("-250") }
        }

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SLOTS.forEach { s ->
                FilterChip(selected = slot == s, onClick = { slot = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Food") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Row {
            OutlinedTextField(
                value = kcal, onValueChange = { kcal = it },
                label = { Text("kcal") }, singleLine = true, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = protein, onValueChange = { protein = it },
                label = { Text("Protein g") }, singleLine = true, modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            vm.add(slot, name, kcal, protein)
            name = ""; kcal = ""; protein = ""
        }) { Text("Log food") }

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = weight, onValueChange = { weight = it },
                label = { Text("Weight kg") }, singleLine = true, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.setWeight(weight); weight = "" }) { Text("Save") }
        }
        weights.firstOrNull()?.let {
            Text("Last logged: ${it.weight} kg on ${it.localDate}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (weights.size >= 2) {
            Spacer(Modifier.height(12.dp))
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("Weight", style = MaterialTheme.typography.titleMedium)
                    LineChart(points = weightTrend, accent = Spine.Diet)
                    StatRow(
                        listOf(
                            "latest" to "%.1f kg".format(weights.first().weight),
                            "change" to weightChange,
                            "logged" to weights.size.toString()
                        )
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        AiPanel(
            settings = container.settingsRepository,
            label = "Nutrition help",
            contextPrompt = "Today the user logged: " +
                items.joinToString("; ") { "${it.name} ${it.kcal.toInt()} kcal" } +
                ". Total ${totalKcal.toInt()} kcal, ${totalProtein.toInt()} g protein, water $ml ml.",
            starterQuestion = "What should I eat for dinner to hit my protein target?",
            system = "You are a practical nutrition coach who knows Pakistani and South Asian food well. " +
                "Give specific, realistic suggestions with rough macros. Recommend seeing a doctor or " +
                "dietitian for medical conditions rather than guessing."
        )
        Spacer(Modifier.height(12.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)

        if (items.isEmpty()) {
            Spacer(Modifier.height(18.dp))
            Text(
                "Nothing logged today. Add a meal above, or tell the Curator what you ate.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
            }
        }

            items(items, key = { it.id }) { item ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, style = MaterialTheme.typography.bodyLarge)
                        Text(item.slot, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${item.kcal.toInt()} kcal", style = MonoNumber)
                    IconButton(onClick = { vm.delete(item) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Remove food")
                    }
                }
                Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
            }
    }
}
