package com.nizam.app.ui.screens.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.net.ApiKeys
import com.nizam.app.ui.components.Feedback
import com.nizam.app.ui.design.Button
import com.nizam.app.ui.design.Group
import com.nizam.app.ui.design.OutlinedTextField
import com.nizam.app.ui.design.rememberWorkScope
import kotlinx.coroutines.launch

/** Every API key in one list: see which are set, switch any on or off, change one, with a clear "saved". */
@Composable
fun KeysScreen(container: AppContainer) {
    val c = LocalContext.current
    val s = container.settingsRepository
    val scope = rememberWorkScope()
    var refresh by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        ModuleTitle("API keys", "Switch any key off to stop Atlas using it — it's kept, not deleted")
        var paste by remember { mutableStateOf("") }
        Group(Modifier.padding(vertical = 5.dp)) {
            Text("Paste all your keys at once", style = MaterialTheme.typography.titleSmall)
            Text("Gemini, OpenRouter, Groq, Hugging Face, Hadith — in any order. Atlas recognises each one and sets itself up for speed.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(paste, { paste = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, placeholder = { Text("Paste here") })
            Button(enabled = paste.isNotBlank(), onClick = { scope.launch {
                val got = ApiKeys.importAll(c, s, paste); paste = ""; refresh++
                Feedback.show(if (got.isEmpty()) "No keys recognised in that text" else "Set up: ${got.joinToString()} ✓")
            } }) { Text("Import keys") }
        }
        var results by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
        var testing by remember { mutableStateOf(false) }
        Button(enabled = !testing, onClick = { testing = true; results = emptyMap(); scope.launch {
            ApiKeys.SLOTS.forEach { sl -> results = results + (sl.id to "Testing…"); results = results + (sl.id to ApiKeys.test(c, s, sl)) }
            testing = false
            Feedback.show("Tested ${results.count { it.value.startsWith("Works") }} working · ${results.count { it.value.startsWith("Failed") }} failing")
        } }) { Text(if (testing) "Testing…" else "Test all keys") }
        ApiKeys.SLOTS.forEach { slot ->
            var value by remember(refresh) { mutableStateOf("") }
            var on by remember(refresh) { mutableStateOf(ApiKeys.enabled(c, slot.id)) }
            var editing by remember { mutableStateOf(false) }
            var draft by remember { mutableStateOf("") }
            LaunchedEffect(refresh) { value = ApiKeys.value(c, s, slot) }
            Group(Modifier.padding(vertical = 5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable(role = Role.Button) { editing = !editing; draft = value }) {
                        Text(slot.label, style = MaterialTheme.typography.titleSmall)
                        Text(slot.what, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(when {
                            value.isBlank() -> "Not set — tap to add"
                            !on -> "Off · ${ApiKeys.mask(value)}"
                            else -> "On · ${ApiKeys.mask(value)}" + if (value == slot.builtIn) " · built in" else ""
                        }, style = MaterialTheme.typography.labelMedium,
                            color = if (on && value.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp))
                    }
                    Switch(checked = on && value.isNotBlank(), enabled = value.isNotBlank(), onCheckedChange = { v ->
                        on = v
                        scope.launch { ApiKeys.setEnabled(c, s, slot, v); Feedback.show("${slot.label} ${if (v) "on" else "off"}"); refresh++ }
                    })
                }
                results[slot.id]?.let { r -> Text(r, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp),
                    color = if (r.startsWith("Works")) androidx.compose.ui.graphics.Color(0xFF3DAA6D) else if (r.startsWith("Failed")) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant) }
                AnimatedVisibility(editing) {
                    Column(Modifier.padding(top = 8.dp)) {
                        OutlinedTextField(draft, { draft = it.trim() }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
                            placeholder = { Text("Paste the key") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { scope.launch {
                                ApiKeys.set(c, s, slot, draft); editing = false; refresh++
                                Feedback.show(if (draft.isBlank()) "${slot.label} key removed" else "${slot.label} key saved ✓")
                            } }) { Text("Save") }
                            if (slot.builtIn.isNotBlank()) com.nizam.app.ui.design.OutlinedButton(onClick = { draft = slot.builtIn }) { Text("Use built-in") }
                        }
                    }
                }
            }
        }
        Text("Built-in keys come from the build's secrets (GitHub → Settings → Secrets → Actions, named ATLAS_KEY_GEMINI, " +
            "ATLAS_KEY_OPENROUTER, ATLAS_KEY_TMDB …), so they're in every new build without being written into the code.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 14.dp))
        Spacer(Modifier.height(80.dp))
    }
}
