package com.nizam.app

import android.os.Bundle
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import androidx.lifecycle.lifecycleScope
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.foundation.isSystemInDarkTheme
import com.nizam.app.data.prefs.ThemeMode
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.nizam.app.feature.backup.ShareInboxScreen
import com.nizam.app.feature.backup.sharedPayloadFrom
import com.nizam.app.feature.lock.LockScreen
import com.nizam.app.feature.notify.Notifications
import com.nizam.app.ui.nav.NizamApp
import com.nizam.app.ui.theme.NizamTheme

class MainActivity : ComponentActivity() {

    companion object {
        const val ACTION_OPEN_CURATOR = "com.nizam.app.OPEN_CURATOR"
        const val ACTION_OPEN_MUSIC = "com.nizam.app.OPEN_MUSIC"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.nizam.app.feature.security.Security.applyPrivacyScreen(this)
        enableEdgeToEdge()
        val container = (application as NizamApplication).container
        Notifications.createChannels(this)
        com.nizam.app.feature.world.Legacy.touch(this)
        val shared = sharedPayloadFrom(intent)
        val openCurator = intent?.action == ACTION_OPEN_CURATOR ||
            intent?.action == android.content.Intent.ACTION_ASSIST
        // Hands-free resumes whenever the app is opened (Android won't start a mic service from the background)
        if (com.nizam.app.feature.jarvis.WakeService.isOn(this)) com.nizam.app.feature.jarvis.WakeService.start(this)
        // offline AI: set it up once on Wi-Fi if there's none, and preload it so the first offline answer is quick
        runCatching { com.nizam.app.net.ModelHub.autoSetup(this) }
        lifecycleScope.launch { runCatching { com.nizam.app.net.ApiKeys.seed(this@MainActivity, container.settingsRepository) } }
        if (com.nizam.app.net.LocalModel.available(this)) Thread { runCatching { com.nizam.app.net.LocalModel.warm(applicationContext) } }.start()
        lifecycleScope.launch {
            com.nizam.app.feature.phone.AtlasAccessibilityService.enabledByUser =
                container.settingsRepository.screenControl.first()
        }

        setContent {
            val mode by container.settingsRepository.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
            val dark = when (mode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            val pin by container.settingsRepository.appPin.collectAsState(initial = "")
            var unlocked by remember { mutableStateOf(false) }
            // re-lock when Atlas has been in the background for more than a minute
            val lifecycle = androidx.compose.ui.platform.LocalLifecycleOwner.current.lifecycle
            androidx.compose.runtime.DisposableEffect(lifecycle) {
                var leftAt = 0L
                val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
                    if (e == androidx.lifecycle.Lifecycle.Event.ON_STOP) leftAt = System.currentTimeMillis()
                    if (e == androidx.lifecycle.Lifecycle.Event.ON_START && leftAt > 0 && System.currentTimeMillis() - leftAt > com.nizam.app.feature.security.Security.lockAfterMs(this@MainActivity)) unlocked = false
                }
                lifecycle.addObserver(obs); onDispose { lifecycle.removeObserver(obs) }
            }

            val palette by container.settingsRepository.accentHex.collectAsState(initial = "")
            val customPalette by container.settingsRepository.customPalette.collectAsState(initial = "")
            // An explicit Light/Dark choice overrides a palette of the opposite brightness, so
            // "switch to dark" never silently does nothing.
            val paletteIsLight = palette.isNotBlank() && palette != "custom" &&
                com.nizam.app.ui.theme.paletteFor(palette).surface.luminance() > 0.5f
            val effectivePalette = when {
                palette.isBlank() -> ""
                mode == ThemeMode.LIGHT && !paletteIsLight && palette != "custom" -> "paper"
                mode == ThemeMode.DARK && paletteIsLight -> "void"
                else -> palette
            }
            NizamTheme(darkTheme = dark, paletteKey = effectivePalette, customPaletteJson = customPalette) {
              // A Surface supplies background AND text colour. Screens drawn outside the Scaffold
              // (onboarding, lock, share) had neither, so their text rendered black on black.
              androidx.compose.material3.Surface(
                  modifier = androidx.compose.ui.Modifier.fillMaxSize().systemBarsPadding(),
                  color = androidx.compose.material3.MaterialTheme.colorScheme.background
              ) {
                var sharedHandled by remember { mutableStateOf(false) }
                when {
                    shared != null && !sharedHandled ->
                        ShareInboxScreen(container, shared) { sharedHandled = true }
                    pin.isNotBlank() && !unlocked ->
                        LockScreen(correctPin = pin, onUnlocked = { unlocked = true })
                    else -> NizamApp(container, startOnCurator = openCurator,
                        startRoute = if (intent?.action == ACTION_OPEN_MUSIC) com.nizam.app.ui.nav.Routes.MUSIC else null)
                }
              }
            }
        }
    }
}
