package com.nizam.app

import android.os.Bundle
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import androidx.lifecycle.lifecycleScope
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.foundation.isSystemInDarkTheme
import com.nizam.app.data.prefs.ThemeMode
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.nizam.app.feature.backup.ShareInboxScreen
import com.nizam.app.feature.backup.sharedPayloadFrom
import com.nizam.app.feature.lock.LockScreen
import com.nizam.app.feature.notify.Notifications
import com.nizam.app.ui.nav.NizamApp
import com.nizam.app.ui.theme.NizamTheme

class MainActivity : ComponentActivity() {

    companion object {
        const val ACTION_OPEN_CURATOR = "com.nizam.app.OPEN_CURATOR"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as NizamApplication).container
        Notifications.createChannels(this)
        com.nizam.app.feature.world.Legacy.touch(this)
        val shared = sharedPayloadFrom(intent)
        val openCurator = intent?.action == ACTION_OPEN_CURATOR ||
            intent?.action == android.content.Intent.ACTION_ASSIST
        lifecycleScope.launch {
            com.nizam.app.feature.phone.AtlasAccessibilityService.enabledByUser =
                container.settingsRepository.screenControl.first()
        }

        setContent {
            val mode by container.settingsRepository.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
            val dark = when (mode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            val pin by container.settingsRepository.appPin.collectAsState(initial = "")
            var unlocked by remember { mutableStateOf(false) }

            val palette by container.settingsRepository.accentHex.collectAsState(initial = "")
            val customPalette by container.settingsRepository.customPalette.collectAsState(initial = "")
            // An explicit Light/Dark choice overrides a palette of the opposite brightness, so
            // "switch to dark" never silently does nothing.
            val paletteIsLight = palette.isNotBlank() && palette != "custom" &&
                com.nizam.app.ui.theme.paletteFor(palette).surface.luminance() > 0.5f
            val effectivePalette = when {
                palette.isBlank() -> ""
                mode == ThemeMode.LIGHT && !paletteIsLight && palette != "custom" -> "paper"
                mode == ThemeMode.DARK && paletteIsLight -> "void"
                else -> palette
            }
            NizamTheme(darkTheme = dark, paletteKey = effectivePalette, customPaletteJson = customPalette) {
              // A Surface supplies background AND text colour. Screens drawn outside the Scaffold
              // (onboarding, lock, share) had neither, so their text rendered black on black.
              androidx.compose.material3.Surface(
                  modifier = androidx.compose.ui.Modifier.fillMaxSize().systemBarsPadding(),
                  color = androidx.compose.material3.MaterialTheme.colorScheme.background
              ) {
                var sharedHandled by remember { mutableStateOf(false) }
                when {
                    shared != null && !sharedHandled ->
                        ShareInboxScreen(container, shared) { sharedHandled = true }
                    pin.isNotBlank() && !unlocked ->
                        LockScreen(correctPin = pin, onUnlocked = { unlocked = true })
                    else -> NizamApp(container, startOnCurator = openCurator)
                }
              }
            }
        }
    }
}
