package com.nizam.app.feature.launcher

import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.MainActivity
import com.nizam.app.NizamApplication
import com.nizam.app.feature.phone.AtlasNotificationListener
import com.nizam.app.ui.theme.NizamTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/** Kept for older callers: the favourites list is now page one of the home screen. */
object LauncherPrefs {
    fun favourites(c: Context): List<String> = Launcher.layout(c)?.pages?.firstOrNull() ?: emptyList()
    fun setFavourites(c: Context, l: List<String>) = Unit
}

/**
 * Atlas as your phone's home screen — iOS-style pages of icons with a dock, folders and badges; a
 * widgets page; the App Library; Spotlight, Notification Center and Control Center on a swipe; your
 * themes (iOS, Pixel, Android, Nothing, Minimal, Atlas Paper); XOS and GT 50 Pro features; and Atlas
 * itself one tap (or one word) away, able to operate the phone for you.
 * Make it your default in Launcher settings, or Android Settings › Apps › Default apps › Home.
 */
class LauncherActivity : ComponentActivity() {
    val homePressed = MutableStateFlow(0)
    val appsChanged = MutableStateFlow(0)
    private var pendingWidget = -1
    val pickWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val id = r.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidget) ?: pendingWidget
        if (r.resultCode == RESULT_OK && id >= 0) configureOrAdd(id) else if (id >= 0) HomeWidgets.host(this).deleteAppWidgetId(id)
    }
    private val configure = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && pendingWidget >= 0) { HomeWidgets.add(this, "app:$pendingWidget"); appsChanged.value++ }
        else if (pendingWidget >= 0) HomeWidgets.host(this).deleteAppWidgetId(pendingWidget)
    }
    private fun configureOrAdd(id: Int) {
        pendingWidget = id
        val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
        if (info?.configure != null) runCatching {
            configure.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).setComponent(info.configure).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        }.onFailure { HomeWidgets.add(this, "app:$id"); appsChanged.value++ }
        else { HomeWidgets.add(this, "app:$id"); appsChanged.value++ }
    }
    /** Android's widget picker. */
    fun addAndroidWidget() {
        val id = HomeWidgets.host(this).allocateAppWidgetId(); pendingWidget = id
        pickWidget.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
    }

    private val pkgReceiver = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { appsChanged.value++ } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        registerReceiver(pkgReceiver, IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package") })
        val container = (application as NizamApplication).container
        setContent { NizamTheme(darkTheme = true) { LauncherRoot(this, container) } }
    }
    override fun onStart() { super.onStart(); runCatching { HomeWidgets.host(this).startListening() } }
    override fun onStop() { super.onStop(); runCatching { HomeWidgets.host(this).stopListening() } }
    override fun onDestroy() { runCatching { unregisterReceiver(pkgReceiver) }; super.onDestroy() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); homePressed.value++ }
    @Deprecated("Home stays home.")
    override fun onBackPressed() { homePressed.value++ }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherRoot(activity: LauncherActivity, container: com.nizam.app.AppContainer) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var rev by remember { mutableIntStateOf(0) }                    // bump to re-read settings
    val theme = remember(rev) { HomeThemes.current(c) }
    val cols = remember(rev) { Launcher.get(c, "cols", "4").toInt() }
    val rows = remember(rev) { Launcher.get(c, "rows", "6").toInt() }
    val iconSize = remember(rev) { Launcher.get(c, "iconSize", "60").toInt().dp }
    val perPage = cols * rows
    var apps by remember { mutableStateOf<List<LApp>>(emptyList()) }
    var layout by remember { mutableStateOf(Launcher.layout(c)) }
    val changed by activity.appsChanged.collectAsState()
    LaunchedEffect(changed) {
        val all = Launcher.apps(c); apps = all
        layout = (layout ?: Launcher.defaultLayout(c, all, perPage)).let { Launcher.reconcile(c, it, all, perPage) }.also { Launcher.save(c, it) }
    }
    fun persist(l: Launcher.Layout) { layout = l; Launcher.save(c, l) }
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val hidden = remember(rev, changed) { Launcher.hidden(c) }

    // live facts for widgets, the clock and Spotlight
    var info by remember { mutableStateOf(HomeInfo()) }
    LaunchedEffect(Unit) {
        while (true) {
            runCatching {
                val s = container.settingsRepository
                val t = com.nizam.app.feature.prayer.PrayerTimes.calculate(LocalDate.now(), s.latitude.first(), s.longitude.first(),
                    runCatching { com.nizam.app.feature.prayer.PrayerTimes.Method.valueOf(s.prayerMethod.first()) }.getOrElse { com.nizam.app.feature.prayer.PrayerTimes.Method.KARACHI },
                    s.hanafiAsr.first())
                val h = LocalTime.now().let { it.hour + it.minute / 60.0 }
                val next = listOf("Fajr" to t.fajr, "Dhuhr" to t.dhuhr, "Asr" to t.asr, "Maghrib" to t.maghrib, "Isha" to t.isha).firstOrNull { it.second > h }
                val (w, temp) = com.nizam.app.ui.design.AmbienceEngine.weather(c, s.latitude.first(), s.longitude.first())
                val tasks = container.taskRepository.all().first().filter { it.completedAt == null }.map { it.title }
                val mins = if (Controls.hasUsage(c)) Controls.recentlyUsed(c).sumOf { it.minutesToday } else 0L
                info = HomeInfo(w, temp?.let { "$it°" }.orEmpty(), next?.let { "${it.first} ${com.nizam.app.core.hourToClock(it.second)}" } ?: "Fajr tomorrow",
                    next?.let { val m = ((it.second - h) * 60).toInt(); if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m" }.orEmpty(), tasks,
                    runCatching { container.quoteRepository.all().first().randomOrNull()?.text }.getOrNull().orEmpty(), mins)
            }
            delay(60_000)
        }
    }
    // notification badges
    val notifVersion by AtlasNotificationListener.version.collectAsState()
    val badges = remember(notifVersion) { AtlasNotificationListener.active().groupingBy { it.packageName }.eachCount() }

    // panels & modes
    var panel by remember { mutableStateOf<String?>(null) }         // notifications, control, spotlight, settings, atlas
    var editing by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<String?>(null) }       // edit mode: the item being moved
    var openFolder by remember { mutableStateOf<String?>(null) }
    var menuFor by remember { mutableStateOf<LApp?>(null) }
    var atlasText by remember { mutableStateOf("") }
    val pages = layout?.pages ?: emptyList()
    val pagerState = rememberPagerState(initialPage = 1) { pages.size + 2 }     // [widgets] + pages + [library]
    val home by activity.homePressed.collectAsState()
    LaunchedEffect(home) { if (home > 0) { if (panel != null || openFolder != null || editing) { panel = null; openFolder = null; editing = false; selected = null } else pagerState.animateScrollToPage(1) } }

    fun open(app: LApp) { if (!editing) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); Launcher.launch(c, app) } }
    fun label(pkg: String) = byPkg[pkg]?.label ?: pkg

    // edit-mode moves: tap one item, then another to swap (or into a folder)
    fun tapInEdit(slot: String, pageIdx: Int, idx: Int) {
        val l = layout ?: return
        val sel = selected
        if (sel == null) { selected = slot; return }
        if (sel == slot) { selected = null; return }
        val pgs = l.pages.map { it.toMutableList() }.toMutableList(); val dock = l.dock.toMutableList()
        fun where(s: String): Pair<Int, Int>? { pgs.forEachIndexed { p, pg -> pg.indexOf(s).takeIf { it >= 0 }?.let { return p to it } }
            return dock.indexOf(s).takeIf { it >= 0 }?.let { -1 to it } }
        val a = where(sel) ?: return; val b = where(slot) ?: (pageIdx to idx)
        fun put(pos: Pair<Int, Int>, v: String) { if (pos.first == -1) dock[pos.second] = v else pgs[pos.first][pos.second] = v }
        put(a, slot); put(b, sel)
        persist(l.copy(pages = pgs, dock = dock)); selected = null
    }
    fun makeFolder(a: String, b: String) {
        val l = layout ?: return
        if (a.startsWith("folder:") || b == a) return
        val id = System.currentTimeMillis().toString()
        val members = (if (b.startsWith("folder:")) l.folders[b.removePrefix("folder:")]?.second.orEmpty() else listOf(b)) + a
        val name = byPkg[members.first()]?.category ?: "Folder"
        val folders = if (b.startsWith("folder:")) l.folders + (b.removePrefix("folder:") to (l.folders[b.removePrefix("folder:")]!!.first to members.distinct()))
            else l.folders + (id to (name to members.distinct()))
        val target = if (b.startsWith("folder:")) b else "folder:$id"
        persist(l.copy(pages = l.pages.map { pg -> pg.mapNotNull { s -> when (s) { a -> null; b -> target; else -> s } } }.filter { it.isNotEmpty() },
            dock = l.dock.filter { it != a }.map { if (it == b) target else it }, folders = folders))
        selected = null
    }

    Box(Modifier.fillMaxSize()) {
        Wallpaper(theme, rev)

        if (theme.list) MinimalHome(theme, apps.filter { it.pkg !in hidden }, pages.firstOrNull().orEmpty().mapNotNull { byPkg[it] }, info, ::open,
            onLongPress = { menuFor = it }, openSettings = { panel = "settings" }, openAtlas = { panel = "atlas" }, gestures = { panel = it })
        else Column(Modifier.fillMaxSize().systemBarsPadding()
            .pointerInput(Unit) {
                var startY = 0f; var startX = 0f; var total = 0f
                detectVerticalDragGestures(onDragStart = { startY = it.y; startX = it.x; total = 0f },
                    onDragEnd = {
                        when {
                            total > 120 && startY < size.height * 0.15f -> panel = if (startX < size.width / 2) "notifications" else "control"
                            total > 120 -> panel = "spotlight"
                            total < -160 -> scope.launch { pagerState.animateScrollToPage(pages.size + 1) }
                        }
                    }) { _, d -> total += d }
            }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { if (Launcher.get(c, "doubleTapLock", "on") == "on") Controls.lock(c) },
                onLongPress = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); editing = true }) }) {

            if (editing) Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { panel = "widgets" }) { Text("+ Widget", color = Color.White) }
                Text(if (selected != null) "Tap where it goes · or ⧉ to group" else "Tap an icon, then where it goes", color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                TextButton(onClick = { editing = false; selected = null }) { Text("Done", color = Color.White, fontWeight = FontWeight.Bold) }
            }

            HorizontalPager(pagerState, Modifier.weight(1f), beyondBoundsPageCount = 1) { page ->
                when {
                    page == 0 -> WidgetsPage(theme, editing, info, { rev++ }, { panel = "atlas" }, { panel = "widgets" })
                    page == pages.size + 1 -> AppLibrary(theme, apps.filter { it.pkg !in hidden }, badges, ::open, { menuFor = it })
                    else -> {
                        val pg = pages.getOrElse(page - 1) { emptyList() }
                        BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
                            val cellH = maxHeight / rows
                            Column {
                                pg.chunked(cols).forEachIndexed { r, rowItems ->
                                    Row(Modifier.fillMaxWidth().height(cellH)) {
                                        rowItems.forEachIndexed { ci, slot ->
                                            val idx = r * cols + ci
                                            Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                                                HomeItem(slot, byPkg, layout?.folders.orEmpty(), theme, iconSize, badges, editing, selected == slot,
                                                    onOpen = { if (editing) tapInEdit(slot, page - 1, idx) else if (slot.startsWith("folder:")) openFolder = slot.removePrefix("folder:") else byPkg[slot]?.let(::open) },
                                                    onLong = { if (!editing) byPkg[slot]?.let { menuFor = it } ?: run { editing = true } },
                                                    onRemove = { persist(layout!!.copy(pages = layout!!.pages.map { p -> p - slot }.filter { it.isNotEmpty() },
                                                        folders = if (slot.startsWith("folder:")) layout!!.folders - slot.removePrefix("folder:") else layout!!.folders)) },
                                                    onGroup = { selected?.let { makeFolder(it, slot) } })
                                            }
                                        }
                                        repeat(cols - rowItems.size) { Spacer(Modifier.weight(1f)) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // page dots
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
                repeat(pages.size + 2) { i -> Box(Modifier.padding(3.dp).size(if (i == pagerState.currentPage) 7.dp else 6.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == pagerState.currentPage) 0.95f else 0.4f))) }
            }
            // Atlas bar
            if (Launcher.get(c, "atlasBar", "on") == "on") Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(50))
                .background(theme.panel).clickable { panel = "atlas" }.padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.AutoAwesome, null, tint = theme.accent, modifier = Modifier.size(18.dp))
                Text("Ask Atlas or tell it what to do…", color = theme.onPanel.copy(alpha = 0.7f), fontFamily = theme.font, modifier = Modifier.weight(1f).padding(start = 10.dp))
                Icon(Icons.Rounded.Mic, "Speak", tint = theme.onPanel)
            }
            // dock
            if (theme.dock) Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp).clip(RoundedCornerShape(theme.corner + 6.dp))
                .background(theme.panel.copy(alpha = 0.55f)).padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                (layout?.dock ?: emptyList()).take(5).forEach { slot ->
                    HomeItem(slot, byPkg, layout?.folders.orEmpty(), theme.copy(labels = false), iconSize, badges, editing, selected == slot,
                        onOpen = { if (editing) tapInEdit(slot, -1, 0) else byPkg[slot]?.let(::open) },
                        onLong = { byPkg[slot]?.let { menuFor = it } },
                        onRemove = { persist(layout!!.copy(dock = layout!!.dock - slot, pages = layout!!.pages.let { p -> if (p.isEmpty()) listOf(listOf(slot)) else p.dropLast(1) + listOf(p.last() + slot) })) },
                        onGroup = {})
                }
            } else Spacer(Modifier.height(12.dp))
        }

        // folder overlay
        openFolder?.let { fid -> layout?.folders?.get(fid)?.let { (name, members) ->
            FolderView(fid, name, members.mapNotNull { byPkg[it] }, theme, iconSize, badges, onClose = { openFolder = null }, onOpen = ::open,
                onRename = { n -> persist(layout!!.copy(folders = layout!!.folders + (fid to (n to members)))) },
                onRemove = { pkg -> val left = members - pkg
                    persist(if (left.size <= 1) layout!!.copy(folders = layout!!.folders - fid, pages = layout!!.pages.map { p -> p.flatMap { if (it == "folder:$fid") left + pkg else listOf(it) } })
                        else layout!!.copy(folders = layout!!.folders + (fid to (name to left)), pages = layout!!.pages.let { p -> p.dropLast(1) + listOf(p.last() + pkg) }))
                    if (left.size <= 1) openFolder = null })
        } }

        // panels
        when (panel) {
            "notifications" -> NotificationCenter(theme) { panel = null }
            "control" -> ControlCenter(theme, activity) { panel = null }
            "spotlight" -> Spotlight(theme, apps.filter { it.pkg !in hidden }, ::open, { panel = null }, { q -> atlasText = q; panel = "atlas" })
            "settings" -> LauncherSettings(activity, apps, { rev++; activity.appsChanged.value++ }) { panel = null }
            "widgets" -> WidgetPicker(activity, theme, { rev++ }) { panel = null }
            "atlas" -> AtlasSheet(container, theme, atlasText) { panel = null; atlasText = "" }
        }
        menuFor?.let { app -> AppMenu(activity, app, theme, layout, onDismiss = { menuFor = null }, onLayout = { persist(it) }, onChanged = { rev++; activity.appsChanged.value++ }) }
        // top-right quick door to launcher settings while editing
        AnimatedVisibility(editing, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 140.dp)) {
            TextButton(onClick = { panel = "settings" }) { Text("Home settings", color = Color.White) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomeItem(slot: String, byPkg: Map<String, LApp>, folders: Map<String, Pair<String, List<String>>>, theme: HomeTheme, size: androidx.compose.ui.unit.Dp,
                     badges: Map<String, Int>, editing: Boolean, selected: Boolean, onOpen: () -> Unit, onLong: () -> Unit, onRemove: () -> Unit, onGroup: () -> Unit) {
    val appear = remember { androidx.compose.animation.core.Animatable(0.7f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, androidx.compose.animation.core.spring(0.6f, 400f)) }
    val angle = if (editing) androidx.compose.animation.core.rememberInfiniteTransition(label = "w").animateFloat(-2f, 2f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(120 + (slot.hashCode() and 3) * 15),
            androidx.compose.animation.core.RepeatMode.Reverse), label = "a").value else 0f
    Column(Modifier.graphicsLayer { scaleX = appear.value * if (selected) 1.12f else 1f; scaleY = scaleX; rotationZ = angle }
        .combinedClickable(onClick = onOpen, onLongClick = onLong), horizontalAlignment = Alignment.CenterHorizontally) {
        Box {
            if (slot.startsWith("folder:")) {
                val f = folders[slot.removePrefix("folder:")]
                Box(Modifier.size(size).clip(HomeThemes.shape(theme.iconShape)).background(theme.panel.copy(alpha = 0.6f)).padding(size * 0.12f)) {
                    Column(verticalArrangement = Arrangement.spacedBy(size * 0.06f)) {
                        f?.second.orEmpty().take(4).chunked(2).forEach { r -> Row(horizontalArrangement = Arrangement.spacedBy(size * 0.06f)) {
                            r.forEach { p -> byPkg[p]?.let { AppIconView(it, theme, size * 0.35f) } } } }
                    }
                }
            } else byPkg[slot]?.let { AppIconView(it, theme, size, badges[slot] ?: 0) }
            if (editing) Box(Modifier.align(Alignment.TopStart).size(20.dp).clip(CircleShape).background(Color(0xE6555555)).clickable(onClick = onRemove),
                contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Remove, "Remove from home", tint = Color.White, modifier = Modifier.size(14.dp)) }
            if (editing && selected.not()) Box(Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(Color(0xE6333333)).clickable(onClick = onGroup),
                contentAlignment = Alignment.Center) { Text("⧉", color = Color.White, fontSize = 11.sp) }
        }
        if (theme.labels) Text(if (slot.startsWith("folder:")) folders[slot.removePrefix("folder:")]?.first.orEmpty() else byPkg[slot]?.label.orEmpty(),
            color = theme.text, fontSize = 11.5.sp, fontFamily = theme.font, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 5.dp).width(size + 16.dp), textAlign = TextAlign.Center,
            style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.5f), blurRadius = 6f)))
    }
}

@Composable
private fun Wallpaper(t: HomeTheme, rev: Int) {
    val c = LocalContext.current
    val mode = remember(rev) { Launcher.get(c, "wallpaper", "system") }
    val dim = remember(rev) { Launcher.get(c, "dim", "0.15").toFloat() }
    when {
        mode == "system" -> {}
        mode == "sky" -> { Box(Modifier.fillMaxSize().background(Color(0xFF0E1320)))
            com.nizam.app.ui.design.AmbientSky(com.nizam.app.ui.design.CurrentAmbience.value ?: com.nizam.app.ui.design.Ambience(com.nizam.app.ui.design.AmbienceEngine.sky(), "clear", null,
                com.nizam.app.ui.design.AmbienceEngine.event()), Modifier.fillMaxSize(), 1f, true, animate = true) }
        mode.startsWith("color:") -> Box(Modifier.fillMaxSize().background(runCatching { Color(android.graphics.Color.parseColor(mode.removePrefix("color:"))) }.getOrDefault(Color.Black)))
        mode.startsWith("gradient:") -> { val cs = mode.removePrefix("gradient:").split(',').mapNotNull { runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull() }
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(cs.ifEmpty { listOf(Color(0xFF1B2A4A), Color(0xFF6A4C93)) }))) }
        mode.startsWith("/") -> { val bmp = remember(mode) { runCatching { android.graphics.BitmapFactory.decodeFile(mode)?.asImageBitmap() }.getOrNull() }
            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Box(Modifier.fillMaxSize().background(Color.Black)) }
    }
    if (dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
    @Suppress("UNUSED_VARIABLE") val unused = t
}

@Composable
private fun WidgetsPage(t: HomeTheme, editing: Boolean, info: HomeInfo, onChanged: () -> Unit, openAtlas: () -> Unit, addWidget: () -> Unit) {
    val c = LocalContext.current
    var list by remember { mutableStateOf(HomeWidgets.list(c)) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Spacer(Modifier.height(8.dp)) }
        items(list, key = { it }) { w -> WidgetView(w, t, editing, info, { list = HomeWidgets.list(c); onChanged() }, openAtlas) }
        item { TextButton(onClick = addWidget, modifier = Modifier.fillMaxWidth()) { Text("+ Add widget", color = Color.White) } }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun FolderView(id: String, name: String, apps: List<LApp>, t: HomeTheme, size: androidx.compose.ui.unit.Dp, badges: Map<String, Int>,
                       onClose: () -> Unit, onOpen: (LApp) -> Unit, onRename: (String) -> Unit, onRemove: (String) -> Unit) {
    var title by remember(id) { mutableStateOf(name) }
    var removing by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).clickable { onRename(title); onClose() }, contentAlignment = Alignment.Center) {
        AnimatedVisibility(true, enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()) {
            Column(Modifier.padding(28.dp).clip(RoundedCornerShape(t.corner + 8.dp)).background(t.panel).clickable(enabled = false) {}.padding(20.dp)) {
                BasicTextField(title, { title = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = t.onPanel, fontSize = 22.sp,
                    fontFamily = t.font, fontWeight = FontWeight.SemiBold), cursorBrush = SolidColor(t.accent), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                apps.chunked(3).forEach { r -> Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    r.forEach { a -> Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(size + 20.dp).clickable {
                        if (removing) onRemove(a.pkg) else onOpen(a) }) {
                        AppIconView(a, t, size, badges[a.pkg] ?: 0)
                        Text(if (removing) "remove" else a.label, color = if (removing) Color(0xFFFF453A) else t.onPanel, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } }
                    repeat(3 - r.size) { Spacer(Modifier.width(size + 20.dp)) }
                } }
                TextButton(onClick = { removing = !removing }) { Text(if (removing) "Done" else "Take apps out", color = t.accent) }
            }
        }
    }
}

/** Minimal mode: a clock, your few apps as words, everything else one swipe away. */
@Composable
private fun MinimalHome(t: HomeTheme, all: List<LApp>, favs: List<LApp>, info: HomeInfo, open: (LApp) -> Unit, onLongPress: (LApp) -> Unit,
                        openSettings: () -> Unit, openAtlas: () -> Unit, gestures: (String) -> Unit) {
    val c = LocalContext.current
    var now by remember { mutableStateOf(LocalTime.now()) }
    var drawer by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { now = LocalTime.now(); delay(15_000) } }
    val align = when (Launcher.get(c, "align", "start")) { "center" -> Alignment.CenterHorizontally; "end" -> Alignment.End; else -> Alignment.Start }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(28.dp)
        .pointerInput(Unit) { var startY = 0f; var total = 0f
            detectVerticalDragGestures(onDragStart = { startY = it.y; total = 0f }, onDragEnd = {
                when { total < -120 -> drawer = true; total > 120 && startY < size.height * 0.15f -> gestures("notifications"); total > 120 -> gestures("spotlight") } }) { _, d -> total += d } }
        .pointerInput(Unit) { detectTapGestures(onDoubleTap = { Controls.lock(c) }, onLongPress = { openSettings() }) }, horizontalAlignment = align) {
        if (!drawer) {
            Text(now.format(DateTimeFormatter.ofPattern(if (android.text.format.DateFormat.is24HourFormat(c)) "HH:mm" else "h:mm")), color = t.text, fontSize = 64.sp,
                fontFamily = t.font, fontWeight = FontWeight.Light, modifier = Modifier.clickable { Controls.alarms(c) })
            Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM")) + (if (info.temp.isNotBlank()) "  ·  ${info.temp}" else "") +
                (if (info.prayer.isNotBlank()) "  ·  ${info.prayer}" else ""), color = t.text.copy(alpha = 0.7f), fontFamily = t.font)
            Spacer(Modifier.weight(1f))
            favs.take(8).forEach { a -> Text(a.label, color = t.text, fontSize = 26.sp, fontFamily = t.font,
                modifier = Modifier.combinedClickableCompat({ open(a) }, { onLongPress(a) }).padding(vertical = 10.dp)) }
            Spacer(Modifier.weight(1f))
            Text("✦ Atlas", color = t.accent, fontFamily = t.font, modifier = Modifier.clickable(onClick = openAtlas).padding(8.dp))
        } else {
            BasicTextField(q, { q = it; all.filter { a -> a.label.contains(it, true) }.singleOrNull()?.takeIf { it2 -> it.length > 1 && Launcher.get(c, "autoOpen", "on") == "on" }?.let { a -> open(a); q = ""; drawer = false } },
                singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = t.text, fontSize = 22.sp, fontFamily = t.font), cursorBrush = SolidColor(t.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { all.firstOrNull { it.label.contains(q, true) }?.let(open) }),
                modifier = Modifier.fillMaxWidth().imePadding(), decorationBox = { inner -> if (q.isEmpty()) Text("Search apps", color = t.text.copy(alpha = 0.5f), fontSize = 22.sp); inner() })
            LazyColumn(Modifier.weight(1f).padding(top = 12.dp)) {
                items(all.filter { q.isBlank() || it.label.contains(q, true) }, key = { it.pkg + it.activity }) { a ->
                    Text(a.label, color = t.text, fontSize = 22.sp, fontFamily = t.font, modifier = Modifier.fillMaxWidth()
                        .combinedClickableCompat({ open(a); drawer = false; q = "" }, { onLongPress(a) }).padding(vertical = 10.dp))
                }
            }
            TextButton(onClick = { drawer = false; q = "" }) { Text("Close", color = t.text) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
fun Modifier.combinedClickableCompat(onClick: () -> Unit, onLong: () -> Unit) = this.combinedClickable(onClick = onClick, onLongClick = onLong)
