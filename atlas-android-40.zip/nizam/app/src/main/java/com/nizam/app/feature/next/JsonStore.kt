package com.nizam.app.feature.next

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * A small list of records kept in one JSON file on the phone. Enough for committees, debts,
 * watched prices, the capture inbox and the family board, without a database migration each time.
 * [sealed] files are encrypted with the phone's secure hardware key.
 */
class JsonStore(private val c: Context, private val name: String, private val sealed: Boolean = false) {
    private fun f() = File(c.filesDir, "$name.json")

    @Synchronized fun all(): List<JSONObject> = runCatching {
        val raw = f().readText()
        val text = if (sealed) com.nizam.app.feature.future.Sealed.openText(raw) else raw
        val a = JSONArray(text)
        (0 until a.length()).map { a.getJSONObject(it) }
    }.getOrElse { emptyList() }

    @Synchronized fun save(list: List<JSONObject>) {
        val text = JSONArray().apply { list.forEach { put(it) } }.toString()
        f().writeText(if (sealed) com.nizam.app.feature.future.Sealed.sealText(text) else text)
    }

    fun add(o: JSONObject): JSONObject {
        if (!o.has("id")) o.put("id", System.currentTimeMillis().toString() + (0..999).random())
        save(all() + o); return o
    }
    fun update(id: String, change: (JSONObject) -> Unit) = save(all().map { if (it.optString("id") == id) it.also(change) else it })
    fun remove(id: String) = save(all().filter { it.optString("id") != id })
}
