package com.nizam.app.net

import com.nizam.app.data.prefs.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

/**
 * One entry point for every AI call in the app.
 *
 * Handles the two things that actually break AI features in practice:
 *  - transient overload (HTTP 429/503/500) → exponential backoff and retry
 *  - a specific model being unavailable → fall through a chain of alternatives
 *
 * Supports Google Gemini and OpenRouter. OpenRouter's `openrouter/free` router picks a working
 * free model per request, which is the most reliable zero-cost option.
 */
object Ai {

    class MissingKeyException(message: String) : Exception(message)

    enum class Provider { GEMINI, OPENROUTER, CUSTOM }

    private const val MAX_ATTEMPTS = 4

    /** Fallbacks tried in order when the chosen model is unavailable. */
    // Tested Sep 2026: the lite models answer in ~1 s and have far bigger free allowances; "flash-latest" (3.8 Flash)
    // allows only 20 free requests a day, so it's the last resort, not the first choice.
    private val geminiChain = listOf("gemini-flash-lite-latest", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3-flash-preview", "gemini-flash-latest")
    // Concrete free model slugs first — the "openrouter/free" router is not enabled on every
    // account, and a missing slug returns 404 rather than falling back.
    private val openRouterChain = listOf(
        "deepseek/deepseek-chat-v3.1:free",
        "meta-llama/llama-3.3-70b-instruct:free",
        "qwen/qwen-2.5-72b-instruct:free",
        "google/gemma-3-27b-it:free",
        "openrouter/free"
    )

    /** Ceilings that free tiers actually accept. Asking for 32k is what made create_goal fail. */
    private const val GEMINI_CEILING = 8192
    private const val OPENROUTER_CEILING = 4096

    suspend fun generate(
        settings: SettingsRepository,
        prompt: String,
        system: String? = null,
        maxOutputTokens: Int = 1200,
        useWeb: Boolean = false
    ): String = try {
        generatePrimary(settings, prompt, system, maxOutputTokens, useWeb)
    } catch (e: Exception) {
        if (e is kotlinx.coroutines.CancellationException) throw e
        // The chosen provider is out (rate limit, outage, missing or rejected key): any other provider
        // you have a key for answers instead of the user seeing an error.
        if (e is MissingKeyException || Router.shouldFailOver(e)) failover(settings, prompt, system, maxOutputTokens, useWeb) ?: throw e
        else throw e
    }

    private suspend fun failover(
        settings: SettingsRepository, prompt: String, system: String?, maxOutputTokens: Int, useWeb: Boolean
    ): String? {
        val primary = when (settings.aiProvider.first()) { "OPENROUTER" -> "OpenRouter"; "CUSTOM" -> "Custom"; else -> "Gemini" }
        for (e in Router.endpoints(settings, null).filter { it.name != primary }) {
            val result = runCatching {
                if (e.kind == "LOCAL") LocalModel.generate(Router.appContext!!, prompt, system, maxOutputTokens)
                else if (e.kind == "FOLAX") com.nizam.app.feature.jarvis.Folax.ask(Router.appContext!!, prompt.takeLast(1500))
                else if (e.kind == "GEMINI") Gemini.raw(e.key, e.model, prompt, system, maxOutputTokens.coerceAtMost(GEMINI_CEILING), useWeb)
                else OpenRouter.raw(e.key, e.model, prompt, system, e.cap(maxOutputTokens.coerceAtMost(OPENROUTER_CEILING)),
                    endpoint = e.url, referer = e.url.contains("openrouter.ai"))
            }
            result.getOrNull()?.takeIf { it.isNotBlank() }?.let { return it }
        }
        return null
    }

    private suspend fun generatePrimary(
        settings: SettingsRepository,
        prompt: String,
        system: String?,
        maxOutputTokens: Int,
        useWeb: Boolean
    ): String {
        val provider = runCatching { Provider.valueOf(settings.aiProvider.first()) }
            .getOrElse { Provider.GEMINI }

        return when (provider) {
            Provider.GEMINI -> {
                val key = settings.geminiApiKey.first()
                if (key.isBlank()) {
                    throw MissingKeyException(
                        "No Gemini API key. Add one in Settings, or switch the provider to OpenRouter."
                    )
                }
                val preferred = settings.geminiModel.first()
                val budget = maxOutputTokens.coerceAtMost(GEMINI_CEILING)
                runChain(
                    models = listOf(preferred) + geminiChain.filter { it != preferred },
                    call = { model ->
                        try {
                            Gemini.raw(key, model, prompt, system, budget, useWeb)
                        } catch (e: Exception) {
                            // Reflexion: a rejected budget is worth one smaller attempt before
                            // giving up on the model entirely.
                            if (budget > 2048) Gemini.raw(key, model, prompt, system, 2048, useWeb)
                            else throw e
                        }
                    }
                )
            }

            Provider.CUSTOM -> {
                // Any OpenAI-compatible endpoint: Groq, Cerebras, DeepSeek, Mistral, or Ollama
                // running on your own machine. Keeps you off my choice of two providers.
                val url = settings.customUrl.first()
                if (url.isBlank()) throw MissingKeyException(
                    "No custom endpoint set. Add the base URL in Settings, e.g. " +
                        "https://api.groq.com/openai/v1"
                )
                val key = settings.customKey.first()
                val model = settings.customModel.first().ifBlank { "llama-3.3-70b-versatile" }
                runChain(
                    models = listOf(model),
                    call = { m ->
                        OpenRouter.raw(
                            apiKey = key, model = m, prompt = prompt, system = system,
                            // Groq charges declared max_tokens against its per-minute budget
                            maxOutputTokens = if (url.contains("groq.com")) maxOutputTokens.coerceAtMost(1024)
                                else maxOutputTokens.coerceAtMost(8192),
                            endpoint = url.trimEnd('/') + "/chat/completions",
                            referer = false
                        )
                    }
                )
            }

            Provider.OPENROUTER -> {
                val key = settings.openRouterKey.first()
                if (key.isBlank()) {
                    throw MissingKeyException(
                        "No OpenRouter API key. Get a free one at openrouter.ai and add it in Settings."
                    )
                }
                val preferred = settings.openRouterModel.first()
                    .takeUnless { it.isBlank() || it == "openrouter/free" } ?: ""
                val budget = maxOutputTokens.coerceAtMost(OPENROUTER_CEILING)
                runChain(
                    models = listOf(preferred) + openRouterChain.filter { it != preferred },
                    call = { model ->
                        // ":free" and ":online" cannot be stacked — that produced an invalid slug
                        // and silently broke web search. Swap the suffix instead of appending.
                        val slug = when {
                            !useWeb -> model
                            model.endsWith(":online") -> model
                            model.endsWith(":free") -> model.removeSuffix(":free") + ":online"
                            else -> "$model:online"
                        }
                        try {
                            OpenRouter.raw(key, slug, prompt, system, budget)
                        } catch (e: Exception) {
                            if (budget > 1500) OpenRouter.raw(key, slug, prompt, system, 1500)
                            else throw e
                        }
                    }
                )
            }
        }
    }

    /** Tries each model in turn; each model gets retries for transient failures. */
    private suspend fun runChain(models: List<String>, call: suspend (String) -> String): String {
        // The FIRST failure is the useful one. Reporting the last means reporting whatever the
        // final fallback said, which hides what actually went wrong on the model you chose.
        var firstError: Exception? = null
        var firstModel = ""
        for (model in models.filter { it.isNotBlank() }.distinct()) {
            var attempt = 0
            while (attempt < MAX_ATTEMPTS) {
                try {
                    return call(model)
                } catch (e: Exception) {
                    if (firstError == null) { firstError = e; firstModel = model }
                    val message = e.message.orEmpty()
                    val transient = message.contains("503") || message.contains("429") ||
                        message.contains("500") || message.contains("overloaded", true) ||
                        message.contains("UNAVAILABLE", true) || message.contains("timeout", true)
                    // A real error (bad key, bad model, bad request) means retrying is pointless —
                    // break out and let the next model in the chain have a go.
                    if (!transient) break
                    attempt++
                    if (attempt < MAX_ATTEMPTS) delay(800L * (1L shl (attempt - 1)))
                }
            }
        }
        throw friendly(firstError, firstModel)
    }

    private fun friendly(error: Exception?, model: String = ""): Exception {
        val message = error?.message.orEmpty()
        val tag = if (model.isBlank()) "" else " [$model]" 
        return when {
            message.contains("503") || message.contains("UNAVAILABLE", true) ->
                Exception(
                    "Every model is busy right now. This is the free tier under load — wait a minute, " +
                        "or switch the provider to OpenRouter in Settings."
                )
            message.contains("429") ->
                Exception("Rate limit reached for this key. Wait a few minutes, or switch provider in Settings.")
            message.contains("401") || message.contains("403") ->
                Exception(
                    "That API key was rejected. For OpenRouter, check the key is active and that " +
                        "free models are enabled in your account privacy settings."
                )
            message.contains("404") ->
                Exception(
                    "That model doesn't exist for your key. Tap \"Fetch models for my key\" in " +
                        "Settings and pick one from the list."
                )
            message.contains("402") ->
                Exception("OpenRouter says this model needs credits. Pick a model ending in :free.")
            message.contains("token", true) && message.contains("max", true) ->
                Exception("The request asked for more output than this model allows$tag. " +
                    "Atlas retries smaller automatically — if you see this, the retry failed too.")
            message.isBlank() -> Exception(
                "${error?.javaClass?.simpleName ?: "Unknown error"}$tag — no message. " +
                    "If this says NetworkOnMainThreadException, it is a bug in Atlas, not your key."
            )
            // Show the provider's own words. Guessing at causes is what sent us chasing ghosts.
            else -> Exception("$tag ${message.take(400)}")
        }
    }

    /** Strips markdown fences so model output can be parsed as JSON. */
    fun cleanJson(raw: String): String {
        var s = Compat.clean(raw)
        if (s.startsWith("```")) {
            s = s.substringAfter('\n', "")
            s = s.substringBeforeLast("```")
        }
        val start = s.indexOfFirst { it == '{' || it == '[' }
        val end = s.indexOfLast { it == '}' || it == ']' }
        return if (start >= 0 && end > start) s.substring(start, end + 1) else s
    }

    /** Model lists for the picker in Settings. */
    suspend fun listModels(settings: SettingsRepository): List<String> {
        val provider = runCatching { Provider.valueOf(settings.aiProvider.first()) }
            .getOrElse { Provider.GEMINI }
        return when (provider) {
            Provider.GEMINI -> Gemini.listModels(settings.geminiApiKey.first())
            Provider.OPENROUTER -> OpenRouter.listFreeModels()
            Provider.CUSTOM -> OpenRouter.listCustomModels(
                settings.customUrl.first(), settings.customKey.first()
            )
        }
    }
}

/** OpenRouter speaks the OpenAI chat-completions format. */
object OpenRouter {

    suspend fun raw(
        apiKey: String,
        model: String,
        prompt: String,
        system: String?,
        maxOutputTokens: Int,
        endpoint: String = "https://openrouter.ai/api/v1/chat/completions",
        referer: Boolean = true
    ): String = withContext(Dispatchers.IO) {
        val messages = JSONArray()
        if (!system.isNullOrBlank()) {
            messages.put(JSONObject().put("role", "system").put("content", system))
        }
        messages.put(JSONObject().put("role", "user").put("content", prompt))

        val body = Compat.tune(JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("max_tokens", if (Compat.reasoning(model)) (maxOutputTokens + 2048).coerceAtMost(8000) else maxOutputTokens)
            .put("temperature", 0.7), endpoint, model)
            .toString()

        val headers = mutableMapOf("Authorization" to "Bearer $apiKey")
        if (referer) {
            headers["HTTP-Referer"] = "https://github.com/atlas-app"
            headers["X-Title"] = "Atlas"
        }
        val response = Http.postJson(url = endpoint, body = body, headers = headers)
        val root = JSONObject(response)
        root.optJSONObject("error")?.let {
            throw IllegalStateException(it.optString("message", "OpenRouter error"))
        }
        val choices = root.optJSONArray("choices")
            ?: throw IllegalStateException("OpenRouter returned no choices.")
        if (choices.length() == 0) throw IllegalStateException("OpenRouter returned nothing.")
        val content = Compat.clean(choices.getJSONObject(0).optJSONObject("message")?.optString("content").orEmpty())
        if (content.isBlank()) throw IllegalStateException("The provider returned an empty message.")
        content
    }

    /** Lists models from any OpenAI-compatible endpoint. */
    suspend fun listCustomModels(baseUrl: String, apiKey: String): List<String> = withContext(Dispatchers.IO) {
        if (baseUrl.isBlank()) return@withContext emptyList()
        val response = Http.getJson(
            baseUrl.trimEnd('/') + "/models",
            if (apiKey.isBlank()) emptyMap() else mapOf("Authorization" to "Bearer $apiKey")
        )
        val data = JSONObject(response).optJSONArray("data") ?: return@withContext emptyList()
        (0 until data.length()).mapNotNull { data.getJSONObject(it).optString("id").ifBlank { null } }
    }

    /** Free models, newest first — no key needed to read the catalogue. */
    suspend fun listFreeModels(): List<String> = withContext(Dispatchers.IO) {
        val response = Http.getJson("https://openrouter.ai/api/v1/models")
        val data = JSONObject(response).optJSONArray("data") ?: return@withContext emptyList()
        val out = mutableListOf("openrouter/free")
        for (i in 0 until data.length()) {
            val m = data.getJSONObject(i)
            val id = m.optString("id")
            val pricing = m.optJSONObject("pricing")
            val promptPrice = pricing?.optString("prompt", "1") ?: "1"
            val completionPrice = pricing?.optString("completion", "1") ?: "1"
            val free = promptPrice.toDoubleOrNull() == 0.0 && completionPrice.toDoubleOrNull() == 0.0
            if (free && id.isNotBlank() && id != "openrouter/free") out.add(id)
        }
        out.distinct()
    }
}
