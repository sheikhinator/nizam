package com.nizam.app.net

import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Offline AI: a small model running on the phone itself (MediaPipe LLM Inference), used when there's
 * no internet — or when every online provider has failed. No data leaves the device.
 *
 * The model file isn't bundled (they're hundreds of MB); you import a MediaPipe `.task` model once,
 * e.g. Gemma 3 1B IT (int4) from Hugging Face's litert-community. Expect short, simple answers —
 * a 1B model is a pocket assistant, not a replacement for the online ones.
 */
object LocalModel {
    private var engine: LlmInference? = null
    private var enginePath = ""

    fun dir(c: Context) = File(c.filesDir, "models").apply { mkdirs() }

    /** Every usable model on the phone (half-finished downloads end in .part and are skipped). */
    fun models(c: Context): List<File> = dir(c).listFiles()?.filter { it.isFile && !it.name.endsWith(".part") && it.length() > 10_000_000 }
        ?.sortedBy { it.name }.orEmpty()

    fun activeName(c: Context) = c.getSharedPreferences("local_model", 0).getString("active", "").orEmpty()
    fun setActive(c: Context, name: String) = c.getSharedPreferences("local_model", 0).edit().putString("active", name).apply()

    /** The chosen model, or the first one if none was chosen. */
    fun file(c: Context): File? = models(c).let { list -> list.firstOrNull { it.name == activeName(c) } ?: list.firstOrNull() }
    fun available(c: Context) = file(c) != null
    fun describe(c: Context) = file(c)?.let { "${it.name} · ${it.length() / 1_048_576} MB" }

    @Synchronized
    fun delete(c: Context, name: String) {
        if (enginePath.endsWith("/$name")) { runCatching { engine?.close() }; engine = null; enginePath = "" }
        File(dir(c), name).delete()
    }

    /** Copies the chosen model into the app's own storage (large files: runs on IO, can take a minute). */
    suspend fun import(c: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val name = com.nizam.app.core.displayNameFor(c, uri).replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "model.task" }
        val out = File(dir(c), name)
        c.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it, 1 shl 20) } }
            ?: throw IllegalStateException("Couldn't open that file")
        if (out.length() < 10_000_000) { out.delete(); throw IllegalStateException("That doesn't look like a model file") }
        setActive(c, name)
        name
    }

    @Synchronized
    fun remove(c: Context) {
        runCatching { engine?.close() }; engine = null; enginePath = ""
        dir(c).listFiles()?.forEach { it.delete() }
    }

    /** Gemma's chat format; other instruction-tuned models cope with it too. */
    private fun format(system: String?, prompt: String) = buildString {
        append("<start_of_turn>user\n")
        if (!system.isNullOrBlank()) append(system.trim()).append("\n\n")
        append(prompt.takeLast(6000))
        append("<end_of_turn>\n<start_of_turn>model\n")
    }

    @Synchronized
    fun generate(c: Context, prompt: String, system: String?, maxTokens: Int): String {
        val f = file(c) ?: throw IllegalStateException("No offline model imported")
        if (engine == null || enginePath != f.path) {
            runCatching { engine?.close() }
            engine = LlmInference.createFromOptions(c, LlmInference.LlmInferenceOptions.builder()
                .setModelPath(f.path).setMaxTokens(maxTokens.coerceIn(512, 2048)).build())
            enginePath = f.path
        }
        return engine!!.generateResponse(format(system, prompt)).trim()
    }
}
