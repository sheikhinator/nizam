package com.nizam.app.feature.launcher

import android.app.WallpaperManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.ui.components.Feedback

/** Everything about the home screen, in one place. */
@Composable
fun LauncherSettings(activity: LauncherActivity, apps: List<LApp>, onChanged: () -> Unit, onClose: () -> Unit) {
    val c = LocalContext.current
    var v by remember { mutableIntStateOf(0) }
    fun get(k: String, d: String): String { v.hashCode(); return Launcher.get(c, k, d).ifBlank { d } }
    fun set(k: String, value: String) { Launcher.set(c, k, value); v++; onChanged() }
    val photo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching {
            val f = java.io.File(c.filesDir, "home_wallpaper.jpg")
            c.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            set("wallpaper", f.absolutePath)
        }
    }
    val systemWall = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching { c.contentResolver.openInputStream(uri)?.use { WallpaperManager.getInstance(c).setStream(it) } }
            .onSuccess { set("wallpaper", "system"); Feedback.show("Wallpaper set for home and lock screen") }
            .onFailure { Feedback.show("Couldn't set that wallpaper") }
    }
    Box(Modifier.fillMaxSize().background(Color(0xF20E0E10)).systemBarsPadding()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Home settings", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onClose) { Text("Done", color = Color(0xFF0A84FF), fontWeight = FontWeight.Bold) }
            }
            if (!Controls.isDefaultHome(c)) Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0A84FF))
                .clickable { Controls.setDefaultHome(activity) }.padding(16.dp)) { Text("Make Atlas your home screen", color = Color.White, fontWeight = FontWeight.SemiBold) }

            Section("Theme")
            Pick(HomeThemes.NAMES, get("theme", "iOS")) { set("theme", it); listOf("iconShape", "iconStyle", "accent", "labels", "dock", "layoutMode").forEach { k -> Launcher.set(c, k, "") }; v++; onChanged() }
            Text(when (get("theme", "iOS")) { "Pixel" -> "Circle icons in one colour (Material You), soft tonal panels."; "Nothing" -> "Monochrome icons, dot-matrix type, red accents."
                "Android" -> "Rounded-square icons, stock Android feel."; "Minimal" -> "No icons: a clock and your few apps as words."
                "Atlas Paper" -> "Warm paper tones, serif type, themed icons."; else -> "Squircle icons, frosted panels, a dock." },
                color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
            Section("Accent colour")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("", "#0A84FF", "#30D158", "#FF453A", "#FF9F0A", "#BF5AF2", "#64D2FF", "#D71921", "#A8C7FA", "#8A6D3B", "#FFFFFF").forEach { h ->
                    Box(Modifier.size(34.dp).clip(CircleShape).background(if (h.isBlank()) Color.DarkGray else Color(android.graphics.Color.parseColor(h)))
                        .then(if (get("accent", "") == h) Modifier.border(3.dp, Color.White, CircleShape) else Modifier).clickable { set("accent", h) },
                        contentAlignment = Alignment.Center) { if (h.isBlank()) Text("A", color = Color.White, fontSize = 12.sp) }
                }
            }
            Section("Icons")
            Pick(listOf("squircle", "circle", "rounded", "square", "teardrop"), get("iconShape", HomeThemes.current(c).iconShape)) { set("iconShape", it) }
            Pick(listOf("original", "themed", "mono"), get("iconStyle", HomeThemes.current(c).iconStyle)) { set("iconStyle", it) }
            Label("Icon size · ${get("iconSize", "60")}")
            Slider(get("iconSize", "60").toFloat(), { set("iconSize", it.toInt().toString()) }, valueRange = 44f..76f)
            Toggle("Labels under icons", get("labels", if (HomeThemes.current(c).labels) "on" else "off") == "on") { set("labels", if (it) "on" else "off") }
            Toggle("Dock", get("dock", if (HomeThemes.current(c).dock) "on" else "off") == "on") { set("dock", if (it) "on" else "off") }
            Toggle("Minimal list instead of icons", get("layoutMode", if (HomeThemes.current(c).list) "list" else "grid") == "list") { set("layoutMode", if (it) "list" else "grid") }
            Section("Grid")
            Label("Columns · ${get("cols", "4")}"); Slider(get("cols", "4").toFloat(), { set("cols", it.toInt().toString()) }, valueRange = 3f..6f, steps = 2)
            Label("Rows · ${get("rows", "6")}"); Slider(get("rows", "6").toFloat(), { set("rows", it.toInt().toString()) }, valueRange = 4f..8f, steps = 3)
            TextButton(onClick = { c.getSharedPreferences("launcher", 0).edit().remove("layout").apply(); onChanged(); Feedback.show("Home screen rearranged A–Z") }) {
                Text("Reset layout (sort all apps A–Z)", color = Color(0xFF0A84FF)) }
            Section("Wallpaper")
            Pick(listOf("system", "sky", "color:#000000", "gradient:#1B2A4A,#6A4C93", "gradient:#0F2027,#2C5364", "gradient:#F4EFE3,#D8CBB0"),
                get("wallpaper", "system").let { if (it.startsWith("/")) "photo" else it },
                labels = { when { it == "system" -> "Phone's"; it == "sky" -> "Living sky"; it.startsWith("color") -> "Black"; it.contains("1B2A4A") -> "Dusk"
                    it.contains("0F2027") -> "Ocean"; it.contains("F4EFE3") -> "Paper"; else -> it } }) { set("wallpaper", it) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { photo.launch("image/*") }) { Text("Photo for Atlas home", color = Color(0xFF0A84FF)) }
                TextButton(onClick = { systemWall.launch("image/*") }) { Text("Set phone wallpaper", color = Color(0xFF0A84FF)) }
            }
            Label("Dim · ${(get("dim", "0.15").toFloat() * 100).toInt()}%"); Slider(get("dim", "0.15").toFloat(), { set("dim", "%.2f".format(it)) }, valueRange = 0f..0.7f)
            Section("Gestures & behaviour")
            Toggle("Double-tap to lock", get("doubleTapLock", "on") == "on") { set("doubleTapLock", if (it) "on" else "off") }
            Toggle("Atlas bar on the home screen", get("atlasBar", "on") == "on") { set("atlasBar", if (it) "on" else "off") }
            Toggle("Let Atlas act without asking (from home)", get("atlasAuto", "on") == "on") { set("atlasAuto", if (it) "on" else "off") }
            Toggle("Minimal: open an app when search finds just one", get("autoOpen", "on") == "on") { set("autoOpen", if (it) "on" else "off") }
            Pick(listOf("start", "center", "end"), get("align", "start"), labels = { it.replaceFirstChar { c -> c.uppercase() } }) { set("align", it) }
            Text("Swipe down: Spotlight · from the top-left: notifications · top-right: Control Center · swipe up: App Library · long-press: edit",
                color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            Section("Permissions that unlock more")
            Perm("Notifications in Notification Center & badges", com.nizam.app.feature.phone.AtlasNotificationListener.connected) {
                c.startActivity(android.content.Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
            Perm("Screen time & running apps", Controls.hasUsage(c)) { Controls.askUsage(c) }
            Perm("Lock, screenshot, recents & Atlas using apps for you", com.nizam.app.feature.phone.AtlasAccessibilityService.instance != null) {
                c.startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
            Perm("Brightness & rotation from Control Center", Controls.canWriteSettings(c)) { Controls.setBrightness(c, Controls.brightness(c)) }
            Section("Hidden apps")
            val hidden = remember(v) { Launcher.hidden(c) }
            if (hidden.isEmpty()) Text("None. Long-press any app › Hide.", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
            hidden.forEach { p -> Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(apps.firstOrNull { it.pkg == p }?.label ?: p, color = Color.White, modifier = Modifier.weight(1f))
                TextButton(onClick = { Launcher.setHidden(c, p, false); v++; onChanged() }) { Text("Show", color = Color(0xFF0A84FF)) } } }
            Section("XOS & GT 50 Pro")
            Xos.features(c).take(24).chunked(3).forEach { r -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                r.forEach { f -> Text(f.label, color = Color.White, fontSize = 13.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF2C2C2E))
                    .clickable { runCatching { c.startActivity(f.intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } }.padding(horizontal = 12.dp, vertical = 8.dp)) } } }
            TextButton(onClick = { c.startActivity(android.content.Intent(c, com.nizam.app.MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                Text("Open Atlas", color = Color(0xFF0A84FF)) }
            Spacer(Modifier.height(60.dp))
        }
    }
}

@Composable private fun Section(t: String) = Text(t, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
@Composable private fun Label(t: String) = Text(t, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

@Composable
private fun Pick(options: List<String>, selected: String, labels: (String) -> String = { it.replaceFirstChar { c -> c.uppercase() } }, onPick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o -> Text(labels(o), color = if (o == selected) Color.Black else Color.White, fontSize = 14.sp,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(if (o == selected) Color.White else Color(0xFF2C2C2E)).clickable { onPick(o) }.padding(horizontal = 14.dp, vertical = 8.dp)) }
    }
}

@Composable
private fun Toggle(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(on, onChange)
    }
}

@Composable
private fun Perm(label: String, ok: Boolean, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text((if (ok) "✓  " else "○  ") + label, color = if (ok) Color(0xFF30D158) else Color.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
        if (!ok) TextButton(onClick = onFix) { Text("Allow", color = Color(0xFF0A84FF)) }
    }
}
