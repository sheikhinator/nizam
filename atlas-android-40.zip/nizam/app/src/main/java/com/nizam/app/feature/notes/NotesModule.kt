package com.nizam.app.feature.notes

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import com.nizam.app.ui.design.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.nizam.app.ui.design.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.vmFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@Entity(tableName = "note")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String = "",
    val pinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM note ORDER BY pinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<Note>>

    @Query("SELECT * FROM note WHERE title LIKE '%' || :q || '%' OR body LIKE '%' || :q || '%' ORDER BY updatedAt DESC")
    fun search(q: String): Flow<List<Note>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: Note): Long

    @Update
    suspend fun update(note: Note)

    @Delete
    suspend fun delete(note: Note)
}

class NoteRepository(private val dao: NoteDao) {
    fun all() = dao.observeAll()
    fun search(q: String) = dao.search(q)
    suspend fun create(title: String): Long = dao.insert(Note(title = title.trim()))
    suspend fun createFull(title: String, body: String): Long =
        dao.insert(Note(title = title.trim(), body = body))
    suspend fun save(note: Note) = dao.update(note.copy(updatedAt = System.currentTimeMillis()))
    suspend fun remove(note: Note) = dao.delete(note)
}

/** Extracts [[wikilinks]] from a note body. */
fun wikilinksIn(body: String): List<String> =
    Regex("\\[\\[([^\\]]+)]]").findAll(body).map { it.groupValues[1].trim() }.toList()

class NotesViewModel(private val repository: NoteRepository) : ViewModel() {
    val notes: StateFlow<List<Note>> = repository.all()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun create(title: String) {
        if (title.isBlank()) return
        viewModelScope.launch { repository.create(title) }
    }
    fun save(note: Note) = viewModelScope.launch { repository.save(note) }
    fun delete(note: Note) = viewModelScope.launch { repository.remove(note) }
}

@Composable
fun NotesScreen(container: AppContainer) {
    val vm: NotesViewModel = viewModel(factory = vmFactory { NotesViewModel(container.noteRepository) })
    val notes by vm.notes.collectAsState()

    var draft by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var openId by remember { mutableStateOf<Long?>(null) }

    val open = notes.firstOrNull { it.id == openId }

    if (open != null) {
        NoteEditor(
            note = open,
            allNotes = notes,
            onBack = { openId = null },
            onSave = { vm.save(it) },
            onDelete = { vm.delete(it); openId = null },
            onOpenLink = { title ->
                val target = notes.firstOrNull { it.title.equals(title, ignoreCase = true) }
                if (target != null) openId = target.id else vm.create(title)
            }
        )
        return
    }

    val visible = if (query.isBlank()) notes
    else notes.filter { it.title.contains(query, true) || it.body.contains(query, true) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        ModuleTitle("Notes", "Markdown, [[wikilinks]] and backlinks")

        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("Search notes") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = draft, onValueChange = { draft = it },
                label = { Text("New note title") }, singleLine = true, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.create(draft); draft = "" }) { Text("Add") }
        }

        Spacer(Modifier.height(12.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)

        if (visible.isEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(
                "No notes yet — create one above. Link notes by typing [[Another note]] in the body.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Column(Modifier.fillMaxWidth()) {
                visible.forEach { note ->
                    Column(
                        Modifier.fillMaxWidth().clickable { openId = note.id }.padding(vertical = 10.dp)
                    ) {
                        Text(note.title, style = MaterialTheme.typography.bodyLarge)
                        if (note.body.isNotBlank()) {
                            Text(
                                note.body.take(90).replace("\n", " "),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun NoteEditor(
    note: Note,
    allNotes: List<Note>,
    onBack: () -> Unit,
    onSave: (Note) -> Unit,
    onDelete: (Note) -> Unit,
    onOpenLink: (String) -> Unit
) {
    var title by remember(note.id) { mutableStateOf(note.title) }
    var body by remember(note.id) { mutableStateOf(note.body) }

    val links = wikilinksIn(body)
    val backlinks = allNotes.filter { other ->
        other.id != note.id && wikilinksIn(other.body).any { it.equals(note.title, true) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                onSave(note.copy(title = title, body = body))
                onBack()
            }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back to notes") }
            Text("Editing", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = { onDelete(note) }) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete note")
            }
        }

        OutlinedTextField(
            value = title, onValueChange = { title = it },
            label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = body, onValueChange = { body = it },
            label = { Text("Body (markdown)") },
            modifier = Modifier.fillMaxWidth().height(260.dp)
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = { onSave(note.copy(title = title, body = body)) }) { Text("Save note") }

        if (links.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("Links", style = MaterialTheme.typography.titleMedium)
            links.distinct().forEach { link ->
                Text(
                    link,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable(role = Role.Button) { onOpenLink(link) }.padding(vertical = 4.dp)
                )
            }
        }

        if (backlinks.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("Linked mentions", style = MaterialTheme.typography.titleMedium)
            backlinks.forEach { b ->
                Text(
                    b.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}
