package com.nizam.app.feature.podcasts

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.nizam.app.core.ChipRow
import com.nizam.app.core.ModuleTitle
import com.nizam.app.ui.theme.DisplayFamily
import com.nizam.app.ui.theme.MonoNumber
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Where the app hands a show to its detail screen. */
object PodcastNav { var feed: String = ""; var title: String = "" }

private fun clock(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0); return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun Art(url: String?, title: String, modifier: Modifier = Modifier) {
    Box(modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center) {
        if (url != null) AsyncImage(url, title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Text("🎙", style = MaterialTheme.typography.headlineMedium)
    }
}

@Composable
fun PodcastsScreen(onShow: (String, String) -> Unit, onOpenPlayer: () -> Unit) {
    val c = LocalContext.current
    val scope = remember { kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob()) }
    val store = remember { PodcastStore(c) }
    var tab by remember { mutableStateOf("Listening") }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Show>>(emptyList()) }
    var charts by remember { mutableStateOf<List<Show>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    LaunchedEffect(tab) {
        if (tab == "Discover" && charts.isEmpty()) {
            busy = true; charts = runCatching { PodcastDirectory.charts("pk") }.getOrElse { emptyList() }; busy = false
        }
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 18.dp)) {
            ModuleTitle("Podcasts", "Subscribe, download, and listen with the screen off")
            ChipRow(listOf("Listening", "Shows", "Discover", "Up Next", "Downloads"), tab, { tab = it })
        }
        Box(Modifier.weight(1f).padding(horizontal = 18.dp)) {
            when (tab) {
                "Listening" -> {
                    val inProgress = remember(refresh) { store.inProgress() }
                    val starred = remember(refresh) { store.starred() }
                    LazyColumn {
                        if (inProgress.isEmpty()) item { Text("Nothing on the go. Find a show in Discover and press play.",
                            style = MaterialTheme.typography.bodyMedium) }
                        items(inProgress) { p ->
                            val ep = Episode(p.optString("id"), p.optString("feed"), p.optString("show"), p.optString("title"),
                                p.optString("audio"), "", (p.optLong("dur") / 1000).toInt(), "", p.optString("image").ifBlank { null })
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable(role = Role.Button) {
                                Playback.start(c, ep, store); refresh++
                            }) {
                                Art(ep.image, ep.show, Modifier.size(64.dp))
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(ep.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                    Text(ep.show, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    LinearProgressIndicator(progress = { (p.optLong("pos").toFloat() / p.optLong("dur").coerceAtLeast(1)) },
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                                    Text("${clock(p.optLong("dur") - p.optLong("pos"))} left", style = MonoNumber)
                                }
                            }
                        }
                        if (starred.isNotEmpty()) item { Text("${starred.size} starred episodes", style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(top = 12.dp)) }
                    }
                }
                "Shows" -> {
                    val shows = remember(refresh) { store.shows() }
                    if (shows.isEmpty()) Text("No subscriptions yet.", style = MaterialTheme.typography.bodyMedium)
                    LazyColumn {
                        items(shows) { s ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable(role = Role.Button) { onShow(s.feed, s.title) }) {
                                Art(s.image, s.title, Modifier.size(64.dp)); Spacer(Modifier.width(12.dp))
                                Column { Text(s.title, style = MaterialTheme.typography.bodyLarge, maxLines = 2)
                                    Text(s.author, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            }
                        }
                    }
                }
                "Discover" -> LazyColumn {
                    item {
                        OutlinedTextField(query, { query = it }, singleLine = true, label = { Text("Search podcasts") },
                            modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                scope.launch { busy = true; results = runCatching { PodcastDirectory.search(query) }.getOrElse { emptyList() }; busy = false }
                            }))
                        if (busy) Text("Searching…", style = MaterialTheme.typography.labelMedium)
                        if (results.isEmpty() && charts.isNotEmpty()) Text("TOP IN PAKISTAN", style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(top = 10.dp))
                    }
                    items(results.ifEmpty { charts }) { s ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable(role = Role.Button) {
                            scope.launch { val full = runCatching { PodcastDirectory.resolve(s) }.getOrElse { s }
                                if (full.feed.startsWith("http")) onShow(full.feed, full.title) }
                        }) {
                            Art(s.image, s.title, Modifier.size(64.dp)); Spacer(Modifier.width(12.dp))
                            Column { Text(s.title, style = MaterialTheme.typography.bodyLarge, maxLines = 2)
                                Text(listOf(s.author, s.description).filter { it.isNotBlank() }.joinToString(" · "), maxLines = 1,
                                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
                "Up Next" -> {
                    var queue by remember(refresh) { mutableStateOf(store.queue()) }
                    LazyColumn {
                        if (queue.isEmpty()) item { Text("Up Next is empty. Add episodes from any show.", style = MaterialTheme.typography.bodyMedium) }
                        items(queue) { ep ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Art(ep.image, ep.show, Modifier.size(52.dp)); Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(ep.title, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                                    Text(ep.show, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(">", modifier = Modifier.clickable(role = Role.Button) { Playback.start(c, ep, store); refresh++ }.padding(6.dp))
                                Text("✕", color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.clickable(role = Role.Button) { queue = queue - ep; store.setQueue(queue) }.padding(6.dp))
                            }
                        }
                    }
                }
                else -> {
                    val files = remember(refresh) { store.downloads() }
                    LazyColumn {
                        item { Text("${files.size} downloaded · ${files.sumOf { it.length() } / 1_048_576} MB",
                            style = MaterialTheme.typography.bodyMedium) }
                        items(files) { f ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(f.name, Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                Text("delete", color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.clickable(role = Role.Button) { f.delete(); refresh++ })
                            }
                        }
                    }
                }
            }
        }
        NowPlaying(onOpenPlayer)
    }
}

/** The bar that follows you around the podcast screens. Reads playback state; does no work itself. */
@Composable
fun NowPlaying(onOpenPlayer: () -> Unit = {}) {
    val ep = Playback.current ?: return
    val pos = Playback.positionMs
    val dur = if (Playback.durationMs > 0) Playback.durationMs else ep.durationSec * 1000L
    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
        modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.clickable(role = Role.Button) { onOpenPlayer() }.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Art(ep.image, ep.show, Modifier.size(44.dp)); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(ep.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                    Text(if (Playback.buffering) "buffering…" else "${clock(pos)} / ${clock(dur)}", style = MonoNumber)
                }
                Text(if (Playback.isPlaying) "⏸" else ">", fontSize = 26.sp,
                    modifier = Modifier.clickable(role = Role.Button) { Playback.toggle() }.padding(8.dp))
            }
            LinearProgressIndicator(progress = { (pos.toFloat() / dur.coerceAtLeast(1)) }, modifier = Modifier.fillMaxWidth())
        }
    }
}

/** The full player, on its own screen so nothing is clipped by the tab bar. */
@Composable
fun PodcastPlayerScreen() {
    val c = LocalContext.current
    val scope = remember { kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob()) }
    val store = remember { PodcastStore(c) }
    val ep = Playback.current
    if (ep == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nothing playing") }; return }
    val pos = Playback.positionMs
    val dur = if (Playback.durationMs > 0) Playback.durationMs else ep.durationSec * 1000L
    var note by remember(ep.id) { mutableStateOf("") }
    var marks by remember(ep.id) { mutableStateOf(store.bookmarks(ep.id)) }
    var summary by remember(ep.id) { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var scrub by remember { mutableStateOf<Float?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(8.dp))
        Art(ep.image, ep.show, Modifier.fillMaxWidth(0.72f).align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(16.dp))
        Text(ep.title, style = MaterialTheme.typography.titleLarge, maxLines = 3)
        Text(ep.show, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        androidx.compose.material3.Slider(
            value = scrub ?: pos.toFloat(),
            valueRange = 0f..dur.coerceAtLeast(1L).toFloat(),
            onValueChange = { scrub = it },
            onValueChangeFinished = { scrub?.let { Playback.seekTo(it.toLong()) }; scrub = null },
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(clock((scrub ?: pos.toFloat()).toLong()), style = MonoNumber)
            Text("-${clock(dur - (scrub ?: pos.toFloat()).toLong())}", style = MonoNumber)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            Text("⏮ 15", fontSize = 20.sp, modifier = Modifier.clickable(role = Role.Button) { Playback.skip(-15) }.padding(12.dp))
            Text(if (Playback.isPlaying) "⏸" else ">", fontSize = 44.sp,
                modifier = Modifier.clickable(role = Role.Button) { Playback.toggle() }.padding(12.dp))
            Text("30 ⏭", fontSize = 20.sp, modifier = Modifier.clickable(role = Role.Button) { Playback.skip(30) }.padding(12.dp))
        }
        if (Playback.buffering) Text("buffering…", style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))

        Text("SPEED", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp))
        ChipRow(listOf("0.8", "1.0", "1.2", "1.5", "1.8", "2.0"), "%.1f".format(Playback.speed), { v ->
            Playback.applySpeed(v.toFloat()); store.setShowSpeed(ep.feed, v.toFloat())
            com.nizam.app.ui.components.Feedback.show("Speed ${v}× — saved for ${ep.show.take(24)}")
        }, labels = { "${it}×" })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
            OutlinedButton(onClick = {
                Playback.setTrim(!Playback.trimSilence)
                com.nizam.app.ui.components.Feedback.show(if (Playback.trimSilence) "Trimming silence" else "Trim silence off")
            }) { Text(if (Playback.trimSilence) "✓ Trim silence" else "Trim silence") }
            OutlinedButton(onClick = {
                Playback.applyBoost(!Playback.boost)
                com.nizam.app.ui.components.Feedback.show(if (Playback.boost) "Volume boosted" else "Volume normal")
            }) { Text(if (Playback.boost) "✓ Boost" else "Boost") }
        }
        Text("SLEEP" + if (Playback.sleepMinutesLeft > 0) " · ${Playback.sleepMinutesLeft} min left" else "",
            style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 10.dp))
        ChipRow(listOf("0", "5", "15", "30", "60", "end"), "${Playback.sleepMinutesLeft}", { v ->
            if (v == "end") { Playback.sleepAtEpisodeEnd(scope); com.nizam.app.ui.components.Feedback.show("Will pause at the end of this episode") }
            else { Playback.sleep(v.toInt(), scope); com.nizam.app.ui.components.Feedback.show(if (v == "0") "Sleep timer off" else "Sleeping in $v min") }
        }, labels = { if (it == "0") "Off" else if (it == "end") "End of episode" else "$it min" })

        Text("BOOKMARK THIS MOMENT", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(note, { note = it }, singleLine = true, label = { Text("Note (optional)") }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                store.addBookmark(ep.id, pos, note); marks = store.bookmarks(ep.id); note = ""
                com.nizam.app.ui.components.Feedback.show("Bookmarked at ${clock(pos)}")
            }) { Text("★ ${clock(pos)}") }
        }
        marks.forEach { (at, text) ->
            Row(Modifier.fillMaxWidth().clickable(role = Role.Button) { Playback.seekTo(at) }.padding(vertical = 6.dp)) {
                Text(clock(at), style = MonoNumber, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp)); Text(text.ifBlank { "bookmark" }, style = MaterialTheme.typography.bodyMedium)
            }
        }
        OutlinedButton(enabled = !busy, onClick = {
            scope.launch {
                busy = true
                com.nizam.app.ui.components.Feedback.show("Reading the show notes…")
                runCatching {
                    com.nizam.app.net.Ai.generate(
                        (c.applicationContext as com.nizam.app.NizamApplication).container.settingsRepository,
                        "Podcast: ${ep.show}\nEpisode: ${ep.title}\nShow notes: ${ep.description.take(6000)}\n\n" +
                            "Give the key points, who it's for, and three things worth remembering. If the notes are too thin " +
                            "to be sure, say so rather than inventing content.", maxOutputTokens = 900)
                }.onSuccess { text ->
                    summary = text
                    (c.applicationContext as com.nizam.app.NizamApplication).container.noteRepository
                        .createFull("Podcast: ${ep.title}", text + "\n\n" + ep.show)
                    com.nizam.app.ui.components.Feedback.show("Summary saved to Notes")
                }.onFailure { com.nizam.app.ui.components.Feedback.failed("Summary", it) }
                busy = false
            }
        }, modifier = Modifier.padding(top = 10.dp)) { Text(if (busy) "Reading…" else "✦ Summarise this episode") }
        summary?.let { text ->
            Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    // auto-flashcards from what the episode actually taught
                    scope.launch {
                        val container = (c.applicationContext as com.nizam.app.NizamApplication).container
                        runCatching {
                            val cards = com.nizam.app.net.Ai.generate(container.settingsRepository,
                                "From this episode summary, write up to 6 flashcards that test understanding.\n" +
                                    "Return ONLY JSON [{\"front\":\"...\",\"back\":\"...\"}]\n\n$text", maxOutputTokens = 800)
                            val arr = org.json.JSONArray(com.nizam.app.net.Ai.cleanJson(cards))
                            val spec = container.dynamicRepository.spec("vocab")
                            val backKey = spec?.fields?.firstOrNull { it.type == "TEXT" || it.type == "LONGTEXT" }?.key
                            var n = 0
                            for (i in 0 until arr.length()) {
                                val card = arr.getJSONObject(i)
                                if (spec != null && backKey != null) {
                                    container.dynamicRepository.addEntry("vocab", card.optString("front"),
                                        mapOf(backKey to card.optString("back"))); n++
                                }
                            }
                            com.nizam.app.ui.components.Feedback.show("$n flashcards saved")
                        }.onFailure { com.nizam.app.ui.components.Feedback.failed("Flashcards", it) }
                    }
                }) { Text("Make flashcards") }
                OutlinedButton(onClick = {
                    com.nizam.app.feature.reflect.shareCard(c, ep.title.take(40),
                        listOf(ep.show, "at ${clock(pos)}", "") + text.lines().filter { it.isNotBlank() }.take(6))
                }) { Text("Share a clip card") }
            }
        }

        // ── Ask this episode ──
        var question by remember(ep.id) { mutableStateOf("") }
        var answer by remember(ep.id) { mutableStateOf<String?>(null) }
        Text("ASK THIS EPISODE", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(question, { question = it }, label = { Text("What did they say about…?") }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Button(enabled = question.isNotBlank() && !busy, onClick = {
                scope.launch {
                    busy = true
                    answer = runCatching {
                        com.nizam.app.net.Ai.generate(
                            (c.applicationContext as com.nizam.app.NizamApplication).container.settingsRepository,
                            "Episode: ${ep.title} from ${ep.show}\nShow notes: ${ep.description.take(8000)}\n" +
                                "Your bookmarks: " + marks.joinToString { "${clock(it.first)}: ${it.second}" } +
                                "\n\nQuestion: ${question.trim()}\n\nAnswer from the notes. If the notes don't cover it, " +
                                "say so plainly rather than guessing — you don't have the audio.", maxOutputTokens = 700)
                    }.getOrElse { "Couldn't answer: " + com.nizam.app.ui.components.Feedback.friendly(it) }
                    busy = false
                }
            }) { Text("Ask") }
        }
        answer?.let { Text(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp)) }
        val (listened, saved) = remember(Playback.current) { store.stats() }
        if (listened > 0) Text("Listened ${listened / 3600}h · speed saved you ${saved / 3600}h",
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(50.dp))
    }
}

/** A show and its episodes. */
@Composable
fun PodcastShowScreen(onOpenPlayer: () -> Unit) {
    val c = LocalContext.current
    val scope = remember { kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob()) }
    val store = remember { PodcastStore(c) }
    var show by remember { mutableStateOf<Show?>(null) }
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("All") }
    var subscribed by remember { mutableStateOf(store.subscribed(PodcastNav.feed)) }
    var refresh by remember { mutableStateOf(0) }
    LaunchedEffect(PodcastNav.feed) {
        runCatching { Rss.load(PodcastNav.feed) }.onSuccess { (s, eps) -> show = s; episodes = eps }
            .onFailure { error = "Couldn't read this feed: ${com.nizam.app.ui.components.Feedback.friendly(it)}" }
    }
    val s = show
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.verticalScroll(rememberScrollState()).weight(1f).padding(horizontal = 18.dp)) {
            if (s == null) { Text(error ?: "Loading…", Modifier.padding(20.dp)); return@Column }
            Row(Modifier.padding(top = 10.dp)) {
                Art(s.image, s.title, Modifier.size(110.dp)); Spacer(Modifier.width(14.dp))
                Column {
                    Text(s.title, style = MaterialTheme.typography.titleLarge.copy(fontFamily = DisplayFamily), maxLines = 3)
                    Text(s.author, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${episodes.size} episodes", style = MonoNumber)
                    Button(onClick = {
                        store.toggle(s); subscribed = store.subscribed(s.feed)
                        com.nizam.app.ui.components.Feedback.show(if (subscribed) "Subscribed" else "Unsubscribed")
                    }, modifier = Modifier.padding(top = 6.dp)) {
                        Text(if (subscribed) "✓ Subscribed" else "＋ Subscribe")
                    }
                    if (subscribed) {
                        var auto by remember(s.feed) { mutableStateOf(store.autoDownload(s.feed)) }
                        Text(if (auto) "✓ Auto-download on Wi-Fi" else "Auto-download off",
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable(role = Role.Button) {
                                store.toggleAutoDownload(s.feed); auto = store.autoDownload(s.feed)
                                com.nizam.app.ui.components.Feedback.show(if (auto) "New episodes will download on Wi-Fi" else "Auto-download off")
                            }.padding(top = 6.dp))
                    }
                }
            }
            if (s.description.isNotBlank()) Text(s.description.take(400), style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 10.dp))
            ChipRow(listOf("All", "Unplayed", "In progress", "Starred"), filter, { filter = it })
            val starred = remember(refresh) { store.starred() }
            val visible = episodes.filter {
                when (filter) {
                    "Unplayed" -> !store.played(it.id) && store.position(it.id) == 0L
                    "In progress" -> store.position(it.id) > 30_000 && !store.played(it.id)
                    "Starred" -> it.id in starred
                    else -> true
                }
            }
            visible.take(120).forEach { ep ->
                val pos = store.position(ep.id); val played = store.played(ep.id)
                Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Text(ep.title, style = MaterialTheme.typography.bodyLarge, maxLines = 2,
                        color = if (played) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                    Text(listOf(ep.published, if (ep.durationSec > 0) clock(ep.durationSec * 1000L) else "",
                        if (played) "played" else if (pos > 0) "${clock(pos)} in" else "").filter { it.isNotBlank() }.joinToString(" · "),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("> Play", color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable(role = Role.Button) { Playback.start(c, ep, store); refresh++ }.padding(vertical = 4.dp))
                        Text("+ Up Next", modifier = Modifier.clickable(role = Role.Button) { store.enqueue(ep, next = true) }.padding(vertical = 4.dp))
                        Text(if (ep.id in starred) "★" else "☆", modifier = Modifier.clickable(role = Role.Button) { store.star(ep.id); refresh++ }.padding(vertical = 4.dp))
                        Text(if (store.downloaded(ep) != null) "downloaded" else "⤓ Download",
                            modifier = Modifier.clickable(role = Role.Button) {
                                scope.launch { runCatching { store.download(ep) }; refresh++ }
                            }.padding(vertical = 4.dp))
                    }
                    if (ep.description.isNotBlank()) Text(ep.description.take(220), style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(30.dp))
        }
        NowPlaying(onOpenPlayer)
    }
}


