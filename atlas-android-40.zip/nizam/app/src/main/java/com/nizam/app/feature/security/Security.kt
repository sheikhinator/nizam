package com.nizam.app.feature.security

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Debug
import android.provider.Settings
import android.view.WindowManager
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nizam.app.core.ChipRow
import com.nizam.app.core.ModuleTitle
import com.nizam.app.ui.design.Group
import com.nizam.app.ui.design.Label
import java.io.File

/**
 * Atlas's privacy and security: what protects your data, what's weak on this phone, and the switches
 * you control — the privacy screen (no screenshots, blank in recent apps) and how soon Atlas re-locks.
 *
 * Built in regardless: no cloud or device-transfer backup of any Atlas data; only the phone's own trusted
 * certificates are accepted (no user-installed ones, so traffic can't be quietly intercepted); keys and
 * data live in Atlas's private storage, which Android encrypts on disk whenever the phone has a screen lock.
 */
object Security {
    private fun p(c: Context) = c.getSharedPreferences("security", 0)
    fun privacyScreen(c: Context) = p(c).getBoolean("privacy_screen", false)
    fun setPrivacyScreen(c: Context, on: Boolean) = p(c).edit().putBoolean("privacy_screen", on).apply()
    fun lockAfterMs(c: Context) = p(c).getLong("lock_after", 60_000L)
    fun setLockAfter(c: Context, ms: Long) = p(c).edit().putLong("lock_after", ms).apply()

    fun applyPrivacyScreen(a: Activity) {
        if (privacyScreen(a)) a.window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else a.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    data class Check(val ok: Boolean, val title: String, val detail: String)

    fun checks(c: Context): List<Check> {
        val km = c.getSystemService(KeyguardManager::class.java)
        val rooted = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk", "/data/local/xbin/su")
            .any { File(it).exists() } || Build.TAGS?.contains("test-keys") == true
        val unknownAccess = runCatching {
            Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                .split(':').filter { it.isNotBlank() && !it.startsWith(c.packageName) }
        }.getOrElse { emptyList() }
        val adb = runCatching { Settings.Global.getInt(c.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1 }.getOrDefault(false)
        return listOf(
            Check(km.isDeviceSecure, "Screen lock", if (km.isDeviceSecure) "On — Android encrypts Atlas's data on disk with it."
                else "Off — set a PIN or pattern so your data is encrypted at rest and the phone can't just be opened."),
            Check(true, "No cloud backup", "Nothing of Atlas is copied to Google backup or transferred to another phone."),
            Check(true, "Trusted connections only", "Only the phone's built-in certificates are trusted; user-installed ones can't intercept Atlas."),
            Check(!rooted, "Device integrity", if (rooted) "This phone looks rooted — any app with root can read Atlas's private files." else "No signs of root."),
            Check(!Debug.isDebuggerConnected(), "No debugger attached", if (Debug.isDebuggerConnected()) "A debugger is attached to Atlas right now." else "Nothing is attached to Atlas."),
            Check(!adb, "USB debugging", if (adb) "On — a computer you've allowed can read the phone. Turn it off in Developer options when you're not using it." else "Off."),
            Check(unknownAccess.isEmpty(), "Other apps reading the screen",
                if (unknownAccess.isEmpty()) "Only Atlas has screen-reading access." else "These can read everything on screen: " +
                    unknownAccess.joinToString { it.substringBefore('/') }),
        )
    }
}

/** Settings › Privacy & security. */
@Composable
fun SecurityScreen() {
    val c = LocalContext.current
    var privacy by remember { mutableStateOf(Security.privacyScreen(c)) }
    var lockAfter by remember { mutableStateOf(Security.lockAfterMs(c)) }
    val checks = remember { Security.checks(c) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        ModuleTitle("Privacy & security", "${checks.count { it.ok }} of ${checks.size} protections in place")
        Group {
            checks.forEach { ch ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
                    Icon(if (ch.ok) Icons.Rounded.CheckCircle else Icons.Rounded.Warning, null, Modifier.size(20.dp),
                        tint = if (ch.ok) Color(0xFF3DAA6D) else Color(0xFFE0A030))
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(ch.title, style = MaterialTheme.typography.titleSmall)
                        Text(ch.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Label("Privacy screen", Modifier.padding(top = 16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Block screenshots and hide Atlas in recent apps. Applies next time Atlas opens.", style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f))
            Switch(privacy, { privacy = it; Security.setPrivacyScreen(c, it); (c as? Activity)?.let(Security::applyPrivacyScreen) })
        }
        Label("Lock again after leaving Atlas", Modifier.padding(top = 16.dp))
        val options = listOf(0L to "Right away", 60_000L to "1 min", 300_000L to "5 min", 1_800_000L to "30 min")
        ChipRow(options.map { it.second }, options.firstOrNull { it.first == lockAfter }?.second ?: "1 min", { v ->
            options.first { it.second == v }.first.let { lockAfter = it; Security.setLockAfter(c, it) } })
        Text("Needs an app PIN (Settings › App lock).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(96.dp))
    }
}
