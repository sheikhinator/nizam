package com.nizam.app.feature.maps

import android.content.Context
import com.nizam.app.net.Http
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import java.net.URLEncoder

/**
 * Maps without keys or accounts: OpenStreetMap data, styled tiles (Paper is the house style — a
 * minimal light map warmed to the colour of paper), Photon/Nominatim for search, and the public
 * OSRM routers for driving, cycling and walking directions with turn-by-turn steps.
 */
data class Place(val name: String, val detail: String, val point: GeoPoint, val kind: String = "")
data class Step(val text: String, val distanceM: Double, val point: GeoPoint)
data class Route(val points: List<GeoPoint>, val distanceM: Double, val durationS: Double, val steps: List<Step>)

class TemplateTiles(name: String, private val template: String, maxZoom: Int, copyright: String) :
    OnlineTileSourceBase(name, 0, maxZoom, 256, ".png", arrayOf(template), copyright) {
    override fun getTileURLString(pMapTileIndex: Long): String = template
        .replace("{z}", MapTileIndex.getZoom(pMapTileIndex).toString())
        .replace("{x}", MapTileIndex.getX(pMapTileIndex).toString())
        .replace("{y}", MapTileIndex.getY(pMapTileIndex).toString())
        .replace("{s}", listOf("a", "b", "c")[(MapTileIndex.getX(pMapTileIndex) + MapTileIndex.getY(pMapTileIndex)) % 3])
}

object MapStyles {
    val NAMES = listOf("Paper", "Minimal", "Streets", "Dark", "Satellite", "Terrain")
    fun source(name: String) = when (name) {
        // OpenStreetMap's own tiles need no key; Paper, Minimal and Dark are restyled on the phone (see filter())
        "Minimal", "Paper", "Dark", "Streets" -> TemplateTiles("osm", "https://tile.openstreetmap.org/{z}/{x}/{y}.png", 19, "© OpenStreetMap contributors")
        "Satellite" -> TemplateTiles("esri-imagery", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", 19, "© Esri, Maxar, Earthstar")
        else -> TemplateTiles("opentopo", "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png", 17, "© OpenStreetMap © OpenTopoMap")
    }
}

/** How each style recolours the OpenStreetMap tiles. */
fun styleFilter(style: String): android.graphics.ColorMatrix? {
    fun m(vararg f: Float) = android.graphics.ColorMatrix(f)
    return when (style) {
        // warm, faded paper: desaturated, then tinted sepia and lifted
        "Paper" -> android.graphics.ColorMatrix().apply { setSaturation(0.18f) }.apply {
            postConcat(m(0.93f, 0f, 0f, 0f, 22f,  0f, 0.9f, 0f, 0f, 18f,  0f, 0f, 0.78f, 0f, 10f,  0f, 0f, 0f, 1f, 0f)) }
        // clean light grey: no colour, softer contrast
        "Minimal" -> android.graphics.ColorMatrix().apply { setSaturation(0f) }.apply {
            postConcat(m(0.85f, 0f, 0f, 0f, 36f,  0f, 0.85f, 0f, 0f, 36f,  0f, 0f, 0.85f, 0f, 38f,  0f, 0f, 0f, 1f, 0f)) }
        // night: greyscale, inverted, with a cool tint
        "Dark" -> android.graphics.ColorMatrix().apply { setSaturation(0.1f) }.apply {
            postConcat(m(-0.82f, 0f, 0f, 0f, 225f,  0f, -0.82f, 0f, 0f, 228f,  0f, 0f, -0.8f, 0f, 238f,  0f, 0f, 0f, 1f, 0f)) }
        else -> null
    }
}

object MapPrefs {
    private fun p(c: Context) = c.getSharedPreferences("maps", 0)
    fun style(c: Context) = p(c).getString("style", "Paper").orEmpty()
    fun setStyle(c: Context, s: String) = p(c).edit().putString("style", s).apply()
    fun miles(c: Context) = p(c).getBoolean("miles", false)
    fun setMiles(c: Context, v: Boolean) = p(c).edit().putBoolean("miles", v).apply()
    fun voice(c: Context) = p(c).getBoolean("voice", true)
    fun setVoice(c: Context, v: Boolean) = p(c).edit().putBoolean("voice", v).apply()
    fun mode(c: Context) = p(c).getString("mode", "Drive").orEmpty()
    fun setMode(c: Context, v: String) = p(c).edit().putString("mode", v).apply()
    fun last(c: Context): GeoPoint? = p(c).getString("last", null)?.split(',')?.let { runCatching { GeoPoint(it[0].toDouble(), it[1].toDouble(), ) }.getOrNull() }
    fun setLast(c: Context, g: GeoPoint) = p(c).edit().putString("last", "${g.latitude},${g.longitude}").apply()

    fun saved(c: Context): List<Place> = runCatching { JSONArray(p(c).getString("saved", "[]")) }.getOrElse { JSONArray() }
        .let { a -> (0 until a.length()).map { a.getJSONObject(it) }.map { Place(it.optString("name"), it.optString("detail"), GeoPoint(it.optDouble("lat"), it.optDouble("lon")), it.optString("kind")) } }
    fun save(c: Context, pl: Place) = p(c).edit().putString("saved", JSONArray().apply {
        (listOf(pl) + saved(c).filter { it.name != pl.name && (pl.kind.isBlank() || it.kind != pl.kind) }).take(50).forEach {
            put(JSONObject().put("name", it.name).put("detail", it.detail).put("lat", it.point.latitude).put("lon", it.point.longitude).put("kind", it.kind)) }
    }.toString()).apply()
    fun unsave(c: Context, pl: Place) = p(c).edit().putString("saved", JSONArray().apply {
        saved(c).filter { it.name != pl.name }.forEach { put(JSONObject().put("name", it.name).put("detail", it.detail).put("lat", it.point.latitude).put("lon", it.point.longitude).put("kind", it.kind)) }
    }.toString()).apply()
    fun recents(c: Context) = p(c).getString("recent", "").orEmpty().split('\n').filter { it.isNotBlank() }
    fun addRecent(c: Context, q: String) = p(c).edit().putString("recent", (listOf(q) + recents(c).filter { it != q }).take(12).joinToString("\n")).apply()
}

object Geo {
    private val UA = mapOf("User-Agent" to "Atlas/1.0 (personal assistant app)")
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Search-as-you-type via Photon, biased to where you are. */
    suspend fun suggest(q: String, near: GeoPoint?): List<Place> = runCatching {
        val bias = near?.let { "&lat=${it.latitude}&lon=${it.longitude}" }.orEmpty()
        val o = JSONObject(Http.getJson("https://photon.komoot.io/api/?q=${enc(q)}&limit=8$bias", UA))
        val f = o.optJSONArray("features") ?: JSONArray()
        (0 until f.length()).map { f.getJSONObject(it) }.map { x ->
            val pr = x.getJSONObject("properties"); val c = x.getJSONObject("geometry").getJSONArray("coordinates")
            Place(pr.optString("name").ifBlank { pr.optString("street") },
                listOf(pr.optString("street"), pr.optString("district"), pr.optString("city"), pr.optString("state"), pr.optString("country"))
                    .filter { it.isNotBlank() }.distinct().joinToString(", "),
                GeoPoint(c.getDouble(1), c.getDouble(0)), pr.optString("osm_value"))
        }.filter { it.name.isNotBlank() }
    }.getOrElse { emptyList() }

    /** Full search via Nominatim (also finds categories like "pharmacy" within the visible area). */
    suspend fun search(q: String, box: DoubleArray?): List<Place> = runCatching {
        val vb = box?.let { "&viewbox=${it[0]},${it[1]},${it[2]},${it[3]}&bounded=1" }.orEmpty()
        val a = JSONArray(Http.getJson("https://nominatim.openstreetmap.org/search?q=${enc(q)}&format=jsonv2&limit=20$vb", UA))
        (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            Place(o.optString("name").ifBlank { o.optString("display_name").substringBefore(',') },
                o.optString("display_name").substringAfter(", ", ""), GeoPoint(o.getDouble("lat"), o.getDouble("lon")), o.optString("type"))
        }
    }.getOrElse { emptyList() }.ifEmpty { if (box != null) search(q, null) else emptyList() }

    suspend fun reverse(g: GeoPoint): Place = runCatching {
        val o = JSONObject(Http.getJson("https://nominatim.openstreetmap.org/reverse?lat=${g.latitude}&lon=${g.longitude}&format=jsonv2&zoom=18", UA))
        Place(o.optString("name").ifBlank { o.optString("display_name").substringBefore(',') }, o.optString("display_name").substringAfter(", ", ""), g)
    }.getOrElse { Place("Dropped pin", "%.5f, %.5f".format(g.latitude, g.longitude), g) }

    /** Directions. mode: Drive, Bike, Walk. */
    suspend fun route(from: GeoPoint, to: GeoPoint, mode: String): Route {
        val profile = when (mode) { "Walk" -> "routed-foot"; "Bike" -> "routed-bike"; else -> "routed-car" }
        val url = "https://routing.openstreetmap.de/$profile/route/v1/driving/${from.longitude},${from.latitude};${to.longitude},${to.latitude}" +
            "?overview=full&geometries=geojson&steps=true"
        val o = JSONObject(Http.getJson(url, UA))
        val r = o.optJSONArray("routes")?.optJSONObject(0) ?: throw IllegalStateException("No route found between these places")
        val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
        val pts = (0 until coords.length()).map { coords.getJSONArray(it).let { c -> GeoPoint(c.getDouble(1), c.getDouble(0)) } }
        val steps = mutableListOf<Step>()
        val legs = r.optJSONArray("legs") ?: JSONArray()
        for (l in 0 until legs.length()) {
            val st = legs.getJSONObject(l).optJSONArray("steps") ?: continue
            for (i in 0 until st.length()) {
                val s = st.getJSONObject(i); val m = s.getJSONObject("maneuver")
                val loc = m.getJSONArray("location")
                steps += Step(describe(m.optString("type"), m.optString("modifier"), s.optString("name")), s.optDouble("distance"),
                    GeoPoint(loc.getDouble(1), loc.getDouble(0)))
            }
        }
        return Route(pts, r.optDouble("distance"), r.optDouble("duration"), steps)
    }

    private fun describe(type: String, mod: String, road: String): String {
        val on = if (road.isNotBlank()) " onto $road" else ""
        return when (type) {
            "depart" -> "Head ${mod.ifBlank { "out" }}" + if (road.isNotBlank()) " on $road" else ""
            "arrive" -> "You've arrived"
            "roundabout", "rotary" -> "At the roundabout, take the exit$on"
            "merge" -> "Merge$on"
            "on ramp" -> "Take the ramp$on"
            "off ramp" -> "Take the exit$on"
            "fork" -> "Keep ${mod.ifBlank { "ahead" }} at the fork$on"
            "end of road" -> "At the end of the road, turn ${mod}$on"
            "continue", "new name" -> "Continue$on"
            else -> when (mod) { "uturn" -> "Make a U-turn$on"; "straight" -> "Go straight$on"; "" -> "Continue$on"; else -> "Turn $mod$on" }
        }
    }

    fun distance(m: Double, miles: Boolean): String = if (miles) {
        val mi = m / 1609.34; if (mi < 0.2) "${(m * 3.281).toInt()} ft" else "%.1f mi".format(mi)
    } else if (m < 1000) "${m.toInt()} m" else "%.1f km".format(m / 1000)

    fun duration(s: Double): String { val m = (s / 60).toInt(); return if (m < 60) "$m min" else "${m / 60} h ${m % 60} min" }
}
