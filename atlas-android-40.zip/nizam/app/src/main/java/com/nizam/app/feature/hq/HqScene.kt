package com.nizam.app.feature.hq

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan

// Atlas HQ's world: a tower with a floor per part of life, a desk per agent, a street outside.
// Pure Kotlin (no Android), so it can be drawn and tested anywhere.

data class HqAgent(val id: String, val name: String, val emoji: String, val color: Int, val room: Int, val slot: Int,
                   val status: String, val pose: String, val card: String, val line: String)

data class HqRoomDef(val name: String, val emoji: String, val color: Int)

data class HqState(
    val agents: List<HqAgent> = emptyList(), val needs: List<String> = emptyList(),
    val sky: String = "DAY", val hour: Float = 12f, val weather: String = "clear", val event: String? = null,
    val salah: Boolean = false, val qibla: Float = 255f, val loadshed: Boolean = false, val low: Boolean = false,
    val meeting: List<String> = emptyList(), val speaking: String? = null, val jar: Float = 1f,
    val approvals: Int = 0, val changes: Int = 0, val pcOnline: Boolean = false, val celebrate: Int = -1,
    val summary: String = "", val prayer: String = "", val routine: String = "", val plugsOk: Int = 0, val plugsTotal: Int = 0,
)

/** Something on screen: an agent's card, a sign, a bubble. */
class HqLabel(val key: String, var kind: String, var id: String) {
    var x = 0f; var y = 0f; var shown = false; var text = ""; var sub = ""; var line = ""; var color = 0; var status = ""; var near = false
}

class HqScene(private val rooms: List<HqRoomDef>) {
    companion object {
        const val W = 14f; const val D = 10f; const val H = 3.2f
        private val SKY = mapOf(
            "DAWN" to intArrayOf(0x7C8FD6, 0xF6B98A, 0xFFD7A8), "DAY" to intArrayOf(0x4F8FEA, 0xDBEAFE, 0xFFFFFF),
            "GOLDEN" to intArrayOf(0x6D8FDC, 0xFFD18A, 0xFFC27A), "DUSK" to intArrayOf(0x3B2B6B, 0xF08A6C, 0xFF9D6B),
            "NIGHT" to intArrayOf(0x070B1C, 0x1B2447, 0x8AA0FF))
        val STATUS = mapOf("working" to 0x3B82F6, "needs" to 0xEF4444, "done" to 0x22C55E, "idle" to 0x9CA3AF, "asleep" to 0x6B7280)
    }

    var state = HqState()
        private set

    // ───────────── building ─────────────
    class Slot(val x: Float, val z: Float, val bean: Boolean, val deskZ: Float)
    class Spot(val kind: String, val id: String, val label: String, val floor: Int, val x: Float, val z: Float, val ay: Float = 1.2f)
    inner class Floor(val i: Int, val room: HqRoomDef) {
        val y = i * H
        val under = Mesh(512); val walls = Mesh(128); val decor = Mesh(128); val main = Mesh(1024); val dyn = Mesh(1024)
        val slots = ArrayList<Slot>(); val solids = ArrayList<FloatArray>(); val seats = ArrayList<FloatArray>()
        val doorX = -5.9f; val doorZ = -3.0f
    }
    val floors = ArrayList<Floor>()
    val spots = ArrayList<Spot>()
    private val ground = Mesh(1024); private val back = Mesh(1024); private val front = Mesh(512); private val roof = Mesh(256)
    private val worldDyn = Mesh(512)
    val light = Light(); val inside = Light()
    var skyTop = 0x4F8FEA; var skyBottom = 0xDBEAFE; var night = false; var stars = false; var raining = false; var storm = false; var fog = false

    private fun solid(f: Floor, x: Float, z: Float, w: Float, d: Float) { f.solids += floatArrayOf(x - w / 2, x + w / 2, z - d / 2, z + d / 2) }

    private fun build() {
        // the street
        ground.floor(160f, 160f, 0f, -0.03f, 0f, 0x7FB069, 10f)
        ground.floor(160f, 6f, 0f, -0.01f, 13f, 0x3D4250, 4f)
        ground.floor(160f, 3.2f, 0f, 0.0f, 8.4f, 0xC9C3B6, 4f)
        ground.floor(160f, 3.2f, 0f, 0.0f, 17.6f, 0xC9C3B6, 4f)
        var x = -78f; while (x < 80f) { ground.floor(2.4f, 0.18f, x, 0.005f, 13f, 0xF5F0E1); x += 6f }
        fun tree(m: Mesh, tx: Float, tz: Float, s: Float) {
            m.cyl(0.14f * s, 0.2f * s, 1.4f * s, tx, 0.7f * s, tz, 0x7A5537, 5)
            m.sphere(1.1f * s, tx, 2.1f * s, tz, 0x4F9D4F, 6, 4)
            m.sphere(0.8f * s, tx + 0.4f * s, 2.7f * s, tz + 0.2f * s, 0x5FB35F, 6, 3)
        }
        listOf(-10f to 7.5f, 10f to 7.5f, -16f to 7.5f, 16f to 7.5f, -22f to 7.4f, 22f to 7.6f).forEachIndexed { i, (a, b) -> tree(front, a, b, 0.9f + (i % 3) * 0.15f) }
        listOf(-9f to -9f, 11f to -10f, -14f to -6f).forEachIndexed { i, (a, b) -> tree(back, a, b, 1f + (i % 2) * 0.2f) }
        fun building(m: Mesh, bx: Float, bz: Float, w: Float, h: Float, d: Float, color: Int) {
            m.box(w, h, d, bx, h / 2, bz, color)
            var fy = 1.4f
            while (fy < h - 0.8f) {
                var fx = -w / 2 + 1f
                while (fx < w / 2 - 0.6f) { cityWindows += intArrayOf(m.n, (fx * 7 + fy * 13).toInt()); m.front(0.8f, 1.1f, bx + fx, fy, bz + d / 2 + 0.02f, 0x2A3350, EMIT); fx += 1.6f }
                fy += 2.2f
            }
        }
        building(back, -12f, -20f, 8f, 14f, 6f, 0xC7B7A3); building(back, 2f, -24f, 9f, 22f, 7f, 0x9FB3C8); building(back, 15f, -19f, 6f, 11f, 5f, 0xD9C8B4)
        building(back, 28f, -22f, 10f, 17f, 7f, 0xB8A894); building(back, -30f, -16f, 9f, 12f, 6f, 0xA9B8A0)
        // the neighbourhood masjid, whose lights come on for salah
        back.with(M4.t(-24f, 0f, -8f).mul(M4.ry(-PI.toFloat() / 2))) {
            back.box(8f, 4f, 6f, 0f, 2f, 0f, 0xF1ECE2)
            back.sphere(2.3f, 0f, 4f, 0f, 0x2F9E8F, 10, 3, 1f)
            back.cyl(0.45f, 0.55f, 10f, 4.6f, 5f, -2f, 0xF1ECE2, 8)
            back.cyl(0f, 0.6f, 1.4f, 4.6f, 10.7f, -2f, 0x2F9E8F, 8)
            for (k in -1..1) { masjidWindows += back.n; back.quad(k * 2.4f + 0.55f, 0.9f, -3.02f, k * 2.4f - 0.55f, 0.9f, -3.02f, k * 2.4f - 0.55f, 2.7f, -3.02f, k * 2.4f + 0.55f, 2.7f, -3.02f, 0f, 0f, -1f, 0x5A4A2A, EMIT) }
        }
        rooms.forEachIndexed { i, r -> buildFloor(Floor(i, r).also { floors += it }) }
        buildRoof()
    }
    private val cityWindows = ArrayList<IntArray>()     // (triangle index, seed)
    private val masjidWindows = ArrayList<Int>()

    private fun desk(f: Floor, x: Float, z: Float, big: Boolean) {
        val m = f.main; val w = if (big) 2.2f else 1.6f
        m.box(w, 0.08f, 0.8f, x, 0.76f, z, if (big) 0x6B4A33 else 0xC79A6B)
        for ((dx, dz) in listOf(-w / 2 + 0.08f to -0.32f, w / 2 - 0.08f to -0.32f, -w / 2 + 0.08f to 0.32f, w / 2 - 0.08f to 0.32f)) m.box(0.06f, 0.74f, 0.06f, x + dx, 0.37f, z + dz, 0x4B5563)
        m.box(0.55f, 0.08f, 0.5f, x, 0.48f, z - 0.78f, 0x374151); m.box(0.55f, 0.6f, 0.08f, x, 0.8f, z - 1.04f, 0x374151)
        m.box(0.5f, 0.03f, 0.34f, x, 0.815f, z + 0.05f, 0x9CA3AF)
        m.with(M4.t(x, 0.83f, z + 0.22f).mul(M4.rx(-0.35f))) { m.box(0.5f, 0.34f, 0.02f, 0f, 0.17f, 0f, 0x9CA3AF) }
        solid(f, x, z - 0.2f, w + 0.1f, 1.6f)
    }
    private fun beanbag(f: Floor, x: Float, z: Float, col: Int) {
        f.main.sphere(0.55f, x, 0.3f, z - 0.05f, col, 8, 4, 0.55f)
        f.main.box(0.7f, 0.05f, 0.4f, x, 0.42f, z + 0.55f, 0xC79A6B); f.main.box(0.4f, 0.02f, 0.28f, x, 0.46f, z + 0.55f, 0x9CA3AF)
    }
    private fun plant(m: Mesh, x: Float, z: Float, s: Float = 1f) {
        m.cyl(0.22f * s, 0.17f * s, 0.4f * s, x, 0.2f * s, z, 0xB45309, 6)
        m.sphere(0.32f * s, x, 0.78f * s, z, 0x3F8F4A, 6, 4); m.sphere(0.22f * s, x + 0.1f * s, 1.05f * s, z, 0x5AAD5F, 6, 3)
    }

    private fun slotsFor(i: Int): List<Triple<Float, Float, Int>> =   // x, z, 0 desk / 1 bean / 2 big desk
        if (i == 0) listOf(Triple(4.9f, -2.6f, 2), Triple(-2.6f, -2.6f, 0), Triple(4.9f, 3.4f, 0), Triple(-2.6f, 3.4f, 0), Triple(1.2f, 4.1f, 1), Triple(6.2f, 0.6f, 1), Triple(-1.0f, 4.1f, 1))
        else listOf(Triple(-2.8f, -2.0f, 0), Triple(0.4f, -2.0f, 0), Triple(3.6f, -2.0f, 0), Triple(-0.8f, 3.6f, 1), Triple(2.4f, 3.6f, 1), Triple(5.4f, 3.6f, 1), Triple(5.9f, 0.6f, 1))

    private fun buildFloor(f: Floor) {
        val i = f.i; val tint = f.room.color
        f.under.with(M4.t(0f, f.y, 0f)) {
            f.under.box(W, 0.2f, D, 0f, -0.1f, 0f, mix(0xEFE6D8, tint, 0.08f))
            f.under.floor(W, D, 0f, 0.001f, 0f, mix(0xEFE6D8, tint, 0.08f), 2f)
            f.under.floor(5.5f, 3.4f, 1.2f, 0.01f, if (i == 0) 0.2f else -0.5f, mix(0xFFFFFF, tint, 0.35f), 1.2f)
        }
        val wall = mix(0xF7F3EC, tint, 0.12f)
        f.walls.with(M4.t(0f, f.y, 0f)) { f.walls.box(W, H, 0.2f, 0f, H / 2, -D / 2, wall); f.walls.box(0.2f, H, D, -W / 2, H / 2, 0f, wall) }
        f.decor.with(M4.t(0f, f.y, 0f)) {
            for (wx in listOf(-4.5f, -1.5f, 1.5f, 4.5f)) { panes += intArrayOf(i, f.decor.n); f.decor.front(1.9f, 1.5f, wx + 1.2f, 1.75f, -D / 2 + 0.11f, 0x9CC3F5, EMIT) }
            f.decor.front(2.4f, 0.6f, -1.5f, 2.75f, -D / 2 + 0.12f, tint, EMIT)                      // the floor's sign
        }
        val m = f.main
        m.with(M4.t(0f, f.y, 0f)) {
            m.box(0.3f, H, 0.3f, W / 2, H / 2, D / 2, 0xD6D3D1); m.box(0.3f, H, 0.3f, -W / 2, H / 2, D / 2, 0xD6D3D1); m.box(0.3f, H, 0.3f, W / 2, H / 2, -D / 2, 0xD6D3D1)
            // elevator
            m.box(1.6f, H - 0.1f, 1.4f, -5.9f, (H - 0.1f) / 2, -4.1f, 0x9AA3B2)
            m.front(0.62f, 2.2f, -6.22f, 1.1f, -3.39f, 0xCBD5E1); m.front(0.62f, 2.2f, -5.58f, 1.1f, -3.39f, 0xCBD5E1)
            m.front(0.4f, 0.2f, -5.9f, 2.45f, -3.38f, 0xFBBF24, EMIT)
            for ((lx, lz) in listOf(-2f to -1f, 3f to -1f, -2f to 2.5f, 3f to 2.5f)) { lamps += intArrayOf(i, m.n); m.cyl(0.35f, 0.35f, 0.06f, lx, H - 0.25f, lz, 0xFFF2CC, 8, EMIT) }
            plant(m, 6.4f, -4.4f); plant(m, -6.3f, 4.3f, 1.2f)
        }
        solid(f, -5.9f, -4.1f, 1.7f, 1.5f); solid(f, 6.4f, -4.4f, 0.6f, 0.6f); solid(f, -6.3f, 4.3f, 0.6f, 0.6f)
        spots += Spot("elevator", "$i", "🛗 Elevator", i, -5.9f, -3.2f, 1.6f)
        m.with(M4.t(0f, f.y, 0f)) {
            for ((sx, sz, kind) in slotsFor(i)) {
                if (kind == 1) beanbag(f, sx, sz, tint) else desk(f, sx, sz, kind == 2)
                f.slots += Slot(sx, if (kind == 1) sz else sz - 0.72f, kind == 1, sz)
            }
            decorate(f)
        }
    }

    private val panes = ArrayList<IntArray>()           // (floor, triangle)
    private val lamps = ArrayList<IntArray>()
    var tableSeats = ArrayList<FloatArray>()
    private var jarAt = floatArrayOf(-6.2f, 0.9f, 1.7f)
    private var gongSwing = 0f
    private var pcSignTri = -1

    private fun decorate(f: Floor) {
        val m = f.main; val i = f.i
        val oldDecor = f.decor.mat; f.decor.mat = M4.t(0f, f.y, 0f)
        decorate2(f, m, i)
        f.decor.mat = oldDecor
    }
    private fun decorate2(f: Floor, m: Mesh, i: Int) {
        when {
            i == 0 -> {
                m.box(4.4f, 0.1f, 1.5f, 1.2f, 0.76f, 0.2f, 0x5B3B26); m.cyl(0.25f, 0.35f, 0.72f, 0.1f, 0.36f, 0.2f, 0x3B2A1C, 6); m.cyl(0.25f, 0.35f, 0.72f, 2.3f, 0.36f, 0.2f, 0x3B2A1C, 6)
                for (sx in listOf(-0.3f, 1.2f, 2.7f)) for (side in listOf(-1f, 1f)) {
                    val sz = 0.2f + side * 1.05f
                    m.box(0.5f, 0.08f, 0.5f, sx, 0.46f, sz, 0x1F2937)
                    tableSeats += floatArrayOf(sx, 0.2f + side * 1.2f, if (side < 0) 0f else PI.toFloat())
                }
                spots += Spot("table", "", "🤝 Meeting table", 0, 1.2f, 0.2f, 1.0f)
                solid(f, 1.2f, 0.2f, 4.6f, 1.7f)
                // the big screen
                m.box(4.35f, 1.78f, 0.06f, 2.6f, 1.95f, -D / 2 + 0.1f, 0x111827)
                f.decor.front(4.2f, 1.64f, 2.6f, 1.95f, -D / 2 + 0.14f, 0x1E1B4B, EMIT)
                spots += Spot("screen", "", "📺 HQ screen", 0, 2.6f, -4.6f, 2.2f)
                // cabinet with the inbox tray, the changes tray and the cash jar
                m.box(1.0f, 0.9f, 3.6f, -6.2f, 0.45f, 0.6f, 0xD6C7B0); solid(f, -6.2f, 0.6f, 1.1f, 3.7f)
                m.box(0.6f, 0.06f, 0.45f, -6.2f, 0.93f, -0.6f, 0xEF4444)
                spots += Spot("inbox", "", "📥 Inbox", 0, -6.2f, -0.6f, 1.1f)
                m.box(0.6f, 0.06f, 0.45f, -6.2f, 0.93f, 0.5f, 0x0EA5E9)
                spots += Spot("changes", "", "🧾 What agents changed", 0, -6.2f, 0.5f, 1.1f)
                m.cyl(0.3f, 0.3f, 0.06f, -6.2f, 1.63f, 1.7f, 0xB45309, 8)
                spots += Spot("jar", "", "🫙 Agent budget", 0, -6.2f, 1.7f, 1.4f)
                // plug wall and routine board
                f.decor.side(1.8f, 1.8f, -W / 2 + 0.12f, 1.9f, 3.3f, 0x1F2937, EMIT)
                spots += Spot("plugs", "", "🔌 Connectors", 0, -6.8f, 3.3f, 1.9f)
                f.decor.front(1.8f, 0.9f, -3.6f, 1.9f, -D / 2 + 0.12f, 0xFEF3C7, EMIT)
                spots += Spot("routines", "", "⏰ Routines", 0, -3.6f, -4.7f, 1.9f)
                // gong
                m.box(0.08f, 1.8f, 0.08f, 5.6f, 0.9f, 2.0f, 0x3B2A1C); m.box(0.08f, 1.8f, 0.08f, 6.8f, 0.9f, 2.0f, 0x3B2A1C); m.box(1.3f, 0.08f, 0.08f, 6.2f, 1.8f, 2.0f, 0x3B2A1C)
                spots += Spot("gong", "", "🔔 Ring the gong", 0, 6.2f, 2.0f, 1.2f); solid(f, 6.2f, 2.0f, 1.4f, 0.4f)
                m.cyl(0.45f, 0.45f, 0.14f, 6.3f, 0.07f, 4.3f, 0xF97316, 10)
            }
            f.room.name.contains("Home") -> {
                m.box(2.8f, 0.9f, 0.6f, 3.6f, 0.45f, -4.5f, 0xE7E5E4); m.box(2.8f, 0.06f, 0.64f, 3.6f, 0.92f, -4.5f, 0x78716C)
                m.box(0.8f, 1.9f, 0.7f, 5.6f, 0.95f, -4.45f, 0xF1F5F9); solid(f, 4.1f, -4.5f, 3.8f, 0.8f)
                m.box(0.9f, 0.45f, 2.1f, -5.6f, 0.3f, 1.4f, 0x6366F1); m.box(0.25f, 0.7f, 2.1f, -5.95f, 0.6f, 1.4f, 0x4F46E5)
                m.box(0.9f, 0.55f, 0.22f, -5.6f, 0.45f, 0.35f, 0x4F46E5); m.box(0.9f, 0.55f, 0.22f, -5.6f, 0.45f, 2.45f, 0x4F46E5); solid(f, -5.6f, 1.4f, 1.0f, 2.2f)
                f.decor.side(0.9f, 0.7f, -W / 2 + 0.12f, 1.9f, -1.8f, 0xFEF3C7, EMIT)
            }
            f.room.name.contains("Money") -> {
                m.box(1.1f, 1.2f, 0.9f, 5.8f, 0.6f, -4.2f, 0x374151); solid(f, 5.8f, -4.2f, 1.2f, 1.0f)
                m.cyl(0.14f, 0.14f, 0.05f, 6.0f, 0.7f, -3.74f, 0xD4AF37, 8)
                for (k in 0 until 5) for (hh in 0 until 2 + k) m.cyl(0.12f, 0.12f, 0.05f, -5.8f + k * 0.3f, 0.03f + hh * 0.055f, 2.2f, 0xEAB308, 8)
                f.decor.side(2f, 1f, -W / 2 + 0.12f, 1.9f, 1.5f, 0x0F172A, EMIT)
            }
            f.room.name.contains("Deen") -> {
                for (k in 0 until 3) {
                    m.box(1.8f, 0.05f, 0.4f, -5.6f, 0.6f + k * 0.55f, -1f, 0x8B5A2B)
                    for (b in 0 until 8) m.box(0.14f, 0.4f, 0.3f, -6.3f + b * 0.19f, 0.83f + k * 0.55f, -1f, intArrayOf(0x166534, 0x7C2D12, 0x1E3A8A, 0x854D0E)[b % 4])
                }
                solid(f, -5.6f, -1f, 1.9f, 0.5f)
                m.sphere(0.25f, -4.2f, 2.6f, 1.6f, 0xFFC36B, 4, 2, 1.3f, EMIT)
            }
            f.room.name.contains("Work") -> {
                f.decor.side(2.2f, 1.1f, -W / 2 + 0.12f, 1.8f, 1.5f, 0xFFFFFF, EMIT)
                for (k in 0 until 3) m.box(0.6f, 1.3f, 0.6f, 4.6f + k * 0.65f, 0.65f, -4.4f, 0x94A3B8)
                solid(f, 5.25f, -4.4f, 2.0f, 0.7f)
            }
            else -> {
                for (k in 0 until 3) {
                    m.box(0.8f, 2.2f, 0.8f, 4.2f + k * 0.9f, 1.1f, -4.3f, 0x1F2937)
                    for (r in 0 until 6) { blinkers += intArrayOf(i, m.n, r + k * 7); m.front(0.08f, 0.08f, 4.0f + k * 0.9f + (r % 2) * 0.14f, 0.4f + r * 0.3f, -3.89f, 0x22C55E, EMIT) }
                }
                solid(f, 5.1f, -4.3f, 2.8f, 0.9f)
                pcSignTri = f.decor.n; f.decor.side(1.6f, 0.4f, -W / 2 + 0.12f, 2.3f, 1.5f, 0x7F1D1D, EMIT)
                spots += Spot("pc", "", "🖥️ PC link", i, -6.8f, 1.5f, 2.3f)
            }
        }
    }
    private val blinkers = ArrayList<IntArray>()

    private fun buildRoof() {
        val y = floors.size * H
        roof.with(M4.t(0f, y, 0f)) {
            roof.box(W, 0.2f, D, 0f, -0.1f, 0f, 0xD6D3D1)
            roof.box(W, 0.6f, 0.2f, 0f, 0.3f, D / 2, 0xE7E5E4); roof.box(W, 0.6f, 0.2f, 0f, 0.3f, -D / 2, 0xE7E5E4)
            roof.box(0.2f, 0.6f, D, W / 2, 0.3f, 0f, 0xE7E5E4); roof.box(0.2f, 0.6f, D, -W / 2, 0.3f, 0f, 0xE7E5E4)
            roof.front(6f, 1.3f, 0f, 1.4f, D / 2 - 0.3f, 0x6366F1, EMIT)
            roof.cyl(0.04f, 0.06f, 3f, 5f, 1.5f, -3f, 0x9CA3AF, 4)
        }
    }

    // ───────────── agents ─────────────
    class Way(val x: Float, val z: Float, val floor: Int, val jump: Boolean = false)
    class Place(val key: String, val floor: Int, val x: Float, val z: Float, val face: Float, val mode: String, val slot: Slot?)
    inner class Rt(var a: HqAgent) {
        var x = 0f; var z = 0f; var floor = 0; var face = 0f
        var place: Place? = null; val path = ArrayList<Way>(); var hop = 0f
        val phase = (a.id.hashCode() % 1000) / 160f
        var bodyY = 0f
    }
    val agents = LinkedHashMap<String, Rt>()

    private fun qiblaYaw(): Float { val b = Math.toRadians(state.qibla.toDouble()); return atan2(sin(b), -cos(b)).toFloat() }

    private fun placeFor(r: Rt): Place {
        val a = r.a
        val fi = a.room.coerceIn(0, floors.size - 1); val f = floors[fi]
        val slot = f.slots[a.slot % f.slots.size]
        if (state.salah && a.status != "asleep") return Place("mat$fi", fi, slot.x, if (slot.bean) slot.z + 0.9f else slot.z - 0.95f, qiblaYaw(), "pray", slot)
        val mi = state.meeting.indexOf(a.id)
        if (mi >= 0 && tableSeats.isNotEmpty()) { val s = tableSeats[mi % tableSeats.size]; return Place("table$mi", 0, s[0], s[1], s[2], "table", null) }
        return Place("desk$fi-${a.slot}", fi, slot.x, slot.z, 0f, if (slot.bean) "bean" else "desk", slot)
    }

    var celebrations = 0
        private set
    private var lastCelebrate = -1
    var celebrateText = ""

    fun update(s: HqState) {
        state = s
        val seen = HashSet<String>()
        for (a in s.agents) {
            seen += a.id
            val r = agents.getOrPut(a.id) { Rt(a) }
            r.a = a
            val p = placeFor(r)
            val cur = r.place
            if (cur == null) { r.x = p.x; r.z = p.z; r.floor = p.floor; r.face = p.face; r.place = p }
            else if (cur.key != p.key) { r.place = p; route(r, p) }
            else r.place = p
        }
        agents.keys.retainAll(seen)
        if (lastCelebrate >= 0 && s.celebrate > lastCelebrate) celebrate()
        lastCelebrate = s.celebrate
        applySky()
    }

    private fun route(r: Rt, p: Place) {
        r.path.clear()
        if (r.floor != p.floor) {
            r.path += Way(floors[r.floor].doorX, floors[r.floor].doorZ, r.floor)
            r.path += Way(floors[p.floor].doorX, floors[p.floor].doorZ, p.floor, true)
        }
        r.path += Way(p.x, p.z, p.floor)
    }

    fun celebrate() { celebrations++; gongSwing = 1f; for (r in agents.values) if (r.a.status != "asleep" && r.path.isEmpty()) r.hop = 1.2f }

    // ───────────── the dog ─────────────
    private var dogX = 6.3f; private var dogZ = 4.3f; private var dogFloor = 0; private var dogFace = 0f
    private val dogPath = ArrayList<Way>(); private var dogNext = 0f; private var dogMode = "nap"; private var dogMoving = false
    var dogBark = false; private set
    var dogSleep = false; private set
    private var rnd = java.util.Random(7)

    private fun dogThink(t: Float) {
        if (t < dogNext || dogPath.isNotEmpty()) return
        dogNext = t + 2.5f
        val needy = state.needs.firstOrNull()?.let { agents[it] }
        val f: Int; val x: Float; val z: Float
        if (needy != null) { f = needy.floor; x = needy.x + 0.6f; z = needy.z + 0.8f; dogMode = "bark" }
        else {
            f = if (mode == "explore") player.floor else view.floor
            val busy = agents.values.filter { it.floor == f && it.a.status == "working" }
            if (busy.isNotEmpty() && rnd.nextFloat() < 0.5f) { val a = busy[rnd.nextInt(busy.size)]; x = a.x + 0.3f; z = (a.place?.slot?.deskZ ?: a.z) + 0.1f; dogMode = "nap" }
            else if (rnd.nextFloat() < 0.3f && f == 0) { x = 6.3f; z = 4.3f; dogMode = "nap" }
            else { x = -3f + rnd.nextFloat() * 9f; z = -1.5f + rnd.nextFloat() * 1.2f; dogMode = "wander" }
        }
        dogPath.clear()
        if (dogFloor != f) { dogPath += Way(floors[dogFloor].doorX, floors[dogFloor].doorZ, dogFloor); dogPath += Way(floors[f].doorX, floors[f].doorZ, f, true) }
        dogPath += Way(x, z, f)
    }
    fun petDog(t: Float) { dogMode = "wander"; dogNext = t + 3f }

    // ───────────── cars, confetti, weather ─────────────
    private val cars = listOf(floatArrayOf(-60f, 11.5f, 1f, 5f), floatArrayOf(-27f, 14.5f, -1f, 6f), floatArrayOf(6f, 11.5f, 1f, 7f), floatArrayOf(39f, 14.5f, -1f, 8f))
    private val carCols = intArrayOf(0xEF4444, 0xF8FAFC, 0x0EA5E9, 0xF59E0B)

    private fun applySky() {
        val s = SKY[state.sky] ?: SKY.getValue("DAY")
        val grey = state.weather in setOf("rain", "storm", "cloudy", "fog")
        skyTop = if (grey) mix(s[0], 0x6B7280, 0.5f) else s[0]; skyBottom = if (grey) mix(s[1], 0x9AA3B2, 0.5f) else s[1]
        night = state.sky == "NIGHT" || state.sky == "DUSK"
        stars = state.sky == "NIGHT" && !grey
        raining = state.weather == "rain" || state.weather == "storm"; storm = state.weather == "storm"; fog = state.weather == "fog"
        val ang = ((state.hour - 6f) / 12.5f * PI).toFloat()
        light.sx = cos(ang) * 0.8f; light.sy = max(0.35f, sin(ang)); light.sz = 0.55f; light.norm()
        light.sun = s[2]; light.sunK = (if (night) 0.35f else 0.75f) * (if (grey) 0.6f else 1f)
        light.amb = mix(skyTop, 0xFFFFFF, 0.55f); light.ambK = if (night) 0.45f else 0.62f
        inside.sx = 0.35f; inside.sy = 0.9f; inside.sz = 0.55f; inside.norm()
        inside.sun = if (night) 0xFFD7A0 else 0xFFF4E0
        inside.sunK = when { state.loadshed -> 0.25f; night -> 0.6f; else -> 0.62f }
        inside.amb = if (night) 0xFFE2B8 else mix(skyBottom, 0xFFFFFF, 0.6f)
        inside.ambK = when { state.loadshed -> 0.32f; night -> 0.55f; else -> 0.6f }
        // windows, lamps and neighbours follow the time
        val pane = mix(mix(skyBottom, skyTop, 0.4f), if (night) 0x000000 else 0xFFFFFF, if (night) 0.3f else 0.05f)
        for ((fi, t) in panes) { floors[fi].decor.col[t] = pane; floors[fi].decor.col[t + 1] = pane }
        val lamp = when { state.loadshed -> 0x3A3A2A; night -> 0xFFE7A8; else -> 0xFFF7DC }
        for ((fi, t) in lamps) for (k in 0 until 24) if (t + k < floors[fi].main.n) floors[fi].main.col[t + k] = lamp
        for ((t, seed) in cityWindows) { val lit = night && (seed and 3) != 0; back.col[t] = if (lit) 0xFFD98A else 0x2A3350; back.col[t + 1] = back.col[t] }
        for (t in masjidWindows) { val c = if (state.salah || night) 0xFFD27A else 0x5A4A2A; back.col[t] = c; back.col[t + 1] = c }
        if (pcSignTri >= 0) floors.lastOrNull()?.decor?.let { it.col[pcSignTri] = if (state.pcOnline) 0x22C55E else 0x7F1D1D; it.col[pcSignTri + 1] = it.col[pcSignTri] }
    }

    // ───────────── camera ─────────────
    class View { var floor = 0; var yaw = 0.65f; var pitch = 0.5f; var zoom = 1f; var tx = 0.6f; var ty = 0.9f; var tz = 0.2f; var focus: FloatArray? = null
        var cx = 30f; var cy = 30f; var cz = 40f }
    class Player { var x = 0.8f; var y = 0f; var z = 2.4f; var vy = 0f; var floor = 0; var yaw = PI.toFloat(); var look = 0.35f; var face = PI.toFloat(); var ground = true; var moving = false }
    val view = View(); val player = Player()
    var mode = "diorama"
        private set
    val cam = Cam()
    var joyX = 0f; var joyY = 0f
    var nearSpot: Spot? = null; var nearAgent: String? = null; var nearDog = false
    val overview get() = mode == "diorama" && view.zoom > 1.7f

    fun switchMode(m: String) {
        mode = m
        if (m == "explore") { player.floor = view.floor; player.x = 0.8f; player.z = if (view.floor == 0) 2.4f else 0.1f; player.y = floors[view.floor].y; player.yaw = PI.toFloat(); player.look = 0.35f; view.focus = null }
    }
    fun goFloor(i: Int) {
        val k = i.coerceIn(0, floors.size - 1)
        view.floor = k; view.focus = null
        if (mode == "explore") { player.floor = k; player.x = floors[k].doorX + 0.4f; player.z = floors[k].doorZ + 0.9f; player.y = floors[k].y; player.vy = 0f }
    }
    fun focusAgent(id: String) {
        val r = agents[id] ?: return
        if (mode == "explore") { goFloor(r.floor); player.x = r.x + 0.2f; player.z = r.z + 1.6f; player.yaw = PI.toFloat() }
        else { view.floor = r.floor; view.zoom = min(view.zoom, 1f); view.focus = floatArrayOf(r.x, floors[r.floor].y, r.z) }
    }
    fun drag(dx: Float, dy: Float) {
        if (mode == "diorama") { view.yaw = (view.yaw - dx * 0.006f).coerceIn(0.08f, 1.45f); view.pitch = (view.pitch + dy * 0.004f).coerceIn(0.18f, 1.2f) }
        else { player.yaw -= dx * 0.006f; player.look = (player.look + dy * 0.004f).coerceIn(-0.2f, 1.1f) }
    }
    fun pinch(scale: Float) { if (mode == "diorama" && scale > 0f) { view.zoom = (view.zoom / scale).coerceIn(0.35f, 2.6f); if (view.zoom > 0.8f) view.focus = null } }
    fun jump() { if (player.ground) { player.vy = 6.5f; player.ground = false } }

    private fun fitDist(): Float { val a = min(cam.w / cam.h, 1.2f); return 17.5f / (2f * tan(Math.toRadians(15.0).toFloat()) * a) }

    private fun updateCamera(dt: Float) {
        if (mode == "diorama") {
            cam.fov = 30f
            val f = floors[view.floor]
            val fo = view.focus
            val gx = fo?.get(0) ?: 0.6f; val gy = (fo?.get(1) ?: f.y) + 0.9f; val gz = fo?.get(2) ?: 0.2f
            val k = min(1f, dt * 4f)
            view.tx += (gx - view.tx) * k; view.ty += (gy - view.ty) * k; view.tz += (gz - view.tz) * k
            val dist = fitDist() * view.zoom * (if (fo != null) 0.42f else 1f)
            val cp = cos(view.pitch)
            val wx = view.tx + sin(view.yaw) * cp * dist; val wy = view.ty + sin(view.pitch) * dist; val wz = view.tz + cos(view.yaw) * cp * dist
            val q = min(1f, dt * 5f)
            view.cx += (wx - view.cx) * q; view.cy += (wy - view.cy) * q; view.cz += (wz - view.cz) * q
            cam.look(view.cx, view.cy, view.cz, view.tx, view.ty, view.tz)
        } else {
            cam.fov = 62f
            val back = 3.6f; val up = 1.9f
            var wx = player.x - sin(player.yaw) * back * cos(player.look)
            var wy = player.y + up + sin(player.look) * back * 0.6f
            var wz = player.z - cos(player.yaw) * back * cos(player.look)
            if (player.z < D / 2 + 0.2f) { wx = wx.coerceIn(-W / 2 + 0.3f, W / 2 + 4f); wz = max(-D / 2 + 0.3f, wz); wy = min(wy, player.y + H - 0.35f) }
            val q = min(1f, dt * 8f)
            view.cx += (wx - view.cx) * q; view.cy += (wy - view.cy) * q; view.cz += (wz - view.cz) * q
            cam.look(view.cx, view.cy, view.cz, player.x, player.y + 1.1f, player.z)
        }
    }

    private fun movePlayer(dt: Float) {
        val sp = 3.2f
        val fx = sin(player.yaw); val fz = cos(player.yaw); val rx = -fz; val rz = fx
        val mx = (fx * -joyY + rx * -joyX) * sp * dt; val mz = (fz * -joyY + rz * -joyX) * sp * dt
        player.moving = abs(joyX) + abs(joyY) > 0.08f
        if (player.moving) player.face = atan2(mx, mz)
        val f = floors[player.floor]
        val outside = player.floor == 0 && player.z > D / 2 - 0.1f
        var nx = player.x + mx; var nz = player.z + mz
        if (!outside) {
            val gap = player.floor == 0 && abs(nx) < 1.0f
            nx = nx.coerceIn(-W / 2 + 0.35f, W / 2 - 0.35f)
            nz = if (gap) max(-D / 2 + 0.35f, nz) else nz.coerceIn(-D / 2 + 0.35f, D / 2 - 0.35f)
            for (s in f.solids) if (nx > s[0] - 0.3f && nx < s[1] + 0.3f && nz > s[2] - 0.3f && nz < s[3] + 0.3f) {
                val px = player.x; val pz = player.z
                if (px > s[0] - 0.3f && px < s[1] + 0.3f) nz = pz else if (pz > s[2] - 0.3f && pz < s[3] + 0.3f) nx = px else { nx = px; nz = pz }
            }
        } else {
            nx = nx.coerceIn(-40f, 40f); nz = nz.coerceIn(-30f, 30f)
            if (nz < D / 2 && abs(nx) > 1.0f && nx > -W / 2 - 0.3f && nx < W / 2 + 0.3f) nz = D / 2 + 0.05f
        }
        player.x = nx; player.z = nz
        player.vy -= 18f * dt; player.y += player.vy * dt
        if (player.y <= f.y) { player.y = f.y; player.vy = 0f; player.ground = true }
        // what's close enough to use
        var best: Spot? = null; var bd = 1.9f
        for (s in spots) if (s.floor == player.floor) { val d = hypot(s.x - player.x, s.z - player.z); if (d < bd) { bd = d; best = s } }
        nearAgent = null
        for (r in agents.values) if (r.floor == player.floor) { val d = hypot(r.x - player.x, r.z - player.z); if (d < bd) { bd = d; nearAgent = r.a.id; best = null } }
        nearDog = dogFloor == player.floor && hypot(dogX - player.x, dogZ - player.z) < 1.2f
        nearSpot = best
    }

    // ───────────── each frame ─────────────
    private var clock = 0f
    fun step(dt: Float) {
        clock += dt
        val t = clock
        for (r in agents.values) moveAgent(r, dt)
        dogThink(t); moveDog(dt)
        if (mode == "explore") movePlayer(dt)
        gongSwing = max(0f, gongSwing - dt * 0.4f)
        for (c in cars) { c[0] += c[2] * c[3] * dt; if (c[0] > 70f) c[0] = -70f; if (c[0] < -70f) c[0] = 70f }
        updateCamera(dt)
    }

    private fun moveAgent(r: Rt, dt: Float) {
        if (r.path.isNotEmpty()) {
            val w = r.path[0]
            if (w.jump) { r.x = w.x; r.z = w.z; r.floor = w.floor; r.path.removeAt(0) }
            else {
                val dx = w.x - r.x; val dz = w.z - r.z; val dist = hypot(dx, dz); val step = 2.4f * dt
                r.face = atan2(dx, dz)
                if (dist <= step) { r.x = w.x; r.z = w.z; r.floor = w.floor; r.path.removeAt(0) } else { r.x += dx / dist * step; r.z += dz / dist * step }
            }
        } else r.place?.let { r.face = lerpAngle(r.face, it.face, min(1f, dt * 6f)) }
        if (r.hop > 0f) r.hop -= dt
    }
    private fun moveDog(dt: Float) {
        dogMoving = false
        if (dogPath.isNotEmpty()) {
            val w = dogPath[0]
            if (w.jump) { dogX = w.x; dogZ = w.z; dogFloor = w.floor; dogPath.removeAt(0) }
            else {
                val dx = w.x - dogX; val dz = w.z - dogZ; val dist = hypot(dx, dz); val step = (if (dogMode == "bark") 4f else 2f) * dt
                dogFace = atan2(dx, dz)
                if (dist <= step) { dogX = w.x; dogZ = w.z; dogFloor = w.floor; dogPath.removeAt(0) } else { dogX += dx / dist * step; dogZ += dz / dist * step; dogMoving = true }
            }
        }
        dogBark = !dogMoving && dogMode == "bark" && (clock % 2.2f) < 0.7f
        dogSleep = !dogMoving && dogMode == "nap"
    }
    private fun lerpAngle(a: Float, b: Float, t: Float): Float {
        var d = ((b - a + PI.toFloat()) % (2 * PI.toFloat())) - PI.toFloat(); if (d < -PI.toFloat()) d += 2 * PI.toFloat(); return a + d * t
    }

    // ───────────── drawing the characters ─────────────
    private fun character(m: Mesh, x: Float, y: Float, z: Float, face: Float, color: Int, status: String, pose: String, t: Float, you: Boolean = false): Float {
        var by = 0f; var bodyRx = 0f; var headRx = 0f; var headRz = 0f; var aL = 0f; var aR = 0f; var aLz = 0f; var aRz = 0f
        var bulb = STATUS[status] ?: 0x9CA3AF
        when (pose) {
            "walk" -> { by = abs(sin(t * 9)) * 0.08f; aL = sin(t * 9) * 0.7f; aR = -aL }
            "type", "web", "money" -> { by = sin(t * 18) * 0.01f; aL = -1.1f + sin(t * 22) * 0.18f; aR = -1.1f + cos(t * 20) * 0.18f; headRx = 0.18f }
            "read" -> { aL = -1.2f; aR = -1.2f; headRx = 0.3f + sin(t * 0.8f) * 0.05f }
            "call" -> { aR = -2.6f; aRz = 0.35f; aL = -0.2f; headRz = 0.12f }
            "talk" -> { aL = -0.6f + sin(t * 3) * 0.4f; aR = -0.3f + cos(t * 2.3f) * 0.3f; by = sin(t * 2) * 0.02f; headRz = sin(t * 1.5f) * 0.08f }
            "needs" -> { by = abs(sin(t * 6)) * 0.35f; aR = -2.9f + sin(t * 10) * 0.25f; aRz = 0.2f; if (floor(t * 4).toInt() % 2 == 0) bulb = 0xFECACA }
            "done" -> { val h = t % 3.5f; if (h < 0.5f) by = sin(h / 0.5f * PI.toFloat()) * 0.25f; if (h < 0.6f) { aL = -2.8f; aR = -2.8f } }
            "asleep" -> { headRx = 0.5f; by = sin(t * 1.2f) * 0.015f }
            "pray" -> { val cy = t % 9f
                when { cy < 3.5f -> { aL = -0.9f; aR = -0.9f; aLz = -0.5f; aRz = 0.5f }; cy < 5.5f -> { bodyRx = 1.0f; aL = -0.6f; aR = -0.6f }
                    cy < 8f -> { bodyRx = 1.45f; by = -0.45f; aL = -2.6f; aR = -2.6f }; else -> by = -0.35f } }
            else -> { by = sin(t * 1.6f) * 0.012f; headRz = sin(t * 0.5f) * 0.05f }
        }
        val skin = mix(color, 0xFFFFFF, 0.55f)
        m.with(M4.t(x, y, z).mul(M4.ry(face))) {
            m.disc(0.36f, 0f, 0.012f, 0f, 0xB9B0A0, 10, EMIT)                               // a soft shadow
            m.with(M4.t(0f, by, 0f).mul(M4.rx(bodyRx))) {
                m.sphere(0.29f, 0f, 0.62f, 0f, color, 8, 5, 1.45f)
                m.with(M4.t(0f, 1.22f, 0f).mul(M4.rx(headRx)).mul(M4.rz(headRz))) {
                    m.sphere(0.27f, 0f, 0f, 0f, skin, 8, 5)
                    m.sphere(0.045f, -0.09f, 0.03f, 0.245f, 0x111827, 4, 2); m.sphere(0.045f, 0.09f, 0.03f, 0.245f, 0x111827, 4, 2)
                    m.cyl(0.012f, 0.012f, 0.22f, 0f, 0.36f, 0f, 0x6B7280, 3)
                    m.sphere(0.065f, 0f, 0.5f, 0f, bulb, 5, 3, 1f, EMIT)
                }
                for ((side, ax, az) in listOf(Triple(-1f, aL, aLz), Triple(1f, aR, aRz))) {
                    m.with(M4.t(side * 0.31f, 0.86f, 0f).mul(M4.rx(ax)).mul(M4.rz(az))) {
                        m.sphere(0.075f, 0f, -0.2f, 0f, color, 5, 3, 2.7f)
                        if (side > 0 && pose == "call") m.box(0.06f, 0.16f, 0.03f, 0f, -0.42f, 0.07f, 0x111827)
                    }
                }
                if (pose == "read") m.with(M4.t(0f, 0.85f, 0.36f).mul(M4.rx(-0.5f))) { m.front(0.28f, 0.36f, 0f, 0f, 0f, 0xFFFFFF, EMIT or TWO) }
            }
            if (pose == "web") m.with(M4.t(0.4f, 1.55f, 0.2f).mul(M4.ry(t * 1.5f))) { m.sphere(0.16f, 0f, 0f, 0f, 0x38BDF8, 5, 3, 1f, EMIT) }
            if (pose == "money") { val k = 2 + ((sin(t * 3) + 1) * 1.5f).toInt(); for (c in 0 until k) m.cyl(0.07f, 0.07f, 0.03f, -0.35f, 0.83f + c * 0.035f, 0.45f, 0xEAB308, 6) }
        }
        return by
    }

    private fun drawDog(m: Mesh, y: Float, t: Float) {
        val tan = 0xD9A066; val dark = 0x7C4A1E
        val sleepy = !dogMoving && dogMode == "nap"
        m.with(M4.t(dogX, y, dogZ).mul(M4.ry(dogFace - PI.toFloat() / 2)).mul(M4.s(1f, if (sleepy) 0.7f else 1f, 1f))) {
            m.disc(0.2f, 0f, 0.012f, 0f, 0xB9B0A0, 8, EMIT, 1.8f)
            m.box(0.55f, 0.28f, 0.28f, 0f, 0.32f, 0f, tan)
            val hz = if (sleepy) -0.4f else if (dogBark) sin(t * 10) * 0.15f + 0.2f else 0f
            m.with(M4.t(0.33f, 0.48f, 0f).mul(M4.rz(hz))) {
                m.box(0.24f, 0.22f, 0.22f, 0f, 0f, 0f, tan); m.box(0.12f, 0.1f, 0.14f, 0.14f, -0.05f, 0f, 0xF5DEB3)
                m.box(0.05f, 0.14f, 0.08f, -0.04f, 0.12f, 0.1f, dark); m.box(0.05f, 0.14f, 0.08f, -0.04f, 0.12f, -0.1f, dark)
                m.box(0.03f, 0.04f, 0.04f, 0.21f, -0.02f, 0f, 0x111827); m.box(0.02f, 0.03f, 0.03f, 0.12f, 0.05f, 0.08f, 0x111827); m.box(0.02f, 0.03f, 0.03f, 0.12f, 0.05f, -0.08f, 0x111827)
            }
            for ((i, lx, lz) in listOf(Triple(0, 0.18f, 0.09f), Triple(1, 0.18f, -0.09f), Triple(2, -0.18f, 0.09f), Triple(3, -0.18f, -0.09f))) {
                val a = if (dogMoving) sin(t * 16 + i * PI.toFloat()) * 0.5f else 0f
                m.with(M4.t(lx, 0.2f, lz).mul(M4.rz(a))) { m.box(0.07f, 0.2f, 0.07f, 0f, -0.1f, 0f, tan) }
            }
            m.with(M4.t(-0.3f, 0.42f, 0f).mul(M4.rz(0.7f)).mul(M4.rx(sin(t * (if (dogMode == "bark") 20 else 8)) * 0.6f))) { m.box(0.18f, 0.05f, 0.05f, -0.09f, 0f, 0f, dark) }
        }
    }

    // ───────────── render ─────────────
    val labels = LinkedHashMap<String, HqLabel>()
    private val pp = FloatArray(3)

    fun render(r: Renderer, w: Float, h: Float) {
        cam.w = w; cam.h = h
        val t = clock
        // moving things
        worldDyn.clear()
        for ((i, c) in cars.withIndex()) worldDyn.with(M4.t(c[0], 0f, c[1]).mul(M4.ry(if (c[2] > 0) 0f else PI.toFloat()))) {
            worldDyn.box(2.2f, 0.55f, 1.1f, 0f, 0.45f, 0f, carCols[i]); worldDyn.box(1.2f, 0.45f, 1.0f, -0.1f, 0.95f, 0f, 0xDFE8F5)
            for ((wx, wz) in listOf(-0.7f to 0.56f, 0.7f to 0.56f, -0.7f to -0.56f, 0.7f to -0.56f)) worldDyn.box(0.44f, 0.44f, 0.12f, wx, 0.22f, wz, 0x111827)
            worldDyn.box(0.05f, 0.14f, 0.7f, 1.11f, 0.5f, 0f, 0xFFF6C0, EMIT)
        }
        for (f in floors) f.dyn.clear()
        for (a in agents.values) {
            val f = floors[a.floor]
            val walking = a.path.isNotEmpty()
            val mode0 = a.place?.mode
            val pose = when {
                walking -> "walk"; mode0 == "pray" -> "pray"; a.a.status == "needs" -> "needs"; a.a.status == "asleep" -> "asleep"
                a.a.status == "done" -> "done"; a.a.status == "working" -> a.a.pose.ifBlank { "type" }; mode0 == "table" -> "talk"; else -> "idle"
            }
            val hop = if (a.hop > 0f) abs(sin(a.hop * 8f)) * 0.3f else 0f
            a.bodyY = character(f.dyn, a.x, f.y + hop, a.z, a.face, a.a.color, a.a.status, pose, t + a.phase) + hop
            // the laptop lid glows while its agent works
            a.place?.slot?.takeIf { !walking && a.place?.mode != "table" }?.let { s ->
                if (!s.bean) f.dyn.with(M4.t(s.x, f.y + 0.83f, s.deskZ + 0.21f).mul(M4.rx(-0.35f))) {
                    f.dyn.front(0.44f, 0.28f, 0f, 0.17f, 0.012f, if (a.a.status == "asleep") 0x334155 else a.a.color, EMIT)
                }
            }
        }
        drawDog(floors[dogFloor].dyn, floors[dogFloor].y, t)
        // HQ floor live bits: jar, trays, gong, mats at salah
        floors.firstOrNull()?.let { f ->
            val v = state.jar.coerceIn(0.04f, 1f)
            f.dyn.cyl(0.25f, 0.25f, 0.66f * v, jarAt[0], jarAt[1] + 0.33f * v, jarAt[2], if (v > 0.5f) 0x22C55E else if (v > 0.2f) 0xF59E0B else 0xEF4444, 8)
            val n = min(12, state.approvals); if (n > 0) f.dyn.box(0.5f, 0.02f * n, 0.36f, -6.2f, 0.96f + 0.01f * n, -0.6f, 0xFFFFFF)
            val c = min(12, state.changes); if (c > 0) f.dyn.box(0.5f, 0.02f * c, 0.36f, -6.2f, 0.96f + 0.01f * c, 0.5f, 0xE0F2FE)
            f.dyn.with(M4.t(6.2f, 1.75f, 2.0f).mul(M4.rx(sin(t * 9) * 0.35f * gongSwing))) { f.dyn.cyl(0.45f, 0.45f, 0.05f, 0f, -0.55f, 0f, 0xD4A017, 12) }
        }
        if (state.salah) for (a in agents.values) if (a.place?.mode == "pray" && a.path.isEmpty()) {
            val f = floors[a.floor]
            f.dyn.with(M4.t(a.x, f.y + 0.012f, a.z).mul(M4.ry(qiblaYaw()))) { f.dyn.floor(0.75f, 1.3f, 0f, 0f, 0.25f, 0x166534, 2f, EMIT) }
        }
        // you
        if (mode == "explore") {
            val f = floors[player.floor]
            character(f.dyn, player.x, player.y, player.z, player.face, 0xF97316, "idle", if (player.moving && player.ground) "walk" else "idle", t, true)
        }

        updateCamera(0f)
        r.begin()
        r.layer(cam, light, ground)
        r.layer(cam, light, back)
        val top = when { mode == "explore" -> player.floor; overview -> floors.size - 1; else -> view.floor }
        val bottom = if (mode == "explore") player.floor else 0
        for (k in bottom..top) {
            val f = floors[k]
            r.layer(cam, inside, f.under); r.layer(cam, inside, f.walls); r.layer(cam, inside, f.decor); r.layer(cam, inside, f.main, f.dyn)
        }
        if (overview) r.layer(cam, light, roof)
        r.layer(cam, light, front, worldDyn)
        placeLabels(w, h, t)
    }

    private fun label(key: String, kind: String, id: String) = labels.getOrPut(key) { HqLabel(key, kind, id) }
    private fun project(x: Float, y: Float, z: Float, l: HqLabel, w: Float, h: Float, show: Boolean) {
        if (!show) { l.shown = false; return }
        cam.project(x, y, z, pp)
        l.shown = pp[2] > 0.2f && pp[0] > -60 && pp[0] < w + 60 && pp[1] > -60 && pp[1] < h + 60
        l.x = pp[0]; l.y = pp[1]
    }
    private fun placeLabels(w: Float, h: Float, t: Float) {
        val shownFloor = if (mode == "explore") player.floor else view.floor
        val close = mode == "explore" || view.focus != null || view.zoom < 1.25f
        val seen = HashSet<String>()
        for (a in agents.values) {
            val l = label("a:" + a.a.id, "agent", a.a.id); seen += l.key
            l.text = a.a.emoji + " " + a.a.name; l.sub = a.a.card; l.line = a.a.line; l.color = a.a.color; l.status = a.a.status; l.near = close
            val on = a.floor == shownFloor && !overview
            project(a.x, floors[a.floor].y + a.bodyY + 1.95f, a.z, l, w, h, on && (close || a.a.status in setOf("needs", "working", "done")))
            val b = label("b:" + a.a.id, "bubble", a.a.id); seen += b.key
            b.text = when { a.a.status == "asleep" && a.path.isEmpty() -> "z z z"; state.speaking == a.a.id && a.place?.mode == "table" && a.path.isEmpty() -> "💬"; else -> "" }
            project(a.x + 0.35f, floors[a.floor].y + 2.45f + sin(t * 3) * 0.05f, a.z, b, w, h, on && b.text.isNotEmpty())
        }
        val d = label("dog", "bubble", "dog"); seen += d.key
        d.text = if (dogBark) "Woof!" else if (dogSleep) "zz" else ""
        project(dogX, floors[dogFloor].y + 0.95f, dogZ, d, w, h, dogFloor == shownFloor && d.text.isNotEmpty() && !overview)
        // signs and boards on the floor in view
        for (f in floors) {
            val l = label("sign:${f.i}", "sign", "${f.i}"); seen += l.key
            l.text = f.room.emoji + " " + f.room.name; l.color = f.room.color
            project(-1.5f, f.y + 2.75f, -D / 2 + 0.2f, l, w, h, f.i == shownFloor && !overview)
        }
        if (floors.isNotEmpty()) {
            val f0 = floors[0]
            fun board(key: String, text: String, sub: String, x: Float, y: Float, z: Float) {
                val l = label(key, "board", key); seen += l.key; l.text = text; l.sub = sub
                project(x, f0.y + y, z, l, w, h, shownFloor == 0 && (mode == "explore" || view.zoom < 0.8f) && view.focus == null)
            }
            board("screen", "ATLAS HQ · " + state.summary, listOfNotNull(state.prayer.ifBlank { null }, if (state.loadshed) "⚡ On backup power" else null).joinToString(" · "), 2.6f, 2.5f, -D / 2 + 0.2f)
            board("routine", "⏰ " + state.routine.ifBlank { "No routines" }, "", -3.6f, 2.2f, -D / 2 + 0.2f)
            board("plugs", "🔌 ${state.plugsOk}/${state.plugsTotal} connectors ok", "", -W / 2 + 0.3f, 2.9f, 3.3f)
        }
        labels.keys.retainAll(seen)
    }

    /** What's under a tap at (x, y), if anything. */
    fun pick(x: Float, y: Float, radius: Float): Pair<String, String>? {
        val shownFloor = if (mode == "explore") player.floor else view.floor
        var best: Pair<String, String>? = null; var bd = radius
        for (a in agents.values) if (a.floor == shownFloor || overview) {
            cam.project(a.x, floors[a.floor].y + 1.0f, a.z, pp); if (pp[2] <= 0) continue
            val d = hypot(pp[0] - x, pp[1] - y) * 0.8f
            if (d < bd) { bd = d; best = "agent" to a.a.id }
            val l = labels["a:" + a.a.id]
            if (l != null && l.shown && abs(l.x - x) < 90f && y < l.y && y > l.y - 70f) { bd = 0f; best = "agent" to a.a.id }
        }
        for (s in spots) if (s.floor == shownFloor) {
            cam.project(s.x, floors[s.floor].y + s.ay, s.z, pp); if (pp[2] <= 0) continue
            val d = hypot(pp[0] - x, pp[1] - y)
            if (d < bd) { bd = d; best = s.kind to s.id }
        }
        cam.project(dogX, floors[dogFloor].y + 0.4f, dogZ, pp)
        if (dogFloor == shownFloor && pp[2] > 0 && hypot(pp[0] - x, pp[1] - y) < bd) best = "pet" to ""
        if (best?.first == "agent" && mode == "diorama") agents[best.second]?.let { view.focus = floatArrayOf(it.x, floors[it.floor].y, it.z) }
        if (best?.first == "gong") celebrate()
        if (best?.first == "pet") petDog(clock)
        return best
    }

    init { build() }
}
