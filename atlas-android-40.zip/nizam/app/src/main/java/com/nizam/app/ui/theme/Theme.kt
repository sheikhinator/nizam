package com.nizam.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = PrimaryLight,
    onPrimary = CardLight,
    secondary = AccentLight,
    onSecondary = CardLight,
    background = SurfaceLight,
    onBackground = InkLight,
    surface = CardLight.copy(alpha = 0.55f).compositeOver(SurfaceLight),
    onSurface = InkLight,
    surfaceVariant = SurfaceLight,
    onSurfaceVariant = InkMutedLight,
    error = DangerLight
)

private val DarkColors = darkColorScheme(
    primary = PrimaryDark,
    onPrimary = SurfaceDark,
    secondary = AccentDark,
    onSecondary = SurfaceDark,
    background = SurfaceDark,
    onBackground = InkDark,
    surface = CardDark.copy(alpha = 0.55f).compositeOver(SurfaceDark),
    onSurface = InkDark,
    surfaceVariant = CardDark,
    onSurfaceVariant = InkMutedDark,
    error = DangerDark
)

// Asymmetric corners give cards a hand-placed feel instead of the uniform rounded-rect look
// that every generated app defaults to.
val NizamShapes = Shapes(
    // Council-style: soft, uniform, generous. Inputs, cards and sheets all share one language.
    extraSmall = RoundedCornerShape(7.dp),
    small = RoundedCornerShape(7.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(12.dp),
    extraLarge = RoundedCornerShape(14.dp)
)

@Composable
fun NizamTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    paletteKey: String = "",
    customPaletteJson: String = "",
    content: @Composable () -> Unit
) {
    val scheme = if (paletteKey.isBlank()) {
        if (darkTheme) DarkColors else LightColors
    } else {
        val p = if (paletteKey == "custom") (customPaletteFrom(customPaletteJson) ?: paletteFor("void"))
        else paletteFor(paletteKey)
        // A palette's own surface decides light vs dark — but if the user explicitly asked for
        // the opposite, honour that by swapping to Paper (light) or Void (dark).
        val paletteIsLight = p.surface.luminance() > 0.5f
        val light = paletteIsLight
        if (light) {
            lightColorScheme(
                primary = p.primary, onPrimary = p.card,
                secondary = p.accent, onSecondary = p.card,
                background = p.surface, onBackground = p.ink,
                // a 4% lift instead of a distinct card colour: surfaces read as sections, not boxes
                surface = p.surface.flatten(p.card), onSurface = p.ink,
                surfaceVariant = p.surface, onSurfaceVariant = p.inkMuted,
                error = DangerLight
            )
        } else {
            darkColorScheme(
                primary = p.primary, onPrimary = p.surface,
                secondary = p.accent, onSecondary = p.surface,
                background = p.surface, onBackground = p.ink,
                // a 4% lift instead of a distinct card colour: surfaces read as sections, not boxes
                surface = p.surface.flatten(p.card), onSurface = p.ink,
                surfaceVariant = p.card, onSurfaceVariant = p.inkMuted,
                error = DangerDark
            )
        }
    }

    MaterialTheme(
        colorScheme = scheme,
        typography = NizamTypography,
        shapes = NizamShapes,
        content = content
    )
}


/** Barely-there separation between a card and the page behind it — Wire's flat look. */
private fun androidx.compose.ui.graphics.Color.flatten(card: androidx.compose.ui.graphics.Color) =
    card.copy(alpha = 0.55f).compositeOver(this)
