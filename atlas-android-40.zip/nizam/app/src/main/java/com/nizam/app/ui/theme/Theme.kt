package com.nizam.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp

/**
 * The default look: soft neutrals rather than pure black or white (easier on the eyes over long
 * use), one calm accent, and surfaces that separate by the faintest change in tone instead of
 * borders and shadows.
 */
private val Calm = AtlasPalette(
    "", "Calm",
    surface = Color(0xFF0F1013), card = Color(0xFF17181C), ink = Color(0xFFECEDEF), inkMuted = Color(0xFF8C9099),
    primary = Color(0xFF5CC8A8), accent = Color(0xFFE0895E)
)
private val CalmLight = AtlasPalette(
    "", "Calm light",
    surface = Color(0xFFF6F6F3), card = Color(0xFFFFFFFF), ink = Color(0xFF16171A), inkMuted = Color(0xFF6A6E75),
    primary = Color(0xFF1E7A66), accent = Color(0xFFB9602F)
)

/**
 * Every Material colour role, derived from one palette. Material's own defaults for the roles we
 * don't mention are lavender, and they leak into the tab bar, sheets and fields — so all are set.
 */
fun schemeFor(p: AtlasPalette): ColorScheme {
    val light = p.surface.luminance() > 0.5f
    fun over(c: Color, a: Float) = c.copy(alpha = a).compositeOver(p.surface)
    val field = over(p.ink, if (light) 0.05f else 0.07f)
    val hairline = over(p.ink, if (light) 0.09f else 0.10f)
    val primaryTint = over(p.primary, if (light) 0.12f else 0.18f)
    val onPrimary = if (p.primary.luminance() > 0.45f) Color(0xFF0B0C0E) else Color.White
    return if (light) lightColorScheme(
        primary = p.primary, onPrimary = onPrimary,
        primaryContainer = primaryTint, onPrimaryContainer = p.ink,
        secondary = p.accent, onSecondary = Color.White,
        secondaryContainer = primaryTint, onSecondaryContainer = p.ink,
        tertiary = p.accent, onTertiary = Color.White,
        tertiaryContainer = over(p.accent, 0.14f), onTertiaryContainer = p.ink,
        background = p.surface, onBackground = p.ink,
        surface = p.card, onSurface = p.ink,
        surfaceVariant = field, onSurfaceVariant = p.inkMuted,
        surfaceTint = Color.Transparent,
        surfaceBright = p.card, surfaceDim = p.surface,
        surfaceContainerLowest = p.card, surfaceContainerLow = p.card,
        surfaceContainer = p.card, surfaceContainerHigh = p.card, surfaceContainerHighest = field,
        inverseSurface = p.ink, inverseOnSurface = p.surface, inversePrimary = p.primary,
        outline = hairline, outlineVariant = hairline,
        error = DangerLight, onError = Color.White,
        errorContainer = over(DangerLight, 0.12f), onErrorContainer = p.ink,
        scrim = Color.Black
    ) else darkColorScheme(
        primary = p.primary, onPrimary = onPrimary,
        primaryContainer = primaryTint, onPrimaryContainer = p.ink,
        secondary = p.accent, onSecondary = Color(0xFF0B0C0E),
        secondaryContainer = primaryTint, onSecondaryContainer = p.ink,
        tertiary = p.accent, onTertiary = Color(0xFF0B0C0E),
        tertiaryContainer = over(p.accent, 0.18f), onTertiaryContainer = p.ink,
        background = p.surface, onBackground = p.ink,
        surface = p.card, onSurface = p.ink,
        surfaceVariant = field, onSurfaceVariant = p.inkMuted,
        surfaceTint = Color.Transparent,
        surfaceBright = over(p.ink, 0.10f), surfaceDim = p.surface,
        surfaceContainerLowest = p.surface, surfaceContainerLow = p.card,
        surfaceContainer = p.card, surfaceContainerHigh = over(p.ink, 0.08f), surfaceContainerHighest = field,
        inverseSurface = p.ink, inverseOnSurface = p.surface, inversePrimary = p.primary,
        outline = hairline, outlineVariant = hairline,
        error = DangerDark, onError = Color(0xFF0B0C0E),
        errorContainer = over(DangerDark, 0.18f), onErrorContainer = p.ink,
        scrim = Color.Black
    )
}

// Soft, even corners: one language for fields, cards and sheets.
val NizamShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NizamTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    paletteKey: String = "",
    customPaletteJson: String = "",
    content: @Composable () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val comfort = com.nizam.app.ui.design.Comfort.state(ctx)
    val palette = when {
        paletteKey.isBlank() -> if (darkTheme) Calm else CalmLight
        paletteKey == "custom" -> customPaletteFrom(customPaletteJson) ?: paletteFor("void")
        else -> paletteFor(paletteKey)
    }
    var scheme = schemeFor(palette)
    // Material You: colours drawn from your wallpaper (Android 12 and later)
    if (comfort.wallpaperColours && android.os.Build.VERSION.SDK_INT >= 31) {
        val dark = palette.surface.luminance() < 0.5f
        val you = if (dark) androidx.compose.material3.dynamicDarkColorScheme(ctx) else androidx.compose.material3.dynamicLightColorScheme(ctx)
        scheme = scheme.copy(primary = you.primary, onPrimary = you.onPrimary, primaryContainer = you.primaryContainer,
            onPrimaryContainer = you.onPrimaryContainer, secondary = you.secondary, tertiary = you.tertiary)
    }
    // True black for AMOLED screens: saves battery and looks deeper at night
    if (comfort.oled && scheme.background.luminance() < 0.5f) {
        scheme = scheme.copy(background = Color.Black, surfaceDim = Color.Black, surfaceContainerLowest = Color.Black,
            surface = Color(0xFF0C0C0E), surfaceContainerLow = Color(0xFF0C0C0E), surfaceContainer = Color(0xFF0C0C0E))
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = if (comfort.textScale == 1f) NizamTypography else NizamTypography.scaled(comfort.textScale),
        shapes = NizamShapes,
        content = content
    )
}

/** Every text style, grown or shrunk together (the Text size setting). */
fun androidx.compose.material3.Typography.scaled(k: Float): androidx.compose.material3.Typography {
    fun androidx.compose.ui.text.TextStyle.x() = copy(fontSize = fontSize * k,
        lineHeight = if (lineHeight == androidx.compose.ui.unit.TextUnit.Unspecified) lineHeight else lineHeight * k)
    return copy(
        displayLarge = displayLarge.x(), displayMedium = displayMedium.x(), displaySmall = displaySmall.x(),
        headlineLarge = headlineLarge.x(), headlineMedium = headlineMedium.x(), headlineSmall = headlineSmall.x(),
        titleLarge = titleLarge.x(), titleMedium = titleMedium.x(), titleSmall = titleSmall.x(),
        bodyLarge = bodyLarge.x(), bodyMedium = bodyMedium.x(), bodySmall = bodySmall.x(),
        labelLarge = labelLarge.x(), labelMedium = labelMedium.x(), labelSmall = labelSmall.x()
    )
}
