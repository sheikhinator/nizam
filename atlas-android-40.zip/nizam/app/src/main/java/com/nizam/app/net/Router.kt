package com.nizam.app.net

import android.content.Context
import com.nizam.app.data.prefs.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Picks the right path and the right model for each message, so simple things are instant and only
 * real work pays for the full agent.
 *
 *  LOCAL — parsed on the phone (LocalCommands): no network at all
 *  CHAT  — a question or conversation: one streamed call on the fastest endpoint, words appear at once
 *  ACT   — something must change in the app, the phone or a connected tool: the full agent loop
 *
 * Every call also fails over: when the chosen provider rate-limits or is down, the next endpoint you
 * have a key for takes the request instead of the user seeing an error.
 */
object Router {

    /** Set once at startup so code without a Context (Ai.generate's failover) can still reach the offline model. */
    @Volatile var appContext: Context? = null

    fun online(c: Context): Boolean = runCatching {
        val cm = c.getSystemService(android.net.ConnectivityManager::class.java)
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    }.getOrElse { true }

    enum class Lane { LOCAL, CHAT, ACT }

    /** One place a request can go. kind is "GEMINI" or "OPENAI" (any OpenAI-compatible API). */
    data class Endpoint(val name: String, val kind: String, val url: String, val key: String, val model: String) {
        val isGroq get() = url.contains("groq.com")
        /** Groq counts declared max_tokens against its per-minute budget, so ask for less there. */
        fun cap(tokens: Int) = if (isGroq) minOf(tokens, 1024) else tokens
    }

    private val ACTION = Regex(
        "\\b(open|launch|call|ring|text|sms|message|whatsapp|email|send|reply|set|add|log|record|create|make|build|" +
            "delete|remove|clear|remind|schedule|book|order|pay|play|pause|stop|start|turn|switch|enable|disable|" +
            "navigate|directions|track|mark|complete|finish|rename|change|update|edit|move|install|generate|" +
            "search|find|look up|google|download|share|save|note|alarm|timer|volume|flashlight|torch|dnd|" +
            "theme|icon|palette|module|mission|goal|task|budget|expense|spent|paid|workout|meal|prayed|" +
            "whenever|every time|autopilot|replay|timeline|yesterday|last (?:heard|talked|spoke|messaged|texted)|what happened|" +
            "brief me|briefing|subscriptions?|bills?|zakat|open loops|anything open|family)\\b",
        RegexOption.IGNORE_CASE
    )

    /** Cheap, on-device routing — no model call to decide which model to call. */
    fun classify(text: String, useWeb: Boolean, hasAttachments: Boolean, mcpServers: List<String>): Lane {
        val t = text.lowercase()
        if (useWeb) return Lane.ACT
        if (mcpServers.any { it.isNotBlank() && t.contains(it.lowercase()) }) return Lane.ACT
        if (ACTION.containsMatchIn(t)) return Lane.ACT
        // "can you …" / "please …" requests read as instructions even without a known verb
        if (Regex("^(can you|could you|please|go ahead|do it|yes|yeah|ok do)\\b").containsMatchIn(t.trim())) return Lane.ACT
        return Lane.CHAT
    }

    // ── fast lane: an optional second endpoint used for chat, e.g. Groq or Cerebras ──────────────

    private fun prefs(c: Context) = c.getSharedPreferences("router", 0)
    fun fastLane(c: Context): Endpoint? {
        val p = prefs(c)
        val url = p.getString("fast_url", "").orEmpty()
        val model = p.getString("fast_model", "").orEmpty()
        if (url.isBlank() || model.isBlank()) return null
        return Endpoint("Fast lane", "OPENAI", url.trimEnd('/') + "/chat/completions", p.getString("fast_key", "").orEmpty(), model)
    }
    fun setFastLane(c: Context, url: String, key: String, model: String) =
        prefs(c).edit().putString("fast_url", url.trim()).putString("fast_key", key.trim()).putString("fast_model", model.trim()).apply()
    fun fastLaneParts(c: Context) = Triple(
        prefs(c).getString("fast_url", "").orEmpty(), prefs(c).getString("fast_key", "").orEmpty(), prefs(c).getString("fast_model", "").orEmpty()
    )

    /** Every endpoint with credentials, the chosen provider first. For CHAT the fast lane leads. */
    suspend fun endpoints(settings: SettingsRepository, c: Context?, lane: Lane = Lane.ACT): List<Endpoint> {
        val gemini = settings.geminiApiKey.first().takeIf { it.isNotBlank() }?.let {
            Endpoint("Gemini", "GEMINI", "https://generativelanguage.googleapis.com/v1beta/models", it,
                settings.geminiModel.first().ifBlank { "gemini-flash-latest" })
        }
        val openRouter = settings.openRouterKey.first().takeIf { it.isNotBlank() }?.let {
            Endpoint("OpenRouter", "OPENAI", "https://openrouter.ai/api/v1/chat/completions", it,
                settings.openRouterModel.first().takeUnless { m -> m.isBlank() || m == "openrouter/free" }
                    ?: "deepseek/deepseek-chat-v3.1:free")
        }
        val custom = settings.customUrl.first().takeIf { it.isNotBlank() }?.let {
            Endpoint("Custom", "OPENAI", it.trimEnd('/') + "/chat/completions", settings.customKey.first(),
                settings.customModel.first().ifBlank { "llama-3.3-70b-versatile" })
        }
        val primary = when (settings.aiProvider.first()) {
            "OPENROUTER" -> openRouter
            "CUSTOM" -> custom
            else -> gemini
        }
        val fast = c?.let { fastLane(it) }
        val ctx = c ?: appContext
        val local = ctx?.takeIf { LocalModel.available(it) }?.let { Endpoint("On this phone", "LOCAL", "", "", LocalModel.file(it)?.name.orEmpty()) }
        val ordered = buildList {
            // No internet: the on-device model answers straight away instead of every provider timing out
            if (local != null && ctx != null && !online(ctx)) add(local)
            if (lane == Lane.CHAT && fast != null) add(fast)
            primary?.let { add(it) }
            listOfNotNull(gemini, custom, openRouter, fast, local).forEach { if (it !in this) add(it) }
        }
        return ordered
    }

    /** Worth trying the next provider? Rate limits, overload and timeouts yes; a bad request no. */
    fun shouldFailOver(e: Throwable): Boolean {
        val m = (e.message ?: e.javaClass.simpleName).lowercase()
        return listOf("429", "500", "502", "503", "504", "rate", "quota", "overload", "unavailable", "timeout",
            "timed out", "exhausted", "401", "403", "unable to resolve", "failed to connect", "busy", "rejected",
            "no ai provider", "no gemini", "no openrouter", "no custom endpoint").any { m.contains(it) } ||
            e is java.io.IOException
    }

    /**
     * Opens the TLS connection to the provider before the user hits send. The handshake is a third
     * of first-token latency on mobile networks; keep-alive then reuses the warm socket.
     */
    suspend fun warm(settings: SettingsRepository, c: Context) = withContext(Dispatchers.IO) {
        runCatching {
            endpoints(settings, c, Lane.CHAT).filter { it.kind != "LOCAL" }.take(2).forEach { e ->
                val host = URL(e.url).let { "${it.protocol}://${it.host}/" }
                (URL(host).openConnection() as HttpURLConnection).apply {
                    requestMethod = "HEAD"; connectTimeout = 4000; readTimeout = 4000
                    runCatching { responseCode }
                    runCatching { inputStream.close() }
                }
            }
        }
    }
}
