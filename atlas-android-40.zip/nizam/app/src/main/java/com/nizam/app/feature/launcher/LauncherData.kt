package com.nizam.app.feature.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.Process
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** One launchable app on the phone. */
data class LApp(val pkg: String, val activity: String, val label: String, val category: String, val xos: Boolean) {
    val component get() = ComponentName(pkg, activity)
}

/**
 * Everything the home screen knows: installed apps, their icons, your layout (pages, dock, folders),
 * hidden and renamed apps, and your look-and-feel choices. All of it stays on the phone.
 */
object Launcher {
    private fun p(c: Context) = c.getSharedPreferences("launcher", 0)

    // ── apps ────────────────────────────────────────────────────────────────────────────────────
    private val XOS_PREFIX = listOf("com.transsion", "com.infinix", "com.tecno", "com.itel", "com.hoffnung", "com.talpa", "com.xui", "com.afmobi",
        "net.bat.store", "com.zeroscreen", "com.carlcare", "com.gallery20", "com.sh.smart")

    suspend fun apps(c: Context): List<LApp> = withContext(Dispatchers.IO) {
        val la = c.getSystemService(LauncherApps::class.java)
        val renamed = renames(c)
        la.getActivityList(null, Process.myUserHandle()).filter { it.applicationInfo.packageName != c.packageName || it.name.endsWith("MainActivity") }
            .map { a ->
                val pkg = a.applicationInfo.packageName
                LApp(pkg, a.name, renamed[pkg] ?: a.label.toString(), category(a.applicationInfo, pkg), XOS_PREFIX.any { pkg.startsWith(it) })
            }.distinctBy { it.pkg + it.activity }.sortedBy { it.label.lowercase() }
    }

    private fun category(ai: ApplicationInfo, pkg: String): String = when {
        XOS_PREFIX.any { pkg.startsWith(it) } -> "XOS"
        Build.VERSION.SDK_INT >= 26 -> when (ai.category) {
            ApplicationInfo.CATEGORY_GAME -> "Games"; ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_AUDIO -> "Music & audio"; ApplicationInfo.CATEGORY_VIDEO -> "Video"
            ApplicationInfo.CATEGORY_IMAGE -> "Photos"; ApplicationInfo.CATEGORY_MAPS -> "Travel & maps"
            ApplicationInfo.CATEGORY_NEWS -> "News & reading"; ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
            else -> guess(pkg)
        }
        else -> guess(pkg)
    }
    private fun guess(p: String) = when {
        listOf("whatsapp", "telegram", "messenger", "instagram", "facebook", "snapchat", "twitter", "tiktok", "discord", "signal", "reddit").any { p.contains(it) } -> "Social"
        listOf("bank", "pay", "wallet", "finance", "easypaisa", "jazzcash", "hbl", "meezan").any { p.contains(it) } -> "Money"
        listOf("chrome", "browser", "firefox", "opera", "brave").any { p.contains(it) } -> "Browsers"
        listOf("dialer", "contacts", "mms", "messaging", "camera", "gallery", "clock", "calculator", "settings", "calendar", "files", "filemanager").any { p.contains(it) } -> "Utilities"
        listOf("youtube", "netflix", "video", "player").any { p.contains(it) } -> "Video"
        listOf("music", "spotify", "audio", "podcast").any { p.contains(it) } -> "Music & audio"
        listOf("mail", "gm", "docs", "office", "drive", "notion", "keep").any { p.contains(it) } -> "Productivity"
        p.startsWith("com.google") || p.startsWith("com.android") -> "Google & system"
        else -> "Other"
    }

    // ── icons (cached, shaped at draw time) ─────────────────────────────────────────────────────
    private val icons = LruCache<String, ImageBitmap>(320)
    fun cachedIcon(pkg: String): ImageBitmap? = icons.get(pkg)
    suspend fun icon(c: Context, app: LApp, px: Int = 144): ImageBitmap? = icons.get(app.pkg) ?: withContext(Dispatchers.IO) {
        runCatching {
            val la = c.getSystemService(LauncherApps::class.java)
            val d = la.resolveActivity(Intent().setComponent(app.component), Process.myUserHandle())?.getBadgedIcon(0)
                ?: c.packageManager.getApplicationIcon(app.pkg)
            d.toBitmap(px, px, Bitmap.Config.ARGB_8888).asImageBitmap().also { icons.put(app.pkg, it) }
        }.getOrNull()
    }

    fun launch(c: Context, app: LApp, bounds: android.graphics.Rect? = null) = runCatching {
        c.getSystemService(LauncherApps::class.java).startMainActivity(app.component, Process.myUserHandle(), bounds, null)
        usedNow(c, app.pkg)
    }.getOrElse { c.packageManager.getLaunchIntentForPackage(app.pkg)?.let { c.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }

    /** App shortcuts (long-press menu) — Android only gives these to the default launcher. */
    fun shortcuts(c: Context, pkg: String): List<ShortcutInfo> = runCatching {
        val la = c.getSystemService(LauncherApps::class.java)
        if (!la.hasShortcutHostPermission()) return emptyList()
        la.getShortcuts(LauncherApps.ShortcutQuery().setPackage(pkg).setQueryFlags(
            LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED),
            Process.myUserHandle()).orEmpty().take(5)
    }.getOrElse { emptyList() }
    fun startShortcut(c: Context, s: ShortcutInfo) = runCatching { c.getSystemService(LauncherApps::class.java).startShortcut(s, null, null) }

    // ── layout: pages of slots ("pkg" or "folder:<id>"), a dock, folders ─────────────────────────
    data class Layout(val pages: List<List<String>>, val dock: List<String>, val folders: Map<String, Pair<String, List<String>>>)

    fun layout(c: Context): Layout? = runCatching {
        val o = JSONObject(p(c).getString("layout", null) ?: return null)
        fun list(a: JSONArray?) = a?.let { x -> (0 until x.length()).map { x.optString(it) } } ?: emptyList()
        Layout(o.optJSONArray("pages")?.let { a -> (0 until a.length()).map { list(a.getJSONArray(it)) } } ?: emptyList(),
            list(o.optJSONArray("dock")),
            o.optJSONObject("folders")?.let { f -> f.keys().asSequence().associateWith { k -> f.getJSONObject(k).let { it.optString("name") to list(it.optJSONArray("apps")) } } } ?: emptyMap())
    }.getOrNull()

    fun save(c: Context, l: Layout) = p(c).edit().putString("layout", JSONObject()
        .put("pages", JSONArray().apply { l.pages.forEach { put(JSONArray(it)) } })
        .put("dock", JSONArray(l.dock))
        .put("folders", JSONObject().apply { l.folders.forEach { (k, v) -> put(k, JSONObject().put("name", v.first).put("apps", JSONArray(v.second))) } })
        .toString()).apply()

    /** First run: a dock of phone, messages, browser and camera; then every app, alphabetically, a page at a time. */
    fun defaultLayout(c: Context, all: List<LApp>, perPage: Int): Layout {
        fun roleApp(i: Intent) = c.packageManager.resolveActivity(i, 0)?.activityInfo?.packageName?.takeIf { p -> all.any { it.pkg == p } }
        val dock = listOfNotNull(roleApp(Intent(Intent.ACTION_DIAL)), roleApp(Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:"))),
            roleApp(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://example.com"))), roleApp(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE))).distinct()
        val rest = all.map { it.pkg }.distinct().filter { it !in dock && it !in hidden(c) }
        val atlasFirst = listOf(c.packageName).filter { p -> all.any { it.pkg == p } }
        return Layout((atlasFirst + rest.filter { it != c.packageName }).chunked(perPage), dock, emptyMap())
    }

    /** New apps land on the last page; uninstalled ones disappear everywhere. */
    fun reconcile(c: Context, l: Layout, all: List<LApp>, perPage: Int): Layout {
        val have = all.map { it.pkg }.toSet()
        val folders = l.folders.mapValues { (_, v) -> v.first to v.second.filter { it in have } }.filterValues { it.second.isNotEmpty() }
        val pages = l.pages.map { pg -> pg.filter { s -> if (s.startsWith("folder:")) s.removePrefix("folder:") in folders else s in have } }.filter { it.isNotEmpty() }
        val dock = l.dock.filter { it in have }
        val placed = (pages.flatten() + dock + folders.values.flatMap { it.second }).toSet()
        val fresh = have.filter { it !in placed && it !in hidden(c) }.sortedBy { p -> all.first { it.pkg == p }.label.lowercase() }
        val out = pages.toMutableList()
        fresh.forEach { f -> if (out.isEmpty() || out.last().size >= perPage) out += listOf(f) else out[out.lastIndex] = out.last() + f }
        return Layout(out, dock, folders)
    }

    // ── hidden, renamed, recents, usage ─────────────────────────────────────────────────────────
    fun hidden(c: Context): Set<String> = p(c).getStringSet("hidden", emptySet()) ?: emptySet()
    fun setHidden(c: Context, pkg: String, hide: Boolean) = p(c).edit().putStringSet("hidden", hidden(c).let { if (hide) it + pkg else it - pkg }).apply()
    fun renames(c: Context): Map<String, String> = runCatching { JSONObject(p(c).getString("renames", "{}")!!).let { o -> o.keys().asSequence().associateWith { o.getString(it) } } }.getOrElse { emptyMap() }
    fun rename(c: Context, pkg: String, name: String?) = p(c).edit().putString("renames", JSONObject(renames(c).toMutableMap().apply { if (name.isNullOrBlank()) remove(pkg) else put(pkg, name) }).toString()).apply()
    fun recent(c: Context) = p(c).getString("recent", "").orEmpty().split(',').filter { it.isNotBlank() }
    private fun usedNow(c: Context, pkg: String) = p(c).edit().putString("recent", (listOf(pkg) + recent(c).filter { it != pkg }).take(12).joinToString(",")).apply()

    // ── look and feel ───────────────────────────────────────────────────────────────────────────
    fun get(c: Context, k: String, d: String) = p(c).getString("s_$k", d) ?: d
    fun set(c: Context, k: String, v: String) = p(c).edit().putString("s_$k", v).apply()
}

/** Infinix XOS features: the XOS apps on this phone plus deep links into XOS/Android settings panels. */
object Xos {
    data class Feature(val label: String, val intent: Intent)

    /** Well-known XOS screens, each tried by package first, then by the standard Android action. */
    fun features(c: Context): List<Feature> {
        val pm = c.packageManager
        fun ok(i: Intent) = i.resolveActivity(pm) != null
        fun pkg(vararg names: String): Intent? = names.firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
        val list = listOf(
            "Folax" to (pkg("com.transsion.folax", "com.transsion.aivoiceassistant", "com.transsion.ai.assistant")),
            "Phone Master" to pkg("com.transsion.phonemaster", "com.cyin.himgr"),
            "Game Space" to pkg("com.transsion.gamemode", "com.transsion.gamespace", "com.transsion.gamecenter"),
            "Themes" to pkg("com.transsion.theme", "com.transsion.theme.store"),
            "Screen recorder" to pkg("com.transsion.screenrecord", "com.transsion.screenrecorder"),
            "Carlcare" to pkg("com.transsion.carlcare", "com.carlcare"),
            "XOS Cloud" to pkg("com.transsion.cloud", "com.transsion.infinixcloud"),
            "Palm Store" to pkg("net.bat.store", "com.transsion.market"),
            "Smart Panel" to pkg("com.transsion.smartpanel", "com.transsion.sidebar"),
            "Kids Mode" to pkg("com.transsion.kidsmode", "com.transsion.childmode"),
            "Magic voice" to pkg("com.transsion.magicvoice", "com.transsion.voicechanger"),
            "AI Gallery" to pkg("com.gallery20", "com.transsion.gallery"),
            "File manager" to pkg("com.transsion.filemanagerx", "com.android.documentsui"),
            "Recorder" to pkg("com.transsion.soundrecorder", "com.android.soundrecorder"),
            "Weather" to pkg("com.transsion.weather", "com.infinix.weather"),
            "Notes" to pkg("com.transsion.notebook", "com.transsion.note"),
        ).mapNotNull { (l, i) -> i?.let { Feature(l, it) } }
        val settings = listOf(
            "Battery" to Intent(android.content.Intent.ACTION_POWER_USAGE_SUMMARY),
            "Display" to Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS),
            "Sound" to Intent(android.provider.Settings.ACTION_SOUND_SETTINGS),
            "Wi-Fi" to Intent(android.provider.Settings.ACTION_WIFI_SETTINGS),
            "Bluetooth" to Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS),
            "Mobile data" to Intent(android.provider.Settings.ACTION_DATA_ROAMING_SETTINGS),
            "Hotspot" to Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
            "Location" to Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS),
            "Storage" to Intent(android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
            "Apps" to Intent(android.provider.Settings.ACTION_APPLICATION_SETTINGS),
            "Notifications" to Intent("android.settings.ALL_APPS_NOTIFICATION_SETTINGS"),
            "Digital wellbeing" to Intent("android.settings.USAGE_ACCESS_SETTINGS").let { i ->
                pkg("com.google.android.apps.wellbeing")?.let { it } ?: i },
            "Security" to Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS),
            "Privacy" to Intent(android.provider.Settings.ACTION_PRIVACY_SETTINGS),
            "Accessibility" to Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS),
            "Date & time" to Intent(android.provider.Settings.ACTION_DATE_SETTINGS),
            "Language" to Intent(android.provider.Settings.ACTION_LOCALE_SETTINGS),
            "Developer options" to Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
            "About phone" to Intent(android.provider.Settings.ACTION_DEVICE_INFO_SETTINGS),
            "System update" to Intent("android.settings.SYSTEM_UPDATE_SETTINGS"),
            "Wallpaper" to Intent(Intent.ACTION_SET_WALLPAPER),
        ).filter { ok(it.second) }.map { Feature(it.first, it.second) }
        return list + settings
    }

    /**
     * Infinix GT features (Mecha Loop RGB lights, GT/game mode, shoulder triggers, cooling/performance):
     * there's no public API, so Atlas looks inside the phone's XOS apps for the screens that control them
     * and opens those directly.
     */
    fun gt(c: Context): List<Feature> {
        val pm = c.packageManager
        val words = listOf("light" to "Light effects", "mecha" to "Mecha Loop lights", "rgb" to "RGB lights", "breath" to "Light effects",
            "game" to "Game mode", "xarena" to "XArena", "trigger" to "Shoulder triggers", "shoulder" to "Shoulder triggers",
            "cool" to "Cooling", "thermal" to "Cooling", "performance" to "Performance mode", "turbo" to "Turbo mode", "refresh" to "Refresh rate")
        val out = linkedMapOf<String, Feature>()
        val pkgs = runCatching { pm.getInstalledPackages(0).map { it.packageName } }.getOrElse { emptyList() }
            .filter { p -> listOf("com.transsion", "com.infinix", "com.android.settings", "com.hoffnung", "com.xui").any { p.startsWith(it) } }
        for (p in pkgs) {
            val acts = runCatching { pm.getPackageInfo(p, android.content.pm.PackageManager.GET_ACTIVITIES).activities?.toList() }.getOrNull().orEmpty()
            for (a in acts) {
                if (!a.exported) continue
                val n = a.name.lowercase()
                val hit = words.firstOrNull { (w, _) -> n.substringAfterLast('.').contains(w) } ?: continue
                if (n.contains("receiver") || n.contains("service") || n.contains("dialog") || n.contains("test")) continue
                out.putIfAbsent(hit.second, Feature(hit.second, Intent().setClassName(p, a.name)))
            }
        }
        return out.values.toList()
    }

    data class Heat(val tempC: Float, val status: String)
    fun heat(c: Context): Heat {
        val i = c.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (i?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val st = if (Build.VERSION.SDK_INT >= 29) when (c.getSystemService(android.os.PowerManager::class.java).currentThermalStatus) {
            android.os.PowerManager.THERMAL_STATUS_NONE -> "Cool"; android.os.PowerManager.THERMAL_STATUS_LIGHT -> "Warm"
            android.os.PowerManager.THERMAL_STATUS_MODERATE -> "Hot"; android.os.PowerManager.THERMAL_STATUS_SEVERE -> "Very hot"
            else -> "Critical" } else if (t < 38) "Cool" else if (t < 42) "Warm" else "Hot"
        return Heat(t, st)
    }
}
