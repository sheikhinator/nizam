package com.nizam.app.ui.screens.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.nizam.app.ui.nav.Routes
import com.nizam.app.ui.theme.DisplayFamily

private data class App(val emoji: String, val name: String, val blurb: String, val route: String, val tint: Color)

private val APPS = listOf(
    App("🎬", "Cinema", "Films, series, your addons", Routes.CINEMA, Color(0xFF8A4F6B)),
    App("🎙", "Podcasts", "Subscribe, download, listen", Routes.PODCASTS, Color(0xFF4FC3A1))
)

@Composable
fun AppsScreen(onOpen: (String) -> Unit) {
    LazyVerticalGrid(GridCells.Fixed(1), Modifier.fillMaxSize().padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.padding(top = 16.dp, bottom = 4.dp)) {
                Text("Apps", style = MaterialTheme.typography.headlineMedium.copy(fontFamily = DisplayFamily))
                Text("Cinema and Podcasts", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(APPS, key = { it.route }) { app ->
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.aspectRatio(2.1f).clickable(role = Role.Button) { onOpen(app.route) }) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Box(Modifier.size(44.dp).background(app.tint.copy(alpha = 0.18f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center) { Text(app.emoji, style = MaterialTheme.typography.titleLarge) }
                    Column {
                        Text(app.name, style = MaterialTheme.typography.titleMedium)
                        Text(app.blurb, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(60.dp)) }
    }
}
