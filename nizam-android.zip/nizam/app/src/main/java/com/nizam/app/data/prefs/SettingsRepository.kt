package com.nizam.app.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: androidx.datastore.core.DataStore<Preferences> by preferencesDataStore(name = "nizam_settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

class SettingsRepository(private val context: Context) {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val currencyKey = stringPreferencesKey("currency")
    private val latKey = doublePreferencesKey("latitude")
    private val lngKey = doublePreferencesKey("longitude")
    private val methodKey = stringPreferencesKey("prayer_method")
    private val hanafiKey = booleanPreferencesKey("hanafi_asr")
    private val hadithKeyKey = stringPreferencesKey("hadith_api_key")
    private val geminiKeyKey = stringPreferencesKey("gemini_api_key")
    private val geminiModelKey = stringPreferencesKey("gemini_model")

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        when (prefs[themeKey]) {
            "LIGHT" -> ThemeMode.LIGHT
            "DARK" -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
    }

    val currency: Flow<String> = context.dataStore.data.map { it[currencyKey] ?: "PKR" }
    val latitude: Flow<Double> = context.dataStore.data.map { it[latKey] ?: 31.5204 }
    val longitude: Flow<Double> = context.dataStore.data.map { it[lngKey] ?: 74.3587 }
    val prayerMethod: Flow<String> = context.dataStore.data.map { it[methodKey] ?: "KARACHI" }
    val hanafiAsr: Flow<Boolean> = context.dataStore.data.map { it[hanafiKey] ?: true }
    val hadithApiKey: Flow<String> = context.dataStore.data.map { it[hadithKeyKey] ?: "" }
    val geminiApiKey: Flow<String> = context.dataStore.data.map { it[geminiKeyKey] ?: "" }
    val geminiModel: Flow<String> = context.dataStore.data.map { it[geminiModelKey] ?: "gemini-2.5-flash" }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }
    suspend fun setCurrency(code: String) {
        context.dataStore.edit { it[currencyKey] = code }
    }
    suspend fun setLocation(lat: Double, lng: Double) {
        context.dataStore.edit {
            it[latKey] = lat
            it[lngKey] = lng
        }
    }
    suspend fun setPrayerMethod(method: String) {
        context.dataStore.edit { it[methodKey] = method }
    }
    suspend fun setHanafiAsr(value: Boolean) {
        context.dataStore.edit { it[hanafiKey] = value }
    }
    suspend fun setHadithApiKey(key: String) {
        context.dataStore.edit { it[hadithKeyKey] = key.trim() }
    }
    suspend fun setGeminiApiKey(key: String) {
        context.dataStore.edit { it[geminiKeyKey] = key.trim() }
    }
    suspend fun setGeminiModel(model: String) {
        context.dataStore.edit { it[geminiModelKey] = model.trim() }
    }
}
