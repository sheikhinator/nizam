package com.nizam.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.nizam.app.feature.diary.DiaryDao
import com.nizam.app.feature.diary.DiaryEntry
import com.nizam.app.feature.diary.MoodCheckIn
import com.nizam.app.feature.diet.BodyMetric
import com.nizam.app.feature.diet.DietDao
import com.nizam.app.feature.diet.MealItem
import com.nizam.app.feature.diet.WaterLog
import com.nizam.app.feature.finance.Budget
import com.nizam.app.feature.finance.FinanceDao
import com.nizam.app.feature.finance.Txn
import com.nizam.app.feature.gym.Cardio
import com.nizam.app.feature.gym.GymDao
import com.nizam.app.feature.gym.WorkoutSet
import com.nizam.app.feature.hadith.Hadith
import com.nizam.app.feature.hadith.HadithDao
import com.nizam.app.feature.learning.Flashcard
import com.nizam.app.feature.learning.LearningDao
import com.nizam.app.feature.learning.StudySession
import com.nizam.app.feature.learning.Track
import com.nizam.app.feature.library.Book
import com.nizam.app.feature.library.BookDao
import com.nizam.app.feature.notes.Note
import com.nizam.app.feature.notes.NoteDao
import com.nizam.app.feature.prayer.PrayerDao
import com.nizam.app.feature.prayer.PrayerDay
import com.nizam.app.feature.prayer.PrayerExtra
import com.nizam.app.feature.quotes.Quote
import com.nizam.app.feature.quotes.QuoteDao
import com.nizam.app.feature.quran.Ayah
import com.nizam.app.feature.quran.AyahBookmark
import com.nizam.app.feature.quran.QuranDao
import com.nizam.app.feature.survival.ChecklistItem
import com.nizam.app.feature.survival.SurvivalDao

@Database(
    entities = [
        DayLog::class, Task::class, Project::class, Habit::class, HabitEntry::class,
        PrayerDay::class, PrayerExtra::class,
        Txn::class, Budget::class,
        MealItem::class, WaterLog::class, BodyMetric::class,
        WorkoutSet::class, Cardio::class,
        Note::class,
        Book::class,
        DiaryEntry::class, MoodCheckIn::class,
        Ayah::class, AyahBookmark::class,
        Hadith::class,
        Track::class, StudySession::class, Flashcard::class,
        ChecklistItem::class,
        Quote::class
    ],
    version = 2,
    exportSchema = false
)
abstract class NizamDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun habitDao(): HabitDao
    abstract fun dayLogDao(): DayLogDao
    abstract fun prayerDao(): PrayerDao
    abstract fun financeDao(): FinanceDao
    abstract fun dietDao(): DietDao
    abstract fun gymDao(): GymDao
    abstract fun noteDao(): NoteDao
    abstract fun bookDao(): BookDao
    abstract fun diaryDao(): DiaryDao
    abstract fun quranDao(): QuranDao
    abstract fun hadithDao(): HadithDao
    abstract fun learningDao(): LearningDao
    abstract fun survivalDao(): SurvivalDao
    abstract fun quoteDao(): QuoteDao

    companion object {
        @Volatile
        private var INSTANCE: NizamDatabase? = null

        fun get(context: Context): NizamDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    NizamDatabase::class.java,
                    "nizam.db"
                )
                    // v1 → v2 adds every module table. v1 only ever held a few test tasks, so this
                    // one jump is destructive. From v2 onward, write real migrations.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
