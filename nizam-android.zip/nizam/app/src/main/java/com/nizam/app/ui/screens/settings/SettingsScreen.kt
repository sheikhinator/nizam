package com.nizam.app.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.data.prefs.ThemeMode
import com.nizam.app.ui.components.SectionHeader
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val settings = container.settingsRepository
    val theme by settings.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
    val currency by settings.currency.collectAsState(initial = "PKR")
    val hadithKey by settings.hadithApiKey.collectAsState(initial = "")
    val geminiKey by settings.geminiApiKey.collectAsState(initial = "")
    val geminiModel by settings.geminiModel.collectAsState(initial = "gemini-2.5-flash")

    var hadithDraft by remember(hadithKey) { mutableStateOf(hadithKey) }
    var geminiDraft by remember(geminiKey) { mutableStateOf(geminiKey) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))

        SectionHeader("APPEARANCE")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.entries.forEach { mode ->
                FilterChip(
                    selected = theme == mode,
                    onClick = { scope.launch { settings.setThemeMode(mode) } },
                    label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("CURRENCY")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("PKR", "USD", "AED", "SAR").forEach { code ->
                FilterChip(
                    selected = currency == code,
                    onClick = { scope.launch { settings.setCurrency(code) } },
                    label = { Text(code) }
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("API KEYS")
        Text(
            "Keys are stored on this device only and are never sent anywhere except the service they belong to.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = hadithDraft,
                onValueChange = { hadithDraft = it },
                label = { Text("Hadith API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { scope.launch { settings.setHadithApiKey(hadithDraft) } }) { Text("Save") }
        }
        Text(
            "Get a free key at hadithapi.com. Without it, the Hadith module shows nothing rather than unsourced text.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = geminiDraft,
                onValueChange = { geminiDraft = it },
                label = { Text("Gemini API key (optional)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { scope.launch { settings.setGeminiApiKey(geminiDraft) } }) { Text("Save") }
        }
        Text(
            "Powers courses, the assistant, and the Ask panels in Diet, Gym, Finance, Diary, Survival and News. " +
                "Get a key at aistudio.google.com.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Text("Model", style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("gemini-2.5-flash", "gemini-2.5-pro").forEach { m ->
                FilterChip(
                    selected = geminiModel == m,
                    onClick = { scope.launch { settings.setGeminiModel(m) } },
                    label = { Text(m.removePrefix("gemini-")) }
                )
            }
        }
        Text(
            "Flash is fast and cheap; Pro writes better lectures but is slower. If Google renames its models, " +
                "the app keeps working — change the name here.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(20.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(14.dp))

        SectionHeader("ABOUT")
        Text("Nizam 0.3.0 — AI courses, assistant and news", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            "Your data stays on this device. The only network calls are Quran text (Al Quran Cloud) and Hadith (hadithapi.com), both cached after first use.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(40.dp))
    }
}
