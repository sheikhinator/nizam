package com.nizam.app.net

import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

/** Minimal HTTP helper — no third-party networking library needed. */
object Http {
    fun getJson(url: String, headers: Map<String, String> = emptyMap()): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return body
        } finally {
            connection.disconnect()
        }
    }
}
