package com.nizam.app.ui.screens.modules

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nizam.app.ui.nav.Routes
import com.nizam.app.ui.theme.Spine

private data class ModuleCard(val name: String, val route: String, val color: Color)

private val modules = listOf(
    ModuleCard("Tasks", Routes.TASKS, Spine.Tasks),
    ModuleCard("Prayer", Routes.PRAYER, Spine.Prayer),
    ModuleCard("Finance", Routes.FINANCE, Spine.Finance),
    ModuleCard("Diet", Routes.DIET, Spine.Diet),
    ModuleCard("Gym", Routes.GYM, Spine.Gym),
    ModuleCard("Notes", Routes.NOTES, Spine.Notes),
    ModuleCard("Library", Routes.LIBRARY, Spine.Library),
    ModuleCard("Diary", Routes.DIARY, Spine.Diary),
    ModuleCard("Quran", Routes.QURAN, Spine.Scripture),
    ModuleCard("Hadith", Routes.HADITH, Spine.Scripture),
    ModuleCard("Learning", Routes.LEARNING, Spine.Learning),
    ModuleCard("Survival", Routes.SURVIVAL, Spine.Survival),
    ModuleCard("Quotes", Routes.QUOTES, Spine.Diary),
    ModuleCard("Courses", Routes.COURSES, Spine.Learning),
    ModuleCard("Assistant", Routes.ASSISTANT, Spine.Notes),
    ModuleCard("News", Routes.NEWS, Spine.Finance),
    ModuleCard("Search", Routes.SEARCH, Spine.Notes)
)

@Composable
fun ModulesScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("Modules", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(modules) { module ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(76.dp)
                        .clickable { onOpen(module.route) }
                ) {
                    Row(Modifier.fillMaxWidth()) {
                        Box(
                            Modifier
                                .width(4.dp)
                                .fillMaxHeight()
                                .background(module.color, RoundedCornerShape(2.dp))
                        )
                        Column(Modifier.padding(14.dp)) {
                            Text(module.name, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
}
