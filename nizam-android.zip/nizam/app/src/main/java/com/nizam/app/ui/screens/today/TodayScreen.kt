package com.nizam.app.ui.screens.today

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nizam.app.AppContainer
import com.nizam.app.core.fmtAmount
import com.nizam.app.core.hourToClock
import com.nizam.app.core.today
import com.nizam.app.core.vmFactory
import com.nizam.app.feature.diary.DiaryViewModel
import com.nizam.app.feature.diet.DietViewModel
import com.nizam.app.feature.finance.FinanceViewModel
import com.nizam.app.feature.gym.GymViewModel
import com.nizam.app.feature.learning.LearningViewModel
import com.nizam.app.feature.prayer.PrayerViewModel
import com.nizam.app.feature.quotes.QuotesViewModel
import com.nizam.app.feature.quotes.quoteOfTheDay
import com.nizam.app.ui.components.EmptyState
import com.nizam.app.ui.components.SpineSection
import com.nizam.app.ui.components.StreakDot
import com.nizam.app.ui.nav.Routes
import com.nizam.app.ui.screens.tasks.TasksViewModel
import com.nizam.app.ui.theme.MonoNumber
import com.nizam.app.ui.theme.Spine
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter

@Composable
fun TodayScreen(container: AppContainer, onOpen: (String) -> Unit) {
    val tasksVm: TasksViewModel = viewModel(
        factory = TasksViewModel.factory(container.taskRepository, container.habitRepository)
    )
    val prayerVm: PrayerViewModel = viewModel(
        key = "prayer",
        factory = vmFactory { PrayerViewModel(container.prayerRepository, container.settingsRepository) }
    )
    val financeVm: FinanceViewModel = viewModel(
        key = "finance", factory = vmFactory { FinanceViewModel(container.financeRepository) }
    )
    val dietVm: DietViewModel = viewModel(
        key = "diet", factory = vmFactory { DietViewModel(container.dietRepository) }
    )
    val gymVm: GymViewModel = viewModel(
        key = "gym", factory = vmFactory { GymViewModel(container.gymRepository) }
    )
    val diaryVm: DiaryViewModel = viewModel(
        key = "diary", factory = vmFactory { DiaryViewModel(container.diaryRepository) }
    )
    val learningVm: LearningViewModel = viewModel(
        key = "learning", factory = vmFactory { LearningViewModel(container.learningRepository) }
    )
    val quotesVm: QuotesViewModel = viewModel(
        key = "quotes", factory = vmFactory { QuotesViewModel(container.quoteRepository) }
    )

    val tasks by tasksVm.tasks.collectAsState()
    val habits by tasksVm.habits.collectAsState()
    val habitEntries by tasksVm.todayEntries.collectAsState()
    val prayerDay by prayerVm.day.collectAsState()
    val lat by prayerVm.latitude.collectAsState()
    val lng by prayerVm.longitude.collectAsState()
    val method by prayerVm.methodName.collectAsState()
    val hanafi by prayerVm.hanafi.collectAsState()
    val month by financeVm.thisMonth.collectAsState()
    val meals by dietVm.items.collectAsState()
    val water by dietVm.water.collectAsState()
    val sets by gymVm.sets.collectAsState()
    val entries by diaryVm.entries.collectAsState()
    val due by learningVm.due.collectAsState()
    val quotes by quotesVm.quotes.collectAsState()

    val date = LocalDate.now()
    val hijri = runCatching {
        HijrahDate.from(date).format(DateTimeFormatter.ofPattern("d MMMM y G"))
    }.getOrElse { "" }

    val times = remember(lat, lng, method, hanafi) { prayerVm.times() }
    val nowHours = java.time.LocalTime.now().let { it.hour + it.minute / 60.0 }
    val upcoming = listOf(
        "Fajr" to times.fajr, "Dhuhr" to times.dhuhr, "Asr" to times.asr,
        "Maghrib" to times.maghrib, "Isha" to times.isha
    ).firstOrNull { it.second > nowHours }

    val openTasks = tasks.filter { it.completedAt == null }
    val doneToday = tasks.count { it.completedAt != null }
    val spentToday = month.filter { it.kind == "EXPENSE" && it.localDate == today() }.sumOf { it.amount }
    val kcal = meals.sumOf { it.kcal }.toInt()
    val todaySets = sets.filter { it.localDate == today() }
    val entryToday = entries.any { it.localDate == today() }
    val prayerStatuses = prayerDay?.let {
        listOf(it.fajr, it.dhuhr, it.asr, it.maghrib, it.isha)
    } ?: List(5) { "NOT_PRAYED" }
    val quote = quoteOfTheDay(quotes)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(20.dp))
        Text(date.dayOfMonth.toString(), style = MaterialTheme.typography.displaySmall)
        Text(
            date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy")),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (hijri.isNotEmpty()) {
            Text(hijri, style = MonoNumber, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(18.dp))

        SpineSection(
            label = "Prayer",
            spineColor = Spine.Prayer,
            trailing = prayerStatuses.count { it != "NOT_PRAYED" }.toString() + "/5"
        ) {
            Column(Modifier.clickable { onOpen(Routes.PRAYER) }) {
                Text(
                    if (upcoming != null) "Next: ${upcoming.first} at ${hourToClock(upcoming.second)}"
                    else "All prayers passed for today",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    prayerStatuses.forEach { status ->
                        StreakDot(filled = status != "NOT_PRAYED", color = Spine.Prayer)
                        Spacer(Modifier.width(8.dp))
                    }
                }
            }
        }

        SpineSection(
            label = "Tasks",
            spineColor = Spine.Tasks,
            trailing = "${openTasks.size} open · $doneToday done"
        ) {
            Column(Modifier.clickable { onOpen(Routes.TASKS) }) {
                if (openTasks.isEmpty()) {
                    EmptyState("No open tasks — add one")
                } else {
                    openTasks.take(4).forEach {
                        Text(it.title, style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(vertical = 3.dp))
                    }
                    if (openTasks.size > 4) {
                        Text("+${openTasks.size - 4} more", style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        SpineSection(
            label = "Habits",
            spineColor = Spine.Tasks,
            trailing = "${habitEntries.size}/${habits.size}"
        ) {
            Row(Modifier.clickable { onOpen(Routes.TASKS) }, verticalAlignment = Alignment.CenterVertically) {
                if (habits.isEmpty()) {
                    EmptyState("No habits yet — add your first")
                } else {
                    habits.take(10).forEach { habit ->
                        StreakDot(filled = habitEntries.any { it.habitId == habit.id }, color = Spine.Tasks)
                        Spacer(Modifier.width(8.dp))
                    }
                }
            }
        }

        SpineSection(label = "Finance", spineColor = Spine.Finance, trailing = fmtAmount(spentToday)) {
            Text(
                if (spentToday == 0.0) "Nothing spent today" else "Spent today",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.clickable { onOpen(Routes.FINANCE) }
            )
        }

        SpineSection(label = "Diet", spineColor = Spine.Diet, trailing = "$kcal kcal") {
            Text(
                "${water?.ml ?: 0} ml water · ${meals.size} items logged",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.clickable { onOpen(Routes.DIET) }
            )
        }

        SpineSection(label = "Gym", spineColor = Spine.Gym, trailing = "${todaySets.size} sets") {
            Text(
                if (todaySets.isEmpty()) "No sets logged — rest day?" else "Training logged today",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.clickable { onOpen(Routes.GYM) }
            )
        }

        SpineSection(label = "Learning", spineColor = Spine.Learning, trailing = "${due.size} due") {
            Text(
                if (due.isEmpty()) "No cards due today" else "Cards waiting for review",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.clickable { onOpen(Routes.LEARNING) }
            )
        }

        SpineSection(label = "Diary", spineColor = Spine.Diary) {
            Text(
                if (entryToday) "Written today" else "Nothing written yet today",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.clickable { onOpen(Routes.DIARY) }
            )
        }

        SpineSection(label = "Library", spineColor = Spine.Library) {
            Text(
                "Open your books",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.clickable { onOpen(Routes.LIBRARY) }
            )
        }

        SpineSection(label = "Quote", spineColor = Spine.Scripture) {
            Text(
                quote?.text ?: "No quotes saved yet",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.clickable { onOpen(Routes.QUOTES) }
            )
        }

        Spacer(Modifier.height(32.dp))
    }
}
