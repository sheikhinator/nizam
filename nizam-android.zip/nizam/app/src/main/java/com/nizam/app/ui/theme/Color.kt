package com.nizam.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light
val SurfaceLight = Color(0xFFF4F5F7)
val CardLight = Color(0xFFFFFFFF)
val InkLight = Color(0xFF141A2E)
val InkMutedLight = Color(0xFF5C6478)
val PrimaryLight = Color(0xFF2E7D6F)
val AccentLight = Color(0xFFC9832B)
val DangerLight = Color(0xFFB3453A)

// Dark
val SurfaceDark = Color(0xFF101521)
val CardDark = Color(0xFF182031)
val InkDark = Color(0xFFE7EAF2)
val InkMutedDark = Color(0xFF98A1B5)
val PrimaryDark = Color(0xFF4FA694)
val AccentDark = Color(0xFFE0A032)
val DangerDark = Color(0xFFD9695C)

// Module spine colours
object Spine {
    val Tasks = Color(0xFF2E7D6F)
    val Prayer = Color(0xFF1F6F63)
    val Finance = Color(0xFFC9832B)
    val Diet = Color(0xFF6B8E4E)
    val Gym = Color(0xFF3E5C76)
    val Notes = Color(0xFF4A5468)
    val Library = Color(0xFF8A5A3B)
    val Diary = Color(0xFF6E4A7E)
    val Scripture = Color(0xFF2C4A42)
    val Learning = Color(0xFF3A4A8C)
    val Survival = Color(0xFFA44A28)
}
