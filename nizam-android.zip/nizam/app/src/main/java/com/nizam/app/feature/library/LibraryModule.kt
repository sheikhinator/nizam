package com.nizam.app.feature.library

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.core.vmFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Entity(tableName = "book")
data class Book(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String = "",
    val format: String = "TXT",
    val fileUri: String = "",
    val status: String = "TO_READ",
    val progressPercent: Int = 0,
    val addedAt: Long = System.currentTimeMillis()
)

@Dao
interface BookDao {
    @Query("SELECT * FROM book ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<Book>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(book: Book)

    @Update
    suspend fun update(book: Book)

    @Delete
    suspend fun delete(book: Book)
}

class BookRepository(private val dao: BookDao) {
    fun all() = dao.observeAll()
    suspend fun add(book: Book) = dao.insert(book)
    suspend fun save(book: Book) = dao.update(book)
    suspend fun remove(book: Book) = dao.delete(book)
}

class LibraryViewModel(private val repository: BookRepository) : ViewModel() {
    val books: StateFlow<List<Book>> = repository.all()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(title: String, uri: String, format: String) {
        viewModelScope.launch {
            repository.add(Book(title = title, fileUri = uri, format = format, status = "READING"))
        }
    }

    fun save(book: Book) = viewModelScope.launch { repository.save(book) }
    fun delete(book: Book) = viewModelScope.launch { repository.remove(book) }
}

@Composable
fun LibraryScreen(container: AppContainer) {
    val vm: LibraryViewModel = viewModel(factory = vmFactory { LibraryViewModel(container.bookRepository) })
    val books by vm.books.collectAsState()
    val context = LocalContext.current

    var reading by remember { mutableStateOf<Book?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Untitled"
            val format = when {
                name.endsWith(".pdf", true) -> "PDF"
                name.endsWith(".epub", true) -> "EPUB"
                name.endsWith(".md", true) -> "MD"
                else -> "TXT"
            }
            vm.add(name.substringBeforeLast('.'), uri.toString(), format)
        }
    }

    val current = reading
    if (current != null) {
        Reader(book = current, onBack = { reading = null }, onSave = { vm.save(it) })
        return
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ModuleTitle("Library", "Text and markdown open in the reader; PDF and EPUB open in your device app")

        Button(onClick = {
            picker.launch(arrayOf("text/plain", "text/markdown", "application/pdf", "application/epub+zip", "*/*"))
        }) { Text("Add a book from storage") }

        Spacer(Modifier.height(12.dp))
        Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)

        if (books.isEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(
                "No books yet — add one from your device storage.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(books, key = { it.id }) { book ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        if (book.format == "TXT" || book.format == "MD") {
                            reading = book
                        } else {
                            runCatching {
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(
                                        Uri.parse(book.fileUri),
                                        if (book.format == "PDF") "application/pdf" else "application/epub+zip"
                                    )
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(intent)
                            }
                        }
                    }.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(book.title, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "${book.format} · ${book.progressPercent}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(onClick = { vm.delete(book) }) { Text("Remove") }
                }
                Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.surfaceVariant)
            }
        }
    }
}

@Composable
private fun Reader(book: Book, onBack: () -> Unit, onSave: (Book) -> Unit) {
    val context = LocalContext.current
    var text by remember(book.id) { mutableStateOf("Loading…") }
    var fontSize by remember { mutableStateOf(17f) }

    androidx.compose.runtime.LaunchedEffect(book.id) {
        text = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(book.fileUri))?.use { stream ->
                    stream.bufferedReader().readText()
                } ?: "Could not open this file."
            }.getOrElse { "Could not open this file. It may have been moved or deleted." }
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back to library")
            }
            Text(book.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        }
        Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 14f..28f)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Text(
                text,
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = fontSize.sp, lineHeight = (fontSize * 1.6).sp)
            )
            Spacer(Modifier.height(40.dp))
        }
    }
}
