package com.nizam.app.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Gemini client. The key is yours, entered in Settings and stored on the device.
 * Note it ships inside the APK's storage — fine for a personal build, not for a shared one.
 */
object Gemini {

    class MissingKeyException : Exception("No Gemini API key. Add one in Settings.")

    suspend fun generate(
        apiKey: String,
        prompt: String,
        system: String? = null,
        model: String = "gemini-2.5-flash",
        maxOutputTokens: Int = 8192
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw MissingKeyException()

        val parts = JSONArray().put(JSONObject().put("text", prompt))
        val contents = JSONArray().put(
            JSONObject().put("role", "user").put("parts", parts)
        )
        val body = JSONObject().apply {
            put("contents", contents)
            if (!system.isNullOrBlank()) {
                put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
            }
            put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.7)
                    .put("maxOutputTokens", maxOutputTokens)
            )
        }.toString()

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val response = Http.postJson(url, body)
        val root = JSONObject(response)

        val candidates = root.optJSONArray("candidates")
            ?: throw IllegalStateException(
                root.optJSONObject("error")?.optString("message") ?: "Empty response from Gemini."
            )
        if (candidates.length() == 0) throw IllegalStateException("Gemini returned nothing.")

        val partsOut = candidates.getJSONObject(0)
            .optJSONObject("content")?.optJSONArray("parts")
            ?: throw IllegalStateException("Gemini returned no text.")

        val builder = StringBuilder()
        for (i in 0 until partsOut.length()) {
            builder.append(partsOut.getJSONObject(i).optString("text", ""))
        }
        builder.toString().trim()
    }

    /** Strips markdown fences so model output can be parsed as JSON. */
    fun cleanJson(raw: String): String {
        var s = raw.trim()
        if (s.startsWith("```")) {
            s = s.substringAfter('\n', "")
            s = s.substringBeforeLast("```")
        }
        val start = s.indexOfFirst { it == '{' || it == '[' }
        val end = s.indexOfLast { it == '}' || it == ']' }
        return if (start >= 0 && end > start) s.substring(start, end + 1) else s
    }
}
