package com.nizam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.foundation.isSystemInDarkTheme
import com.nizam.app.data.prefs.ThemeMode
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.nizam.app.feature.onboarding.OnboardingScreen
import com.nizam.app.ui.nav.NizamApp
import com.nizam.app.ui.theme.NizamTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as NizamApplication).container

        setContent {
            val mode by container.settingsRepository.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
            val dark = when (mode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            val onboarded by container.settingsRepository.onboarded.collectAsState(initial = true)
            var showApp by remember { mutableStateOf(false) }
            NizamTheme(darkTheme = dark) {
                if (onboarded || showApp) {
                    NizamApp(container)
                } else {
                    OnboardingScreen(
                        settings = container.settingsRepository,
                        onDone = { showApp = true }
                    )
                }
            }
        }
    }
}
