# Nizam

A private, offline-first personal companion app for Android. Kotlin + Jetpack Compose + Room.
No accounts, no cloud, no analytics. Everything lives on the device.

**All 13 modules are built.** Tasks, Habits, Prayer, Finance, Diet, Gym, Notes, Library, Diary,
Quran, Hadith, Learning, Survival and Quotes, plus the Day Sheet, cross-module search and settings.

---

## Getting an APK without a PC

1. Create a new **public or private repo** on GitHub (e.g. `nizam`).
2. Upload the **contents** of this zip to the repo root. The repo root must contain
   `settings.gradle.kts`, `build.gradle.kts`, the `app/` folder and the `.github/` folder.
   (If you drag the zip into GitHub's web uploader, unzip it first — GitHub does not unzip for you.)
3. Go to the **Actions** tab and enable workflows if prompted.
4. The `Build APK` workflow runs on every push. You can also start it manually:
   Actions → Build APK → **Run workflow**.
5. When it finishes (about 4–8 minutes on the first run), open the run and download the
   **nizam-debug-apk** artifact. Unzip it to get `app-debug.apk`.
6. On your phone: open the APK, allow "install from unknown sources" for your browser or file
   manager when prompted, and install.

The APK is a **debug build**, signed with the standard Android debug key. That is fine for
installing on your own phone. It is not suitable for the Play Store — that needs a release build
signed with your own keystore.

## Building on a computer instead

Open the folder in Android Studio (Koala or newer), let it sync, then Run. Or from a terminal with
the Android SDK installed:

```
gradle wrapper          # once, to generate ./gradlew
./gradlew assembleDebug
```

The APK lands in `app/build/outputs/apk/debug/`.

---

## If the first build fails

This scaffold was written without a compiler to test against, so expect one or two fixes on the
first run. The workflow log tells you exactly what broke — scroll to the first line containing
`error:`.

The usual suspects, and what to do:

| Symptom | Fix |
|---|---|
| `Unsupported class file major version` | JDK mismatch — the workflow pins 17, don't change it |
| AGP / Gradle version complaint | bump `gradle-version` in `.github/workflows/build-apk.yml` to match what AGP 8.5.2 asks for |
| Unresolved reference in a Compose call | a library version moved; check the exact import named in the error |
| Room "cannot find implementation" | KSP didn't run — confirm the `com.google.devtools.ksp` plugin line survived the upload |

Paste the failing lines into Claude or the AI Studio agent and ask for a fix to that one file.

## Project layout

```
app/src/main/java/com/nizam/app/
├─ NizamApplication.kt      Application + AppContainer (manual DI)
├─ MainActivity.kt          single Activity, Compose host
├─ ui/
│  ├─ theme/                colours, type scale, module spine colours
│  ├─ nav/                  bottom nav + NavHost
│  ├─ components/           SpineSection, StatTile, StreakDot, EmptyState
│  └─ screens/              today · modules · tasks · search · settings
└─ data/
   ├─ db/                   Room entities, DAOs, database
   ├─ prefs/                DataStore settings
   └─ repo/                 repositories
```

## Adding the next module

Each module is a phase in the spec document. Open the project in Google AI Studio Build mode, or
Android Studio with an AI assistant, and paste one phase prompt at a time. Always start the prompt
with:

> Keep the existing architecture, theme tokens, navigation, database conventions and component
> library exactly as they are. Add a Room migration rather than destroying existing data. Build only
> what I describe below.

Recommended order: Prayer → Finance → Diary → Diet → Gym → Notes → Library → Quran → Hadith →
Learning → Survival → Quotes.

---

## What each module does

| Module | Works today | Needs something from you |
|---|---|---|
| Tasks & Habits | add, complete, delete tasks; habits with daily dots | — |
| Prayer | five prayers with on-time / late / jamaah / qada, offline prayer time calculation, 30-day stats | set your latitude and longitude once (defaults to Lahore) |
| Finance | income and expenses, categories, monthly totals, top categories, daily spend | — |
| Diet | meals by slot, calories and protein, water, weight log | targets are hardcoded at 2200 kcal / 3000 ml; change them in `DietScreen` |
| Gym | log sets, previous-session reference, estimated 1RM, volume | — |
| Notes | markdown notes, `[[wikilinks]]`, backlinks, search | — |
| Library | import books via storage picker, built-in reader for TXT and MD | PDF and EPUB hand off to your device's reader app |
| Diary | entries, 1–5 mood, emotion chips, rotating prompts, mood average | — |
| Quran | full surah list, Arabic + English, cached offline after first open | internet once per surah |
| Hadith | six major collections, Arabic + English with grading and reference | free API key from hadithapi.com, entered in Settings |
| Learning | tracks, study minutes, SM-2 spaced repetition flashcards | — |
| Survival | offline topics, seeded checklists, one-tap emergency numbers | — |
| Quotes | your own collection, deterministic quote of the day | you add the quotes |

### Two deliberate design decisions

**Scripture is never generated.** Quran text comes from the Al Quran Cloud API and hadith from
hadithapi.com, both cached into the local database. If a source is unreachable or a key is missing,
the module says so rather than displaying anything unsourced.

**First aid is not generated either.** The Survival module ships practical non-medical guidance and
checklists. The first aid topic tells you to get trained and to keep a printed manual from a
recognised body. Add your own vetted material.

### Prayer times

Calculated on-device from solar geometry — no network, no API. Accurate to roughly a minute.
Check them against your local masjid once; if they are consistently off, switch the calculation
method (Karachi, MWL, ISNA, Egyptian, Umm al-Qura) and the Asr madhab in the Prayer module.

### Database note

The database is at version 2 and this jump uses a destructive migration, because version 1 only
existed in the earlier scaffold. **From now on, write real migrations** — the app is where your
data lives.

## Conventions to keep

- Every entity: `id: Long` autogenerate, `createdAt`, `updatedAt`, `deletedAt: Long?` for soft delete.
- Anything belonging to a day carries `localDate: String` in `YYYY-MM-DD`.
- Bump the database version and write a real migration. Never `fallbackToDestructiveMigration()`.
- Numbers, amounts and times render in the mono type style (`MonoNumber`).
- Each module gets one spine colour, used only in its rail and header.
- No network call is ever required for the app to open and work.
