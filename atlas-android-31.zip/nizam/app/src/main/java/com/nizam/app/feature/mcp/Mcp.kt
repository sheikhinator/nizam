package com.nizam.app.feature.mcp

import android.content.Context
import com.nizam.app.net.Http
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Model Context Protocol client. MCP servers speak JSON-RPC 2.0 over HTTP: you initialize, they hand
 * back a session id, then you list tools and call them. Responses come back either as plain JSON or
 * as an SSE stream, so both are handled.
 *
 * Any MCP server you point Atlas at becomes usable in the Playground AND callable by the Curator —
 * which is what makes this open-ended rather than a fixed list of integrations.
 */
data class McpServer(val name: String, val url: String, val token: String, val enabled: Boolean)
data class McpTool(val server: String, val name: String, val description: String, val schema: JSONObject?)

/** One piece of a tool's reply. MCP can return text, images, audio, embedded files or links. */
data class McpPart(
    val kind: String,            // text | image | audio | file | link
    val text: String = "",
    val mime: String = "",
    val file: java.io.File? = null,
    val uri: String = ""
)

object Mcp {
    private val sessions = HashMap<String, String>()          // server url -> session id
    private val toolCache = HashMap<String, List<McpTool>>()

    private fun f(c: Context) = File(c.filesDir, "mcp.json")

    fun servers(c: Context): List<McpServer> = runCatching { JSONArray(f(c).readText()) }.getOrElse { JSONArray() }
        .let { a -> (0 until a.length()).map { a.getJSONObject(it) }.map {
            McpServer(it.optString("name"), it.optString("url"), it.optString("token"), it.optBoolean("enabled", true)) } }

    fun save(c: Context, list: List<McpServer>) = f(c).writeText(JSONArray().apply {
        list.forEach { put(JSONObject().put("name", it.name).put("url", it.url).put("token", it.token).put("enabled", it.enabled)) }
    }.toString())

    /** MCP replies can be SSE; the payload is the last `data:` line. */
    private fun payload(raw: String): JSONObject {
        val body = if (raw.contains("data:")) raw.lines().filter { it.startsWith("data:") }
            .joinToString("\n") { it.removePrefix("data:").trim() }.trim().lines().last() else raw.trim()
        return JSONObject(body)
    }

    /** Turns transport failures into something that says what to actually do about it. */
    private fun explain(e: Throwable): Throwable {
        val m = e.message.orEmpty()
        return when {
            m.contains("401") || m.contains("access token", true) || m.contains("unauthor", true) ->
                IllegalStateException("this server needs authentication — either paste a bearer token above, or append " +
                    "your key to the URL, e.g. …/mcp?apikey=YOUR_KEY")
            m.contains("404") -> IllegalStateException("no MCP endpoint at that URL — most servers end in /mcp or /sse")
            m.contains("405") -> IllegalStateException("that URL doesn't accept MCP requests — check you copied the server URL, not its homepage")
            m.contains("Unable to resolve host") -> IllegalStateException("couldn't reach that address — check the URL and your connection")
            else -> e
        }
    }

    private suspend fun rpc(server: McpServer, method: String, params: JSONObject?, id: Int = 1): JSONObject {
        val req = JSONObject().put("jsonrpc", "2.0").put("id", id).put("method", method)
        if (params != null) req.put("params", params)
        val headers = buildMap {
            put("Content-Type", "application/json")
            put("Accept", "application/json, text/event-stream")
            if (server.token.isNotBlank()) put("Authorization", "Bearer ${server.token}")
            sessions[server.url]?.let { put("Mcp-Session-Id", it) }
        }
        val raw = runCatching {
            Http.postJsonWithHeaders(server.url, req.toString(), headers) { name, value ->
                if (name.equals("Mcp-Session-Id", true)) sessions[server.url] = value    // keep the session alive
            }
        }.getOrElse { throw explain(it) }
        val o = payload(raw)
        o.optJSONObject("error")?.let { throw IllegalStateException(it.optString("message", "MCP error ${it.optInt("code")}")) }
        return o.optJSONObject("result") ?: JSONObject()
    }

    /** Handshake. Must happen before anything else, and returns the server's own name and version. */
    suspend fun connect(server: McpServer): String {
        sessions.remove(server.url)
        val result = rpc(server, "initialize", JSONObject()
            .put("protocolVersion", "2025-06-18")
            .put("capabilities", JSONObject())
            .put("clientInfo", JSONObject().put("name", "Atlas").put("version", "1.0")))
        runCatching { rpc(server, "notifications/initialized", null, id = 0) }    // best-effort; some servers require it
        val info = result.optJSONObject("serverInfo")
        return listOfNotNull(info?.optString("name"), info?.optString("version")).filter { it.isNotBlank() }.joinToString(" ")
            .ifBlank { "connected" }
    }

    suspend fun tools(server: McpServer, refresh: Boolean = false): List<McpTool> {
        if (!refresh) toolCache[server.url]?.let { return it }
        if (sessions[server.url] == null) connect(server)
        val arr = rpc(server, "tools/list", JSONObject(), id = 2).optJSONArray("tools") ?: JSONArray()
        val list = (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            McpTool(server.name, it.optString("name"), it.optString("description"), it.optJSONObject("inputSchema"))
        }
        toolCache[server.url] = list
        return list
    }

    /** Calls a tool and returns every part of its reply, media included. */
    suspend fun callRich(c: Context, server: McpServer, tool: String, args: JSONObject): List<McpPart> {
        if (sessions[server.url] == null) connect(server)
        val result = rpc(server, "tools/call", JSONObject().put("name", tool).put("arguments", args), id = 3)
        val parts = parts(c, result, tool)
        if (result.optBoolean("isError"))
            throw IllegalStateException(parts.firstOrNull { it.kind == "text" }?.text?.take(300)
                ?: "the tool reported an error")
        // structuredContent is a newer field some servers use instead of text blocks
        if (parts.isEmpty()) result.optJSONObject("structuredContent")?.let {
            return listOf(McpPart("text", it.toString(2)))
        }
        return parts
    }

    private fun parts(c: Context, result: JSONObject, tool: String): List<McpPart> {
        val content = result.optJSONArray("content") ?: return emptyList()
        val dir = java.io.File(c.filesDir, "mcp").apply { mkdirs() }
        return (0 until content.length()).map { content.getJSONObject(it) }.mapNotNull { block ->
            when (block.optString("type")) {
                "text" -> McpPart("text", block.optString("text"))
                "image", "audio" -> {
                    val mime = block.optString("mimeType", if (block.optString("type") == "image") "image/png" else "audio/mpeg")
                    val bytes = runCatching { android.util.Base64.decode(block.optString("data"), android.util.Base64.DEFAULT) }.getOrNull()
                        ?: return@mapNotNull McpPart("text", "(unreadable ${block.optString("type")})")
                    val f = java.io.File(dir, "${tool}_${System.currentTimeMillis()}.${mime.substringAfter('/').substringBefore('+')}")
                    f.writeBytes(bytes)
                    McpPart(block.optString("type"), mime = mime, file = f)
                }
                "resource" -> {
                    val r = block.optJSONObject("resource") ?: return@mapNotNull null
                    val mime = r.optString("mimeType")
                    when {
                        r.has("text") -> McpPart("text", r.optString("text"), mime)
                        r.has("blob") -> {
                            val bytes = runCatching { android.util.Base64.decode(r.optString("blob"), android.util.Base64.DEFAULT) }.getOrNull()
                            val name = r.optString("uri").substringAfterLast('/').ifBlank { "${tool}_${System.currentTimeMillis()}" }
                            val f = java.io.File(dir, name)
                            if (bytes != null) { f.writeBytes(bytes)
                                McpPart(if (mime.startsWith("image")) "image" else "file", mime = mime, file = f, uri = r.optString("uri"))
                            } else null
                        }
                        else -> McpPart("link", r.optString("uri"), mime, uri = r.optString("uri"))
                    }
                }
                "resource_link" -> McpPart("link", block.optString("name"), block.optString("mimeType"), uri = block.optString("uri"))
                else -> McpPart("text", "[${block.optString("type")}]")
            }
        }
    }

    private fun text(result: JSONObject): String {
        val content = result.optJSONArray("content") ?: return result.toString().take(4000)
        return (0 until content.length()).map { content.getJSONObject(it) }.joinToString("\n") { c ->
            when (c.optString("type")) {
                "text" -> c.optString("text")
                "resource" -> c.optJSONObject("resource")?.optString("text").orEmpty()
                else -> "[${c.optString("type")}]"
            }
        }.trim().take(6000)
    }

    /** Remembered so the chat can show media a tool returned. */
    var lastParts: List<McpPart> = emptyList()
        private set
    fun noteParts(p: List<McpPart>) { lastParts = p }
    fun clearParts() { lastParts = emptyList() }

    /**
     * The tools most likely to matter for what was just asked. A server can expose hundreds; putting
     * all of them in the prompt buries the model, so they're scored locally against the message and
     * only the best are offered. This is what makes any MCP server usable without you learning it.
     */
    suspend fun relevant(c: Context, query: String, limit: Int = 20): List<McpTool> {
        val all = allTools(c)
        if (all.size <= limit) return all
        val words = query.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length > 2 }
        fun score(t: McpTool): Int {
            val hay = (t.name + " " + t.description).lowercase()
            return words.sumOf { w -> if (hay.contains(w)) (if (t.name.lowercase().contains(w)) 3 else 1).toInt() else 0 }
        }
        val scored = all.map { it to score(it) }.filter { it.second > 0 }.sortedByDescending { it.second }
        // nothing matched the words: fall back to a spread across servers so the model still sees options
        return (if (scored.isEmpty()) all.groupBy { it.server }.flatMap { it.value.take(6) } else scored.map { it.first }).take(limit)
    }

    /** Full schema for one tool, for when the summary isn't enough. */
    suspend fun schemaOf(c: Context, toolName: String): String {
        val t = allTools(c).firstOrNull { it.name.equals(toolName, true) }
            ?: return "No connected tool called \"$toolName\". Use mcp_tools to see what exists."
        return "${t.name} (${t.server})\n${t.description}\nInput schema:\n${t.schema?.toString(2) ?: "(none declared)"}"
    }

    /** The block handed to the agent each turn. */
    suspend fun promptBlock(c: Context, query: String): String {
        val tools = runCatching { relevant(c, query) }.getOrElse { emptyList() }
        if (tools.isEmpty()) return ""
        return "\n── CONNECTED TOOLS you can call right now with mcp_call {tool, args} ──\n" +
            tools.joinToString("\n") { t ->
                val argKeys = t.schema?.optJSONObject("properties")?.keys()?.asSequence()?.toList().orEmpty()
                val required = t.schema?.optJSONArray("required")?.let { r -> (0 until r.length()).map { r.optString(it) } }.orEmpty()
                val props = t.schema?.optJSONObject("properties")
                val argDesc = argKeys.joinToString(", ") { k ->
                    val spec = props?.optJSONObject(k)
                    val type = spec?.optString("type").orEmpty().ifBlank { "any" }
                    val enum = spec?.optJSONArray("enum")?.let { e -> (0 until minOf(6, e.length())).joinToString("|") { e.optString(it) } }
                    "$k:${enum ?: type}${if (k in required) "*" else ""}"
                }
                "${t.name} (${t.server}): ${t.description.take(320)}" +
                    (if (argKeys.isEmpty()) "" else "\n    args: $argDesc")
            } + "\n(* = required. Use mcp_tools only if none of these fit.)\n"
    }

    /** Every tool the AI is allowed to reach, across all enabled servers. */
    suspend fun allTools(c: Context): List<McpTool> = servers(c).filter { it.enabled }
        .flatMap { runCatching { tools(it) }.getOrElse { emptyList() } }

    suspend fun findAndCallRich(c: Context, toolName: String, args: JSONObject): List<McpPart> {
        for (s in servers(c).filter { it.enabled }) {
            val match = runCatching { tools(s) }.getOrElse { emptyList() }.firstOrNull { it.name == toolName }
            if (match != null) return callRich(c, s, toolName, args).also { noteParts(it) }
        }
        throw IllegalStateException("No connected MCP server offers a tool called \"$toolName\"")
    }

    suspend fun findAndCall(c: Context, toolName: String, args: JSONObject): String {
        for (s in servers(c).filter { it.enabled }) {
            val match = runCatching { tools(s) }.getOrElse { emptyList() }.firstOrNull { it.name == toolName }
            if (match != null) return callRich(c, s, toolName, args).also { noteParts(it) }.joinToString("\n") { p ->
                when (p.kind) {
                    "text" -> p.text
                    "link" -> "[link: ${p.uri}]"
                    else -> "[${p.kind} saved as ${p.file?.name} — visible in the Playground]"
                }
            }.take(6000)
        }
        throw IllegalStateException("No connected MCP server offers a tool called \"$toolName\"")
    }
}
