// Offline text writer (Qwen2.5 GGUF via llama.cpp) for titles and descriptions.
//
// Speed:
//   * the model stays loaded between calls;
//   * the long, constant style prompt ("prefix") is evaluated once and its KV cache kept — each
//     new item only evaluates its own short tag list before generating;
//   * tokens are streamed back to Kotlin as they are produced.
// Text is passed as raw UTF-8 bytes in both directions: JNI's NewStringUTF expects *modified*
// UTF-8 and would choke on emoji, so Kotlin does the decoding.
#include <jni.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <vector>

#include "llama.h"

namespace {

constexpr auto kDeadline = std::chrono::seconds(90);

struct Writer {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    const llama_vocab * vocab = nullptr;
    int32_t n_ctx = 0;
    int32_t n_batch = 0;
    std::vector<llama_token> prefix;   // tokens currently cached at positions [0, prefix.size())
    std::mutex mutex;
    std::atomic<bool> cancel{false};
    std::chrono::steady_clock::time_point deadline{};

    ~Writer() {
        if (ctx) llama_free(ctx);
        if (model) llama_model_free(model);
    }
};

bool abort_cb(void * data) {
    auto * w = static_cast<Writer *>(data);
    return w->cancel.load(std::memory_order_relaxed) || std::chrono::steady_clock::now() > w->deadline;
}

void throw_java(JNIEnv * env, const char * msg) {
    env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), msg);
}

std::string utf8(JNIEnv * env, jbyteArray bytes) {
    if (!bytes) return {};
    const jsize n = env->GetArrayLength(bytes);
    std::string s(static_cast<size_t>(n), '\0');
    if (n > 0) env->GetByteArrayRegion(bytes, 0, n, reinterpret_cast<jbyte *>(&s[0]));
    return s;
}

std::vector<llama_token> tokenize(const Writer & w, const std::string & text, bool add_special) {
    std::vector<llama_token> out(text.size() + 16);
    int32_t n = llama_tokenize(w.vocab, text.data(), static_cast<int32_t>(text.size()),
                               out.data(), static_cast<int32_t>(out.size()), add_special, true);
    if (n < 0) {
        out.resize(static_cast<size_t>(-n));
        n = llama_tokenize(w.vocab, text.data(), static_cast<int32_t>(text.size()),
                           out.data(), static_cast<int32_t>(out.size()), add_special, true);
    }
    if (n < 0) throw std::runtime_error("Tokenization failed");
    out.resize(static_cast<size_t>(n));
    return out;
}

/** Evaluates tokens at positions starting from the current end of the cache, in batch-sized chunks. */
void eval(Writer & w, const std::vector<llama_token> & tokens) {
    for (size_t i = 0; i < tokens.size(); i += static_cast<size_t>(w.n_batch)) {
        const int32_t n = static_cast<int32_t>(std::min(tokens.size() - i, static_cast<size_t>(w.n_batch)));
        llama_batch batch = llama_batch_get_one(const_cast<llama_token *>(tokens.data() + i), n);
        if (llama_decode(w.ctx, batch) != 0) {
            if (abort_cb(&w)) throw std::runtime_error(w.cancel ? "cancelled" : "The writer took too long");
            throw std::runtime_error("Prompt evaluation failed");
        }
    }
}

} // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_nizam_app_feature_netscape_ai_NativeWriter_nativeOpen(JNIEnv * env, jobject, jstring path, jint threads, jint n_ctx) {
    if (!path) { throw_java(env, "model path required"); return 0; }
    const char * p = env->GetStringUTFChars(path, nullptr);
    std::unique_ptr<Writer> w(new Writer());
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    w->model = llama_model_load_from_file(p, mp);
    env->ReleaseStringUTFChars(path, p);
    if (!w->model) { throw_java(env, "Unable to load the writer model"); return 0; }
    w->vocab = llama_model_get_vocab(w->model);
    llama_context_params cp = llama_context_default_params();
    w->n_ctx = std::max(256, static_cast<int>(n_ctx));
    w->n_batch = std::min(512, w->n_ctx);
    cp.n_ctx = static_cast<uint32_t>(w->n_ctx);
    cp.n_batch = static_cast<uint32_t>(w->n_batch);
    cp.n_ubatch = static_cast<uint32_t>(w->n_batch);
    cp.n_threads = std::max(1, static_cast<int>(threads));
    cp.n_threads_batch = cp.n_threads;
    w->ctx = llama_init_from_model(w->model, cp);
    if (!w->ctx) { throw_java(env, "Unable to create the writer context"); return 0; }
    llama_set_abort_callback(w->ctx, abort_cb, w.get());
    return reinterpret_cast<jlong>(w.release());
}

/** Asks a running generation to stop as soon as possible (safe from any thread). */
extern "C" JNIEXPORT void JNICALL
Java_com_nizam_app_feature_netscape_ai_NativeWriter_nativeCancel(JNIEnv *, jobject, jlong handle) {
    if (handle) reinterpret_cast<Writer *>(handle)->cancel.store(true);
}

/**
 * Generates a continuation of prefix+suffix (both already chat-formatted, UTF-8).
 * Calls listener.onBytes(byte[]) for each piece; if it returns false, generation stops.
 * Returns the number of tokens generated.
 */
extern "C" JNIEXPORT jint JNICALL
Java_com_nizam_app_feature_netscape_ai_NativeWriter_nativeGenerate(
        JNIEnv * env, jobject, jlong handle, jbyteArray prefix_bytes, jbyteArray suffix_bytes,
        jint max_tokens, jfloat temp, jfloat top_p, jfloat min_p, jfloat repeat_penalty, jint seed,
        jobject listener) {
    if (!handle || !listener) { throw_java(env, "writer closed"); return 0; }
    auto * w = reinterpret_cast<Writer *>(handle);
    std::lock_guard<std::mutex> lock(w->mutex);
    w->cancel.store(false);
    w->deadline = std::chrono::steady_clock::now() + kDeadline;

    jclass cls = env->GetObjectClass(listener);
    jmethodID on_bytes = env->GetMethodID(cls, "onBytes", "([B)Z");
    if (!on_bytes) return 0;  // NoSuchMethodError pending

    llama_sampler * chain = nullptr;
    int generated = 0;
    try {
        const std::vector<llama_token> pre = tokenize(*w, utf8(env, prefix_bytes), false);
        const std::vector<llama_token> suf = tokenize(*w, utf8(env, suffix_bytes), false);
        const int room = w->n_ctx - static_cast<int>(pre.size() + suf.size()) - 1;
        if (room < 16) throw std::runtime_error("Prompt too long for the writer");
        llama_memory_t mem = llama_get_memory(w->ctx);
        if (pre != w->prefix) {
            // New style prompt: rebuild the cache from scratch.
            llama_memory_clear(mem, true);
            w->prefix.clear();
            eval(*w, pre);
            w->prefix = pre;
        } else {
            // Same style prompt: keep its cached keys/values, drop the previous item.
            llama_memory_seq_rm(mem, 0, static_cast<llama_pos>(pre.size()), -1);
        }
        eval(*w, suf);

        chain = llama_sampler_chain_init(llama_sampler_chain_default_params());
        llama_sampler_chain_add(chain, llama_sampler_init_penalties(
                llama_vocab_n_tokens(w->vocab), 96, repeat_penalty, 0.0f, 0.0f));
        llama_sampler_chain_add(chain, llama_sampler_init_top_k(60));
        llama_sampler_chain_add(chain, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(chain, llama_sampler_init_min_p(min_p, 1));
        llama_sampler_chain_add(chain, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(chain, llama_sampler_init_dist(static_cast<uint32_t>(seed)));

        char buf[256];
        const int limit = std::clamp(static_cast<int>(max_tokens), 1, room);
        for (int i = 0; i < limit; ++i) {
            if (abort_cb(w)) break;
            llama_token tok = llama_sampler_sample(chain, w->ctx, -1);
            if (llama_vocab_is_eog(w->vocab, tok)) break;
            llama_sampler_accept(chain, tok);
            const int n = llama_token_to_piece(w->vocab, tok, buf, sizeof(buf), 0, false);
            ++generated;
            if (n > 0) {
                jbyteArray arr = env->NewByteArray(n);
                env->SetByteArrayRegion(arr, 0, n, reinterpret_cast<const jbyte *>(buf));
                const jboolean keep = env->CallBooleanMethod(listener, on_bytes, arr);
                env->DeleteLocalRef(arr);
                if (env->ExceptionCheck() || !keep) break;
            }
            llama_batch next = llama_batch_get_one(&tok, 1);
            if (llama_decode(w->ctx, next) != 0) break;  // cancelled or out of time: keep what we have
        }
    } catch (const std::exception & e) {
        if (!env->ExceptionCheck() && std::string(e.what()) != "cancelled") throw_java(env, e.what());
    }
    if (chain) llama_sampler_free(chain);
    llama_synchronize(w->ctx);
    // If the prefix evaluation itself was interrupted the cache is partial: forget it.
    if (w->cancel.load() && w->prefix.empty()) llama_memory_clear(llama_get_memory(w->ctx), true);
    w->cancel.store(false);
    return generated;
}

extern "C" JNIEXPORT void JNICALL
Java_com_nizam_app_feature_netscape_ai_NativeWriter_nativeClose(JNIEnv *, jobject, jlong handle) {
    delete reinterpret_cast<Writer *>(handle);
}
