package com.nizam.app.feature.netscape.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Sell
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.ViewCarousel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.feature.netscape.data.MediaKind
import com.nizam.app.feature.netscape.data.Settings
import com.nizam.app.feature.netscape.data.TagCatalog
import com.nizam.app.feature.netscape.data.TitleGenerator
import com.nizam.app.feature.netscape.data.TitleStyle
import com.nizam.app.feature.netscape.data.Vault
import com.nizam.app.feature.netscape.data.VaultItem
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun SettingsScreen() {
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    var styleOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    var groupsOpen by remember { mutableStateOf(false) }
    var customOpen by remember { mutableStateOf(false) }
    var passOpen by remember { mutableStateOf(false) }
    var confirmRename by remember { mutableStateOf<Boolean?>(null) }
    var previewSeed by remember { mutableStateOf(0) }

    fun set(change: (Settings) -> Settings) = scope.launch { Vault.updateSettings(change) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(bottom = 130.dp)
    ) {
        LargeTitle("Settings")

        // Live preview of the naming style
        val sample = remember(previewSeed, s) { sampleItem() }
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Brand.Surface)
                .clickable { previewSeed++ }
                .padding(16.dp)
        ) {
            Text("PREVIEW · TAP TO SHUFFLE", color = Brand.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(
                TitleGenerator.title(sample, 7, s),
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
            if (s.autoDescribe) {
                Text(
                    TitleGenerator.description(sample, s),
                    color = Brand.Label,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        GroupedSection(header = "Titles & descriptions", footer = "Auto titles use your tags, rating and length. Titles you type yourself are never overwritten.") {
            GroupedRow("Style", icon = Icons.Rounded.Style, value = s.titleStyle.label, onClick = { styleOpen = true })
            GroupedRow("Emojis", icon = Icons.Rounded.AutoAwesome, iconTint = Color(0xFFFF9F0A), showDivider = true, trailing = {
                Segmented(
                    options = listOf("None", "Some", "Lots"),
                    selected = s.emojiLevel,
                    modifier = Modifier.size(width = 180.dp, height = 34.dp)
                ) { lvl -> set { it.copy(emojiLevel = lvl) } }
            })
            if (s.titleStyle == TitleStyle.CUSTOM) {
                Column(modifier = Modifier.padding(14.dp)) {
                    var draft by remember { mutableStateOf(s.customTemplate) }
                    FilledField(
                        value = draft,
                        onValueChange = { draft = it; set { st -> st.copy(customTemplate = it) } },
                        label = "Template"
                    )
                    Text(
                        "Tokens: {emoji} {adj} {noun} {category} {who} {type} {position} {act} {body} {look} {outfit} {kink} {setting} {mood} {person} {age} {n} {duration} {quality} {rating} {date}",
                        color = Brand.Muted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
            ToggleRow("Auto-name new imports", s.autoNameOnImport, icon = Icons.Rounded.TextFields, iconTint = Color(0xFF0A84FF)) { v -> set { it.copy(autoNameOnImport = v) } }
            ToggleRow("Auto-write descriptions", s.autoDescribe, icon = Icons.Rounded.TextFields, iconTint = Color(0xFF5E5CE6)) { v -> set { it.copy(autoDescribe = v) } }
            ToggleRow("Re-title when tags change", s.retitleOnTagChange, icon = Icons.Rounded.Refresh, iconTint = Color(0xFF30D158)) { v -> set { it.copy(retitleOnTagChange = v) } }
            GroupedRow("Regenerate auto titles", icon = Icons.Rounded.AutoAwesome, onClick = { confirmRename = true })
            GroupedRow("Rename everything", icon = Icons.Rounded.AutoAwesome, iconTint = Color(0xFFFF453A), showDivider = false, onClick = { confirmRename = false })
        }

        GroupedSection(header = "Appearance") {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconTile(Icons.Rounded.Palette)
                    Text("Accent colour", color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
                    Text(Brand.accents[s.accent.coerceIn(0, Brand.accents.lastIndex)].name, color = Brand.Muted, fontSize = 14.sp)
                }
                Row(
                    modifier = Modifier.padding(top = 14.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Brand.accents.forEachIndexed { i, a ->
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(a.color)
                                .border(3.dp, if (i == s.accent) Color.White else Color.Transparent, CircleShape)
                                .clickable { set { it.copy(accent = i) } }
                        )
                    }
                }
            }
            GroupedRow("Grid size", icon = Icons.Rounded.Dashboard, iconTint = Color(0xFF64D2FF), trailing = {
                Segmented(
                    options = listOf("1", "2", "3", "4"),
                    selected = s.gridColumns - 1,
                    modifier = Modifier.size(width = 160.dp, height = 34.dp)
                ) { i -> set { it.copy(gridColumns = i + 1) } }
            })
            GroupedRow("Default sort", icon = Icons.Rounded.Sort, iconTint = Color(0xFFFF9F0A), value = s.defaultSort.label, onClick = { sortOpen = true })
            ToggleRow("Big billboard on Home", s.showBillboard, icon = Icons.Rounded.ViewCarousel, iconTint = Color(0xFFBF5AF2)) { v -> set { it.copy(showBillboard = v) } }
            ToggleRow("Show tags under tiles", s.showTagsOnCards, icon = Icons.Rounded.Sell, iconTint = Color(0xFF30D158), showDivider = false) { v -> set { it.copy(showTagsOnCards = v) } }
        }

        GroupedSection(header = "Privacy", footer = "Discreet mode swaps every title for a neutral name (\"Clip 12\") and hides tags, emojis and descriptions — handy if someone is looking over your shoulder.") {
            ToggleRow("Blur thumbnails", s.blurThumbs, icon = Icons.Rounded.BlurOn, iconTint = Color(0xFF5E5CE6)) { v -> set { it.copy(blurThumbs = v) } }
            ToggleRow("Discreet mode", s.discreet, icon = Icons.Rounded.VisibilityOff, iconTint = Color(0xFF8E8E93)) { v -> set { it.copy(discreet = v) } }
            ToggleRow("Start videos muted", s.startMuted, icon = Icons.Rounded.VolumeOff, iconTint = Color(0xFFFF453A), showDivider = false) { v -> set { it.copy(startMuted = v) } }
        }

        GroupedSection(header = "Tags") {
            val customCount = s.customTags.values.sumOf { it.size }
            GroupedRow("Tag groups", icon = Icons.Rounded.Sell, value = "${TagCatalog.groups.size - s.hiddenGroups.size} shown", onClick = { groupsOpen = true })
            GroupedRow("Your own tags", icon = Icons.Rounded.Sell, iconTint = Color(0xFF30D158), value = "$customCount", showDivider = false, onClick = { customOpen = true })
        }

        AiSettingsSection()

        WriterSettingsSection()

        GroupedSection(header = "Security") {
            GroupedRow("Change passphrase", icon = Icons.Rounded.Key, iconTint = Color(0xFF8E8E93), onClick = { passOpen = true })
            GroupedRow("Lock now", icon = Icons.Rounded.Lock, iconTint = Color(0xFFFF453A), showDivider = false, onClick = { Vault.lock() })
        }

        val videos = Vault.items.count { it.kind == MediaKind.VIDEO }
        val photos = Vault.items.count { it.kind == MediaKind.PHOTO }
        GroupedSection(header = "Vault", footer = "Everything is encrypted with AES-256 and never leaves this device. There is no network permission.") {
            GroupedRow("Videos", value = "$videos")
            GroupedRow("Photos", value = "$photos")
            GroupedRow("Tags in use", value = "${Vault.tagCounts().size}")
            GroupedRow("Storage", value = String.format(Locale.US, "%.1f GB", Vault.storageBytes() / 1_073_741_824.0), showDivider = false)
        }
    }

    if (styleOpen) {
        Sheet(onDismiss = { styleOpen = false }) {
            Text("Title style", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            GroupedSection {
                TitleStyle.values().forEachIndexed { i, style ->
                    val example = TitleGenerator.title(sampleItem(), 7, s.copy(titleStyle = style))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                set { it.copy(titleStyle = style) }
                                styleOpen = false
                            }
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(style.label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            if (style == s.titleStyle) Text("✓", color = Brand.Red, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(example, color = Brand.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                    if (i < TitleStyle.values().lastIndex) {
                        Box(Modifier.fillMaxWidth().padding(start = 14.dp).height(0.5.dp).background(Brand.Line))
                    }
                }
            }
            Spacer(Modifier.height(30.dp))
        }
    }

    if (sortOpen) {
        SortSheet(current = s.defaultSort, onDismiss = { sortOpen = false }) { order ->
            sortOpen = false
            set { it.copy(defaultSort = order) }
        }
    }

    if (groupsOpen) {
        Sheet(onDismiss = { groupsOpen = false }) {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text("Tag groups", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                GroupedSection(footer = "Hidden groups disappear from the tag editor. Tags already on items stay.") {
                    TagCatalog.groups.forEachIndexed { i, g ->
                        GroupedRow(
                            title = g.name,
                            emoji = g.emoji,
                            value = "${TagCatalog.tagsIn(g.id, s).size}  ",
                            showDivider = i < TagCatalog.groups.lastIndex,
                            onClick = {
                                set { st ->
                                    st.copy(hiddenGroups = if (g.id in st.hiddenGroups) st.hiddenGroups - g.id else st.hiddenGroups + g.id)
                                }
                            },
                            trailing = {
                                androidx.compose.material3.Switch(
                                    checked = g.id !in s.hiddenGroups,
                                    onCheckedChange = { on ->
                                        set { st -> st.copy(hiddenGroups = if (on) st.hiddenGroups - g.id else st.hiddenGroups + g.id) }
                                    },
                                    colors = androidx.compose.material3.SwitchDefaults.colors(
                                        checkedTrackColor = Color(0xFF30D158),
                                        checkedBorderColor = Color.Transparent,
                                        uncheckedTrackColor = Brand.SurfaceHigher,
                                        uncheckedBorderColor = Color.Transparent,
                                        uncheckedThumbColor = Color.White
                                    )
                                )
                            }
                        )
                    }
                }
                Spacer(Modifier.height(30.dp))
            }
        }
    }

    if (customOpen) {
        Sheet(onDismiss = { customOpen = false }) {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(bottom = 30.dp)) {
                Text("Your own tags", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                Text(
                    "Add them from any item's tag editor. Tap one here to remove it from the list.",
                    color = Brand.Muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                val entries = s.customTags.filterValues { it.isNotEmpty() }
                if (entries.isEmpty()) {
                    Text("None yet.", color = Brand.Muted, modifier = Modifier.padding(20.dp))
                }
                entries.forEach { (gid, list) ->
                    val g = TagCatalog.group(gid) ?: return@forEach
                    SectionLabel("${g.emoji} ${g.name}")
                    FlowRow(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        list.forEach { name ->
                            TagChip("$name  ✕") { scope.launch { Vault.removeCustomTag(gid, name) } }
                        }
                    }
                }
            }
        }
    }

    if (passOpen) {
        ChangePassphraseSheet(onDismiss = { passOpen = false })
    }

    val onlyAuto = confirmRename
    if (onlyAuto != null) {
        AlertDialog(
            onDismissRequest = { confirmRename = null },
            containerColor = Brand.Surface,
            title = { Text(if (onlyAuto) "Regenerate auto titles?" else "Rename everything?", color = Color.White) },
            text = {
                Text(
                    if (onlyAuto) "Every machine-written title and description gets a fresh one in the current style. Titles you typed stay."
                    else "Every item — including ones you named yourself — gets a new title in the current style.",
                    color = Brand.Muted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmRename = null
                    scope.launch { Vault.regenerateAll(onlyAuto) }
                }) { Text("Go", color = Brand.Red, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirmRename = null }) { Text("Cancel", color = Color.White) } }
        )
    }
}

@Composable
private fun IconTile(icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(Brand.Red),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
    }
}

/** A realistic item for the preview — uses a real tagged item if there is one. */
private fun sampleItem(): VaultItem {
    Vault.items.filter { it.tags.size >= 2 }.randomOrNull()?.let { return it }
    return VaultItem(
        id = "sample", title = "", kind = MediaKind.VIDEO, hash = "", sizeBytes = 0,
        durationMs = 7 * 60_000L + 12_000, addedAt = System.currentTimeMillis(), keyWrap = "",
        collection = Vault.DEFAULT_COLLECTION, favorite = false, progressMs = 0, lastOpened = 0,
        hasThumb = false,
        tags = listOf(
            listOf("Late Night", "Hot", "Steamy").random(),
            listOf("Cowgirl", "Doggy Style", "Spooning", "Missionary").random(),
            listOf("Shower", "Bedroom", "Hotel", "Couch").random(),
            listOf("Passionate", "Playful", "Sensual").random(),
            "Couple", "Lingerie", "Adult"
        ),
        rating = 5, width = 3840, height = 2160
    )
}

@Composable
private fun ChangePassphraseSheet(onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var current by remember { mutableStateOf("") }
    var next by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }

    Sheet(onDismiss = onDismiss) {
        Column(modifier = Modifier.padding(horizontal = 18.dp).padding(bottom = 36.dp)) {
            Text("Change passphrase", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "Every item's key is re-wrapped under the new passphrase. Your media isn't re-encrypted, so this is quick.",
                color = Brand.Muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )
            if (done) {
                Text("✅ Passphrase changed.", color = Color(0xFF30D158), fontSize = 16.sp, modifier = Modifier.padding(vertical = 12.dp))
                PrimaryButton("Done", modifier = Modifier.fillMaxWidth(), onClick = onDismiss)
                return@Column
            }
            val fields: List<Triple<String, String, (String) -> Unit>> = listOf(
                Triple("Current passphrase", current, { v: String -> current = v }),
                Triple("New passphrase", next, { v: String -> next = v }),
                Triple("Confirm new passphrase", confirm, { v: String -> confirm = v })
            )
            fields.forEach { (label, value, onChange) ->
                TextField(
                    value = value,
                    onValueChange = { onChange(it); error = null },
                    label = { Text(label) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    shape = RoundedCornerShape(12.dp),
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                )
            }
            error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp)) }
            PrimaryButton(
                if (working) "Working…" else "Change passphrase",
                enabled = !working,
                modifier = Modifier.fillMaxWidth()
            ) {
                when {
                    next.length < 6 -> error = "Use at least 6 characters"
                    next != confirm -> error = "New passphrases don't match"
                    else -> {
                        working = true
                        scope.launch {
                            val ok = Vault.changePassword(current, next)
                            working = false
                            if (ok) done = true else error = "Current passphrase is wrong"
                        }
                    }
                }
            }
        }
    }
}
