package com.nizam.app.feature.netscape.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.feature.netscape.data.TagCatalog
import com.nizam.app.feature.netscape.data.TagGroup
import com.nizam.app.feature.netscape.data.Vault
import kotlinx.coroutines.launch

/**
 * Full-screen tag picker for one item or a multi-selection. Every preset group is here,
 * plus the user's own tags.
 */
@Composable
fun TagEditorScreen(ids: Set<String>, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    val targets = Vault.items.filter { it.id in ids }
    if (targets.isEmpty()) {
        Box(Modifier.fillMaxSize().background(Brand.Ink))
        return
    }
    val single = targets.size == 1

    // Tags present on every target start selected.
    val initialTags = remember(ids) {
        targets.map { it.tags.toSet() }.reduce { a, b -> a intersect b }
    }
    var selected by remember(ids) { mutableStateOf(initialTags) }
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(setOf("category", "age", "position", "act")) }
    var addingTo by remember { mutableStateOf<TagGroup?>(null) }
    var removingCustom by remember { mutableStateOf<Pair<String, String>?>(null) }

    fun toggle(tag: String) {
        selected = if (selected.any { it.equals(tag, ignoreCase = true) }) {
            selected.filterNot { it.equals(tag, ignoreCase = true) }.toSet()
        } else selected + tag
    }

    fun save() {
        val add = selected.filterNot { t -> initialTags.any { it.equals(t, ignoreCase = true) } }.toSet()
        val remove = initialTags.filterNot { t -> selected.any { it.equals(t, ignoreCase = true) } }.toSet()
        scope.launch {
            Vault.applyTagChanges(ids, add, remove)
            onDone()
        }
    }

    val groups = TagCatalog.groups.filter { it.id !in s.hiddenGroups }
    val counts = Vault.tagCounts()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
            .statusBarsPadding()
    ) {
        // Navigation bar: Cancel · Title · Done
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onDone) { Text("Cancel", color = Brand.Red, fontSize = 16.sp) }
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Tags", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (single) "${selected.size} selected" else "${targets.size} items · ${selected.size} selected",
                    color = Brand.Muted,
                    fontSize = 12.sp
                )
            }
            TextButton(onClick = { save() }) {
                Text("Done", color = Brand.Red, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }

        SearchField(
            value = query,
            onValueChange = { query = it },
            placeholder = "Search ${groups.sumOf { TagCatalog.tagsIn(it.id, s).size }} tags",
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        LazyColumn(contentPadding = PaddingValues(bottom = 60.dp)) {
            // Currently selected — tap to remove.
            if (selected.isNotEmpty() && query.isBlank()) {
                item {
                    SectionLabel("Selected")
                    FlowRow(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        selected.sortedBy { it.lowercase() }.forEach { tag ->
                            TagChip(tagLabel(tag), ChipState.ON) { toggle(tag) }
                        }
                    }
                }
            }

            if (query.isNotBlank()) {
                val q = query.trim()
                val matches = groups.flatMap { g ->
                    TagCatalog.tagsIn(g.id, s).filter { it.name.contains(q, ignoreCase = true) }.map { g to it }
                }
                item {
                    SectionLabel("${matches.size} matches")
                    FlowRow(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        matches.forEach { (_, def) ->
                            val on = selected.any { it.equals(def.name, ignoreCase = true) }
                            TagChip(
                                if (s.emojiLevel == 0) def.name else "${def.emoji} ${def.name}",
                                if (on) ChipState.ON else ChipState.OFF,
                                count = counts[def.name]
                            ) { toggle(def.name) }
                        }
                    }
                }
                if (matches.none { it.second.name.equals(q, ignoreCase = true) }) {
                    item {
                        SectionLabel("Create \"$q\" in…")
                        FlowRow(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            groups.forEach { g ->
                                TagChip("${g.emoji} ${g.name}") {
                                    scope.launch {
                                        Vault.addCustomTag(g.id, q)
                                        selected = selected + q
                                        query = ""
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                groups.forEach { g ->
                    item(key = g.id) {
                        val tags = TagCatalog.tagsIn(g.id, s)
                        val open = g.id in expanded
                        val chosen = tags.count { d -> selected.any { it.equals(d.name, ignoreCase = true) } }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                                .clickable { expanded = if (open) expanded - g.id else expanded + g.id }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(g.emoji, fontSize = 20.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(g.name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    if (chosen > 0) "$chosen selected · ${tags.size} tags" else "${tags.size} tags",
                                    color = if (chosen > 0) Brand.Red else Brand.Muted,
                                    fontSize = 12.sp
                                )
                            }
                            Icon(
                                if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                contentDescription = null,
                                tint = Brand.Muted
                            )
                        }
                        if (open) {
                            FlowRow(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                tags.forEach { def ->
                                    val on = selected.any { it.equals(def.name, ignoreCase = true) }
                                    val isCustom = s.customTags[g.id].orEmpty().contains(def.name)
                                    TagChip(
                                        label = if (s.emojiLevel == 0) def.name else "${def.emoji} ${def.name}",
                                        state = if (on) ChipState.ON else ChipState.OFF,
                                        count = counts[def.name],
                                        onLongClick = if (isCustom) ({ removingCustom = g.id to def.name }) else null
                                    ) { toggle(def.name) }
                                }
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(Color.Transparent)
                                        .clickable { addingTo = g }
                                        .padding(horizontal = 10.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(16.dp))
                                    Text(
                                        if (g.id == "people") "Add person" else "Add your own",
                                        color = Brand.Red,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val group = addingTo
    if (group != null) {
        var draft by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addingTo = null },
            containerColor = Brand.Surface,
            title = { Text("New tag in ${group.emoji} ${group.name}", color = Color.White, fontSize = 17.sp) },
            text = { FilledField(value = draft, onValueChange = { draft = it }, label = "Tag name") },
            confirmButton = {
                TextButton(onClick = {
                    val name = draft.trim()
                    addingTo = null
                    if (name.isNotEmpty()) scope.launch {
                        Vault.addCustomTag(group.id, name)
                        selected = selected + name
                    }
                }) { Text("Add", color = Brand.Red, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { addingTo = null }) { Text("Cancel", color = Color.White) } }
        )
    }

    val removing = removingCustom
    if (removing != null) {
        AlertDialog(
            onDismissRequest = { removingCustom = null },
            containerColor = Brand.Surface,
            title = { Text("Remove \"${removing.second}\"?", color = Color.White) },
            text = { Text("It disappears from the tag list. Items already tagged keep it.", color = Brand.Muted) },
            confirmButton = {
                TextButton(onClick = {
                    removingCustom = null
                    scope.launch { Vault.removeCustomTag(removing.first, removing.second) }
                }) { Text("Remove", color = Color(0xFFFF453A)) }
            },
            dismissButton = { TextButton(onClick = { removingCustom = null }) { Text("Cancel", color = Color.White) } }
        )
    }
}

@Composable
fun SectionLabel(text: String) {
    Box(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 8.dp)) {
        Text(text.uppercase(), color = Brand.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
