package com.nizam.app.feature.netscape.ui

import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.feature.netscape.ai.AiService
import com.nizam.app.feature.netscape.ai.AiTagger
import com.nizam.app.feature.netscape.ai.SceneDraft
import com.nizam.app.feature.netscape.ai.Suggestion
import com.nizam.app.feature.netscape.data.TagCatalog
import com.nizam.app.feature.netscape.data.Vault
import com.nizam.app.feature.netscape.data.VaultItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

// ---------------------------------------------------------------- Settings section

@Composable
fun AiSettingsSection() {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val st = AiService.status.value
    val s = Vault.settings.value
    var installing by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }
    var installError by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        Vault.suppressAutoLock = false
        if (uri != null) {
            installing = true
            AiService.appScope.launch {
                val error = AiService.install(uri)
                installing = false
                if (error == null) {
                    Toast.makeText(context, "✨ AI models installed", Toast.LENGTH_LONG).show()
                    // Do the slow one-time CLIP preparation now, not on the first "Suggest tags".
                    AiService.warmUp()
                }
                else installError = error
            }
        }
    }

    GroupedSection(
        header = "AI models (offline)",
        footer = if (st.any) "Models run entirely on this phone — nothing is uploaded. Frames are decrypted in memory only."
        else "Download Netscape-AI-Pack.zip from your GitHub repo → Releases → \"Netscape AI pack\", then tap Install and pick the zip. Everything runs offline on this phone."
    ) {
        GroupedRow("NSFW classifier", icon = Icons.Rounded.Memory, iconTint = Color(0xFFFF453A), value = if (st.classifier) "✅ Installed" else "Not installed")
        GroupedRow("NudeNet body detector", icon = Icons.Rounded.Memory, iconTint = Color(0xFFFF9F0A), value = if (st.nudeNet) "✅ Installed" else "Not installed")
        AiService.prepareProgress.value?.let { p ->
            GroupedRow(p, icon = Icons.Rounded.Memory, iconTint = Color(0xFF64D2FF), value = "one-time")
        }
        GroupedRow("CLIP scene & position model", icon = Icons.Rounded.Memory, iconTint = Color(0xFFBF5AF2), value = if (st.clip) "✅ Installed" else "Not installed")
        GroupedRow("SmolVLM2 scene suggestions", icon = Icons.Rounded.Memory, iconTint = Color(0xFF30D158), value = if (st.captioner) "✅ Installed" else "Not installed")
        GroupedRow(
            title = if (installing) {
                AiService.installProgress.value?.let { "Installing… ${(it * 100).toInt()}%" } ?: "Installing…"
            } else if (st.any) "Reinstall / update AI pack" else "Install AI pack (.zip)",
            icon = Icons.Rounded.Download,
            iconTint = Color(0xFF0A84FF),
            value = if (st.any) String.format(Locale.US, "%.0f MB", st.bytes / 1e6) else null,
            showDivider = st.any,
            onClick = {
                if (!installing) {
                    Vault.suppressAutoLock = true
                    picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
                }
            },
            trailing = {
                if (installing) CircularProgressIndicator(color = Brand.Red, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                else Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Brand.Muted, modifier = Modifier.size(20.dp))
            }
        )
        if (st.taggerAvailable) {
            ToggleRow("Auto-tag new imports", s.aiAutoTagImports, icon = Icons.Rounded.AutoAwesome, iconTint = Color(0xFF30D158)) { v ->
                scope.launch { Vault.updateSettings { it.copy(aiAutoTagImports = v) } }
            }
            GroupedRow("Sensitivity", icon = Icons.Rounded.Tune, iconTint = Color(0xFF64D2FF), trailing = {
                Segmented(
                    options = listOf("Strict", "Balanced", "Loose"),
                    selected = s.aiSensitivity,
                    modifier = Modifier.size(width = 220.dp, height = 34.dp)
                ) { i -> scope.launch { Vault.updateSettings { it.copy(aiSensitivity = i) } } }
            })
        }
        if (st.any) {
            GroupedRow("Remove AI models", icon = Icons.Rounded.Delete, iconTint = Color(0xFF8E8E93), titleColor = Color(0xFFFF453A), showDivider = false, onClick = { confirmRemove = true })
        }
    }

    installError?.let { msg ->
        AlertDialog(
            onDismissRequest = { installError = null },
            containerColor = Brand.Surface,
            title = { Text("Couldn't install the AI pack", color = Color.White) },
            text = { Text(msg, color = Brand.Muted) },
            confirmButton = { TextButton(onClick = { installError = null }) { Text("OK", color = Brand.Red, fontWeight = FontWeight.Bold) } }
        )
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            containerColor = Brand.Surface,
            title = { Text("Remove AI models?", color = Color.White) },
            text = { Text("Frees ${String.format(Locale.US, "%.0f MB", st.bytes / 1e6)}. Your tags stay.", color = Brand.Muted) },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemove = false
                    scope.launch { AiService.remove() }
                }) { Text("Remove", color = Color(0xFFFF453A), fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel", color = Color.White) } }
        )
    }
}

// ---------------------------------------------------------------- scene-specific title / tag / description suggestions

/** Cancel is a request: native inference may keep running until it returns. */
@Composable
private fun RowScope.AiRunningProgress(phase: String, startedAt: Long, cancelling: Boolean, onCancel: () -> Unit) {
    var elapsed by remember(startedAt) { mutableStateOf(0L) }
    LaunchedEffect(startedAt) {
        while (true) {
            elapsed = (SystemClock.elapsedRealtime() - startedAt) / 1000
            delay(1_000)
        }
    }
    CircularProgressIndicator(color = Brand.Red, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
    Text(
        "  ${if (cancelling) "Cancel requested; model may still be running" else phase} · ${elapsed}s",
        color = Color.White,
        fontSize = 13.sp,
        modifier = Modifier.weight(1f)
    )
    if (!cancelling) {
        TextButton(onClick = onCancel) { Text("Cancel", color = Brand.Red) }
    }
}

/** Optional multimodal suggestions; unlike bulk tagging, every field is reviewed before saving. */
@Composable
fun AiSceneSuggestionRow(item: VaultItem) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val st = AiService.status.value
    var running by remember(item.id) { mutableStateOf(false) }
    var phase by remember(item.id) { mutableStateOf("Waiting for AI") }
    var startedAt by remember(item.id) { mutableStateOf(0L) }
    var cancelling by remember(item.id) { mutableStateOf(false) }
    var job by remember(item.id) { mutableStateOf<Job?>(null) }
    var draft by remember(item.id) { mutableStateOf<SceneDraft?>(null) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brand.Surface)
            .clickable(enabled = !running) {
                if (!st.captioner) {
                    Toast.makeText(context, "Install the SmolVLM2 AI pack first: Settings → AI models", Toast.LENGTH_LONG).show()
                    return@clickable
                }
                running = true
                cancelling = false
                phase = "Waiting for AI"
                startedAt = SystemClock.elapsedRealtime()
                job = scope.launch {
                    try {
                        draft = AiService.suggestScene(item) { if (!cancelling) phase = it }.also {
                            // The AI writer uses what the scene model saw for this item from now on.
                            com.nizam.app.feature.netscape.ai.WriterService.rememberScene(item.id, it.description, it.tags)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Toast.makeText(context, "Scene suggestion failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                    } finally {
                        running = false
                        job = null
                    }
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (running) {
            AiRunningProgress(phase, startedAt, cancelling) {
                cancelling = true
                job?.cancel()
            }
        } else {
            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = Color(0xFF30D158), modifier = Modifier.size(18.dp))
            Text(
                "  Suggest title, tags & description",
                color = if (st.captioner) Color.White else Brand.Muted,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }

    draft?.let { result ->
        AiSceneDraftSheet(
            item = item,
            draft = result,
            onDismiss = { draft = null }
        )
    }
}

@Composable
private fun AiSceneDraftSheet(item: VaultItem, draft: SceneDraft, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var title by remember(draft) { mutableStateOf(draft.title) }
    var description by remember(draft) { mutableStateOf(draft.description) }
    var chosen by remember(draft) { mutableStateOf(draft.tags.toSet()) }

    // With the AI writer installed, the plain scene text is rewritten in the user's voice straight
    // away, using what the scene model saw. "Plain scene text" goes back to the original.
    val writerReady = com.nizam.app.feature.netscape.ai.WriterService.status.value.installed
    var writing by remember(draft) { mutableStateOf(false) }
    var writeTake by remember(draft) { mutableStateOf(if (writerReady) 1 else 0) }
    var writeError by remember(draft) { mutableStateOf<String?>(null) }
    var keepPlain by remember(draft) { mutableStateOf(false) }
    LaunchedEffect(writeTake) {
        if (writeTake == 0) return@LaunchedEffect
        writing = true
        writeError = null
        keepPlain = false
        try {
            val sceneNote = buildString {
                append(draft.description)
                if (chosen.isNotEmpty()) append(" (").append(chosen.joinToString(", ")).append(")")
            }
            val r = com.nizam.app.feature.netscape.ai.WriterService.write(item, scene = sceneNote) { raw ->
                val live = com.nizam.app.feature.netscape.ai.WriterPrompt.parse(raw.removePrefix("TITLE:"))
                if (keepPlain) return@write
                if (live.title.isNotBlank()) title = live.title
                if (live.description.isNotBlank()) description = live.description
            }
            if (!keepPlain) {
                if (r.title.isNotBlank()) title = r.title
                if (r.description.isNotBlank()) description = r.description
            }
        } catch (e: Throwable) {
            if (e !is kotlinx.coroutines.CancellationException) writeError = e.message ?: e.javaClass.simpleName
        } finally {
            writing = false
        }
    }
    DisposableEffect(Unit) { onDispose { if (writing) com.nizam.app.feature.netscape.ai.WriterService.cancel() } }

    fun applyText() {
        scope.launch {
            Vault.saveDetails(item.id, title, description, item.rating, titleIsAuto = false)
            onDismiss()
        }
    }

    Sheet(onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 36.dp)
        ) {
            Text("✨ Scene suggestions", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                when {
                    writing -> "✍️ The AI writer is spicing up what the scene model saw…"
                    writerReady -> "Written by the AI writer from what the scene model saw. Edit anything before saving; frames are analyzed in memory on this phone."
                    else -> "Non-graphic catalog text. Install the AI writer (Settings) to have it rewritten in your style. Frames are analyzed in memory on this phone."
                },
                color = Brand.Muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )
            TextField(
                value = title,
                onValueChange = { title = it.take(90) },
                label = { Text("Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = Brand.Red,
                    unfocusedLabelColor = Brand.Muted,
                    focusedContainerColor = Brand.Surface,
                    unfocusedContainerColor = Brand.Surface,
                    focusedIndicatorColor = Brand.Red,
                    unfocusedIndicatorColor = Brand.Muted
                )
            )
            Spacer(Modifier.height(8.dp))
            TextField(
                value = description,
                onValueChange = { description = it.take(800) },
                label = { Text("Description") },
                minLines = 2,
                maxLines = 8,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = Brand.Red,
                    unfocusedLabelColor = Brand.Muted,
                    focusedContainerColor = Brand.Surface,
                    unfocusedContainerColor = Brand.Surface,
                    focusedIndicatorColor = Brand.Red,
                    unfocusedIndicatorColor = Brand.Muted
                )
            )
            writeError?.let { Text("Writer: $it", color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
            if (writerReady) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryButton(if (writing) "Stop" else "✍️ Rewrite", modifier = Modifier.weight(1f)) {
                        if (writing) com.nizam.app.feature.netscape.ai.WriterService.cancel() else writeTake++
                    }
                    SecondaryButton("Plain scene text", modifier = Modifier.weight(1f)) {
                        if (writing) com.nizam.app.feature.netscape.ai.WriterService.cancel()
                        keepPlain = true
                        title = draft.title
                        description = draft.description
                    }
                }
            }
            if (draft.tags.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                SectionLabel("Suggested catalog tags")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    draft.tags.forEach { tag ->
                        val on = tag in chosen
                        TagChip(tag, if (on) ChipState.ON else ChipState.OFF) {
                            chosen = if (on) chosen - tag else chosen + tag
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            PrimaryButton(
                "Apply all selected suggestions",
                enabled = !writing && (title.isNotBlank() || chosen.isNotEmpty()),
                modifier = Modifier.fillMaxWidth()
            ) {
                scope.launch {
                    if (chosen.isNotEmpty()) {
                        Vault.applyTagChanges(setOf(item.id), chosen, emptySet())
                    }
                    Vault.saveDetails(item.id, title, description, item.rating, titleIsAuto = false)
                    onDismiss()
                }
            }
            Spacer(Modifier.height(8.dp))
            if (title.isNotBlank() || chosen.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (title.isNotBlank()) {
                        SecondaryButton("Save text only", modifier = Modifier.weight(1f)) { applyText() }
                    }
                    if (chosen.isNotEmpty()) {
                        SecondaryButton("Add selected tags", modifier = Modifier.weight(1f)) {
                            scope.launch {
                                Vault.applyTagChanges(setOf(item.id), chosen, emptySet())
                                onDismiss()
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- per-item suggestions

/** "✨ Suggest tags with AI" row for the detail screen, plus its results sheet. */
@Composable
fun AiSuggestRow(item: VaultItem) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val st = AiService.status.value
    var running by remember(item.id) { mutableStateOf(false) }
    var phase by remember(item.id) { mutableStateOf("Waiting for AI") }
    var startedAt by remember(item.id) { mutableStateOf(0L) }
    var cancelling by remember(item.id) { mutableStateOf(false) }
    var job by remember(item.id) { mutableStateOf<Job?>(null) }
    var results by remember(item.id) { mutableStateOf<List<Suggestion>?>(null) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brand.Surface)
            .clickable(enabled = !running) {
                if (!st.taggerAvailable) {
                    Toast.makeText(context, "Install the AI pack first: Settings → AI models", Toast.LENGTH_LONG).show()
                    return@clickable
                }
                running = true
                cancelling = false
                phase = "Waiting for AI"
                startedAt = SystemClock.elapsedRealtime()
                job = scope.launch {
                    try {
                        results = AiService.suggest(item) { if (!cancelling) phase = it }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Toast.makeText(context, "AI failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                    } finally {
                        running = false
                        job = null
                    }
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (running) {
            AiRunningProgress(phase, startedAt, cancelling) {
                cancelling = true
                job?.cancel()
            }
        } else {
            Icon(Icons.Rounded.Memory, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
            Text(
                if (st.taggerAvailable) "  Suggest tags with AI" else "  AI tagging — set up in Settings",
                color = if (st.taggerAvailable) Color.White else Brand.Muted,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }

    val found = results
    if (found != null) {
        AiResultsSheet(item = item, suggestions = found, onDismiss = { results = null })
    }
}

@Composable
private fun AiResultsSheet(item: VaultItem, suggestions: List<Suggestion>, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    val preselected = remember(suggestions) { AiTagger.confident(suggestions, s.aiSensitivity).map { it.tag }.toSet() }
    var chosen by remember(suggestions) { mutableStateOf(preselected) }

    Sheet(onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 36.dp)
        ) {
            Text("✨ AI suggestions", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                if (suggestions.isEmpty()) "Nothing new spotted. Try Loose sensitivity in Settings → AI models."
                else "Tap to choose. Percentages are how sure the model is — positions are the hardest, so double-check those.",
                color = Brand.Muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )
            val byGroup = suggestions.groupBy { it.groupId }
            TagCatalog.groups.filter { it.id in byGroup }.forEach { g ->
                SectionLabel("${g.emoji} ${g.name}")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    byGroup.getValue(g.id).forEach { sug ->
                        val on = sug.tag in chosen
                        TagChip(
                            label = "${tagLabel(sug.tag)}  ${(sug.confidence * 100).toInt()}%",
                            state = if (on) ChipState.ON else ChipState.OFF
                        ) { chosen = if (on) chosen - sug.tag else chosen + sug.tag }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            if (suggestions.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryButton("All", modifier = Modifier.weight(1f)) { chosen = suggestions.map { it.tag }.toSet() }
                    PrimaryButton(
                        "Add ${chosen.size} tag${if (chosen.size == 1) "" else "s"}",
                        enabled = chosen.isNotEmpty(),
                        modifier = Modifier.weight(2f)
                    ) {
                        val add = chosen
                        scope.launch {
                            Vault.applyTagChanges(setOf(item.id), add, emptySet())
                            onDismiss()
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- bulk

/** Confirmation + run for AI-tagging a multi-selection. */
@Composable
fun AiBulkDialog(ids: Set<String>, onDone: () -> Unit) {
    val context = LocalContext.current
    val st = AiService.status.value
    AlertDialog(
        onDismissRequest = onDone,
        containerColor = Brand.Surface,
        title = { Text("✨ AI-tag ${ids.size} item(s)?", color = Color.White) },
        text = {
            Text(
                if (st.taggerAvailable) "Only tags the models are confident about get added (sensitivity: ${listOf("Strict", "Balanced", "Loose")[Vault.settings.value.aiSensitivity]}). Videos take a few seconds each."
                else "Install the AI pack first: Settings → AI models.",
                color = Brand.Muted
            )
        },
        confirmButton = {
            if (st.taggerAvailable) {
                TextButton(onClick = {
                    onDone()
                    AiService.appScope.launch {
                        val n = AiService.autoTag(ids.toList())
                        Toast.makeText(context, "✨ Added $n tag(s)", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Tag them", color = Brand.Red, fontWeight = FontWeight.Bold) }
            }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel", color = Color.White) } }
    )
}
