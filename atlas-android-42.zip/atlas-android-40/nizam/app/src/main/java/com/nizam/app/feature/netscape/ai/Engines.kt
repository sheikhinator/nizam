package com.nizam.app.feature.netscape.ai

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.Closeable
import java.nio.FloatBuffer
import java.nio.LongBuffer
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Thin wrappers over ONNX Runtime. Only uses the ai.onnxruntime Java API, which is identical
 * in onnxruntime-android and the desktop jar — so this file is tested on a normal JVM.
 */
internal object Ort {
    val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }

    fun open(path: String, threads: Int = 4): OrtSession {
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(threads)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        return env.createSession(path, opts)
    }

    fun run(session: OrtSession, input: String, data: FloatArray, shape: LongArray): FloatArray =
        OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape).use { t ->
            session.run(mapOf(input to t)).use { res -> readFloats(res.get(0) as OnnxTensor) }
        }

    fun readFloats(t: OnnxTensor): FloatArray {
        val buf = t.floatBuffer
        val out = FloatArray(buf.remaining())
        buf.get(out)
        return out
    }

    fun l2normalize(v: FloatArray): FloatArray {
        var s = 0.0
        for (x in v) s += x * x
        val n = sqrt(s).toFloat().coerceAtLeast(1e-12f)
        return FloatArray(v.size) { v[it] / n }
    }

    fun softmax(logits: FloatArray, scale: Float = 1f): FloatArray {
        val m = logits.maxOrNull() ?: 0f
        val e = DoubleArray(logits.size) { exp(((logits[it] - m) * scale).toDouble()) }
        val sum = e.sum()
        return FloatArray(logits.size) { (e[it] / sum).toFloat() }
    }
}

/** Preprocessing recipe, shipped in the AI pack manifest so the phone never guesses. */
data class ImageSpec(
    val size: Int,
    /** "stretch" = resize to size×size; "crop" = shortest side then centre-crop. */
    val resize: String,
    val mean: FloatArray,
    val std: FloatArray
)

// ---------------------------------------------------------------- NSFW classifier

class NsfwClassifier(modelPath: String, private val spec: ImageSpec, val labels: List<String>) : Closeable {
    private val session = Ort.open(modelPath)
    private val input = session.inputNames.first()

    /** label → probability. */
    fun classify(img: Pixels): Map<String, Float> {
        val prepared = if (spec.resize == "crop") ImageOps.resizeShortestAndCrop(img, spec.size)
        else ImageOps.resize(ImageOps.shrink(img, spec.size), spec.size, spec.size)
        val data = ImageOps.toTensor(prepared, spec.mean, spec.std, nchw = true)
        val logits = Ort.run(session, input, data, longArrayOf(1, 3, spec.size.toLong(), spec.size.toLong()))
        val probs = Ort.softmax(logits)
        return labels.indices.associate { labels[it] to probs.getOrElse(it) { 0f } }
    }

    override fun close() = session.close()
}

// ---------------------------------------------------------------- NudeNet

data class Detection(val label: String, val score: Float, val x: Float, val y: Float, val w: Float, val h: Float) {
    /** Share of the (square, padded) frame this box covers. */
    fun area(frame: Int): Float = (w * h) / (frame.toFloat() * frame)
}

object NudeNetDecoder {
    val LABELS = listOf(
        "FEMALE_GENITALIA_COVERED", "FACE_FEMALE", "BUTTOCKS_EXPOSED", "FEMALE_BREAST_EXPOSED",
        "FEMALE_GENITALIA_EXPOSED", "MALE_BREAST_EXPOSED", "ANUS_EXPOSED", "FEET_EXPOSED",
        "BELLY_COVERED", "FEET_COVERED", "ARMPITS_COVERED", "ARMPITS_EXPOSED", "FACE_MALE",
        "BELLY_EXPOSED", "MALE_GENITALIA_EXPOSED", "ANUS_COVERED", "FEMALE_BREAST_COVERED",
        "BUTTOCKS_COVERED"
    )

    /**
     * Decodes YOLOv8 output [1, 4 + classes, anchors] (channel-major) into detections in model
     * pixel space, then greedy NMS — same thresholds as the nudenet Python package.
     */
    fun decode(
        out: FloatArray,
        anchors: Int,
        minScore: Float = 0.2f,
        nmsScore: Float = 0.25f,
        iou: Float = 0.45f
    ): List<Detection> {
        val classes = out.size / anchors - 4
        val cands = ArrayList<Detection>()
        for (a in 0 until anchors) {
            var best = -1
            var bestScore = -1f
            for (c in 0 until classes) {
                val s = out[(4 + c) * anchors + a]
                if (s > bestScore) { bestScore = s; best = c }
            }
            if (bestScore < minScore) continue
            val cx = out[a]
            val cy = out[anchors + a]
            val w = out[2 * anchors + a]
            val h = out[3 * anchors + a]
            cands += Detection(LABELS.getOrElse(best) { "CLASS_$best" }, bestScore, cx - w / 2, cy - h / 2, w, h)
        }
        val sorted = cands.filter { it.score >= nmsScore }.sortedByDescending { it.score }
        val kept = ArrayList<Detection>()
        for (d in sorted) {
            if (kept.none { iou(it, d) > iou }) kept += d
        }
        return kept
    }

    private fun iou(a: Detection, b: Detection): Float {
        val x1 = max(a.x, b.x)
        val y1 = max(a.y, b.y)
        val x2 = min(a.x + a.w, b.x + b.w)
        val y2 = min(a.y + a.h, b.y + b.h)
        val inter = max(0f, x2 - x1) * max(0f, y2 - y1)
        val union = a.w * a.h + b.w * b.h - inter
        return if (union <= 0f) 0f else inter / union
    }
}

class NudeNet(modelPath: String, private val size: Int = 320) : Closeable {
    private val session = Ort.open(modelPath)
    private val input = session.inputNames.first()

    fun detect(img: Pixels): List<Detection> {
        val square = ImageOps.padToSquare(ImageOps.shrink(img, size))
        val resized = ImageOps.resize(square, size, size)
        // The reference nudenet pipeline ends up feeding BGR (OpenCV channel order), so match it.
        val data = ImageOps.toTensor(resized, nchw = true, bgr = true)
        val out = Ort.run(session, input, data, longArrayOf(1, 3, size.toLong(), size.toLong()))
        val anchors = out.size / (4 + NudeNetDecoder.LABELS.size)
        return NudeNetDecoder.decode(out, anchors)
    }

    override fun close() = session.close()
}

// ---------------------------------------------------------------- CLIP

class ClipModel(
    visionPath: String,
    textPath: String,
    private val tokenizer: ClipTokenizer,
    private val spec: ImageSpec
) : Closeable {
    private val vision = Ort.open(visionPath)
    private val text = Ort.open(textPath, threads = 2)
    private val visionInput = vision.inputNames.first()
    private val textInput = text.inputNames.first()

    /** L2-normalised image embedding. */
    fun embedImage(img: Pixels): FloatArray {
        val prepared = ImageOps.resizeShortestAndCrop(img, spec.size)
        val data = ImageOps.toTensor(prepared, spec.mean, spec.std, nchw = true)
        return Ort.l2normalize(Ort.run(vision, visionInput, data, longArrayOf(1, 3, spec.size.toLong(), spec.size.toLong())))
    }

    /** L2-normalised text embedding. */
    fun embedText(prompt: String): FloatArray {
        val ids = tokenizer.tokenize(prompt)
        return OnnxTensor.createTensor(Ort.env, LongBuffer.wrap(ids), longArrayOf(1, ids.size.toLong())).use { t ->
            text.run(mapOf(textInput to t)).use { res -> Ort.l2normalize(Ort.readFloats(res.get(0) as OnnxTensor)) }
        }
    }

    override fun close() {
        vision.close()
        text.close()
    }

    companion object {
        fun dot(a: FloatArray, b: FloatArray): Float {
            var s = 0f
            for (i in a.indices) s += a[i] * b[i]
            return s
        }
    }
}
