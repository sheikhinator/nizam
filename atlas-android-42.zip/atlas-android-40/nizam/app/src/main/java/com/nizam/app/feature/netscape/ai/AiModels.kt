package com.nizam.app.feature.netscape.ai

import org.json.JSONObject
import java.io.Closeable
import java.io.File

/**
 * An installed AI pack: a folder holding manifest.json plus the model files it names.
 * Engines are opened lazily and can be closed to free memory between runs.
 */
class AiModels(private val dir: File) : Closeable {

    val manifest: JSONObject? = File(dir, MANIFEST).takeIf { it.exists() }?.let {
        try { JSONObject(it.readText()) } catch (_: Exception) { null }
    }

    private fun section(name: String): JSONObject? = manifest?.optJSONObject("models")?.optJSONObject(name)

    private fun file(section: JSONObject?, key: String): File? =
        section?.optString(key)
            ?.takeIf { it in PACK_FILES && File(it).name == it }
            ?.let { File(dir, it) }
            ?.takeIf { it.isFile }

    private fun spec(o: JSONObject): ImageSpec {
        val mean = o.getJSONArray("mean")
        val std = o.getJSONArray("std")
        return ImageSpec(
            size = o.getInt("size"),
            resize = o.optString("resize", "stretch"),
            mean = FloatArray(3) { mean.getDouble(it).toFloat() },
            std = FloatArray(3) { std.getDouble(it).toFloat() }
        )
    }

    val hasClassifier: Boolean get() = file(section("nsfw"), "file") != null
    val hasNudeNet: Boolean get() = file(section("nudenet"), "file") != null
    val hasClip: Boolean
        get() = section("clip").let { file(it, "vision") != null && file(it, "text") != null && file(it, "vocab") != null }
    val hasCaptioner: Boolean
        get() = section("smolvlm").let { file(it, "model") != null && file(it, "mmproj") != null }

    val version: String get() = manifest?.optString("version").orEmpty()

    private var classifier: NsfwClassifier? = null
    private var nudeNet: NudeNet? = null
    private var clip: ClipModel? = null
    private var captioner: SceneCaptioner? = null

    @Synchronized
    fun classifier(): NsfwClassifier? {
        classifier?.let { return it }
        val s = section("nsfw") ?: return null
        val f = file(s, "file") ?: return null
        val labels = s.getJSONArray("labels").let { a -> (0 until a.length()).map { a.getString(it) } }
        return NsfwClassifier(f.path, spec(s.getJSONObject("spec")), labels).also { classifier = it }
    }

    @Synchronized
    fun nudeNet(): NudeNet? {
        nudeNet?.let { return it }
        val s = section("nudenet") ?: return null
        val f = file(s, "file") ?: return null
        return NudeNet(f.path, s.optInt("size", 320)).also { nudeNet = it }
    }

    @Synchronized
    fun clip(): ClipModel? {
        clip?.let { return it }
        val s = section("clip") ?: return null
        val vision = file(s, "vision") ?: return null
        val text = file(s, "text") ?: return null
        val vocab = file(s, "vocab") ?: return null
        val tokenizer = vocab.inputStream().use { ClipTokenizer.fromGzip(it) }
        return ClipModel(vision.path, text.path, tokenizer, spec(s.getJSONObject("spec"))).also { clip = it }
    }

    @Synchronized
    fun captioner(): SceneCaptioner? {
        captioner?.let { return it }
        val s = section("smolvlm") ?: return null
        val model = file(s, "model") ?: return null
        val mmproj = file(s, "mmproj") ?: return null
        return SceneCaptioner(model.path, mmproj.path).also { captioner = it }
    }

    @Synchronized
    fun closeTaggers() {
        classifier?.close(); classifier = null
        nudeNet?.close(); nudeNet = null
        clip?.close(); clip = null
    }

    @Synchronized
    fun closeCaptioner() {
        captioner?.close(); captioner = null
    }

    @Synchronized
    override fun close() {
        closeTaggers()
        closeCaptioner()
    }

    companion object {
        const val MANIFEST = "manifest.json"

        /** Every file name a pack may contain — anything else in the zip is ignored. */
        val PACK_FILES = setOf(
            MANIFEST, "nsfw.onnx", "nudenet.onnx", "clip_vision.onnx", "clip_text.onnx",
            "clip_vocab.txt.gz", "smolvlm_q8.gguf", "smolvlm_mmproj_q8.gguf", "LICENSES.txt"
        )
    }
}
