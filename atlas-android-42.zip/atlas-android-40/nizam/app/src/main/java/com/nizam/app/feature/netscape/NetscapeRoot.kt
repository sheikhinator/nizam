package com.nizam.app.feature.netscape

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.nizam.app.feature.netscape.data.MediaKind
import com.nizam.app.feature.netscape.data.Vault
import com.nizam.app.feature.netscape.data.VaultItem
import com.nizam.app.feature.netscape.stories.JoytimeApp
import com.nizam.app.feature.netscape.ui.Brand
import com.nizam.app.feature.netscape.ui.CollectionScreen
import com.nizam.app.feature.netscape.ui.DetailScreen
import com.nizam.app.feature.netscape.ui.ExploreScreen
import com.nizam.app.feature.netscape.ui.FramePickerScreen
import com.nizam.app.feature.netscape.ui.HomeScreen
import com.nizam.app.feature.netscape.ui.LibraryScreen
import com.nizam.app.feature.netscape.ui.LockScreen
import com.nizam.app.feature.netscape.ui.NetscapeTheme
import com.nizam.app.feature.netscape.ui.PhotoScreen
import com.nizam.app.feature.netscape.ui.PlayerScreen
import com.nizam.app.feature.netscape.ui.SearchScreen
import com.nizam.app.feature.netscape.ui.SettingsScreen
import com.nizam.app.feature.netscape.ui.TagEditorScreen
import com.nizam.app.feature.netscape.ui.tagLabel
import kotlinx.coroutines.launch

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Home),
    LIBRARY("Library", Icons.Rounded.VideoLibrary),
    EXPLORE("Explore", Icons.Rounded.Explore),
    SEARCH("Search", Icons.Rounded.Search),
    SETTINGS("Settings", Icons.Rounded.Settings),
    STORIES("Stories", Icons.Rounded.AutoStories)
}

private sealed class Route {
    object Tabs : Route()
    data class Detail(val id: String) : Route()
    data class Play(val id: String, val startAt: Long? = null) : Route()
    data class Photo(val id: String) : Route()
    data class Frame(val id: String) : Route()
    data class Folder(val name: String) : Route()
    data class TagView(val name: String) : Route()
    data class Tags(val ids: Set<String>) : Route()
}

/**
 * Photos and videos shared to Netscape from other apps. They wait here until the vault is
 * unlocked, then are imported like files picked in the app. Only the content URIs are held
 * (in memory); nothing is read before unlock.
 */
object ShareInbox {
    val pending = mutableStateListOf<Uri>()

    fun accept(intent: Intent?): Int {
        if (intent == null) return 0
        val uris = mutableListOf<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND ->
                androidx.core.content.IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { uris += it }
            Intent.ACTION_SEND_MULTIPLE ->
                androidx.core.content.IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { uris += it }
            else -> return 0
        }
        // Some apps only fill ClipData.
        intent.clipData?.let { clip -> for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris += it } }
        val fresh = uris.distinct().filter { it !in pending }
        pending.addAll(fresh)
        return fresh.size
    }
}

@Composable
private fun NetscapeApp(backTick: Int, onExit: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val stack = remember { mutableStateListOf<Route>(Route.Tabs) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    val unlocked by Vault.unlocked
    val busy by Vault.busyMessage
    val loadError by Vault.loadError

    fun push(route: Route) {
        if (stack.lastOrNull() != route) stack.add(route)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun importUris(uris: List<Uri>) {
        scope.launch {
            // Shared files can be anything; keep photos and videos only.
            val media = uris.filter { u ->
                val type = runCatching { context.contentResolver.getType(u) }.getOrNull().orEmpty()
                type.isEmpty() || type.startsWith("image/") || type.startsWith("video/")
            }
            val skipped = uris.size - media.size
            if (media.isEmpty()) {
                Toast.makeText(context, "Only photos and videos can be added", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val result = Vault.importMedia(media)
            val message = buildString {
                append("${result.added} added")
                if (result.duplicates > 0) append(", ${result.duplicates} duplicate skipped")
                if (result.failed > 0) append(", ${result.failed} failed")
                if (skipped > 0) append(", $skipped not a photo/video")
            }
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            val ai = com.nizam.app.feature.netscape.ai.AiService
            val writer = com.nizam.app.feature.netscape.ai.WriterService
            val tagFirst = Vault.settings.value.aiAutoTagImports && ai.status.value.any
            val writeAfter = Vault.settings.value.aiAutoWrite && writer.status.value.installed
            if ((tagFirst || writeAfter) && result.ids.isNotEmpty()) {
                ai.appScope.launch {
                    if (tagFirst) {
                        val n = ai.autoTag(result.ids)
                        Toast.makeText(context, "✨ AI added $n tag(s)", Toast.LENGTH_SHORT).show()
                    }
                    // Then write titles/descriptions from those tags, quietly in the background.
                    if (writeAfter) writer.prewrite(result.ids)
                }
            }
        }
    }

    val importer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        Vault.suppressAutoLock = false
        if (!uris.isNullOrEmpty()) importUris(uris)
    }

    // Files shared from other apps are imported as soon as the vault is unlocked.
    LaunchedEffect(unlocked, ShareInbox.pending.size) {
        if (unlocked && ShareInbox.pending.isNotEmpty()) {
            val shared = ShareInbox.pending.toList()
            ShareInbox.pending.clear()
            importUris(shared)
        }
    }

    fun pickMedia() {
        Vault.suppressAutoLock = true
        importer.launch(arrayOf("video/*", "image/*"))
    }

    fun open(item: VaultItem, at: Long? = null) {
        push(if (item.kind == MediaKind.PHOTO) Route.Photo(item.id) else Route.Play(item.id, at))
    }

    fun details(item: VaultItem) = push(Route.Detail(item.id))
    fun editTags(ids: Set<String>) { if (ids.isNotEmpty()) push(Route.Tags(ids)) }
    fun openTag(tag: String) = push(Route.TagView(tag))

    LaunchedEffect(backTick) {
        if (backTick == 0) return@LaunchedEffect
        if (!unlocked) { onExit(); return@LaunchedEffect }
        if (stack.size > 1) { pop(); return@LaunchedEffect }
        if (tab == Tab.STORIES) return@LaunchedEffect   // the story reader handles its own back
        if (tab != Tab.HOME) tab = Tab.HOME else onExit()
    }

    if (!unlocked) {
        LockScreen(onUnlocked = {
            stack.clear()
            stack.add(Route.Tabs)
            tab = Tab.HOME
        })
        return
    }

    val top = stack.last()

    Box(modifier = Modifier.fillMaxSize().background(Brand.Ink)) {
        AnimatedContent(
            targetState = if (top is Route.Tabs) Pair<Route, Tab?>(top, tab) else Pair<Route, Tab?>(top, null),
            transitionSpec = {
                (fadeIn(tween(220)) + scaleIn(initialScale = 0.98f, animationSpec = tween(220)))
                    .togetherWith(fadeOut(tween(160)))
            },
            label = "nav"
        ) { (current, currentTab) ->
            when (current) {
                is Route.Tabs -> when (currentTab ?: Tab.HOME) {
                    Tab.HOME -> HomeScreen(
                        onOpen = { open(it) },
                        onDetails = { details(it) },
                        onAdd = { pickMedia() },
                        onOpenTag = { openTag(it) },
                        onSurprise = { Vault.items.randomOrNull()?.let { details(it) } },
                        onLock = { Vault.lock() }
                    )
                    Tab.LIBRARY -> LibraryScreen(onOpen = { details(it) }, onEditTags = { editTags(it) })
                    Tab.EXPLORE -> ExploreScreen(
                        onOpenFolder = { push(Route.Folder(it)) },
                        onOpenTag = { openTag(it) }
                    )
                    Tab.SEARCH -> SearchScreen(onOpen = { details(it) }, onEditTags = { editTags(it) })
                    Tab.SETTINGS -> SettingsScreen()
                    Tab.STORIES -> Box(Modifier.fillMaxSize().statusBarsPadding().padding(bottom = 64.dp)) { JoytimeApp(backTick, onExit = { tab = Tab.HOME }) }
                }

                is Route.Folder -> CollectionScreen(
                    title = current.name,
                    entries = Vault.itemsIn(current.name),
                    onBack = { pop() },
                    onOpen = { details(it) },
                    onEditTags = { editTags(it) }
                )

                is Route.TagView -> CollectionScreen(
                    title = if (Vault.settings.value.discreet) "Collection" else tagLabel(current.name),
                    entries = Vault.itemsTagged(current.name),
                    onBack = { pop() },
                    onOpen = { details(it) },
                    onEditTags = { editTags(it) }
                )

                is Route.Detail -> DetailScreen(
                    itemId = current.id,
                    onBack = { pop() },
                    onPlay = { open(it) },
                    onPlayAt = { item, ms -> open(item, ms) },
                    onPickFrame = { push(Route.Frame(it.id)) },
                    onEditTags = { editTags(setOf(it.id)) },
                    onOpenTag = { openTag(it) }
                )

                is Route.Tags -> TagEditorScreen(ids = current.ids, onDone = { pop() })

                is Route.Play -> {
                    val item = Vault.find(current.id)
                    if (item != null) PlayerScreen(item, current.startAt) { pop() }
                    else Box(Modifier.fillMaxSize().background(Color.Black))
                }

                is Route.Photo -> {
                    val item = Vault.find(current.id)
                    if (item != null) PhotoScreen(item, onBack = { pop() }, onInfo = { details(it) })
                    else Box(Modifier.fillMaxSize().background(Color.Black))
                }

                is Route.Frame -> {
                    val item = Vault.find(current.id)
                    if (item != null) FramePickerScreen(item) { pop() }
                    else Box(Modifier.fillMaxSize().background(Brand.Ink))
                }
            }
        }

        // iOS-style tab bar — hidden while playing, viewing, editing tags or picking a frame.
        val showBar = top is Route.Tabs || top is Route.Folder || top is Route.TagView
        if (showBar) {
            TabBar(
                current = if (top is Route.Tabs) tab else null,
                modifier = Modifier.align(Alignment.BottomCenter)
            ) { entry ->
                tab = entry
                stack.clear()
                stack.add(Route.Tabs)
            }
        }

        loadError?.let { msg ->
            Text(
                text = "⚠️ $msg",
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF8A1C1C))
                    .padding(12.dp)
            )
        }

        val message = busy
        if (message != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brand.Surface)
                        .padding(horizontal = 28.dp, vertical = 22.dp)
                ) {
                    CircularProgressIndicator(color = Brand.Red)
                    Text(
                        text = message,
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TabBar(current: Tab?, modifier: Modifier = Modifier, onSelect: (Tab) -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xF20A0A0A))
    ) {
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Brand.Line))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(top = 6.dp, bottom = 4.dp)
        ) {
            Tab.values().forEach { entry ->
                val on = current == entry
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(entry) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        entry.icon,
                        contentDescription = entry.label,
                        tint = if (on) Brand.Red else Brand.Muted,
                        modifier = Modifier.size(26.dp)
                    )
                    Text(
                        entry.label,
                        color = if (on) Brand.Red else Brand.Muted,
                        fontSize = 10.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

private fun hostActivity(c: Context): Activity? { var x = c; while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }; return null }

/**
 * Netscape, the encrypted photo and video vault, living inside Atlas. It opens in its own full-screen window with its
 * own passphrase, keeps screenshots off, and locks the moment Atlas leaves the screen or the vault is closed.
 */
@Composable
fun NetscapeRoot(onExit: () -> Unit) {
    var backTick by remember { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        Vault.init(ctx)
        com.nizam.app.feature.netscape.ai.AiService.refresh()
        com.nizam.app.feature.netscape.ai.WriterService.refresh()
        onDispose { Vault.lock() }
    }
    Dialog(onDismissRequest = { backTick++ },
        properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = false, usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect {
            if (window != null) {
                WindowCompat.setDecorFitsSystemWindows(window, false)
                window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                window.setBackgroundDrawableResource(android.R.color.black)
                window.statusBarColor = android.graphics.Color.TRANSPARENT
                window.navigationBarColor = android.graphics.Color.TRANSPARENT
                WindowInsetsControllerCompat(window, window.decorView).apply { isAppearanceLightStatusBars = false; isAppearanceLightNavigationBars = false }
            }
        }
        DisposableEffect(Unit) {
            val w = hostActivity(ctx)?.window
            val alreadySecure = w != null && (w.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE) != 0
            if (w != null && !alreadySecure) w.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            onDispose { if (w != null && !alreadySecure) w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
        }
        val host = LocalLifecycleOwner.current
        DisposableEffect(host) {
            val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP && !Vault.suppressAutoLock) Vault.lock() }
            host.lifecycle.addObserver(o)
            onDispose { host.lifecycle.removeObserver(o) }
        }
        NetscapeTheme { NetscapeApp(backTick, onExit) }
    }
}
