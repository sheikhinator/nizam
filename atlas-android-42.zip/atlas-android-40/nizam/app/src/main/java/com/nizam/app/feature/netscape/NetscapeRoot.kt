package com.nizam.app.feature.netscape

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.nizam.app.feature.netscape.ai.ModelReadiness
import com.nizam.app.feature.netscape.data.MediaKind
import com.nizam.app.feature.netscape.data.Vault
import com.nizam.app.feature.netscape.data.VaultItem
import com.nizam.app.feature.netscape.ui.AiModelSetupDialog
import com.nizam.app.feature.netscape.ui.Brand
import com.nizam.app.feature.netscape.ui.CollectionScreen
import com.nizam.app.feature.netscape.ui.DetailScreen
import com.nizam.app.feature.netscape.ui.FoldersScreen
import com.nizam.app.feature.netscape.ui.FramePickerScreen
import com.nizam.app.feature.netscape.ui.HomeScreen
import com.nizam.app.feature.netscape.ui.LockScreen
import com.nizam.app.feature.netscape.ui.NetscapeTheme
import com.nizam.app.feature.netscape.ui.PhotoScreen
import com.nizam.app.feature.netscape.ui.PhotosScreen
import com.nizam.app.feature.netscape.ui.PlayerScreen
import com.nizam.app.feature.netscape.ui.SearchScreen
import com.nizam.app.feature.netscape.ui.SettingsScreen
import com.nizam.app.feature.netscape.ui.VideosScreen
import kotlinx.coroutines.launch

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    VIDEOS("Videos", Icons.Filled.Movie),
    PHOTOS("Photos", Icons.Filled.Photo),
    FOLDERS("Folders", Icons.Filled.Folder),
    SEARCH("Search", Icons.Filled.Search)
}

private sealed class Route {
    object Tabs : Route()
    object Settings : Route()
    data class Detail(val id: String) : Route()
    data class Play(val id: String) : Route()
    data class Photo(val id: String) : Route()
    data class Frame(val id: String) : Route()
    data class Folder(val name: String) : Route()
    data class TagView(val name: String) : Route()
}

@Composable
private fun NetscapeApp(backTick: Int, onExit: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var route by remember { mutableStateOf<Route>(Route.Tabs) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var aiSetupDialog by remember { mutableStateOf(false) }
    var pendingAiIds by remember { mutableStateOf<List<String>>(emptyList()) }
    val unlocked by Vault.unlocked
    val busy by Vault.busyMessage

    val importer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        Vault.suppressAutoLock = false
        if (!uris.isNullOrEmpty()) {
            scope.launch {
                val result = Vault.importMedia(uris)
                var aiNote = ""
                if (result.addedIds.isNotEmpty()) {
                    when (Vault.aiModelReadiness()) {
                        ModelReadiness.AVAILABLE -> {
                            val aiResult = Vault.analyzeItems(result.addedIds)
                            aiNote = when {
                                aiResult.generated > 0 ->
                                    "${aiResult.generated} AI details generated on-device"
                                aiResult.failed > 0 ->
                                    "On-device AI could not analyze these items"
                                else -> ""
                            }
                        }
                        ModelReadiness.DOWNLOADABLE -> {
                            pendingAiIds = result.addedIds
                            aiSetupDialog = true
                            aiNote = "Download the on-device AI model to generate metadata"
                        }
                        ModelReadiness.DOWNLOADING ->
                            aiNote = "The on-device AI model is still downloading"
                        ModelReadiness.UNAVAILABLE ->
                            aiNote = "On-device AI is unavailable here. Check Settings for device status."
                    }
                }
                val message = buildString {
                    append("${result.added} added")
                    if (result.duplicates > 0) append(", ${result.duplicates} duplicate skipped")
                    if (result.failed > 0) append(", ${result.failed} failed")
                    if (aiNote.isNotBlank()) append(". $aiNote")
                }
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun pickMedia() {
        Vault.suppressAutoLock = true
        importer.launch(arrayOf("video/*", "image/*"))
    }

    fun open(item: VaultItem) {
        route = if (item.kind == MediaKind.PHOTO) Route.Photo(item.id) else Route.Play(item.id)
    }

    LaunchedEffect(backTick) {
        if (backTick == 0) return@LaunchedEffect
        if (!unlocked || (route is Route.Tabs && tab == Tab.HOME)) { onExit(); return@LaunchedEffect }
        route = when (val current = route) {
            is Route.Play -> Route.Detail(current.id)
            is Route.Photo -> Route.Detail(current.id)
            is Route.Frame -> Route.Detail(current.id)
            is Route.Tabs -> { tab = Tab.HOME; Route.Tabs }
            else -> Route.Tabs
        }
    }

    if (!unlocked) {
        LockScreen(onUnlocked = {
            route = Route.Tabs
            tab = Tab.HOME
        })
        return
    }

    Box(modifier = Modifier.fillMaxSize().background(Brand.Ink)) {
        when (val current = route) {
            is Route.Tabs -> when (tab) {
                Tab.HOME -> HomeScreen(
                    onOpen = { open(it) },
                    onDetails = { route = Route.Detail(it.id) },
                    onAdd = { pickMedia() },
                    onSettings = { route = Route.Settings },
                    onLock = { Vault.lock() }
                )
                Tab.VIDEOS -> VideosScreen(onOpen = { route = Route.Detail(it.id) })
                Tab.PHOTOS -> PhotosScreen(onOpen = { route = Route.Detail(it.id) })
                Tab.FOLDERS -> FoldersScreen(
                    onOpenFolder = { route = Route.Folder(it) },
                    onOpenTag = { route = Route.TagView(it) }
                )
                Tab.SEARCH -> SearchScreen(onOpen = { route = Route.Detail(it.id) })
            }

            is Route.Settings -> SettingsScreen(
                onBack = { route = Route.Tabs },
                onLock = { Vault.lock() }
            )

            is Route.Folder -> CollectionScreen(
                title = current.name,
                entries = Vault.itemsIn(current.name),
                onBack = { route = Route.Tabs },
                onOpen = { route = Route.Detail(it.id) }
            )

            is Route.TagView -> CollectionScreen(
                title = "#" + current.name,
                entries = Vault.itemsTagged(current.name),
                onBack = { route = Route.Tabs },
                onOpen = { route = Route.Detail(it.id) }
            )

            is Route.Detail -> DetailScreen(
                itemId = current.id,
                onBack = { route = Route.Tabs },
                onPlay = { open(it) },
                onPickFrame = { route = Route.Frame(it.id) }
            )

            is Route.Play -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) {
                    route = Route.Tabs
                } else {
                    PlayerScreen(item) { route = Route.Detail(item.id) }
                }
            }

            is Route.Photo -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) {
                    route = Route.Tabs
                } else {
                    PhotoScreen(item) { route = Route.Detail(item.id) }
                }
            }

            is Route.Frame -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) {
                    route = Route.Tabs
                } else {
                    FramePickerScreen(item) { route = Route.Detail(item.id) }
                }
            }
        }

        if (aiSetupDialog) {
            AiModelSetupDialog(
                onDownload = {
                    aiSetupDialog = false
                    val ids = pendingAiIds
                    pendingAiIds = emptyList()
                    scope.launch {
                        try {
                            Vault.downloadAiModel()
                            val result = Vault.analyzeItems(ids)
                            val message = if (result.generated > 0) {
                                "${result.generated} AI details generated on-device."
                            } else {
                                "The model is ready, but it could not analyze these items."
                            }
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                        } catch (_: Exception) {
                            Toast.makeText(
                                context,
                                "AI setup failed. Your media is still safely stored.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                },
                onDismiss = {
                    aiSetupDialog = false
                    pendingAiIds = emptyList()
                }
            )
        }

        // Bottom navigation — hidden while playing, viewing a photo or picking a frame.
        val showBar = route is Route.Tabs || route is Route.Folder || route is Route.TagView
        if (showBar) {
            NavigationBar(
                containerColor = Color.Black.copy(alpha = 0.94f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Tab.values().forEach { entry ->
                    NavigationBarItem(
                        selected = route is Route.Tabs && tab == entry,
                        onClick = {
                            tab = entry
                            route = Route.Tabs
                        },
                        icon = { Icon(entry.icon, contentDescription = entry.label) },
                        label = { Text(entry.label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = Brand.Red,
                            unselectedIconColor = Brand.Muted,
                            unselectedTextColor = Brand.Muted
                        )
                    )
                }
            }
        }

        val message = busy
        if (message != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Brand.Red)
                    Text(
                        text = message,
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        }
    }
}

private fun hostActivity(c: Context): Activity? { var x = c; while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }; return null }

/**
 * Netscape, the encrypted photo and video vault, living inside Atlas. It opens in its own full-screen window with its
 * own passphrase, keeps screenshots off, and locks the moment Atlas leaves the screen or the vault is closed.
 */
@Composable
fun NetscapeRoot(onExit: () -> Unit) {
    var backTick by remember { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    DisposableEffect(Unit) { Vault.init(ctx); onDispose { Vault.lock() } }
    Dialog(onDismissRequest = { backTick++ },
        properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect {
            window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
            window?.setBackgroundDrawableResource(android.R.color.black)
        }
        DisposableEffect(Unit) {
            val w = hostActivity(ctx)?.window
            val alreadySecure = w != null && (w.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE) != 0
            if (w != null && !alreadySecure) w.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            onDispose { if (w != null && !alreadySecure) w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
        }
        val host = LocalLifecycleOwner.current
        DisposableEffect(host) {
            val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP && !Vault.suppressAutoLock) Vault.lock() }
            host.lifecycle.addObserver(o)
            onDispose { host.lifecycle.removeObserver(o) }
        }
        NetscapeTheme { NetscapeApp(backTick, onExit) }
    }
}
