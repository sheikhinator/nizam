package com.nizam.app.feature.netscape.ai

import java.io.ByteArrayOutputStream
import java.io.Closeable

/** JNI bridge to writer_jni.cpp (same native library as SmolVLM). */
object NativeWriter {
    init {
        // Tests on a desktop JVM point this at a host build of the same C++ code.
        val hostLib = System.getProperty("netscape.nativeLib")
        if (hostLib != null) System.load(hostLib) else System.loadLibrary("netscape_smolvlm")
    }

    fun interface Listener {
        /** Raw UTF-8 bytes of the next piece; return false to stop. */
        fun onBytes(bytes: ByteArray): Boolean
    }

    external fun nativeOpen(path: String, threads: Int, nCtx: Int): Long
    external fun nativeGenerate(
        handle: Long, prefix: ByteArray, suffix: ByteArray, maxTokens: Int,
        temp: Float, topP: Float, minP: Float, repeatPenalty: Float, seed: Int, listener: Listener
    ): Int
    external fun nativeCancel(handle: Long)
    external fun nativeClose(handle: Long)
}

/**
 * Keeps the writer model loaded and streams text as it is generated.
 * The style prompt (prefix) is cached natively, so repeated calls only pay for the new item.
 */
class StoryWriter(modelPath: String, threads: Int = defaultThreads()) : Closeable {

    data class Stats(val tokens: Int, val millis: Long, val firstTokenMillis: Long)

    @Volatile private var handle: Long = NativeWriter.nativeOpen(modelPath, threads, 2048)
    var lastStats: Stats? = null
        private set

    /**
     * Writes a continuation of [prompt]. [onText] receives the full text so far after each
     * piece (only whole UTF-8 characters, so emoji never arrive half-formed).
     */
    @Synchronized
    fun write(
        prompt: WriterPrompt.Prompt,
        maxTokens: Int = 200,
        seed: Int = (System.nanoTime() and 0x7fffffff).toInt(),
        onText: (String) -> Unit = {}
    ): String {
        check(handle != 0L) { "The writer is closed" }
        val bytes = ByteArrayOutputStream()
        var text = ""
        val start = System.nanoTime()
        var first = -1L
        val n = NativeWriter.nativeGenerate(
            handle,
            prompt.prefix.toByteArray(Charsets.UTF_8),
            prompt.suffix.toByteArray(Charsets.UTF_8),
            maxTokens, 0.9f, 0.92f, 0.05f, 1.12f, seed
        ) { piece ->
            if (first < 0) first = (System.nanoTime() - start) / 1_000_000
            bytes.write(piece)
            val all = bytes.toByteArray()
            val complete = Utf8.completeLength(all)
            val now = String(all, 0, complete, Charsets.UTF_8)
            if (now != text) {
                text = now
                onText(text)
            }
            true
        }
        lastStats = Stats(n, (System.nanoTime() - start) / 1_000_000, first)
        return String(bytes.toByteArray(), Charsets.UTF_8)
    }

    /** Stop the current [write] early (from any thread); it returns what it has so far. */
    fun cancel() {
        val h = handle
        if (h != 0L) NativeWriter.nativeCancel(h)
    }

    @Synchronized
    override fun close() {
        if (handle != 0L) {
            NativeWriter.nativeClose(handle)
            handle = 0L
        }
    }

    companion object {
        /** Big cores only — more threads than that makes small-model decoding slower on phones. */
        fun defaultThreads(): Int = Runtime.getRuntime().availableProcessors().let { if (it >= 8) 4 else (it / 2).coerceAtLeast(2) }
    }
}

object Utf8 {
    /** Length of the longest prefix of [b] that ends on a complete UTF-8 character. */
    fun completeLength(b: ByteArray): Int {
        val n = b.size
        var i = n - 1
        var back = 0
        while (i >= 0 && back < 4) {
            val c = b[i].toInt() and 0xFF
            if (c and 0xC0 != 0x80) {
                val need = when {
                    c < 0x80 -> 1
                    c and 0xE0 == 0xC0 -> 2
                    c and 0xF0 == 0xE0 -> 3
                    c and 0xF8 == 0xF0 -> 4
                    else -> 1
                }
                return if (n - i >= need) n else i
            }
            i--
            back++
        }
        return n
    }
}
