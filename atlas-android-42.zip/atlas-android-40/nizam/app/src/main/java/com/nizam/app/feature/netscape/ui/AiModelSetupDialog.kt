package com.nizam.app.feature.netscape.ui

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable

@Composable
fun AiModelSetupDialog(
    onDownload: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set up on-device AI") },
        text = {
            Text(
                "Android may need to download Google's Gemini Nano model once. " +
                    "This uses your internet connection. Your photos and videos stay on this phone; " +
                    "Netscape does not upload them to a cloud AI service."
            )
        },
        confirmButton = {
            TextButton(onClick = onDownload) { Text("Download model") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Not now") }
        }
    )
}