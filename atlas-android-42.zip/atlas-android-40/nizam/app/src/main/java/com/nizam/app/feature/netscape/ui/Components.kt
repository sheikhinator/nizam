package com.nizam.app.feature.netscape.ui

import android.graphics.Bitmap
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.feature.netscape.data.AutoTags
import com.nizam.app.feature.netscape.data.MediaKind
import com.nizam.app.feature.netscape.data.TagCatalog
import com.nizam.app.feature.netscape.data.TitleGenerator
import com.nizam.app.feature.netscape.data.Vault
import com.nizam.app.feature.netscape.data.VaultItem

// ---------- motion ----------

/** iOS-style press feedback: a soft spring shrink while the finger is down. */
fun Modifier.bounceClick(
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .combinedClickable(
            interactionSource = source,
            indication = null,
            onClick = onClick,
            onLongClick = onLongClick
        )
}

// ---------- artwork ----------

@Composable
fun ThumbImage(item: VaultItem, modifier: Modifier = Modifier, reveal: Boolean = false) {
    val blur = Vault.settings.value.blurThumbs && !reveal
    val bitmap by produceState<ImageBitmap?>(initialValue = null, item.id, item.hasThumb, blur) {
        val bmp = Vault.thumbnail(item)
        value = when {
            bmp == null -> null
            // Tiny down-scale + upscale blurs on every Android version; Modifier.blur smooths it on 12+.
            blur -> Bitmap.createScaledBitmap(bmp, (bmp.width / 24).coerceAtLeast(1), (bmp.height / 24).coerceAtLeast(1), true).asImageBitmap()
            else -> bmp.asImageBitmap()
        }
    }
    Box(modifier = modifier.background(Brand.SurfaceHigh), contentAlignment = Alignment.Center) {
        val bmp = bitmap
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (blur) Modifier.blur(16.dp) else Modifier)
            )
            if (blur) {
                Icon(
                    Icons.Rounded.VisibilityOff,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.55f),
                    modifier = Modifier.size(22.dp)
                )
            }
        } else {
            Icon(
                imageVector = if (item.kind == MediaKind.PHOTO) Icons.Rounded.Photo else Icons.Rounded.PlayArrow,
                contentDescription = null,
                tint = Brand.Muted,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

fun formatDuration(ms: Long): String = TitleGenerator.durationText(ms)

/** Title and text as they should appear on screen, honouring discreet mode and emoji settings. */
fun shownTitle(item: VaultItem): String {
    val t = Vault.displayTitle(item)
    return if (Vault.settings.value.emojiLevel == 0) TitleGenerator.stripEmoji(t) else t
}

fun tagLabel(tag: String): String {
    val s = Vault.settings.value
    return if (s.emojiLevel == 0 || s.discreet) tag else "${TagCatalog.emojiOf(tag, s)} $tag"
}

// ---------- cards ----------

@Composable
fun MediaCard(
    item: VaultItem,
    modifier: Modifier = Modifier.width(172.dp),
    aspect: Float = 16f / 9f,
    selected: Boolean = false,
    selectionMode: Boolean = false,
    showTitle: Boolean = true,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val s = Vault.settings.value
    Column(modifier = modifier.bounceClick(onLongClick = onLongClick, onClick = onClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(aspect)
                .clip(RoundedCornerShape(10.dp))
                .border(
                    width = if (selected) 2.5.dp else 0.dp,
                    color = if (selected) Brand.Red else Color.Transparent,
                    shape = RoundedCornerShape(10.dp)
                )
        ) {
            ThumbImage(item, Modifier.fillMaxSize())
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0.5f to Color.Transparent,
                            1f to Color.Black.copy(alpha = 0.7f)
                        )
                    )
            )
            // Top-left: first category emoji (Netflix-style badge).
            val badge = item.tags.firstOrNull { TagCatalog.groupOf(it, s).id == "category" }
            if (badge != null && !s.discreet && s.emojiLevel > 0) {
                Text(
                    text = TagCatalog.emojiOf(badge, s),
                    fontSize = 13.sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                )
            }
            Row(
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (item.favorite) {
                    Icon(Icons.Rounded.Favorite, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(14.dp))
                }
                AutoTags.quality(item)?.takeIf { it == "4K" || it == "2K" }?.let { q ->
                    Text(
                        q,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .border(1.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 3.dp)
                    )
                }
            }
            Row(
                modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (item.rating > 0) {
                    Icon(Icons.Rounded.Star, contentDescription = null, tint = Brand.Star, modifier = Modifier.size(12.dp))
                    Text(" ${item.rating}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.weight(1f))
                if (item.kind == MediaKind.VIDEO && item.durationMs > 0) {
                    Text(
                        text = formatDuration(item.durationMs),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                } else if (item.kind == MediaKind.PHOTO) {
                    Icon(Icons.Rounded.Photo, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
            if (selectionMode) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(if (selected) Brand.Red.copy(alpha = 0.25f) else Color.Black.copy(alpha = 0.3f))
                )
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = if (selected) Brand.Red else Color.White.copy(alpha = 0.55f),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(28.dp)
                        .background(if (selected) Color.White else Color.Transparent, CircleShape)
                )
            }
            if (item.inProgress) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(Color.White.copy(alpha = 0.25f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(item.progressFraction)
                            .height(3.dp)
                            .background(Brand.Red)
                    )
                }
            }
        }
        if (showTitle) {
            Text(
                text = shownTitle(item),
                color = Brand.Label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp, start = 2.dp)
            )
            if (s.showTagsOnCards && !s.discreet && item.tags.isNotEmpty()) {
                Text(
                    text = item.tags.take(3).joinToString(" • "),
                    color = Brand.Muted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 2.dp)
                )
            }
        }
    }
}

@Composable
fun Rail(
    title: String,
    entries: List<VaultItem>,
    onSeeAll: (() -> Unit)? = null,
    onClick: (VaultItem) -> Unit
) {
    if (entries.isEmpty()) return
    Column(modifier = Modifier.padding(top = 22.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                modifier = Modifier.weight(1f)
            )
            if (onSeeAll != null) {
                Row(
                    modifier = Modifier.clickable(onClick = onSeeAll).padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("See All", color = Brand.Red, fontSize = 14.sp)
                    Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                }
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(entries, key = { it.id }) { item ->
                MediaCard(item) { onClick(item) }
            }
        }
    }
}

// ---------- controls ----------

@Composable
fun Pill(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Color.White else Color.Transparent)
            .border(1.dp, if (selected) Color.White else Color.White.copy(alpha = 0.45f), RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text,
            color = if (selected) Color.Black else Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

enum class ChipState { OFF, ON, EXCLUDED }

@Composable
fun TagChip(
    label: String,
    state: ChipState = ChipState.OFF,
    count: Int? = null,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val bg = when (state) {
        ChipState.ON -> Brand.Red
        ChipState.EXCLUDED -> Color(0xFF3A1214)
        ChipState.OFF -> Brand.SurfaceHigh
    }
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (state == ChipState.EXCLUDED) {
            Icon(Icons.Rounded.Close, contentDescription = "Excluded", tint = Color(0xFFFF6B6B), modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(
            label,
            color = when (state) {
                ChipState.ON -> Color.White
                ChipState.EXCLUDED -> Color(0xFFFF9B9B)
                ChipState.OFF -> Brand.Label
            },
            fontSize = 13.sp,
            fontWeight = if (state == ChipState.ON) FontWeight.SemiBold else FontWeight.Normal
        )
        if (count != null) {
            Text(
                "  $count",
                color = if (state == ChipState.ON) Color.White.copy(alpha = 0.8f) else Brand.Muted,
                fontSize = 12.sp
            )
        }
    }
}

/** iOS segmented control. */
@Composable
fun Segmented(
    options: List<String>,
    selected: Int,
    modifier: Modifier = Modifier,
    onSelect: (Int) -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .background(Brand.SurfaceHigh)
            .padding(2.dp)
    ) {
        options.forEachIndexed { index, label ->
            val on = index == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(7.dp))
                    .background(if (on) Brand.SurfaceHigher else Color.Transparent)
                    .clickable { onSelect(index) }
                    .padding(vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun StarRating(
    rating: Int,
    size: Dp = 26.dp,
    onRate: ((Int) -> Unit)? = null
) {
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        (1..5).forEach { star ->
            Icon(
                imageVector = if (star <= rating) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                contentDescription = "$star stars",
                tint = if (star <= rating) Brand.Star else Brand.Muted,
                modifier = Modifier
                    .size(size)
                    .then(
                        if (onRate != null) Modifier.clickable { onRate(if (rating == star) 0 else star) }
                        else Modifier
                    )
            )
        }
    }
}

/** Big iOS-style page title with optional trailing actions. */
@Composable
fun LargeTitle(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 20.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Brand.Muted, fontSize = 13.sp)
        }
        actions()
    }
}

@Composable
fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder, color = Brand.Muted) },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = Brand.Muted) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                Icon(
                    Icons.Rounded.Close,
                    contentDescription = "Clear",
                    tint = Brand.Muted,
                    modifier = Modifier.clickable { onValueChange("") }
                )
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = fieldColors(),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Brand.SurfaceHigh,
    unfocusedContainerColor = Brand.SurfaceHigh,
    focusedIndicatorColor = Color.Transparent,
    unfocusedIndicatorColor = Color.Transparent,
    disabledIndicatorColor = Color.Transparent,
    cursorColor = Brand.Red,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedLabelColor = Brand.Red,
    unfocusedLabelColor = Brand.Muted
)

@Composable
fun FilledField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1,
    numeric: Boolean = false
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        shape = RoundedCornerShape(12.dp),
        colors = fieldColors(),
        keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
        modifier = modifier.fillMaxWidth()
    )
}

// ---------- grouped lists (iOS Settings look) ----------

@Composable
fun GroupedSection(
    header: String? = null,
    footer: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        if (header != null) {
            Text(
                header.uppercase(),
                color = Brand.Muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 14.dp, bottom = 6.dp)
            )
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Brand.Surface),
            content = content
        )
        if (footer != null) {
            Text(
                footer,
                color = Brand.Muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 6.dp)
            )
        }
    }
}

@Composable
fun GroupedRow(
    title: String,
    icon: ImageVector? = null,
    iconTint: Color = Brand.Red,
    emoji: String? = null,
    value: String? = null,
    showDivider: Boolean = true,
    titleColor: Color = Color.White,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(iconTint),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(12.dp))
            } else if (emoji != null) {
                Text(emoji, fontSize = 20.sp, modifier = Modifier.width(28.dp))
                Spacer(Modifier.width(12.dp))
            }
            Text(title, color = titleColor, fontSize = 16.sp, modifier = Modifier.weight(1f))
            if (value != null) {
                Text(value, color = Brand.Muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (trailing != null) {
                trailing()
            } else if (onClick != null) {
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Brand.Muted, modifier = Modifier.size(20.dp))
            }
        }
        if (showDivider) {
            HorizontalDivider(
                color = Brand.Line,
                thickness = 0.5.dp,
                modifier = Modifier.padding(start = if (icon != null || emoji != null) 54.dp else 14.dp)
            )
        }
    }
}

@Composable
fun ToggleRow(
    title: String,
    checked: Boolean,
    icon: ImageVector? = null,
    iconTint: Color = Brand.Red,
    showDivider: Boolean = true,
    onChange: (Boolean) -> Unit
) {
    GroupedRow(
        title = title,
        icon = icon,
        iconTint = iconTint,
        showDivider = showDivider,
        onClick = { onChange(!checked) },
        trailing = {
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color(0xFF30D158),
                    checkedBorderColor = Color.Transparent,
                    uncheckedThumbColor = Color.White,
                    uncheckedTrackColor = Brand.SurfaceHigher,
                    uncheckedBorderColor = Color.Transparent
                )
            )
        }
    )
}

/** Bottom sheet with the iOS grabber and dark surface. */
@Composable
fun Sheet(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = Brand.Surface,
        contentColor = Color.White,
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(top = 8.dp, bottom = 6.dp)
                    .size(width = 36.dp, height = 5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Brand.SurfaceHigher)
            )
        },
        content = content
    )
}

@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    light: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                when {
                    !enabled -> Brand.SurfaceHigher
                    light -> Color.White
                    else -> Brand.Red
                }
            )
            .then(if (enabled) Modifier.bounceClick(onClick = onClick) else Modifier)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = if (light) Color.Black else Color.White, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text,
            color = if (light) Color.Black else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
    }
}

@Composable
fun SecondaryButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .bounceClick(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}
