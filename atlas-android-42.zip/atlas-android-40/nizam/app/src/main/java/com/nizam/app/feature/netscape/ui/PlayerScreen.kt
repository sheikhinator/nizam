package com.nizam.app.feature.netscape.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import com.nizam.app.feature.netscape.crypto.EncryptedDataSource
import com.nizam.app.feature.netscape.data.TagCatalog
import com.nizam.app.feature.netscape.data.Vault
import com.nizam.app.feature.netscape.data.VaultItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun PlayerScreen(item: VaultItem, startAtMs: Long? = null, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    var muted by remember { mutableStateOf(s.startMuted) }
    var controlsVisible by remember { mutableStateOf(true) }
    var marking by remember { mutableStateOf<Long?>(null) }
    var playerView by remember { mutableStateOf<PlayerView?>(null) }

    val player = remember(item.id) {
        val factory = EncryptedDataSource.Factory(Vault.mediaFile(item), Vault.keyFor(item))
        val source = ProgressiveMediaSource.Factory(factory)
            .createMediaSource(ExoMediaItem.fromUri(Uri.parse("netscape://" + item.id)))
        ExoPlayer.Builder(context)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
            .apply {
                setMediaSource(source)
                prepare()
                val resume = startAtMs ?: if (item.progressMs > 0 && item.progressFraction < 0.98f) item.progressMs else 0L
                if (resume > 0) seekTo(resume)
                volume = if (s.startMuted) 0f else 1f
                playWhenReady = true
            }
    }

    LaunchedEffect(item.id) { Vault.recordView(item) }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    // Saved moments show as ticks on the seek bar.
    val markers = Vault.find(item.id)?.markers.orEmpty()
    LaunchedEffect(markers, playerView) {
        playerView?.setExtraAdGroupMarkers(
            markers.map { it.ms }.toLongArray(),
            BooleanArray(markers.size) { false }
        )
    }

    DisposableEffect(item.id) {
        onDispose {
            val position = player.currentPosition
            val duration = if (player.duration > 0) player.duration else item.durationMs
            player.release()
            CoroutineScope(Dispatchers.Main).launch {
                Vault.setProgress(item, position, duration)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                    setShowFastForwardButton(true)
                    setShowRewindButton(true)
                    setBackgroundColor(android.graphics.Color.BLACK)
                    setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
                        controlsVisible = visibility == android.view.View.VISIBLE
                    })
                    playerView = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (controlsVisible) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = shownTitle(item),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { muted = !muted }) {
                    Icon(
                        if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                        contentDescription = if (muted) "Unmute" else "Mute",
                        tint = Color.White
                    )
                }
                IconButton(onClick = {
                    player.pause()
                    marking = player.currentPosition
                }) {
                    Icon(Icons.Rounded.BookmarkAdd, contentDescription = "Save this moment", tint = Color.White)
                }
            }
        }
    }

    val at = marking
    if (at != null) {
        MarkMomentSheet(
            item = Vault.find(item.id) ?: item,
            positionMs = at,
            onDismiss = {
                marking = null
                player.play()
            },
            onSave = { label ->
                marking = null
                scope.launch { Vault.addMarker(item, at, label) }
                player.play()
            }
        )
    }
}

/** Pick what's happening at this moment — suggestions come from the item's own tags first. */
@Composable
private fun MarkMomentSheet(
    item: VaultItem,
    positionMs: Long,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val s = Vault.settings.value
    var custom by remember { mutableStateOf("") }
    val fromItem = item.tags.filter { TagCatalog.groupOf(it, s).id in setOf("position", "act", "kink", "body", "toys") }
    val suggestions = (fromItem + TagCatalog.tagsIn("position", s).map { it.name }.take(16) +
        TagCatalog.tagsIn("act", s).map { it.name }.take(16)).distinct()

    Sheet(onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 36.dp)
        ) {
            Text(
                "Save moment at ${formatDuration(positionMs.coerceAtLeast(1000))}",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text("What's happening here?", color = Brand.Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledField(value = custom, onValueChange = { custom = it }, label = "Label", modifier = Modifier.weight(1f))
                Spacer(Modifier.padding(4.dp))
                PrimaryButton("Save", enabled = custom.isNotBlank()) { onSave(custom) }
            }
            Spacer(Modifier.height(14.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                suggestions.forEach { tag ->
                    TagChip(tagLabel(tag), if (tag in fromItem) ChipState.ON else ChipState.OFF) { onSave(tag) }
                }
            }
        }
    }
}
