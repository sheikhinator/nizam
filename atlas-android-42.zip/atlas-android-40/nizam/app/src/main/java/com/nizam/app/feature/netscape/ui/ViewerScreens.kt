package com.nizam.app.feature.netscape.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.feature.netscape.data.MediaKind
import com.nizam.app.feature.netscape.data.Vault
import com.nizam.app.feature.netscape.data.VaultItem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Swipe through every photo, pinch or double-tap to zoom, or run a slideshow. */
@Composable
fun PhotoScreen(item: VaultItem, onBack: () -> Unit, onInfo: (VaultItem) -> Unit) {
    val photos = remember { Vault.items.filter { it.kind == MediaKind.PHOTO }.sortedByDescending { it.addedAt } }
    val start = photos.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
    val pager = rememberPagerState(initialPage = start) { photos.size }
    var chrome by remember { mutableStateOf(true) }
    var zoomed by remember { mutableStateOf(false) }
    var slideshow by remember { mutableStateOf(false) }

    LaunchedEffect(pager.currentPage) {
        photos.getOrNull(pager.currentPage)?.let { Vault.recordView(it) }
    }
    LaunchedEffect(slideshow) {
        while (slideshow) {
            delay(3500)
            if (photos.isEmpty()) break
            pager.animateScrollToPage((pager.currentPage + 1) % photos.size)
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (photos.isEmpty()) return@Box
        HorizontalPager(
            state = pager,
            userScrollEnabled = !zoomed,
            key = { photos[it].id },
            modifier = Modifier.fillMaxSize()
        ) { page ->
            ZoomablePhoto(
                item = photos[page],
                active = page == pager.currentPage,
                onZoomChange = { if (page == pager.currentPage) zoomed = it },
                onTap = { chrome = !chrome; slideshow = false }
            )
        }

        if (chrome) {
            val current = photos.getOrNull(pager.currentPage)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .statusBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = Color.White)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        current?.let { shownTitle(it) }.orEmpty(),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text("${pager.currentPage + 1} of ${photos.size}", color = Brand.Muted, fontSize = 12.sp)
                }
                IconButton(onClick = { slideshow = !slideshow; if (slideshow) chrome = false }) {
                    Icon(
                        if (slideshow) Icons.Rounded.Pause else Icons.Rounded.Slideshow,
                        contentDescription = "Slideshow",
                        tint = Color.White
                    )
                }
                IconButton(onClick = { current?.let(onInfo) }) {
                    Icon(Icons.Rounded.Info, contentDescription = "Details", tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun ZoomablePhoto(
    item: VaultItem,
    active: Boolean,
    onZoomChange: (Boolean) -> Unit,
    onTap: () -> Unit
) {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, key1 = item.id) {
        value = Vault.photo(item)?.asImageBitmap()
    }
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    LaunchedEffect(active) {
        if (!active) {
            scale = 1f
            offset = Offset.Zero
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val bmp = bitmap
        if (bmp == null) {
            CircularProgressIndicator(color = Brand.Red)
        } else {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(item.id) {
                        detectTapGestures(
                            onTap = { onTap() },
                            onDoubleTap = { tap ->
                                if (scale > 1f) {
                                    scale = 1f
                                    offset = Offset.Zero
                                } else {
                                    scale = 2.5f
                                    offset = (Offset(size.width / 2f, size.height / 2f) - tap) * 1.5f
                                }
                                onZoomChange(scale > 1f)
                            }
                        )
                    }
                    .pointerInput(item.id) {
                        // Pinch always zooms; one-finger drags only pan once zoomed so the pager can swipe.
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val event = awaitPointerEvent()
                                val multi = event.changes.size > 1
                                if (multi || scale > 1f) {
                                    scale = (scale * event.calculateZoom()).coerceIn(1f, 6f)
                                    offset = if (scale > 1f) offset + event.calculatePan() else Offset.Zero
                                    onZoomChange(scale > 1f)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            )
        }
    }
}

/** Scrub through the encrypted video and freeze any frame as the poster art. */
@Composable
fun FramePickerScreen(item: VaultItem, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var position by remember { mutableStateOf(0.25f) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    val duration = if (item.durationMs > 0) item.durationMs else 1L

    LaunchedEffect(position) {
        loading = true
        delay(60) // debounce while dragging
        preview = Vault.frameAt(item, (position * duration).toLong())
        loading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onDone) {
                Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = Brand.Red)
            }
            Text("Choose artwork", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Box(
            modifier = Modifier
                .padding(top = 12.dp)
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp))
                .background(Brand.SurfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            val bmp = preview
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (loading) CircularProgressIndicator(color = Brand.Red)
        }

        Text(
            text = formatDuration((position * duration).toLong().coerceAtLeast(1000)),
            color = Brand.Muted,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 14.dp)
        )

        Slider(
            value = position,
            onValueChange = { position = it },
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Brand.Red,
                inactiveTrackColor = Brand.SurfaceHigher
            )
        )

        PrimaryButton(
            text = if (saving) "Saving…" else "Use this frame",
            enabled = preview != null && !saving,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) {
            val bmp = preview ?: return@PrimaryButton
            saving = true
            scope.launch {
                Vault.setThumbnail(item, bmp)
                saving = false
                onDone()
            }
        }
    }
}
