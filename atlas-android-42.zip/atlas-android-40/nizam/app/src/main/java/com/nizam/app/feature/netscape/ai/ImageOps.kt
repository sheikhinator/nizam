package com.nizam.app.feature.netscape.ai

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Plain ARGB pixel buffer. Kept free of android.graphics so the whole AI pipeline can be
 * unit-tested on a desktop JVM with the same ONNX Runtime API used on the phone.
 */
class Pixels(val width: Int, val height: Int, val argb: IntArray) {
    init {
        require(argb.size == width * height) { "pixel buffer size mismatch" }
    }
}

object ImageOps {

    /** Bilinear resize with half-pixel centres (matches OpenCV INTER_LINEAR / PIL bilinear on upscale). */
    fun resize(src: Pixels, dw: Int, dh: Int): Pixels {
        if (dw == src.width && dh == src.height) return src
        val out = IntArray(dw * dh)
        val sx = src.width.toFloat() / dw
        val sy = src.height.toFloat() / dh
        val w = src.width
        val h = src.height
        val a = src.argb
        for (y in 0 until dh) {
            val fy = ((y + 0.5f) * sy - 0.5f).coerceIn(0f, (h - 1).toFloat())
            val y0 = floor(fy).toInt()
            val y1 = min(y0 + 1, h - 1)
            val wy = fy - y0
            for (x in 0 until dw) {
                val fx = ((x + 0.5f) * sx - 0.5f).coerceIn(0f, (w - 1).toFloat())
                val x0 = floor(fx).toInt()
                val x1 = min(x0 + 1, w - 1)
                val wx = fx - x0
                val p00 = a[y0 * w + x0]
                val p01 = a[y0 * w + x1]
                val p10 = a[y1 * w + x0]
                val p11 = a[y1 * w + x1]
                fun ch(shift: Int): Int {
                    val c00 = (p00 shr shift) and 0xFF
                    val c01 = (p01 shr shift) and 0xFF
                    val c10 = (p10 shr shift) and 0xFF
                    val c11 = (p11 shr shift) and 0xFF
                    val top = c00 + (c01 - c00) * wx
                    val bottom = c10 + (c11 - c10) * wx
                    return (top + (bottom - top) * wy).roundToInt().coerceIn(0, 255)
                }
                out[y * dw + x] = (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
            }
        }
        return Pixels(dw, dh, out)
    }

    /**
     * Area-average downscale before bilinear when shrinking a lot, so small models don't see
     * aliasing from 4K frames. Only kicks in beyond 2× reduction.
     */
    fun shrink(src: Pixels, maxSide: Int): Pixels {
        var cur = src
        while (max(cur.width, cur.height) > maxSide * 2) {
            cur = halve(cur)
        }
        return cur
    }

    private fun halve(src: Pixels): Pixels {
        val dw = max(1, src.width / 2)
        val dh = max(1, src.height / 2)
        val out = IntArray(dw * dh)
        val w = src.width
        for (y in 0 until dh) {
            for (x in 0 until dw) {
                var r = 0; var g = 0; var b = 0
                for (dy in 0..1) for (dx in 0..1) {
                    val p = src.argb[min(y * 2 + dy, src.height - 1) * w + min(x * 2 + dx, w - 1)]
                    r += (p shr 16) and 0xFF; g += (p shr 8) and 0xFF; b += p and 0xFF
                }
                out[y * dw + x] = (0xFF shl 24) or ((r / 4) shl 16) or ((g / 4) shl 8) or (b / 4)
            }
        }
        return Pixels(dw, dh, out)
    }

    /** Pads right/bottom with black to a square — exactly what NudeNet does before resizing. */
    fun padToSquare(src: Pixels): Pixels {
        val side = max(src.width, src.height)
        if (side == src.width && side == src.height) return src
        val out = IntArray(side * side) { 0xFF000000.toInt() }
        for (y in 0 until src.height) {
            System.arraycopy(src.argb, y * src.width, out, y * side, src.width)
        }
        return Pixels(side, side, out)
    }

    /** Resize the shorter side to [size] then centre-crop to size×size (CLIP preprocessing). */
    fun resizeShortestAndCrop(src: Pixels, size: Int): Pixels {
        val scale = size.toFloat() / min(src.width, src.height)
        val rw = max(size, (src.width * scale).roundToInt())
        val rh = max(size, (src.height * scale).roundToInt())
        val resized = resize(shrink(src, max(rw, rh)), rw, rh)
        val left = (rw - size) / 2
        val top = (rh - size) / 2
        val out = IntArray(size * size)
        for (y in 0 until size) {
            System.arraycopy(resized.argb, (y + top) * rw + left, out, y * size, size)
        }
        return Pixels(size, size, out)
    }

    /**
     * Planar RGB float tensor data, (value / 255 - mean) / std per channel.
     * [nchw] = true → [3, H, W]; false → [H, W, 3]. [bgr] swaps channel order (NudeNet wants BGR).
     */
    fun toTensor(
        src: Pixels,
        mean: FloatArray = floatArrayOf(0f, 0f, 0f),
        std: FloatArray = floatArrayOf(1f, 1f, 1f),
        nchw: Boolean = true,
        bgr: Boolean = false
    ): FloatArray {
        val n = src.width * src.height
        val out = FloatArray(n * 3)
        for (i in 0 until n) {
            val p = src.argb[i]
            val r = (((p shr 16) and 0xFF) / 255f - mean[0]) / std[0]
            val g = (((p shr 8) and 0xFF) / 255f - mean[1]) / std[1]
            val bl = ((p and 0xFF) / 255f - mean[2]) / std[2]
            val c0 = if (bgr) bl else r
            val c2 = if (bgr) r else bl
            if (nchw) {
                out[i] = c0; out[n + i] = g; out[2 * n + i] = c2
            } else {
                out[i * 3] = c0; out[i * 3 + 1] = g; out[i * 3 + 2] = c2
            }
        }
        return out
    }
}
