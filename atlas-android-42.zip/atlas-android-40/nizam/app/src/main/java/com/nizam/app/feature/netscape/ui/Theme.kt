package com.nizam.app.feature.netscape.ui

import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text

object Brand {
    val Red = Color(0xFFE11D2E)
    val RedDeep = Color(0xFF8E0C1B)
    val Ink = Color(0xFF050505)
    val Surface = Color(0xFF121212)
    val SurfaceHigh = Color(0xFF1C1C1E)
    val Muted = Color(0xFF9A9A9E)
    val Line = Color(0xFF262629)
}

private val scheme = darkColorScheme(
    primary = Brand.Red,
    onPrimary = Color.White,
    secondary = Brand.Red,
    background = Brand.Ink,
    onBackground = Color.White,
    surface = Brand.Surface,
    onSurface = Color.White,
    surfaceVariant = Brand.SurfaceHigh,
    onSurfaceVariant = Brand.Muted,
    outline = Brand.Line,
    error = Brand.Red
)

private val typography = Typography(
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = 0.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
)

@Composable
fun NetscapeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}

/**
 * Original Netscape wordmark: heavy condensed caps, deep red, long shadow.
 * Drawn in code so there is no bitmap asset to leak the app's contents.
 */
@Composable
fun NetscapeWordmark(
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 26.sp,
    compact: Boolean = false
) {
    Row(modifier = modifier) {
        Text(
            text = if (compact) "N" else "NETSCAPE",
            color = Brand.Red,
            textAlign = TextAlign.Start,
            style = TextStyle(
                fontSize = fontSize,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp,
                shadow = Shadow(
                    color = Brand.RedDeep,
                    offset = Offset(2f, 3f),
                    blurRadius = 6f
                )
            )
        )
    }
}
