package com.nizam.app.feature.netscape.ai

/** What the models saw in one frame (a photo, or one sampled video frame). */
class FrameResult(
    val nsfw: Map<String, Float>?,
    val detections: List<Detection>?,
    val clip: FloatArray?
)

data class Suggestion(
    val tag: String,
    val groupId: String,
    /** 0..1 */
    val confidence: Float,
    /** Which model produced it: "nsfw", "nudenet" or "clip". */
    val source: String
)

/**
 * Turns raw model outputs into tag suggestions. Pure Kotlin: the tag lists and a text-embedding
 * function are passed in, so this runs (and is tested) without Android.
 */
object AiTagger {

    /** 0 = strict (fewer, surer), 1 = balanced, 2 = loose (more guesses). */
    private fun detThreshold(sensitivity: Int) = floatArrayOf(0.6f, 0.45f, 0.3f)[sensitivity.coerceIn(0, 2)]
    private fun clipThreshold(sensitivity: Int) = floatArrayOf(0.35f, 0.2f, 0.12f)[sensitivity.coerceIn(0, 2)]

    /** Caption templates per tag group — CLIP scores these sentences against the picture. */
    val PROMPTS = linkedMapOf(
        "setting" to "a photo taken in the %s",
        "outfit" to "a photo of a person wearing %s",
        "look" to "a photo of a %s person",
        "camera" to "a %s photo",
        "mood" to "a %s intimate photo",
        "position" to "a photo of a couple having sex in the %s position",
        "act" to "an explicit photo of %s",
        "toys" to "a photo with a %s"
    )

    /** How many tags each CLIP group may contribute. */
    private val TOP_K = mapOf(
        "setting" to 1, "outfit" to 2, "look" to 3, "camera" to 1,
        "mood" to 1, "position" to 2, "act" to 2, "toys" to 1
    )

    /** Groups that only make sense for explicit content. */
    private val EXPLICIT_ONLY = setOf("position", "act", "toys")

    /** Tags that contradict each other — only the more confident of a pair survives. */
    private val CONFLICTS: Set<Pair<String, String>> = run {
        val sets = listOf(
            listOf("face visible", "no face"),
            listOf("mild", "sexy", "explicit"),
            listOf("solo female", "solo male", "couple", "group", "threesome", "foursome"),
            listOf("naked", "lingerie")
        )
        val pairs = HashSet<Pair<String, String>>()
        sets.forEach { set -> set.forEach { a -> set.forEach { b -> if (a != b) pairs += a to b } } }
        listOf("naked", "topless", "explicit").forEach { pairs += "mild" to it; pairs += it to "mild" }
        pairs
    }

    private fun conflicts(a: String, b: String) = (a to b) in CONFLICTS

    /** Decided by the detector/classifier only — CLIP is too vague for these. */
    private val DETECTOR_OWNED = setOf(
        "face visible", "no face", "naked", "topless", "mild", "sexy", "explicit", "animated",
        "solo female", "solo male", "couple", "group", "straight", "lesbian", "gay"
    )

    private val EXPLICIT_LABELS = Regex("nsfw|porn|hentai|explicit|unsafe", RegexOption.IGNORE_CASE)
    private val DRAWN_LABELS = Regex("hentai|drawing|anime|cartoon", RegexOption.IGNORE_CASE)
    private val SEXY_LABELS = Regex("sexy|suggestive", RegexOption.IGNORE_CASE)

    fun suggest(
        frames: List<FrameResult>,
        groupTags: Map<String, List<String>>,
        existing: Set<String>,
        sensitivity: Int,
        embedText: ((String) -> FloatArray)?
    ): List<Suggestion> {
        if (frames.isEmpty()) return emptyList()
        val out = LinkedHashMap<String, Suggestion>()
        val have = existing.map { it.lowercase() }.toSet()
        fun add(tag: String, group: String, conf: Float, source: String) {
            val key = tag.lowercase()
            if (key in have) return
            if (groupTags[group]?.any { it.equals(tag, ignoreCase = true) } != true) return
            if (source == "clip" && key in DETECTOR_OWNED) return
            // Already tagged with a rival by the user → the user wins.
            if (have.any { conflicts(key, it) }) return
            val rivals = out.keys.filter { conflicts(key, it) }
            if (rivals.any { out.getValue(it).confidence >= conf }) return
            rivals.forEach { out.remove(it) }
            val prev = out[key]
            if (prev == null || prev.confidence < conf) out[key] = Suggestion(tag, group, conf.coerceIn(0f, 1f), source)
        }
        val det = detThreshold(sensitivity)

        // ---- NSFW classifier: average over frames
        val cls = frames.mapNotNull { it.nsfw }
        var explicit = -1f
        var sexy = 0f
        if (cls.isNotEmpty()) {
            val labels = cls.first().keys
            val mean = labels.associateWith { l -> cls.map { it[l] ?: 0f }.average().toFloat() }
            explicit = mean.filterKeys { EXPLICIT_LABELS.containsMatchIn(it) }.values.sum()
            sexy = mean.filterKeys { SEXY_LABELS.containsMatchIn(it) }.values.sum()
            val drawn = mean.filterKeys { DRAWN_LABELS.containsMatchIn(it) }.values.sum()
            if (drawn >= 0.5f) add("Animated", "heat", drawn, "nsfw")
        }

        // ---- NudeNet: best score per label, how many people per frame
        val dets = frames.mapNotNull { it.detections }
        val best = HashMap<String, Float>()
        var femaleFaces = 0
        var maleFaces = 0
        var anyFace = false
        dets.forEach { frame ->
            frame.forEach { d -> best[d.label] = maxOf(best[d.label] ?: 0f, d.score) }
            femaleFaces = maxOf(femaleFaces, frame.count { it.label == "FACE_FEMALE" && it.score >= det })
            maleFaces = maxOf(maleFaces, frame.count { it.label == "FACE_MALE" && it.score >= det })
            if (frame.any { it.label.startsWith("FACE") && it.score >= det }) anyFace = true
        }
        fun s(label: String) = best[label] ?: 0f
        fun seen(label: String) = s(label) >= det

        if (dets.isNotEmpty()) {
            if (seen("FEMALE_BREAST_EXPOSED")) {
                add("Breasts", "body", s("FEMALE_BREAST_EXPOSED"), "nudenet")
                add("Topless", "outfit", s("FEMALE_BREAST_EXPOSED") * 0.9f, "nudenet")
            }
            if (seen("FEMALE_GENITALIA_EXPOSED")) add("Pussy", "body", s("FEMALE_GENITALIA_EXPOSED"), "nudenet")
            if (seen("MALE_GENITALIA_EXPOSED")) add("Dick", "body", s("MALE_GENITALIA_EXPOSED"), "nudenet")
            if (seen("BUTTOCKS_EXPOSED") || seen("ANUS_EXPOSED")) add("Butt", "body", maxOf(s("BUTTOCKS_EXPOSED"), s("ANUS_EXPOSED")), "nudenet")
            if (seen("FEET_EXPOSED")) add("Feet", "body", s("FEET_EXPOSED"), "nudenet")
            if (seen("BELLY_EXPOSED")) add("Belly", "body", s("BELLY_EXPOSED"), "nudenet")
            if (seen("MALE_BREAST_EXPOSED")) add("Chest", "body", s("MALE_BREAST_EXPOSED"), "nudenet")
            if (seen("FEMALE_BREAST_EXPOSED") && (seen("FEMALE_GENITALIA_EXPOSED") || seen("BUTTOCKS_EXPOSED"))) {
                add("Naked", "outfit", minOf(s("FEMALE_BREAST_EXPOSED"), maxOf(s("FEMALE_GENITALIA_EXPOSED"), s("BUTTOCKS_EXPOSED"))), "nudenet")
            }
            // Men too: exposed genitals plus bare butt or chest.
            if (seen("MALE_GENITALIA_EXPOSED") && (seen("BUTTOCKS_EXPOSED") || seen("MALE_BREAST_EXPOSED"))) {
                add("Naked", "outfit", minOf(s("MALE_GENITALIA_EXPOSED"), maxOf(s("BUTTOCKS_EXPOSED"), s("MALE_BREAST_EXPOSED"))), "nudenet")
            }
            if (seen("FEMALE_BREAST_COVERED") && !seen("FEMALE_BREAST_EXPOSED") && explicit >= 0.4f) {
                add("Lingerie", "outfit", minOf(s("FEMALE_BREAST_COVERED"), explicit), "nudenet")
            }
            if (anyFace) add("Face Visible", "camera", maxOf(s("FACE_FEMALE"), s("FACE_MALE")), "nudenet")
            else if (frames.size >= 3 && (explicit >= 0.5f || best.keys.any { it.endsWith("EXPOSED") && seen(it) })) {
                add("No Face", "camera", 0.5f, "nudenet")
            }

            // Who's in it — from the most faces seen together in any one frame.
            val maleBody = seen("MALE_GENITALIA_EXPOSED")
            val people = femaleFaces + maleFaces
            val faceConf = maxOf(s("FACE_FEMALE"), s("FACE_MALE")) * 0.8f
            when {
                people >= 3 -> add("Group", "who", faceConf, "nudenet")
                femaleFaces == 1 && maleFaces == 0 && !maleBody -> add("Solo Female", "who", faceConf, "nudenet")
                femaleFaces >= 1 && (maleFaces >= 1 || maleBody) -> {
                    add("Couple", "who", faceConf, "nudenet")
                    add("Straight", "who", faceConf * 0.9f, "nudenet")
                }
                femaleFaces == 2 && maleFaces == 0 && !maleBody -> add("Lesbian", "who", faceConf * 0.8f, "nudenet")
                maleFaces == 1 && femaleFaces == 0 && !seen("FEMALE_GENITALIA_EXPOSED") && !seen("FEMALE_BREAST_EXPOSED") ->
                    add("Solo Male", "who", faceConf, "nudenet")
                maleFaces == 2 && femaleFaces == 0 && maleBody -> add("Gay", "who", faceConf * 0.8f, "nudenet")
            }
        }

        // ---- Heat level: classifier + detector combined
        val genitals = maxOf(s("FEMALE_GENITALIA_EXPOSED"), s("MALE_GENITALIA_EXPOSED"), s("ANUS_EXPOSED"))
        val skin = maxOf(s("FEMALE_BREAST_EXPOSED"), s("BUTTOCKS_EXPOSED"))
        if (explicit >= 0f || dets.isNotEmpty()) {
            val e = maxOf(explicit, if (genitals >= det) genitals else 0f)
            when {
                e >= 0.75f -> add("Explicit", "heat", e, "nsfw")
                e >= 0.35f || skin >= det || sexy >= 0.4f -> add("Sexy", "heat", maxOf(e, skin, sexy), "nsfw")
                explicit in 0f..0.2f && skin < det -> add("Mild", "heat", 1f - explicit, "nsfw")
            }
        }
        val isExplicit = explicit >= 0.5f || genitals >= det || (explicit < 0f && skin >= det)

        // ---- CLIP zero-shot per group
        val embeds = frames.mapNotNull { it.clip }
        if (embeds.isNotEmpty() && embedText != null) {
            val dim = embeds.first().size
            val mean = FloatArray(dim)
            embeds.forEach { e -> for (i in 0 until dim) mean[i] += e[i] }
            val img = Ort.l2normalize(mean)
            val pThr = clipThreshold(sensitivity)
            PROMPTS.forEach { (group, template) ->
                if (group in EXPLICIT_ONLY && !isExplicit) return@forEach
                val tags = groupTags[group].orEmpty()
                if (tags.size < 2) return@forEach
                val logits = FloatArray(tags.size) { i -> ClipModel.dot(img, embedText(template.format(tags[i]))) }
                val probs = Ort.softmax(logits, scale = 100f)
                probs.withIndex()
                    .sortedByDescending { it.value }
                    .take(TOP_K[group] ?: 1)
                    .filter { it.value >= pThr }
                    .forEach { add(tags[it.index], group, it.value, "clip") }
            }
        }

        return out.values.sortedByDescending { it.confidence }
    }

    /** Suggestions sure enough to apply without asking (used by bulk / import auto-tag). */
    fun confident(list: List<Suggestion>, sensitivity: Int): List<Suggestion> {
        val bar = floatArrayOf(0.75f, 0.6f, 0.45f)[sensitivity.coerceIn(0, 2)]
        return list.filter { it.confidence >= if (it.source == "clip") bar - 0.25f else bar }
    }
}
