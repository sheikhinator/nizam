package com.nizam.app.feature.netscape.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import com.nizam.app.feature.browser.AdBlockClient
import android.widget.Toast
import com.nizam.app.feature.netscape.data.Vault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONTokener
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val BG get() = Brand.Ink
private val CARD get() = Brand.Surface
private val HOT get() = Brand.Red
private val DIM get() = Brand.Muted

/** A video the page is playing (or has loaded) that can be saved into the vault. */
private data class Found(val url: String, val hls: Boolean, val referer: String, val title: String)

private val VIDEO_EXT = Regex("\\.(mp4|m4v|webm|mov|mkv|3gp|m3u8)$", RegexOption.IGNORE_CASE)

private fun isVideoUrl(u: String) = VIDEO_EXT.containsMatchIn(u.substringBefore('#').substringBefore('?'))
private fun isHls(u: String) = u.substringBefore('#').substringBefore('?').lowercase().endsWith(".m3u8")

/** Fetches [url] with the page's cookies and referer, the way the page itself would. */
private fun connect(url: String, ua: String, referer: String): HttpURLConnection =
    (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 20_000; readTimeout = 30_000; instanceFollowRedirects = true
        setRequestProperty("User-Agent", ua)
        if (referer.isNotBlank()) setRequestProperty("Referer", referer)
        CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
    }

private fun resolve(base: String, ref: String) = URL(URL(base), ref).toString()

/** Downloads the video to a plain temp file, which the vault then seals and deletes. */
private fun download(f: Found, ua: String, dest: File, onProgress: (Long, Long) -> Unit) {
    if (!f.hls) {
        val conn = connect(f.url, ua, f.referer)
        conn.inputStream.use { input -> dest.outputStream().use { out ->
            val total = conn.contentLengthLong; val buf = ByteArray(64 * 1024); var done = 0L
            while (true) { val n = input.read(buf); if (n < 0) break; out.write(buf, 0, n); done += n; onProgress(done, total) }
        } }
        return
    }
    // an adaptive stream: take the best quality and stitch its segments together
    var playlistUrl = f.url
    var text = connect(playlistUrl, ua, f.referer).inputStream.use { it.bufferedReader().readText() }
    if (text.contains("#EXT-X-STREAM-INF")) {
        val lines = text.lines(); var best = -1L; var pick: String? = null
        lines.forEachIndexed { i, l ->
            if (l.startsWith("#EXT-X-STREAM-INF")) {
                val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                val next = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") }
                if (next != null && bw > best) { best = bw; pick = next.trim() }
            }
        }
        playlistUrl = resolve(playlistUrl, pick ?: error("No video stream in this playlist"))
        text = connect(playlistUrl, ua, f.referer).inputStream.use { it.bufferedReader().readText() }
    }
    if (Regex("#EXT-X-KEY:.*METHOD=(?!NONE)").containsMatchIn(text)) error("This stream is copy-protected and can't be saved")
    val segs = text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
    if (segs.isEmpty()) error("No video found in this stream")
    dest.outputStream().use { out ->
        segs.forEachIndexed { i, s ->
            connect(resolve(playlistUrl, s), ua, f.referer).inputStream.use { it.copyTo(out) }
            onProgress((i + 1).toLong(), segs.size.toLong())
        }
    }
}

/** Looks at every request the page makes, so videos that load through scripts are still caught. */
private class SniffClient(ctx: android.content.Context, private val seen: (String) -> Unit) : AdBlockClient(ctx) {
    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        request?.url?.toString()?.let { if (isVideoUrl(it)) seen(it) }
        return super.shouldInterceptRequest(view, request)
    }
}

/**
 * A private browser inside Netscape. Any video the page plays shows up in a "Save" list, and saving
 * seals it straight into the vault — it never lands in the gallery or the downloads folder.
 * Cookies, history and cache are wiped when the browser closes.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun NetscapeBrowser(backTick: Int, onExit: () -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var address by remember { mutableStateOf("") }
    var progress by remember { mutableIntStateOf(0) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf<String?>(null) }
    var pct by remember { mutableStateOf(0f) }
    var expanded by remember { mutableStateOf(true) }
    val found = remember { mutableStateListOf<Found>() }

    fun add(u: String) {
        if (!u.startsWith("http") || found.any { it.url == u }) return
        val wv = webView
        found.add(Found(u, isHls(u), wv?.url.orEmpty(), wv?.title.orEmpty()))
    }

    fun go(raw: String) {
        val t = raw.trim(); if (t.isBlank()) return
        val u = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(t, "UTF-8")
        }
        found.clear(); webView?.loadUrl(u)
    }

    fun save(f: Found) {
        if (saving != null) { Toast.makeText(c, "Already saving one — wait for it to finish", Toast.LENGTH_SHORT).show(); return }
        val title = f.title.ifBlank { Uri.parse(f.url).lastPathSegment.orEmpty().substringBeforeLast('.') }.ifBlank { "video" }
        saving = title; pct = 0f
        val ua = webView?.settings?.userAgentString.orEmpty()
        scope.launch {
            val tmp = File(File(c.cacheDir, "hv_dl").apply { mkdirs() }, title.take(40).replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "video" } + ".mp4")
            runCatching {
                withContext(Dispatchers.IO) {
                    download(f, ua, tmp) { done, total -> if (total > 0) pct = (done / total.toFloat()).coerceIn(0f, 1f) }
                    Vault.importMedia(listOf(FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", tmp)))
                }
            }.onSuccess { r -> status = if (r.added > 0) "Saved “$title” to the vault" else if (r.duplicates > 0) "That video is already in the vault" else "Couldn't save that one" }
             .onFailure { status = "Couldn't save that one: ${it.message ?: "download failed"}" }
            tmp.delete(); saving = null
        }
    }

    val entryTick = remember { backTick }
    LaunchedEffect(backTick) { if (backTick > entryTick) { if (webView?.canGoBack() == true) webView?.goBack() else onExit() } }

    // players that build their <video> in script show up here even when no file name is visible
    LaunchedEffect(webView) {
        while (true) {
            webView?.evaluateJavascript("(function(){var r=[];document.querySelectorAll('video,video source,audio source').forEach(function(v){var s=v.currentSrc||v.src;if(s)r.push(s)});return JSON.stringify(r)})()") { raw ->
                runCatching {
                    val inner = JSONTokener(raw).nextValue() as? String ?: return@runCatching
                    val a = JSONArray(inner); for (i in 0 until a.length()) add(a.getString(i))
                }
            }
            delay(2000)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webView?.apply { stopLoading(); clearHistory(); clearCache(true); destroy() }
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            File(c.cacheDir, "hv_dl").deleteRecursively()
        }
    }

    Column(Modifier.fillMaxSize().background(BG)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(CARD).padding(horizontal = 12.dp, vertical = 10.dp)) {
                if (address.isEmpty()) Text("Search or type a URL", color = DIM)
                BasicTextField(address, { address = it }, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(HOT), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { go(address) }), modifier = Modifier.fillMaxWidth())
            }
            Text("Go", color = HOT, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { go(address) }.padding(start = 12.dp))
        }
        if (progress in 1..99) LinearProgressIndicator(progress = { progress / 100f }, color = HOT, modifier = Modifier.fillMaxWidth())

        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.cacheMode = WebSettings.LOAD_NO_CACHE
                    settings.saveFormData = false
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    webViewClient = SniffClient(ctx) { u -> post { add(u) } }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, p: Int) { progress = p; view?.url?.let { address = it } }
                    }
                    webView = this
                    loadUrl("https://duckduckgo.com")
                }
            })
        }

        status?.let { Text(it, color = HOT, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
        saving?.let {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                Text("Saving “$it”…", color = Color.White, style = MaterialTheme.typography.labelMedium)
                LinearProgressIndicator(progress = { pct }, color = HOT, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
            }
        }
        if (found.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().background(CARD).padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().clickable { expanded = !expanded }, verticalAlignment = Alignment.CenterVertically) {
                    Text("⬇ ${found.size} video${if (found.size == 1) "" else "s"} on this page", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(if (expanded) "▾" else "▴", color = DIM)
                }
                if (expanded) found.takeLast(5).reversed().forEach { f ->
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(Uri.parse(f.url).lastPathSegment ?: f.url, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text((if (f.hls) "Stream · " else "") + (Uri.parse(f.url).host ?: ""), color = DIM, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall)
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("Save", color = Color.White, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(HOT).clickable { save(f) }.padding(horizontal = 16.dp, vertical = 8.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}
