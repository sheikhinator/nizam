package com.nizam.app.feature.netscape.ai

/**
 * Optional CPU bridge for the SmolVLM2-500M Q8 GGUF prototype.
 * The model and mmproj remain local files; frames never leave this process.
 */
object NativeSmolVlm {
    init { System.loadLibrary("netscape_smolvlm") }

    fun generate(
        handle: Long,
        prompt: String,
        widths: IntArray,
        heights: IntArray,
        frames: Array<IntArray>,
        maxTokens: Int = 160
    ): String {
        check(handle != 0L) { "SmolVLM is closed" }
        require(frames.size in 1..3) { "frames must contain one to three images" }
        require(widths.size == frames.size && heights.size == frames.size) {
            "widths, heights, and frames must have matching sizes"
        }
        frames.forEachIndexed { i, frame ->
            require(widths[i] > 0 && heights[i] > 0 && frame.size == widths[i] * heights[i]) {
                "ARGB frame $i does not match its dimensions"
            }
        }
        return String(nativeGenerate(handle, prompt, widths, heights, frames, maxTokens), Charsets.UTF_8)
    }

    fun open(modelPath: String, mmprojPath: String, threads: Int = 4): Long {
        require(modelPath.isNotBlank() && mmprojPath.isNotBlank()) { "Model paths are required" }
        require(threads > 0) { "threads must be positive" }
        return nativeOpen(modelPath, mmprojPath, threads)
    }

    fun close(handle: Long) {
        if (handle != 0L) nativeClose(handle)
    }

    private external fun nativeOpen(modelPath: String, mmprojPath: String, threads: Int): Long
    private external fun nativeGenerate(
        handle: Long, prompt: String, widths: IntArray, heights: IntArray,
        frames: Array<IntArray>, maxTokens: Int
    ): ByteArray
    private external fun nativeClose(handle: Long)
}