package com.nizam.app.net

import android.graphics.Bitmap
import android.util.Base64
import com.nizam.app.data.prefs.SettingsRepository
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Ask the AI about a photo. Downscaled to 1024px JPEG first — plenty for a plate of food, and it keeps
 * the request small. Works with Gemini natively, and with any OpenAI-compatible provider whose chosen
 * model accepts images (Groq's Llama 4 models, many on OpenRouter and Hugging Face).
 */
object Vision {
    fun encode(bmp: Bitmap): String {
        val scale = 1024f / maxOf(bmp.width, bmp.height)
        val small = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val out = ByteArrayOutputStream(); small.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun ask(settings: SettingsRepository, prompt: String, bmp: Bitmap): String {
        val b64 = encode(bmp)
        return when (settings.aiProvider.first()) {
            "GEMINI" -> {
                val key = settings.geminiApiKey.first().ifBlank { throw IllegalStateException("Add a Gemini key in Settings.") }
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                    .put(JSONObject().put("text", prompt))
                    .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64))))))
                val r = JSONObject(Http.postJson(
                    "https://generativelanguage.googleapis.com/v1beta/models/${settings.geminiModel.first()}:generateContent?key=$key",
                    body.toString()))
                r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    ?.let { p -> (0 until p.length()).joinToString("") { p.getJSONObject(it).optString("text") } }
                    ?: throw IllegalStateException("No answer about the photo.")
            }
            else -> {
                val custom = settings.aiProvider.first() == "CUSTOM"
                val url = if (custom) settings.customUrl.first().trimEnd('/') + "/chat/completions" else "https://openrouter.ai/api/v1/chat/completions"
                val key = if (custom) settings.customKey.first() else settings.openRouterKey.first()
                val model = if (custom) settings.customModel.first() else settings.openRouterModel.first()
                val body = JSONObject().put("model", model).put("max_tokens", 800).put("messages", JSONArray().put(
                    JSONObject().put("role", "user").put("content", JSONArray()
                        .put(JSONObject().put("type", "text").put("text", prompt))
                        .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))))))
                val r = JSONObject(Http.postJson(url, body.toString(), mapOf("Authorization" to "Bearer $key")))
                r.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.takeIf { it.isNotBlank() }
                    ?: throw IllegalStateException("This model didn't answer about the photo — pick one that accepts images.")
            }
        }
    }
}
