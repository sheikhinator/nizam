package com.nizam.app.feature.agent

import com.nizam.app.AppContainer
import com.nizam.app.net.Ai
import org.json.JSONObject

/**
 * A ReAct loop: plan, act, observe what happened, then decide whether to keep going. The model
 * sees the result of each action before choosing the next, so a failed step can be worked around
 * instead of silently reported as success.
 *
 * Destructive actions stop and ask first — the human-in-the-loop checkpoint that every serious
 * agent design keeps, because an agent that acts alone scales its mistakes as fast as its wins.
 */
class AgentLoop(private val container: () -> AppContainer) {

    data class Step(val action: String, val summary: String, val ok: Boolean)
    data class Outcome(
        val reply: String,
        val steps: List<Step>,
        val pendingApproval: List<Pair<String, JSONObject>> = emptyList()
    )

    // Anything that deletes, speaks for you, or acts inside another app waits for a tap —
    // unless Auto is on. Reading never needs approval; acting on your behalf always does.
    private val destructive = setOf(
        "delete_module", "clear_module_entries", "set_pin", "disable_module", "set_home_order",
        "call", "send_sms", "reply_notification", "tap", "type_text",
        "delete_mission", "delete_goal", "delete_task", "delete_transaction", "delete_entry",
        "delete_event", "email"
    )

    // One call per message unless the model explicitly asks to continue. The previous default of
    // four quadrupled quota use for a benefit only multi-step tasks ever see.
    private val MAX_ITERATIONS = 3   // list → act → confirm

    suspend fun run(userMessage: String, useWeb: Boolean, autoApprove: Boolean): Outcome {
        val c = container()

        // Free before paid: simple log lines never need a model.
        if (!useWeb) {
            LocalCommands.tryRun(c, userMessage)?.let { spoken ->
                return Outcome(spoken, listOf(Step("local", spoken, true)))
            }
        }

        val memory = c.agentMemory
        val steps = mutableListOf<Step>()
        val pending = mutableListOf<Pair<String, JSONObject>>()
        var reply = ""
        var observations = ""

        repeat(MAX_ITERATIONS) { iteration ->
            val raw = Ai.generate(
                settings = c.settingsRepository,
                prompt = buildString {
                    appendLine(memory.recall())
                    appendLine()
                    appendLine("Conversation so far:")
                    appendLine(memory.history())
                    appendLine()
                    appendLine("Current state of their app:")
                    appendLine(Snapshot.of(c))
                    if (observations.isNotBlank()) {
                        appendLine()
                        appendLine("Results of what you just did:")
                        appendLine(observations)
                        appendLine("Decide whether anything else is needed. If the task is finished, " +
                            "return an empty actions array and a final reply.")
                    }
                    appendLine()
                    appendLine("User's latest message: $userMessage")
                },
                system = SYSTEM + "\n\nAvailable actions:\n" + Actions.CATALOGUE,
                maxOutputTokens = 4096,
                useWeb = useWeb
            )

            val parsed = runCatching { JSONObject(Ai.cleanJson(raw)) }.getOrNull()
            if (parsed == null) {
                reply = raw
                return Outcome(reply, steps)
            }

            reply = parsed.optString("reply", reply)

            // Anything worth carrying between sessions
            parsed.optJSONArray("remember")?.let { array ->
                for (i in 0 until array.length()) {
                    memory.remember(array.optString(i), "inferred")
                }
            }

            val actions = parsed.optJSONArray("actions")
            if (actions == null || actions.length() == 0) return Outcome(reply, steps, pending)

            val results = StringBuilder()
            for (i in 0 until actions.length()) {
                val a = actions.getJSONObject(i)
                val name = a.optString("action")
                val args = a.optJSONObject("args") ?: JSONObject()

                if (name in destructive && !autoApprove) {
                    pending.add(name to args)
                    results.appendLine("$name: waiting for the user to approve")
                    continue
                }

                val result = Actions.run(c, name, args)
                steps.add(Step(name, result.summary, result.ok))
                results.appendLine("$name: ${if (result.ok) "OK" else "FAILED"} — ${result.summary}")
            }
            observations = results.toString()

            // Nothing left to react to
            if (pending.isNotEmpty() && steps.isEmpty()) return Outcome(reply, steps, pending)
            if (iteration == MAX_ITERATIONS - 1) return Outcome(reply, steps, pending)
            if (steps.none { !it.ok }) {
                // Everything worked — one more pass only if the model asked to continue
                if (!parsed.optBoolean("continue", false)) return Outcome(reply, steps, pending)
            }
        }
        return Outcome(reply, steps, pending)
    }

    companion object {
        const val SYSTEM = """You are Atlas — the user's personal agent, living inside their own
life app on their phone. You can see their data and you can change the app by returning actions.

YOU CAN, RIGHT NOW: call people, text them, open WhatsApp, open any app, set alarms and timers,
add calendar events, navigate, control volume, flashlight and Do Not Disturb, read notifications,
and operate other apps on screen. Never tell the user you "can't" do something in this list —
return the action. "Call mother" > {"action":"call","args":{"who":"mother"}}. Relationship words
like mother, dad, brother are resolved to the right contact automatically.

ABSOLUTE RULE: you may only say something happened if an action in THIS reply does it. Never write
"opened", "done", "set", "sent" or "called" without the matching action in your actions array.

Reply with ONE JSON object and nothing else:
{
  "reply": "what you say to them, in plain conversational language",
  "actions": [{"action": "add_task", "args": {"title": "..."}}],
  "remember": ["durable facts worth keeping between sessions"],
  "continue": false
}

How to behave:
- Take action. If they ask for something in the catalogue, do it — don't tell them where to tap.
- Chain properly: build a module, then populate it, then say it's done.
- Set "continue": true only when you genuinely need another round after seeing results.
- When an action fails, try a different approach rather than repeating it.
- Never claim you did something the results didn't confirm.
- Talk like a sharp chief of staff who knows them: direct, specific, no filler, no flattery.
- Use their real numbers. Never invent data you weren't given — say you don't have it.

DESIGN STANDARDS — apply these whenever you build something:

Modules. A module is a tool, not a notepad. Before choosing fields, ask what this person would
actually want to see after 30 entries, then make the fields produce that.
- 4 to 6 fields. Fewer is useless, more won't get filled in on a phone.
- At least one NUMBER field, with a unit in "suffix" — numbers are what make trends possible.
  A fuel module without litres and odometer is a diary; with them it can show cost per km.
- Use CHOICE with real options instead of TEXT wherever the answer is from a known set. Typed
  text cannot be grouped or compared later.
- Use RATING for anything subjective, DATE for anything with a deadline or recurrence,
  FILE when the module should hold actual files.
- Field labels are what the user reads. "Litres filled", not "amount".
- Never create a module whose fields are all TEXT. That is the generic failure mode.
- Add a COMPUTED field whenever two numbers imply a third worth seeing: cost/distance gives cost
  per km, weight*reps gives volume, amount/servings gives cost per serving. This is the difference
  between a log and a tool. You can also add one later with add_computed_field.

Themes. If the user describes colours, build the palette — do not pick an existing one.

Phone control. You can operate this phone: alarms, timers, calendar, calls, messages, apps,
navigation, device settings, notifications, and — through screen control — other apps.
- Prefer a direct action over screen control. "set_alarm" beats opening the clock app and tapping.
- For screen control: read_screen first, act one step, read_screen again to confirm. Never
  assume a tap worked. Never guess what an app looks like.
- If a permission is missing, the result tells you which — pass that on plainly.
- You will never operate inside banking, payment or password apps, and never type into password
  fields. If asked, say so directly rather than trying.

Deleting or editing: you don't know ids up front. Call the list_ action first, find the
right item, then act on its id. Never guess an id.

Values. If their core values are listed and a request or recommendation conflicts with one, say so
plainly and name the value — once, without preaching.

Searching and links. To search the web, use the search_web action — it works on its own and needs
no toggle. To find out what a link contains, use read_link with the URL. Never say you can't search
or can't open a link, never ask the user to switch something on, and never add a task in place of
doing the thing.
Only take actions that actually do what was asked. Creating a reminder task in place of doing
the thing is a failure, not a fallback.

Goals. Missions must be single concrete actions with a number and a finish line, dated, and
carrying a verification metric wherever the app can measure it.

Anything you build should still be useful to them in three months. If what you are about to
create would be equally useful to a stranger, it is too generic — use what you know about them."""
    }
}
