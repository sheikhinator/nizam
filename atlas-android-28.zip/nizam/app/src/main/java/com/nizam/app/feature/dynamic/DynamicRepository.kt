package com.nizam.app.feature.dynamic

import com.nizam.app.core.today
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

class DynamicRepository(private val dao: DynamicDao) {

    fun specs(): Flow<List<ModuleSpec>> = dao.observeSpecs()
    fun allSpecs(): Flow<List<ModuleSpec>> = dao.observeAllSpecs()
    fun entries(key: String): Flow<List<ModuleEntry>> = dao.observeEntries(key)
    fun recentEntries(): Flow<List<ModuleEntry>> = dao.observeRecentEntries()

    /** Adds any built-in module this install doesn't have yet — so new built-ins reach existing users. */
    suspend fun seedIfEmpty() {
        val missing = Builtins.specs.filter { spec(it.key) == null }
        if (missing.isNotEmpty()) dao.insertSpecs(missing)
    }

    suspend fun addEntry(moduleKey: String, title: String, values: Map<String, String>) {
        val json = JSONObject()
        values.filterValues { it.isNotBlank() }.forEach { (k, v) -> json.put(k, v) }
        dao.insertEntry(
            ModuleEntry(
                moduleKey = moduleKey,
                title = title.trim(),
                localDate = today(),
                valuesJson = json.toString()
            )
        )
    }

    suspend fun deleteEntry(id: Long) = dao.deleteEntry(id)

    suspend fun setEnabled(spec: ModuleSpec, enabled: Boolean) =
        dao.updateSpec(spec.copy(enabled = enabled))

    suspend fun addSpec(spec: ModuleSpec) = dao.insertSpec(spec)

    suspend fun spec(key: String) = dao.spec(key)

    suspend fun countFor(key: String) = dao.countFor(key)

    suspend fun updateSpec(spec: ModuleSpec) = dao.updateSpec(spec)

    suspend fun deleteModule(spec: ModuleSpec) {
        dao.deleteEntriesFor(spec.key)
        dao.deleteSpec(spec.key)
    }

    suspend fun clearEntries(spec: ModuleSpec) = dao.deleteEntriesFor(spec.key)

    suspend fun reorder(specs: List<ModuleSpec>) {
        specs.forEachIndexed { index, spec -> dao.updateSpec(spec.copy(sortIndex = index)) }
    }

    suspend fun updateEntry(entry: ModuleEntry, title: String, values: Map<String, String>) {
        val json = org.json.JSONObject()
        values.filterValues { it.isNotBlank() }.forEach { (k, v) -> json.put(k, v) }
        dao.updateEntryRow(entry.copy(title = title.trim(), valuesJson = json.toString()))
    }
}
