package com.nizam.app.feature.mcp

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.net.Ai
import com.nizam.app.ui.components.Feedback
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Playground: connect any MCP server, see what it offers, and use it — by hand or by asking Atlas.
 */
@Composable
fun PlaygroundScreen(container: AppContainer) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var servers by remember { mutableStateOf(Mcp.servers(c)) }
    var tools by remember { mutableStateOf<List<McpTool>>(emptyList()) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var openTool by remember { mutableStateOf<McpTool?>(null) }
    var args by remember { mutableStateOf("{}") }
    var ask by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }

    fun refresh() = scope.launch {
        busy = true
        tools = servers.filter { it.enabled }.flatMap { s ->
            runCatching { Mcp.tools(s, refresh = true) }.getOrElse {
                Feedback.show("${s.name}: ${Feedback.friendly(it)}"); emptyList()
            }
        }
        busy = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        ModuleTitle("🔌  Playground", "Connect any MCP server — its tools become Atlas's tools")
        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Add a server", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(url, { url = it }, singleLine = true, label = { Text("Server URL (https://…/mcp)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(token, { token = it }, singleLine = true, label = { Text("Bearer token (if the server needs one)") },
                    modifier = Modifier.fillMaxWidth())
                Button(enabled = url.startsWith("http") && !busy, onClick = {
                    scope.launch {
                        busy = true
                        val s = McpServer(name.ifBlank { url.substringAfter("//").substringBefore("/") }, url.trim(), token.trim(), true)
                        runCatching { Mcp.connect(s) }.onSuccess { info ->
                            servers = servers.filterNot { it.url == s.url } + s
                            Mcp.save(c, servers); name = ""; url = ""; token = ""
                            Feedback.show("Connected: $info")
                            refresh()
                        }.onFailure { Feedback.failed("Connection", it); busy = false }
                    }
                }) { Text(if (busy) "Connecting…" else "Connect") }
                Text("Atlas speaks MCP over HTTP (JSON-RPC, streamable). Local servers on your Wi-Fi work too.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        servers.forEach { s ->
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                        Text(s.url, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${tools.count { it.server == s.name }} tools", style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary)
                    }
                    Switch(s.enabled, { on ->
                        servers = servers.map { if (it.url == s.url) it.copy(enabled = on) else it }
                        Mcp.save(c, servers); refresh()
                    })
                    Text("✕", color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.clickable(role = Role.Button) {
                            servers = servers - s; Mcp.save(c, servers); refresh(); Feedback.show("Removed ${s.name}")
                        }.padding(8.dp))
                }
            }
        }
        if (servers.isNotEmpty()) OutlinedButton(onClick = { refresh() }) { Text(if (busy) "Loading tools…" else "Refresh tools") }

        if (tools.isNotEmpty()) {
            Text("ASK ATLAS TO USE THEM", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(ask, { ask = it }, label = { Text("e.g. create an issue titled…") }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Button(enabled = ask.isNotBlank() && !busy, onClick = {
                    scope.launch {
                        busy = true; Feedback.show("Working…")
                        result = runCatching { container.agentLoop.run(ask, useWeb = false, autoApprove = true).reply }
                            .getOrElse { "Failed: ${Feedback.friendly(it)}" }
                        busy = false
                    }
                }) { Text("Run") }
            }

            Text("TOOLS", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 16.dp))
            tools.forEach { t ->
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(role = Role.Button) {
                        openTool = if (openTool?.name == t.name) null else t
                        args = t.schema?.optJSONObject("properties")?.let { props ->
                            JSONObject().apply { props.keys().forEach { k -> put(k, "") } }.toString(2)
                        } ?: "{}"
                    }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${t.name}  ·  ${t.server}", style = MaterialTheme.typography.titleMedium)
                        if (t.description.isNotBlank()) Text(t.description, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
                        if (openTool?.name == t.name) {
                            OutlinedTextField(args, { args = it }, label = { Text("Arguments (JSON)") },
                                modifier = Modifier.fillMaxWidth().height(150.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(enabled = !busy, onClick = {
                                    scope.launch {
                                        busy = true
                                        result = runCatching {
                                            Mcp.findAndCall(c, t.name, JSONObject(args))
                                        }.getOrElse { "Failed: ${Feedback.friendly(it)}" }
                                        busy = false
                                    }
                                }) { Text("Run tool") }
                                OutlinedButton(enabled = !busy, onClick = {
                                    scope.launch {
                                        busy = true
                                        result = runCatching {
                                            val filled = Ai.generate(container.settingsRepository,
                                                "Tool: ${t.name}\nDescription: ${t.description}\nJSON schema: ${t.schema}\n" +
                                                    "User wants: ${ask.ifBlank { "a sensible example call" }}\n" +
                                                    "Return ONLY the arguments JSON object.", maxOutputTokens = 500)
                                            args = JSONObject(Ai.cleanJson(filled)).toString(2)
                                            "Arguments filled in — check them, then Run tool."
                                        }.getOrElse { "Failed: ${Feedback.friendly(it)}" }
                                        busy = false
                                    }
                                }) { Text("✦ Fill arguments") }
                            }
                        }
                    }
                }
            }
        }
        result?.let {
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                Text(it, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(60.dp))
    }
}
