package com.nizam.app.feature.phone

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import com.nizam.app.MainActivity

/**
 * Registering these makes Atlas selectable as the phone's default digital assistant — so a
 * long-press on the power or home button opens Atlas's Curator instead of Google, exactly the
 * way Gemini takes over that gesture.
 */
class AtlasVoiceService : VoiceInteractionService()

class AtlasSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = AtlasSession(this)
}

class AtlasSession(context: Context) : VoiceInteractionSession(context) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val intent = Intent(context, MainActivity::class.java)
            .setAction(MainActivity.ACTION_OPEN_CURATOR)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startAssistantActivity(intent)
        hide()
    }
}

/**
 * Android only lists an app as a selectable digital assistant if it also declares a
 * RecognitionService. Atlas does its own speech capture inside the Curator, so this defers to
 * the system recogniser rather than implementing one.
 */
class AtlasRecognitionService : android.speech.RecognitionService() {
    override fun onStartListening(intent: Intent?, listener: Callback?) {
        runCatching { listener?.error(android.speech.SpeechRecognizer.ERROR_CLIENT) }
    }
    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
