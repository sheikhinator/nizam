package com.nizam.app.core

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.nizam.app.ui.theme.MonoNumber
import kotlin.math.max
import kotlin.math.min

/**
 * Charts drawn on a Compose Canvas — no charting dependency, no WebView, and they inherit the
 * app's theme automatically. Numbers without a shape are just a list; this is what turns a
 * module from a notepad into something you can read a trend off.
 */

data class Point(val label: String, val value: Double)

@Composable
fun LineChart(
    points: List<Point>,
    accent: Color,
    height: Int = 120,
    fill: Boolean = true
) {
    if (points.size < 2) {
        EmptyChart("Two entries and a line appears here.")
        return
    }
    val values = points.map { it.value }
    val minValue = values.min()
    val maxValue = values.max()
    val span = (maxValue - minValue).takeIf { it > 0.0 } ?: 1.0
    val grid = MaterialTheme.colorScheme.surfaceVariant

    Canvas(Modifier.fillMaxWidth().height(height.dp).padding(vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        val stepX = w / (points.size - 1)

        // Three faint guide lines give the eye a reference without cluttering
        repeat(3) { i ->
            val y = h * (i + 1) / 4f
            drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }

        val path = Path()
        val area = Path()
        points.forEachIndexed { index, point ->
            val x = index * stepX
            val y = h - ((point.value - minValue) / span * h).toFloat()
            if (index == 0) { path.moveTo(x, y); area.moveTo(x, h); area.lineTo(x, y) }
            else { path.lineTo(x, y); area.lineTo(x, y) }
        }
        if (fill) {
            area.lineTo(w, h)
            area.close()
            drawPath(area, accent.copy(alpha = 0.16f))
        }
        drawPath(path, accent, style = Stroke(width = 3f))

        // Mark the latest reading
        val lastX = (points.size - 1) * stepX
        val lastY = h - ((points.last().value - minValue) / span * h).toFloat()
        drawCircle(accent, radius = 5f, center = Offset(lastX, lastY))
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween) {
        Text(points.first().label, style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(points.last().label, style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun BarChart(points: List<Point>, accent: Color, height: Int = 110) {
    if (points.isEmpty()) {
        EmptyChart("Nothing to chart yet.")
        return
    }
    val maxValue = points.maxOf { it.value }.takeIf { it > 0.0 } ?: 1.0
    val grid = MaterialTheme.colorScheme.surfaceVariant

    Canvas(Modifier.fillMaxWidth().height(height.dp).padding(vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        val slot = w / points.size
        val barWidth = min(slot * 0.62f, 34f)

        points.forEachIndexed { index, point ->
            val barHeight = max(((point.value / maxValue) * h).toFloat(), 2f)
            val x = index * slot + (slot - barWidth) / 2f
            drawRect(
                color = if (point.value > 0) accent else grid,
                topLeft = Offset(x, h - barHeight),
                size = Size(barWidth, barHeight)
            )
        }
    }
}

/** A year of activity as small squares — the pattern is the message. */
@Composable
fun Heatmap(values: List<Double>, accent: Color, columns: Int = 15) {
    if (values.isEmpty()) {
        EmptyChart("Log a few days and the pattern shows here.")
        return
    }
    val maxValue = values.max().takeIf { it > 0.0 } ?: 1.0
    val empty = MaterialTheme.colorScheme.surfaceVariant
    val rows = (values.size + columns - 1) / columns

    Canvas(Modifier.fillMaxWidth().height((rows * 16).dp).padding(vertical = 4.dp)) {
        val cell = size.width / columns
        val pad = cell * 0.16f
        values.forEachIndexed { index, value ->
            val col = index % columns
            val row = index / columns
            val intensity = (value / maxValue).toFloat().coerceIn(0f, 1f)
            drawRect(
                color = if (value <= 0.0) empty else accent.copy(alpha = 0.25f + intensity * 0.75f),
                topLeft = Offset(col * cell + pad, row * cell + pad),
                size = Size(cell - pad * 2, cell - pad * 2)
            )
        }
    }
}

@Composable
fun StatRow(stats: List<Pair<String, String>>) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        stats.forEach { (label, value) ->
            Column(Modifier.weight(1f)) {
                Text(value, style = MonoNumber)
                Text(
                    label.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun EmptyChart(message: String) {
    Box(Modifier.fillMaxWidth().height(60.dp)) {
        Text(
            message,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
