package com.nizam.app.feature.agent

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.nizam.app.core.ChipRow
import com.nizam.app.core.ModuleTitle
import com.nizam.app.ui.components.Feedback

/** Standing jobs: scheduled agent tasks, and watchers that only speak when something changes. */
@Composable
fun SchedulesScreen() {
    val c = LocalContext.current
    var jobs by remember { mutableStateOf(Schedules.all(c)) }
    var kind by remember { mutableStateOf("task") }
    var prompt by remember { mutableStateOf("") }
    var cadence by remember { mutableStateOf("daily") }
    var hour by remember { mutableStateOf("9") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        ModuleTitle("⏱  Standing jobs", "Work Atlas does on its own, while you get on with things")
        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                ChipRow(listOf("task", "watcher"), kind, { kind = it },
                    labels = { if (it == "task") "Scheduled task" else "Watcher" })
                Text(if (kind == "task") "Runs on a schedule and reports back — \"review my spending and name the three biggest leaks\"."
                    else "Checks a condition and only tells you when the answer becomes yes — \"has the dollar passed 290?\"",
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(prompt, { prompt = it }, label = { Text(if (kind == "task") "What should it do?" else "What should it watch for?") },
                    modifier = Modifier.fillMaxWidth())
                ChipRow(listOf("hourly", "daily", "weekly"), cadence, { cadence = it })
                if (cadence != "hourly") ChipRow(listOf("7", "9", "13", "18", "21"), hour, { hour = it }, labels = { "$it:00" })
                Button(enabled = prompt.isNotBlank(), onClick = {
                    jobs = jobs + AgentJob(System.currentTimeMillis(), kind, prompt.trim(), cadence, hour.toInt())
                    Schedules.save(c, jobs); prompt = ""
                    Feedback.show(if (kind == "task") "Scheduled" else "Watching")
                }, modifier = Modifier.padding(top = 8.dp)) { Text(if (kind == "task") "Schedule it" else "Watch it") }
            }
        }
        jobs.forEach { j ->
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text((if (j.kind == "watcher") "👁 " else "✦ ") + j.prompt, style = MaterialTheme.typography.titleMedium)
                    Text("${j.cadence}${if (j.cadence != "hourly") " at ${j.hour}:00" else ""}" +
                        (j.lastRun.takeIf { it.isNotBlank() }?.let { " · last ran $it" } ?: " · not run yet"),
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (j.lastResult.isNotBlank()) Text(j.lastResult, style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 6.dp))
                    Text("remove", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.clickable(role = Role.Button) { jobs = jobs - j; Schedules.save(c, jobs) }.padding(top = 6.dp))
                }
            }
        }
        Spacer(Modifier.height(60.dp))
    }
}
