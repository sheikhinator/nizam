package com.nizam.app.feature.launcher

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.MainActivity
import com.nizam.app.NizamApplication
import com.nizam.app.core.hourToClock
import com.nizam.app.feature.prayer.PrayerTimes
import com.nizam.app.feature.shield.Shield
import com.nizam.app.ui.theme.DisplayFamily
import com.nizam.app.ui.theme.NizamTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.LocalTime

/** Favourite apps shown on the launcher's front page — everything else is one search away. */
object LauncherPrefs {
    private fun p(c: Context) = c.getSharedPreferences("launcher", 0)
    fun favourites(c: Context): List<String> = p(c).getString("fav", "")!!.split(",").filter { it.isNotBlank() }
    fun setFavourites(c: Context, l: List<String>) = p(c).edit().putString("fav", l.joinToString(",")).apply()
}

/**
 * Atlas as your home screen: the time, the next prayer, today's one mission, and only the apps you
 * choose. Everything else is behind a search, which is the point — fewer icons, fewer impulses.
 * Switch back to your normal launcher any time in Android's Settings → Apps → Default apps → Home.
 */
class LauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as NizamApplication).container
        setContent {
            NizamTheme(darkTheme = true) {
                var now by remember { mutableStateOf(LocalTime.now()) }
                var prayer by remember { mutableStateOf("") }
                var mission by remember { mutableStateOf("") }
                var query by remember { mutableStateOf("") }
                val all = remember { Shield.apps(this) }
                var favs by remember { mutableStateOf(LauncherPrefs.favourites(this)) }
                var editing by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) {
                    val s = container.settingsRepository
                    runCatching {
                        val t = PrayerTimes.calculate(LocalDate.now(), s.latitude.first(), s.longitude.first(),
                            runCatching { PrayerTimes.Method.valueOf(s.prayerMethod.first()) }.getOrElse { PrayerTimes.Method.KARACHI }, s.hanafiAsr.first())
                        val h = LocalTime.now().let { it.hour + it.minute / 60.0 }
                        prayer = listOf("Fajr" to t.fajr, "Dhuhr" to t.dhuhr, "Asr" to t.asr, "Maghrib" to t.maghrib, "Isha" to t.isha)
                            .firstOrNull { it.second > h }?.let { "${it.first} ${hourToClock(it.second)}" } ?: "Isha has passed"
                    }
                    mission = runCatching { container.missionRepository.today().first().firstOrNull { it.completedAt == null }?.title }.getOrNull().orEmpty()
                    while (true) { now = LocalTime.now(); delay(20_000) }
                }
                fun open(pkg: String) = packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
                Column(Modifier.fillMaxSize().background(Color(0xFF0B0F1A)).systemBarsPadding().padding(24.dp)) {
                    Spacer(Modifier.height(40.dp))
                    Text("%02d:%02d".format(now.hour, now.minute), color = Color(0xFFEDEFF5), fontSize = 64.sp,
                        style = MaterialTheme.typography.displaySmall.copy(fontFamily = DisplayFamily))
                    Text(prayer, color = Color(0xFF4FC3A1), fontSize = 18.sp)
                    if (mission.isNotBlank()) Text("Today: $mission", color = Color(0xFFE0B14A), fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(36.dp))
                    OutlinedTextField(query, { query = it }, singleLine = true, label = { Text("Search apps") }, modifier = Modifier.fillMaxWidth())
                    val shown = if (query.isNotBlank()) all.filter { it.first.contains(query, true) }
                        else if (editing) all else favs.mapNotNull { f -> all.firstOrNull { it.second == f } }
                    LazyColumn(Modifier.weight(1f).padding(top = 10.dp)) {
                        items(shown) { (label, pkg) ->
                            Row(Modifier.fillMaxWidth().clickable(role = Role.Button) {
                                if (editing) { favs = if (pkg in favs) favs - pkg else favs + pkg; LauncherPrefs.setFavourites(this@LauncherActivity, favs) }
                                else { open(pkg); query = "" }
                            }.padding(vertical = 12.dp)) {
                                Text((if (editing) (if (pkg in favs) "● " else "○ ") else "") + label, color = Color(0xFFEDEFF5), fontSize = 22.sp)
                            }
                        }
                        if (shown.isEmpty() && query.isBlank()) item {
                            Text("Tap “choose apps” to pick the few that belong here.", color = Color(0xFF8C96AC))
                        }
                    }
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(if (editing) "done" else "choose apps", color = Color(0xFF8C96AC),
                            modifier = Modifier.clickable(role = Role.Button) { editing = !editing }.padding(8.dp))
                        Text("✦ Atlas", color = Color(0xFF4FC3A1),
                            modifier = Modifier.clickable(role = Role.Button) { startActivity(Intent(this@LauncherActivity, MainActivity::class.java)) }.padding(8.dp))
                    }
                }
            }
        }
    }
    @Deprecated("Home stays home.")
    override fun onBackPressed() { /* the home screen has nowhere to go back to */ }
}
