package com.nizam.app.feature.money

import android.content.Context
import android.net.Uri
import com.nizam.app.AppContainer
import java.time.Instant
import java.time.ZoneId

/**
 * Pakistani banks text you on every card swipe and transfer. Reading those messages turns Finance
 * from something you maintain into something that maintains itself.
 *
 * Parsing is done here on the phone with plain patterns — no AI call, no data leaving the device.
 */
data class BankTxn(val amount: Double, val merchant: String, val kind: String, val date: String, val raw: String, val id: Long)

object BankSms {
    private val BANK_WORDS = listOf("debit", "credit", "spent", "withdrawn", "deposited", "transferred", "purchase",
        "transaction", "payment", "received", "sent", "atm", "pos", "card", "account")
    private val AMOUNT = Regex("""(?:PKR|Rs\.?|RS)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
    private val MERCHANT = Regex("""\bat\s+([A-Za-z0-9&'.\- ]{3,36})""", RegexOption.IGNORE_CASE)
    private val CREDIT = listOf("credited", "received", "deposit", "salary", "refund")

    fun looksLikeBank(body: String): Boolean {
        val b = body.lowercase()
        return AMOUNT.containsMatchIn(body) && BANK_WORDS.count { b.contains(it) } >= 1
    }

    fun parse(body: String, at: Long, id: Long): BankTxn? {
        if (!looksLikeBank(body)) return null
        val amount = AMOUNT.find(body)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: return null
        if (amount <= 0) return null
        val b = body.lowercase()
        val kind = if (CREDIT.any { b.contains(it) }) "INCOME" else "EXPENSE"
        val merchant = MERCHANT.find(body)?.groupValues?.get(1)?.trim()?.trim('.', ',')
            ?.takeIf { it.length in 3..36 && !it.lowercase().startsWith("atm ") }
            ?: body.split(Regex("[.\\n]")).firstOrNull { it.length in 6..40 }?.trim().orEmpty()
        return BankTxn(amount, merchant.ifBlank { "Bank transaction" }, kind,
            Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()).toLocalDate().toString(), body.take(220), id)
    }

    /** Category guessed from the merchant name — no AI needed for the common cases. */
    fun category(merchant: String): String {
        val m = merchant.lowercase()
        return when {
            listOf("foodpanda", "kfc", "mcdonald", "pizza", "restaurant", "cafe", "bakery", "hotel").any { m.contains(it) } -> "Food"
            listOf("careem", "uber", "indrive", "petrol", "shell", "pso", "total", "fuel").any { m.contains(it) } -> "Transport"
            listOf("k-electric", "sui", "ptcl", "jazz", "zong", "ufone", "telenor", "bill", "wapda").any { m.contains(it) } -> "Bills"
            listOf("mart", "store", "grocer", "imtiaz", "metro", "carrefour", "al-fatah").any { m.contains(it) } -> "Groceries"
            listOf("pharmacy", "clinic", "hospital", "lab", "medic").any { m.contains(it) } -> "Health"
            listOf("daraz", "shop", "outfitters", "khaadi", "sapphire").any { m.contains(it) } -> "Shopping"
            else -> "Other"
        }
    }

    private fun prefs(c: Context) = c.getSharedPreferences("banksms", 0)
    fun enabled(c: Context) = prefs(c).getBoolean("on", false)
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean("on", v).apply()
    fun auto(c: Context) = prefs(c).getBoolean("auto", false)
    fun setAuto(c: Context, v: Boolean) = prefs(c).edit().putBoolean("auto", v).apply()
    private fun done(c: Context) = prefs(c).getStringSet("done", emptySet())!!.toMutableSet()
    fun markDone(c: Context, id: Long) = prefs(c).edit().putStringSet("done", done(c).apply { add("$id") }).apply()
    fun isDone(c: Context, id: Long) = "$id" in done(c)

    /** Reads the SMS inbox for bank messages not yet logged. Requires the SMS read permission. */
    fun scan(c: Context, days: Int = 30): List<BankTxn> {
        val since = System.currentTimeMillis() - days * 86_400_000L
        val out = mutableListOf<BankTxn>()
        runCatching {
            c.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("_id", "body", "date"),
                "date >= ?", arrayOf("$since"), "date DESC")?.use { cur ->
                while (cur.moveToNext() && out.size < 200) {
                    val id = cur.getLong(0)
                    if (isDone(c, id)) continue
                    parse(cur.getString(1).orEmpty(), cur.getLong(2), id)?.let { out += it }
                }
            }
        }
        return out
    }

    suspend fun log(container: AppContainer, c: Context, t: BankTxn) {
        container.financeRepository.addOn(t.date, t.amount, t.kind, category(t.merchant), t.merchant)
        markDone(c, t.id)
    }
}
