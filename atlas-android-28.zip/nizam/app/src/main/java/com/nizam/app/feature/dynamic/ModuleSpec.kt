package com.nizam.app.feature.dynamic

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import com.nizam.app.core.today
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

/**
 * A module defined as data rather than code. The generic engine renders any spec, so new modules
 * can be added at runtime — by the user or by the curator agent — with no rebuild.
 */
@Entity(tableName = "module_spec")
data class ModuleSpec(
    @PrimaryKey val key: String,
    val name: String,
    val emoji: String,
    val tagline: String,
    val colorHex: String,
    val fieldsJson: String,
    val listStyle: String = "CARD",     // CARD | ROW | GRID
    val builtIn: Boolean = false,
    val enabled: Boolean = true,
    val sortIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    val fields: List<SpecField>
        get() = runCatching {
            val array = JSONArray(fieldsJson)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                SpecField(
                    key = o.optString("key"),
                    label = o.optString("label"),
                    type = o.optString("type", "TEXT"),
                    options = o.optJSONArray("options")?.let { opts ->
                        (0 until opts.length()).map { opts.optString(it) }
                    } ?: emptyList(),
                    suffix = o.optString("suffix"),
                    formula = o.optString("formula")
                )
            }.filter { it.key.isNotBlank() }
        }.getOrElse { emptyList() }
}

data class SpecField(
    val key: String,
    val label: String,
    val type: String,              // TEXT | LONGTEXT | NUMBER | RATING | CHOICE | DATE | BOOL | FILE | COMPUTED
    val options: List<String> = emptyList(),
    val suffix: String = "",
    /** For COMPUTED fields: an expression over the other field keys, e.g. "cost / distance". */
    val formula: String = ""
)

/** One record inside a dynamic module. Values are a flat JSON object keyed by field key. */
@Entity(tableName = "module_entry")
data class ModuleEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val moduleKey: String,
    val localDate: String = today(),
    val title: String = "",
    val valuesJson: String = "{}",
    val done: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun value(key: String): String = runCatching {
        JSONObject(valuesJson).optString(key, "")
    }.getOrElse { "" }

    /** Field values that parse as numbers, keyed for formula evaluation. */
    fun numericValues(spec: ModuleSpec): Map<String, Double> =
        spec.fields.mapNotNull { field ->
            value(field.key).toDoubleOrNull()?.let { field.key to it }
        }.toMap()

    fun values(): Map<String, String> = runCatching {
        val o = JSONObject(valuesJson)
        o.keys().asSequence().associateWith { o.optString(it, "") }
    }.getOrElse { emptyMap() }
}

@Dao
interface DynamicDao {
    @Query("SELECT * FROM module_spec WHERE enabled = 1 ORDER BY sortIndex ASC, createdAt ASC")
    fun observeSpecs(): Flow<List<ModuleSpec>>

    @Query("SELECT * FROM module_spec ORDER BY sortIndex ASC")
    fun observeAllSpecs(): Flow<List<ModuleSpec>>

    @Query("SELECT * FROM module_spec WHERE key = :key")
    suspend fun spec(key: String): ModuleSpec?

    @Query("SELECT COUNT(*) FROM module_spec")
    suspend fun specCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpecs(specs: List<ModuleSpec>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpec(spec: ModuleSpec)

    @Update
    suspend fun updateSpec(spec: ModuleSpec)

    @Query("SELECT * FROM module_entry WHERE moduleKey = :key ORDER BY createdAt DESC LIMIT 300")
    fun observeEntries(key: String): Flow<List<ModuleEntry>>

    @Query("SELECT * FROM module_entry ORDER BY createdAt DESC LIMIT 200")
    fun observeRecentEntries(): Flow<List<ModuleEntry>>

    @Query("SELECT COUNT(*) FROM module_entry WHERE moduleKey = :key")
    suspend fun countFor(key: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: ModuleEntry)

    @Update
    suspend fun updateEntry(entry: ModuleEntry)

    @Query("DELETE FROM module_entry WHERE id = :id")
    suspend fun deleteEntry(id: Long)

    @Query("DELETE FROM module_entry WHERE moduleKey = :key")
    suspend fun deleteEntriesFor(key: String)

    @Query("DELETE FROM module_spec WHERE key = :key")
    suspend fun deleteSpec(key: String)

    @Update
    suspend fun updateEntryRow(entry: ModuleEntry)
}
