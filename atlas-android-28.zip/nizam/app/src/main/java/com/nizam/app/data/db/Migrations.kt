package com.nizam.app.data.db

import androidx.room.migration.Migration

/**
 * Every schema change from v7 onward MUST add a Migration here, in the same build that bumps the
 * version. There is no destructive fallback any more — a missing migration crashes loudly on
 * launch rather than silently deleting your history. That is the point.
 *
 *   val MIGRATION_7_8 = object : Migration(7, 8) {
 *       override fun migrate(db: SupportSQLiteDatabase) {
 *           db.execSQL("CREATE TABLE IF NOT EXISTS `x` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ...)")
 *       }
 *   }
 */
/** v8: books remember their cover image. */
val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `book` ADD COLUMN `coverUrl` TEXT NOT NULL DEFAULT ''")
    }
}

val MIGRATIONS: Array<Migration> = arrayOf(MIGRATION_7_8)
