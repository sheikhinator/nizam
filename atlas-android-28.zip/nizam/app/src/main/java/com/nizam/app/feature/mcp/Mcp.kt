package com.nizam.app.feature.mcp

import android.content.Context
import com.nizam.app.net.Http
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Model Context Protocol client. MCP servers speak JSON-RPC 2.0 over HTTP: you initialize, they hand
 * back a session id, then you list tools and call them. Responses come back either as plain JSON or
 * as an SSE stream, so both are handled.
 *
 * Any MCP server you point Atlas at becomes usable in the Playground AND callable by the Curator —
 * which is what makes this open-ended rather than a fixed list of integrations.
 */
data class McpServer(val name: String, val url: String, val token: String, val enabled: Boolean)
data class McpTool(val server: String, val name: String, val description: String, val schema: JSONObject?)

object Mcp {
    private val sessions = HashMap<String, String>()          // server url -> session id
    private val toolCache = HashMap<String, List<McpTool>>()

    private fun f(c: Context) = File(c.filesDir, "mcp.json")

    fun servers(c: Context): List<McpServer> = runCatching { JSONArray(f(c).readText()) }.getOrElse { JSONArray() }
        .let { a -> (0 until a.length()).map { a.getJSONObject(it) }.map {
            McpServer(it.optString("name"), it.optString("url"), it.optString("token"), it.optBoolean("enabled", true)) } }

    fun save(c: Context, list: List<McpServer>) = f(c).writeText(JSONArray().apply {
        list.forEach { put(JSONObject().put("name", it.name).put("url", it.url).put("token", it.token).put("enabled", it.enabled)) }
    }.toString())

    /** MCP replies can be SSE; the payload is the last `data:` line. */
    private fun payload(raw: String): JSONObject {
        val body = if (raw.contains("data:")) raw.lines().filter { it.startsWith("data:") }
            .joinToString("\n") { it.removePrefix("data:").trim() }.trim().lines().last() else raw.trim()
        return JSONObject(body)
    }

    private suspend fun rpc(server: McpServer, method: String, params: JSONObject?, id: Int = 1): JSONObject {
        val req = JSONObject().put("jsonrpc", "2.0").put("id", id).put("method", method)
        if (params != null) req.put("params", params)
        val headers = buildMap {
            put("Content-Type", "application/json")
            put("Accept", "application/json, text/event-stream")
            if (server.token.isNotBlank()) put("Authorization", "Bearer ${server.token}")
            sessions[server.url]?.let { put("Mcp-Session-Id", it) }
        }
        val raw = Http.postJsonWithHeaders(server.url, req.toString(), headers) { name, value ->
            if (name.equals("Mcp-Session-Id", true)) sessions[server.url] = value        // keep the session alive
        }
        val o = payload(raw)
        o.optJSONObject("error")?.let { throw IllegalStateException(it.optString("message", "MCP error ${it.optInt("code")}")) }
        return o.optJSONObject("result") ?: JSONObject()
    }

    /** Handshake. Must happen before anything else, and returns the server's own name and version. */
    suspend fun connect(server: McpServer): String {
        sessions.remove(server.url)
        val result = rpc(server, "initialize", JSONObject()
            .put("protocolVersion", "2025-06-18")
            .put("capabilities", JSONObject())
            .put("clientInfo", JSONObject().put("name", "Atlas").put("version", "1.0")))
        runCatching { rpc(server, "notifications/initialized", null, id = 0) }    // best-effort; some servers require it
        val info = result.optJSONObject("serverInfo")
        return listOfNotNull(info?.optString("name"), info?.optString("version")).filter { it.isNotBlank() }.joinToString(" ")
            .ifBlank { "connected" }
    }

    suspend fun tools(server: McpServer, refresh: Boolean = false): List<McpTool> {
        if (!refresh) toolCache[server.url]?.let { return it }
        if (sessions[server.url] == null) connect(server)
        val arr = rpc(server, "tools/list", JSONObject(), id = 2).optJSONArray("tools") ?: JSONArray()
        val list = (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            McpTool(server.name, it.optString("name"), it.optString("description"), it.optJSONObject("inputSchema"))
        }
        toolCache[server.url] = list
        return list
    }

    /** Calls a tool and flattens the response into text Atlas (and the AI) can use. */
    suspend fun call(server: McpServer, tool: String, args: JSONObject): String {
        if (sessions[server.url] == null) connect(server)
        val result = rpc(server, "tools/call", JSONObject().put("name", tool).put("arguments", args), id = 3)
        if (result.optBoolean("isError")) throw IllegalStateException(text(result).ifBlank { "the tool reported an error" })
        return text(result)
    }

    private fun text(result: JSONObject): String {
        val content = result.optJSONArray("content") ?: return result.toString().take(4000)
        return (0 until content.length()).map { content.getJSONObject(it) }.joinToString("\n") { c ->
            when (c.optString("type")) {
                "text" -> c.optString("text")
                "resource" -> c.optJSONObject("resource")?.optString("text").orEmpty()
                else -> "[${c.optString("type")}]"
            }
        }.trim().take(6000)
    }

    /** Every tool the AI is allowed to reach, across all enabled servers. */
    suspend fun allTools(c: Context): List<McpTool> = servers(c).filter { it.enabled }
        .flatMap { runCatching { tools(it) }.getOrElse { emptyList() } }

    suspend fun findAndCall(c: Context, toolName: String, args: JSONObject): String {
        for (s in servers(c).filter { it.enabled }) {
            val match = runCatching { tools(s) }.getOrElse { emptyList() }.firstOrNull { it.name == toolName }
            if (match != null) return call(s, toolName, args)
        }
        throw IllegalStateException("No connected MCP server offers a tool called \"$toolName\"")
    }
}
