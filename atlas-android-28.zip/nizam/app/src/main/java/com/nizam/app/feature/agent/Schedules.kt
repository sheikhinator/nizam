package com.nizam.app.feature.agent

import android.content.Context
import com.nizam.app.AppContainer
import com.nizam.app.feature.notify.Notifications
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

/**
 * Standing jobs the agent runs on its own: scheduled tasks ("every Sunday, review my spending") and
 * watchers ("tell me if the dollar passes 290"). A watcher only interrupts you when its answer changes.
 */
data class AgentJob(
    val id: Long, val kind: String, val prompt: String, val cadence: String, val hour: Int,
    val lastRun: String = "", val lastResult: String = ""
)

object Schedules {
    private fun f(c: Context) = File(c.filesDir, "schedules.json")
    fun all(c: Context): List<AgentJob> = runCatching { JSONArray(f(c).readText()) }.getOrElse { JSONArray() }.let { a ->
        (0 until a.length()).map { a.getJSONObject(it) }.map {
            AgentJob(it.optLong("id"), it.optString("kind"), it.optString("prompt"), it.optString("cadence"),
                it.optInt("hour"), it.optString("lastRun"), it.optString("lastResult"))
        }
    }
    fun save(c: Context, list: List<AgentJob>) = f(c).writeText(JSONArray().apply {
        list.forEach { put(JSONObject().put("id", it.id).put("kind", it.kind).put("prompt", it.prompt)
            .put("cadence", it.cadence).put("hour", it.hour).put("lastRun", it.lastRun).put("lastResult", it.lastResult)) }
    }.toString())

    private fun due(job: AgentJob, now: Double): Boolean {
        val today = LocalDate.now()
        if (job.lastRun == today.toString() && job.cadence != "hourly") return false
        return when (job.cadence) {
            "hourly" -> true
            "daily" -> now >= job.hour && now < job.hour + 0.25
            "weekly" -> today.dayOfWeek == java.time.DayOfWeek.SUNDAY && now >= job.hour && now < job.hour + 0.25
            else -> false
        }
    }

    /** Called by the background worker. Runs what's due and notifies only when there's something to say. */
    suspend fun runDue(c: Context, container: AppContainer, now: Double) {
        val jobs = all(c)
        if (jobs.isEmpty()) return
        var changed = false
        val updated = jobs.map { job ->
            if (!due(job, now)) return@map job
            val result = runCatching {
                if (job.kind == "watcher") {
                    val answer = com.nizam.app.net.Ai.generate(container.settingsRepository,
                        "Check this and answer in one short line, starting with YES: or NO: — YES only if the thing has happened.\n\n${job.prompt}",
                        system = "You check a condition using current information and answer tersely.",
                        maxOutputTokens = 300, useWeb = true)
                    if (answer.trim().startsWith("YES", true) && answer.trim() != job.lastResult) {
                        Notifications.post(c, Notifications.CHANNEL_NUDGE, (250 + job.id % 20).toInt(), "👁 ${job.prompt.take(40)}", answer.take(300))
                    }
                    answer.take(300)
                } else {
                    val out = container.agentLoop.run(job.prompt, useWeb = true, autoApprove = true)
                    Notifications.post(c, Notifications.CHANNEL_NUDGE, (250 + job.id % 20).toInt(), "✦ ${job.prompt.take(40)}", out.reply.take(400))
                    out.reply.take(400)
                }
            }.getOrElse { "Failed: ${com.nizam.app.ui.components.Feedback.friendly(it)}" }
            changed = true
            job.copy(lastRun = LocalDate.now().toString(), lastResult = result)
        }
        if (changed) save(c, updated)
    }
}
