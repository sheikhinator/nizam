package com.nizam.app.feature.work

import android.app.Activity
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nizam.app.AppContainer
import com.nizam.app.core.ModuleTitle
import com.nizam.app.net.Ai
import com.nizam.app.ui.components.Feedback
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.LocalDate

/** Speak or paste a meeting, get decisions and action items — your actions land in Tasks. */
@Composable
fun MeetingScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    var transcript by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var output by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK)
            r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
                transcript = (transcript + " " + it).trim()
            }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        ModuleTitle("Meeting notes", "Capture it, get decisions and actions")
        OutlinedTextField(title, { title = it }, singleLine = true, label = { Text("What meeting?") }, modifier = Modifier.fillMaxWidth())
        Row(Modifier.padding(vertical = 8.dp)) {
            Button(onClick = { mic.launch(com.nizam.app.feature.voice.speechIntent()) }) { Text("🎙 Capture") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { transcript = "" }) { Text("Clear") }
        }
        OutlinedTextField(transcript, { transcript = it }, label = { Text("Transcript — speak in chunks or paste") },
            modifier = Modifier.fillMaxWidth().height(200.dp))
        Button(enabled = transcript.length > 40 && !busy, onClick = {
            scope.launch {
                busy = true; Feedback.show("Working through the meeting…")
                runCatching {
                    val raw = Ai.generate(container.settingsRepository,
                        "Meeting: ${title.ifBlank { "untitled" }}\nTranscript:\n${transcript.take(14000)}\n\n" +
                            "Return ONLY JSON {\"summary\":\"3 sentences\",\"decisions\":[\"...\"],\"actions\":[{\"what\":\"...\",\"who\":\"...\"}],\"risks\":[\"...\"]}",
                        maxOutputTokens = 1600)
                    val o = JSONObject(Ai.cleanJson(raw))
                    val actions = o.optJSONArray("actions")
                    var added = 0
                    if (actions != null) for (i in 0 until actions.length()) {
                        val a = actions.getJSONObject(i)
                        val who = a.optString("who")
                        if (who.isBlank() || who.equals("me", true) || who.equals("I", true)) {
                            container.taskRepository.add("📋 " + a.optString("what"), null, 1); added++
                        }
                    }
                    val text = buildString {
                        appendLine(o.optString("summary")); appendLine()
                        o.optJSONArray("decisions")?.let { d -> if (d.length() > 0) { appendLine("DECISIONS")
                            for (i in 0 until d.length()) appendLine("· ${d.optString(i)}"); appendLine() } }
                        actions?.let { a -> if (a.length() > 0) { appendLine("ACTIONS")
                            for (i in 0 until a.length()) a.getJSONObject(i).let { appendLine("· ${it.optString("what")} — ${it.optString("who").ifBlank { "unassigned" }}") }
                            appendLine() } }
                        o.optJSONArray("risks")?.let { r -> if (r.length() > 0) { appendLine("RISKS")
                            for (i in 0 until r.length()) appendLine("· ${r.optString(i)}") } }
                    }
                    container.noteRepository.createFull("Meeting: ${title.ifBlank { LocalDate.now().toString() }}", text + "\n\n---\n" + transcript)
                    output = text
                    Feedback.show("Saved to Notes · $added tasks added")
                }.onFailure { Feedback.failed("Meeting notes", it) }
                busy = false
            }
        }) { Text(if (busy) "Working…" else "Extract decisions & actions") }
        output?.let {
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                Text(it, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(60.dp))
    }
}
