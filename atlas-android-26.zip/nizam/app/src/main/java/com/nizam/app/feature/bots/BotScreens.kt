package com.nizam.app.feature.bots

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.AppContainer
import com.nizam.app.feature.council.TypingDots
import com.nizam.app.ui.components.Feedback
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

object BotNav { var openId: Long = 0 }

private val PRESETS = listOf(
    Triple("🧭", "Work", "You handle this person's job: planning, drafts, decisions and follow-ups at work."),
    Triple("💰", "Money", "You handle money: spending, budgets, savings and anything financial."),
    Triple("📚", "Study", "You are a patient tutor for whatever they're learning right now."),
    Triple("🛠", "Project", "You are working with them on one specific project, start to finish.")
)

/** The bot list: one row per thread, most recent first. */
@Composable
fun BotsScreen(onOpen: (Long) -> Unit) {
    val c = LocalContext.current
    var bots by remember { mutableStateOf(Bots.all(c)) }
    var adding by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var brief by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 26.dp)) {
                Text("Bots", fontSize = 34.sp, style = MaterialTheme.typography.displaySmall)
                Text("Each one is a thread that remembers — you return to it, you don't restart it",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(14.dp))
                Text(if (adding) "cancel" else "+ new bot", color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable(role = Role.Button) { adding = !adding }.padding(vertical = 8.dp))
                if (adding) {
                    OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") },
                        modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(brief, { brief = it }, label = { Text("What is it for?") },
                        modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                        PRESETS.forEach { (emoji, preset, text) ->
                            Text("$emoji $preset", color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.clickable(role = Role.Button) { name = preset; brief = text }.padding(6.dp))
                        }
                    }
                    Button(enabled = name.isNotBlank(), onClick = {
                        bots = bots + Bot(System.currentTimeMillis(), name.trim(),
                            brief.trim().ifBlank { "A general assistant for ${name.trim()}." }, "✦", System.currentTimeMillis())
                        Bots.save(c, bots); bots = Bots.all(c); name = ""; brief = ""; adding = false
                        Feedback.show("Bot created")
                    }) { Text("Create") }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        items(bots) { bot ->
            val last = Bots.turns(c, bot.id).lastOrNull()
            Column(Modifier.fillMaxWidth().clickable(role = Role.Button) { onOpen(bot.id) }) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f), CircleShape),
                        contentAlignment = Alignment.Center) { Text(bot.emoji) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(bot.name, fontSize = 17.sp)
                        Text(last?.text?.take(60) ?: bot.brief.take(60), maxLines = 1,
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    last?.let {
                        Text(Instant.ofEpochMilli(it.at).atZone(ZoneId.systemDefault()).toLocalDate().toString().takeLast(5),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            }
        }
        if (bots.isEmpty()) item {
            Text("No bots yet. Create one for work, money, study or a project.",
                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(20.dp))
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

/** One bot, one thread. It has Atlas's full toolset, including your connected MCP servers. */
@Composable
fun BotThreadScreen(container: AppContainer) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val bot = remember { Bots.all(c).firstOrNull { it.id == BotNav.openId } }
    var turns by remember { mutableStateOf(bot?.let { Bots.turns(c, it.id) } ?: emptyList()) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    LaunchedEffect(turns.size) { if (turns.isNotEmpty()) listState.animateScrollToItem(turns.size - 1) }
    if (bot == null) { Text("Bot not found", Modifier.padding(20.dp)); return }

    fun send() {
        val text = draft.trim(); if (text.isBlank() || busy) return
        draft = ""
        Bots.addTurn(c, bot.id, true, text); turns = Bots.turns(c, bot.id)
        scope.launch {
            busy = true
            val reply = runCatching {
                container.agentLoop.run(Bots.contextFor(c, bot) + "\n\nThem: $text", useWeb = false, autoApprove = true).reply
            }.getOrElse { "Couldn't answer: ${Feedback.friendly(it)}" }
            Bots.addTurn(c, bot.id, false, reply); turns = Bots.turns(c, bot.id)
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${bot.emoji}  ${bot.name}", fontSize = 20.sp)
                Text(bot.brief, maxLines = 1, style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("clear", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.clickable(role = Role.Button) { Bots.clear(c, bot.id); turns = emptyList() }.padding(8.dp))
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), state = listState) {
            items(turns) { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    horizontalArrangement = if (t.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (t.fromUser) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                        else MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) { Text(t.text, Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium) }
                }
            }
            if (busy) item { Box(Modifier.padding(12.dp)) { TypingDots(MaterialTheme.colorScheme.primary) } }
            item { Spacer(Modifier.height(8.dp)) }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(draft, { draft = it }, modifier = Modifier.weight(1f),
                label = { Text(if (busy) "Working…" else "Message ${bot.name}") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !busy) { Text("Send") }
        }
    }
}
