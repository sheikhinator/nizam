package com.nizam.app.feature.icon

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * Launcher icon variants, the way Telegram and Meta's apps do it: one activity-alias per look, and
 * exactly one enabled at a time. The shape never changes — only its colour.
 *
 * Android removes and re-adds the launcher entry when this switches, so the icon can take a few
 * seconds to update, and some launchers need a moment or a restart.
 */
data class IconVariant(val key: String, val name: String, val ink: Long, val background: Long)

object AppIcons {
    val VARIANTS = listOf(
        IconVariant("default", "Original", 0xFFE0603A, 0xFF0B0F1A),
        IconVariant("gold", "Gold", 0xFFD4A24C, 0xFF141008),
        IconVariant("crimson", "Crimson", 0xFFD7263D, 0xFF12060A),
        IconVariant("mono", "Monochrome", 0xFFEDEFF5, 0xFF0B0F1A),
        IconVariant("emerald", "Emerald", 0xFF4FC3A1, 0xFF06140F),
        IconVariant("ivory", "Ivory", 0xFF1A1814, 0xFFF3EEE2),
        IconVariant("violet", "Violet", 0xFF9B8CD6, 0xFF0E0A18)
    )

    private fun alias(c: Context, key: String) =
        if (key == "default") ComponentName(c, "com.nizam.app.MainActivity")
        else ComponentName(c, "com.nizam.app.IconAlias" + key.replaceFirstChar { it.uppercase() })

    fun current(c: Context) = c.getSharedPreferences("icon", 0).getString("variant", "default")!!

    /** Enables the chosen alias and disables the rest — leaving none enabled would hide Atlas entirely. */
    fun apply(c: Context, key: String): Boolean {
        val chosen = VARIANTS.firstOrNull { it.key == key } ?: return false
        val pm = c.packageManager
        runCatching {
            pm.setComponentEnabledSetting(alias(c, chosen.key),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            VARIANTS.filter { it.key != chosen.key }.forEach {
                pm.setComponentEnabledSetting(alias(c, it.key),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        }.onFailure { return false }
        c.getSharedPreferences("icon", 0).edit().putString("variant", chosen.key).apply()
        return true
    }

    /** Matches a spoken description to a variant: "make the icon gold", "red and black". */
    fun match(text: String): IconVariant? {
        val t = text.lowercase()
        return VARIANTS.firstOrNull { t.contains(it.key) || t.contains(it.name.lowercase()) }
            ?: when {
                t.contains("red") || t.contains("blood") -> VARIANTS.first { it.key == "crimson" }
                t.contains("black") && t.contains("white") -> VARIANTS.first { it.key == "mono" }
                t.contains("green") -> VARIANTS.first { it.key == "emerald" }
                t.contains("purple") -> VARIANTS.first { it.key == "violet" }
                t.contains("white") || t.contains("light") || t.contains("cream") -> VARIANTS.first { it.key == "ivory" }
                t.contains("yellow") || t.contains("amber") -> VARIANTS.first { it.key == "gold" }
                t.contains("original") || t.contains("reset") -> VARIANTS.first { it.key == "default" }
                else -> null
            }
    }
}
