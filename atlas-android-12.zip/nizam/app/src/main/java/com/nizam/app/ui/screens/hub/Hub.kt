package com.nizam.app.ui.screens.hub

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizam.app.ui.nav.Routes

/**
 * Wire-style lists: no cards, no shadows, no borders. Just generous space, a hairline between rows,
 * and one accent colour. Everything in Atlas that used to be a grid of boxes reads like this now.
 */
data class HubRow(val label: String, val detail: String, val route: String)
data class HubSection(val title: String, val rows: List<HubRow>)

@Composable
fun HubScreen(title: String, subtitle: String, sections: List<HubSection>, onOpen: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 18.dp)) {
                Text(title, fontSize = 34.sp, style = MaterialTheme.typography.displaySmall)
                if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            }
        }
        sections.forEach { section ->
            if (section.title.isNotBlank()) item {
                Text(section.title.uppercase(), style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 20.dp, top = 26.dp, bottom = 10.dp))
            }
            items(section.rows) { row ->
                Column(Modifier.fillMaxWidth().clickable(role = Role.Button) { onOpen(row.route) }) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(row.label, fontSize = 17.sp, style = MaterialTheme.typography.bodyLarge)
                            if (row.detail.isNotBlank()) Text(row.detail, style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
                }
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

// ── The four hubs of Me, and the Atlas tab ──────────────────────────────────

@Composable
fun AtlasHub(onOpen: (String) -> Unit) = HubScreen("Atlas", "Everything that acts for you", listOf(
    HubSection("", listOf(
        HubRow("Chat", "Ask, log, search, act", Routes.ASSISTANT),
        HubRow("Council", "Six advisors when a decision deserves debate", Routes.COUNCIL),
        HubRow("Agents", "Delegate a goal; they work it daily", Routes.WORKFORCE)
    )),
    HubSection("Automatic", listOf(
        HubRow("Automations", "Rules, schedules, watchers", Routes.SCHEDULES),
        HubRow("Rules", "If this, then that", Routes.RULES),
        HubRow("Connections", "MCP servers and their tools", Routes.PLAYGROUND)
    )),
    HubSection("Behaviour", listOf(
        HubRow("Presence", "Autonomy, intentions, interruptions, what it knows", Routes.PRESENCE)
    ))
), onOpen)

@Composable
fun UnderstandHub(onOpen: (String) -> Unit) = HubScreen("Understand", "What the evidence says", listOf(
    HubSection("", listOf(
        HubRow("Patterns and charts", "Correlations, experiments, the year", Routes.UNDERSTAND),
        HubRow("Mirror", "Compounding, integrity, excuses, regret", Routes.MIRROR),
        HubRow("Lab", "Courses, consequences, versions, bets", Routes.LAB),
        HubRow("Mind", "Charts on demand, life wheel, values, ideas", Routes.MIND)
    ))
), onOpen)

@Composable
fun StoryHub(onOpen: (String) -> Unit) = HubScreen("Story", "The record of your days", listOf(
    HubSection("", listOf(
        HubRow("Memory", "Read later, letters, recap, photos", Routes.MEMORY),
        HubRow("Reflect", "Wrapped, newspaper, life in weeks, dreams", Routes.REFLECT),
        HubRow("Studio", "Your book, legacy, drafts, triage", Routes.STUDIO),
        HubRow("Second brain", "Search everything you've saved", Routes.BRAIN),
        HubRow("Day", "Any single day, in full", Routes.DAY)
    ))
), onOpen)

@Composable
fun GrowHub(onOpen: (String) -> Unit) = HubScreen("Grow", "Missions, streaks and commitments", listOf(
    HubSection("", listOf(
        HubRow("Missions", "Today's, and your goals", Routes.MISSIONS),
        HubRow("Growth", "Challenges, stacks, badges, streak freezes", Routes.GROWTH),
        HubRow("Commit", "48-hour cart, stakes, soundscapes", Routes.COMMIT),
        HubRow("Progress", "Level, XP and history", Routes.SELF)
    ))
), onOpen)

@Composable
fun WellbeingHub(onOpen: (String) -> Unit) = HubScreen("Wellbeing", "Attention, rest and your own head", listOf(
    HubSection("", listOf(
        HubRow("Focus", "Sessions, flip-to-focus, soundscapes", Routes.FLIP),
        HubRow("Pause and screen fade", "Before the feeds, and gentle mode", Routes.PAUSE),
        HubRow("Attention", "Digest, smart replies, wind-down", Routes.ATTENTION),
        HubRow("Calm", "Breathing you can feel", Routes.CALM),
        HubRow("Smart wake", "Woken in light sleep", Routes.WAKE),
        HubRow("Bedside", "A dim clock for the night", Routes.BEDSIDE)
    )),
    HubSection("Your head", listOf(
        HubRow("Future You", "Talk to yourself in five years", Routes.FUTURE),
        HubRow("Thought reframe", "Catch it, check it, rewrite it", Routes.REFRAME),
        HubRow("Night companion", "Set the day down", Routes.NIGHT),
        HubRow("Voice", "Bubble, driving, journal, coach", Routes.VOICE)
    ))
), onOpen)
